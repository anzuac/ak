
(function(w){
  "use strict";

  var EVENT_CHANCE = 0.05;
  var MAX_ACTIVE_EVENTS = 1;

  var LEVELS = [
    {
      id: "weak",
      label: "弱",
      chance: 0.45,
      days: [3, 7],
      cooldown: [18, 32],
      power: 0.45,
      targetCount: [1, 1],
      reveal: "vague"
    },
    {
      id: "medium",
      label: "中",
      chance: 0.35,
      days: [6, 12],
      cooldown: [24, 42],
      power: 0.75,
      targetCount: [1, 2],
      reveal: "partial"
    },
    {
      id: "strong",
      label: "強",
      chance: 0.15,
      days: [10, 20],
      cooldown: [34, 58],
      power: 1.08,
      targetCount: [2, 3],
      reveal: "clear"
    },
    {
      id: "extreme",
      label: "特強",
      chance: 0.05,
      days: [18, 35],
      cooldown: [50, 85],
      power: 1.45,
      targetCount: [2, 4],
      reveal: "critical"
    }
  ];

  var FORCES = [
    {
      id: "abyss_capital",
      name: "深淵資本",
      tone: "黑市投機",
      modes: ["pump", "short", "etf_snipe"],
      industries: ["黑市密貿", "王國軍工", "鍊金工坊", "古代遺跡"]
    },
    {
      id: "free_city_fund",
      name: "自由城邦基金",
      tone: "跨國套利",
      modes: ["pump", "accumulate"],
      industries: ["天空航路", "魔晶能源", "金契商會", "皇家建設"]
    },
    {
      id: "sanctuary_fund",
      name: "聖堂基金",
      tone: "穩定布局",
      modes: ["accumulate"],
      industries: ["聖療教院", "糧食聯盟", "皇家建設", "魔晶能源"]
    },
    {
      id: "obsidian_short",
      name: "黑曜空頭團",
      tone: "做空狙擊",
      modes: ["short"],
      industries: ["天空航路", "黑市密貿", "冒險公會", "古代遺跡"]
    }
  ];

  function num(v, fallback){
    var n = Number(v);
    return isFinite(n) ? n : Number(fallback || 0);
  }

  function rand(min, max){
    return min + Math.random() * (max - min);
  }

  function randInt(min, max){
    return Math.floor(rand(min, max + 1));
  }

  function pick(arr){
    if(!arr || !arr.length) return null;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function ensure(state){
    if(!state) return null;

    if(!state.foreignCapitalAI || typeof state.foreignCapitalAI !== "object"){
      state.foreignCapitalAI = {};
    }

    var ai = state.foreignCapitalAI;

    if(!Array.isArray(ai.activeEvents)){
      ai.activeEvents = [];
    }

    if(!Array.isArray(ai.history)){
      ai.history = [];
    }

    if(!(num(ai.cooldownProgress, 0) >= 0)){
      ai.cooldownProgress = 100;
    }

    if(!(num(ai.cooldownDaysLeft, 0) >= 0)){
      ai.cooldownDaysLeft = 0;
    }

    if(!ai.lastMarketDay){
      ai.lastMarketDay = 0;
    }

    return ai;
  }

  function getMarketDay(state){
    return Math.max(1, Math.floor(num(state && state.marketDay, 1)));
  }

  function rollLevel(){
    var r = Math.random();
    var acc = 0;
    for(var i=0;i<LEVELS.length;i++){
      acc += LEVELS[i].chance;
      if(r <= acc) return LEVELS[i];
    }
    return LEVELS[0];
  }

  function getSectorName(asset){
    if(!asset) return "";
    var info = asset.companyInfo || {};
    var profile = asset.companyProfile || {};
    return String(
      asset.sectorLabel ||
      asset.industryLabel ||
      info.industryLabel ||
      info.industry ||
      profile.category ||
      asset.sectorCode ||
      ""
    );
  }

  function isValidTarget(asset){
    return !!(
      asset &&
      asset.unlocked &&
      !asset.isDelisted &&
      !asset.delisted &&
      !asset.isRoyalEnterprise &&
      !asset.excludeFromIndex &&
      asset.marketType === "free"
    );
  }

  function getMarketCap(asset){
    var price = Math.max(1, Math.floor(num(asset && asset.price, 1)));
    var eq = (asset && asset.equityConfig) || {};
    var shares = Math.max(
      1,
      Math.floor(
        num(
          asset && (
            asset.totalShares ||
            asset.floatShares ||
            asset.sharesOutstanding ||
            eq.totalShares ||
            eq.publicFloatShares ||
            asset.availableShares
          ),
          1
        )
      )
    );
    return price * shares;
  }

  function getCandidates(state, force, mode){
    var assets = (state && state.assets) || {};
    var list = [];

    Object.keys(assets).forEach(function(id){
      var a = assets[id];
      if(!isValidTarget(a)) return;

      var sector = getSectorName(a);
      var score = Math.sqrt(Math.max(1, getMarketCap(a)));

      for(var i=0;i<force.industries.length;i++){
        if(sector.indexOf(force.industries[i]) >= 0 || String(a.tags || "").indexOf(force.industries[i]) >= 0){
          score *= 1.35;
          break;
        }
      }

      if(mode === "etf_snipe" && w.StockETFSystem && typeof w.StockETFSystem.getSummary === "function"){
        try{
          var s = w.StockETFSystem.getSummary(state);
          if(s && Array.isArray(s.holdings)){
            for(var h=0;h<s.holdings.length;h++){
              if(s.holdings[h].assetId === a.id){
                score *= (1.8 + num(s.holdings[h].weight,0) * 8);
                break;
              }
            }
          }
        }catch(_){}
      }

      list.push({
        asset: a,
        score: score
      });
    });

    list.sort(function(a,b){
      return num(b.score) - num(a.score);
    });

    return list;
  }

  function selectTargets(state, force, mode, level){
    var count = randInt(level.targetCount[0], level.targetCount[1]);
    var list = getCandidates(state, force, mode);
    var result = [];
    var used = {};

    // 從前段候選取樣，避免永遠只打第一名。
    var pool = list.slice(0, Math.min(list.length, 18 + count * 4));

    while(result.length < count && pool.length){
      var idx = Math.floor(Math.random() * pool.length);
      var row = pool.splice(idx, 1)[0];
      if(!row || !row.asset || used[row.asset.id]) continue;
      used[row.asset.id] = true;
      result.push({
        assetId: row.asset.id,
        name: row.asset.name || row.asset.id,
        sector: getSectorName(row.asset)
      });
    }

    return result;
  }

  function makeNewsTitle(force, mode, level){
    if(level.id === "extreme"){
      return "⚠ 世界級資本異動：" + force.name;
    }

    if(level.id === "strong"){
      return "⚠ 已確認外部資本介入：" + force.name;
    }

    if(level.id === "medium"){
      return "📡 疑似境外資金流入";
    }

    return "📡 市場出現異常資金流";
  }

  function modeLabel(mode){
    if(mode === "pump") return "做多拉抬";
    if(mode === "short") return "做空狙擊";
    if(mode === "accumulate") return "長期吸納";
    if(mode === "etf_snipe") return "ETF權重狙擊";
    return "資本操作";
  }

  function pushCapitalNews(type, title, desc, days){
    if(typeof w.pushCapitalNews === "function"){
      w.pushCapitalNews(type, title, desc, days);
    }
  }

  function startEvent(state){
    var ai = ensure(state);
    if(!ai) return null;

    var force = pick(FORCES);
    var mode = pick(force.modes);
    var level = rollLevel();
    var targets = selectTargets(state, force, mode, level);

    if(!targets.length) return null;

    var event = {
      id: "fc_" + Date.now() + "_" + Math.random().toString(36).slice(2),
      forceId: force.id,
      forceName: force.name,
      forceTone: force.tone,
      mode: mode,
      modeLabel: modeLabel(mode),
      level: level.id,
      levelLabel: level.label,
      power: level.power,
      remainingDays: randInt(level.days[0], level.days[1]),
      totalDays: 0,
      cooldownDaysAfter: randInt(level.cooldown[0], level.cooldown[1]),
      targets: targets,
      createdAt: Date.now()
    };

    event.totalDays = event.remainingDays;

    ai.activeEvents.push(event);

    var targetText =
      targets.map(function(t){ return t.name; }).join("、");

    var desc =
      "等級：" + level.label +
      "｜模式：" + modeLabel(mode) +
      "｜目標：" + targetText +
      "｜預估持續 " + event.remainingDays + " 天。";

    pushCapitalNews(
      "capital",
      makeNewsTitle(force, mode, level),
      desc,
      event.remainingDays
    );

    return event;
  }

  function completeEvent(state, ai, event){
    if(!event) return;

    ai.history.unshift({
      forceName: event.forceName,
      modeLabel: event.modeLabel,
      levelLabel: event.levelLabel,
      targets: event.targets,
      endedAtDay: getMarketDay(state),
      ts: Date.now()
    });

    ai.history = ai.history.slice(0, 20);

    ai.cooldownDaysLeft = Math.max(1, Math.floor(num(event.cooldownDaysAfter, 25)));
    ai.cooldownDaysTotal = ai.cooldownDaysLeft;
    ai.cooldownProgress = 0;

    pushCapitalNews(
      "capital",
      "📉 " + event.forceName + " 資本行動暫歇",
      "外部資本操作結束，市場將進入冷卻觀察期。冷卻完成前不會再次發動。",
      3
    );
  }

  function tickDaily(state){
    var ai = ensure(state);
    if(!ai) return;

    var day = getMarketDay(state);
    if(ai.lastMarketDay === day) return;
    ai.lastMarketDay = day;

    // 推進既有事件
    for(var i=ai.activeEvents.length-1;i>=0;i--){
      var e = ai.activeEvents[i];
      e.remainingDays = Math.max(0, Math.floor(num(e.remainingDays, 0) - 1));
      if(e.remainingDays <= 0){
        ai.activeEvents.splice(i,1);
        completeEvent(state, ai, e);
      }
    }

    // 冷卻進度：沒到 100% 不會抽 5%。
    if(ai.cooldownDaysLeft > 0){
      ai.cooldownDaysLeft = Math.max(0, Math.floor(num(ai.cooldownDaysLeft,0) - 1));
      var base = Math.max(1, Math.floor(num(ai.cooldownDaysTotal || ai.cooldownDaysLeft || 1, ai.cooldownDaysLeft || 1)));
      // 若沒有 total，就以剩餘值初始化
      if(!ai.cooldownDaysTotal || ai.cooldownDaysTotal <= 0){
        ai.cooldownDaysTotal = Math.max(1, ai.cooldownDaysLeft + 1);
      }
      ai.cooldownProgress = Math.min(100, Math.floor((1 - ai.cooldownDaysLeft / Math.max(1, ai.cooldownDaysTotal)) * 100));
      if(ai.cooldownDaysLeft <= 0){
        ai.cooldownProgress = 100;
        ai.cooldownDaysTotal = 0;
      }
    }else{
      ai.cooldownProgress = 100;
      ai.cooldownDaysTotal = 0;
    }

    if(ai.activeEvents.length >= MAX_ACTIVE_EVENTS) return;
    if(num(ai.cooldownProgress,0) < 100) return;

    if(Math.random() < EVENT_CHANCE){
      startEvent(state);
    }
  }

  function tick(state){
    var ai = ensure(state);
    if(!ai) return null;
    tickDaily(state);
    return ai;
  }

  function targetMatches(event, asset){
    if(!event || !asset || !Array.isArray(event.targets)) return false;
    for(var i=0;i<event.targets.length;i++){
      if(event.targets[i].assetId === asset.id) return true;
    }
    return false;
  }

  function getEffectForAsset(state, asset){
    var ai = ensure(state);

    var result = {
      buyBoost: 0,
      sellBoost: 0,
      liquidityDrain: 0,
      volatilityBoost: 0,
      drift: 0,
      anchorLift: 0
    };

    if(!ai || !asset || !Array.isArray(ai.activeEvents)) return result;

    for(var i=0;i<ai.activeEvents.length;i++){
      var e = ai.activeEvents[i];
      if(!targetMatches(e, asset)) continue;

      var power = num(e.power, 0.5);

      // 快結束時效果慢慢衰退，避免突然斷崖。
      var remainRatio = Math.max(0.25, num(e.remainingDays,1) / Math.max(1, num(e.totalDays,1)));
      var p = power * remainRatio;

      if(e.mode === "pump" || e.mode === "accumulate" || e.mode === "etf_snipe"){
        result.buyBoost += 0.28 * p;
        result.liquidityDrain += 0.45 * p;
        result.volatilityBoost += 0.25 * p;
        result.drift += 0.0028 * p;
        result.anchorLift += 0.00045 * p;
      }

      if(e.mode === "short"){
        result.sellBoost += 0.32 * p;
        result.liquidityDrain += 0.36 * p;
        result.volatilityBoost += 0.35 * p;
        result.drift -= 0.0032 * p;
      }
    }

    return result;
  }

  function getSummary(state){
    var ai = ensure(state);
    return {
      activeEvents: ai && Array.isArray(ai.activeEvents) ? ai.activeEvents.slice() : [],
      history: ai && Array.isArray(ai.history) ? ai.history.slice() : [],
      cooldownProgress: ai ? num(ai.cooldownProgress, 100) : 100,
      cooldownDaysLeft: ai ? Math.max(0, Math.floor(num(ai.cooldownDaysLeft,0))) : 0
    };
  }

  w.ForeignCapitalAI = {
    tick: tick,
    getEffectForAsset: getEffectForAsset,
    getSummary: getSummary,
    startEvent: startEvent
  };

})(window);
