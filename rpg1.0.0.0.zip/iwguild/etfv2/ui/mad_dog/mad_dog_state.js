// =====================================================
// mad_dog_state.js
// 王國戰略資本：MadDogCore 轉接層
// UI 只讀資料；市場更新由 StockActiveETFSystem.tick 交給中央市場循環。
// =====================================================

(function(w){
  "use strict";

  var ID = "mad_dog_fund";

  function core(){
    return w.MadDogCore || null;
  }

  function fail(reason){
    return {
      ok: false,
      reason: reason || "mad_dog_core_missing"
    };
  }

  function normalizeQty(a,b){
    // 支援兩種呼叫：
    // MadDogETFState.buy(qty)
    // StockActiveETFSystem.buy(state, qty)
    return b == null ? a : b;
  }

  function ensureFund(){
    var c = core();
    if(!c || !c.ensureFund) return null;
    return c.ensureFund(); // 只初始化 / 讀取，不推進市場。
  }

  function tick(){
    var c = core();
    if(!c) return null;

    if(c.tick) return c.tick();
    if(c.dailyUpdate) return c.dailyUpdate();
    return null;
  }

  function getUIData(){
    var c = core();
    if(!c || !c.getUIData) return null;
    return c.getUIData();
  }

  function buy(a,b){
    var c = core();
    if(!c || !c.buy) return fail();
    return c.buy(normalizeQty(a,b));
  }

  function subscribe(a,b){
    var c = core();
    if(!c || !c.subscribe) return fail();
    return c.subscribe(normalizeQty(a,b));
  }

  function sell(a,b){
    var c = core();
    if(!c || !c.sell) return fail();
    return c.sell(normalizeQty(a,b));
  }

  function getScale(){
    var c = core();
    if(c && c.getScale) return c.getScale();
    return 1000;
  }

  w.MadDogETFState = {
    ID: ID,
    ensureFund: ensureFund,
    tick: tick,
    dailyUpdate: tick,
    getUIData: getUIData,
    getSummary: getUIData,
    buy: buy,
    subscribe: subscribe,
    sell: sell,
    getScale: getScale
  };

  // stock_etf_tab.js 與 stock_market_engine.js 會找這個名稱。
  // 這裡只做轉接，不另開第二套核心。
  w.StockActiveETFSystem = {
    ID: ID,
    ensureFund: ensureFund,
    tick: tick,
    dailyUpdate: tick,
    getSummary: getUIData,
    getUIData: getUIData,
    buy: buy,
    subscribe: subscribe,
    sell: sell,
    getScale: getScale
  };

})(window);
