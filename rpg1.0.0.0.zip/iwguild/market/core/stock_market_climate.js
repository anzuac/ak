

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

// stock_market_climate.js
(function(w) {
  "use strict";
  
  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }
  
  function ensureClimate(state) {
    if (!state.climate) {
      state.climate = {
        stability: 60,
        volatilityLevel: 1.0,
        sentiment: 0,
        panic: 0,
        heat: 0
      };
    }
    return state.climate;
  }
  
  function tickClimate(state) {
    var c = ensureClimate(state);
    
    if (c.panic > 0) c.panic = clamp(c.panic - 0.8, 0, 100);
    if (c.heat > 0) c.heat = clamp(c.heat - 0.5, 0, 100);
    
    if (c.sentiment > 0) c.sentiment = clamp(c.sentiment - 1, -100, 100);
    else if (c.sentiment < 0) c.sentiment = clamp(c.sentiment + 1, -100, 100);
    
    if (c.stability < 60) c.stability = clamp(c.stability + 0.4, 0, 100);
    else if (c.stability > 60) c.stability = clamp(c.stability - 0.2, 0, 100);
    
    var baseVol = 1.0 + (c.heat / 200) + (c.panic / 150) - (c.stability - 50) / 200;
    c.volatilityLevel = clamp(baseVol, 0.5, 2.0);
  }
  
  function applyEventImpactToClimate(state, evt) {
    var c = ensureClimate(state);
    if (!evt) return;
    
    var intensity = Math.abs(Number(evt.bias || 0));
    c.heat = clamp(c.heat + intensity * 180, 0, 100);
    
    if (evt.bias > 0) {
      c.sentiment = clamp(c.sentiment + intensity * 120, -100, 100);
    } else if (evt.bias < 0) {
      c.sentiment = clamp(c.sentiment - intensity * 140, -100, 100);
      c.panic = clamp(c.panic + intensity * 150, 0, 100);
    }
    
    c.stability = clamp(c.stability - intensity * 90, 0, 100);
  }
  
  function applyTradeImpactToClimate(state, tradeInfo) {
    var c = ensureClimate(state);
    if (!tradeInfo) return;

    // 玩家單一股票交易不應改變「全市場方向」。
    // 這裡只保留極輕微的市場熱度 / 波動提升，避免強買一檔股票造成全市場漲停。
    var qty = Math.max(1, Number(tradeInfo.qty || 1));
    var score = Math.min(8, Math.log(qty + 1) * 0.35);

    c.heat = clamp(c.heat + score * 0.18, 0, 100);
    c.volatilityLevel = clamp(c.volatilityLevel + score * 0.002, 0.5, 2.0);
  }

  function getVolatilityMultiplier(state) {
    var c = ensureClimate(state);
    return clamp(c.volatilityLevel * (1 + c.panic / 300) * (1 - c.stability / 250), 0.4, 2.5);
  }
  
  function getTrendBias(state) {
    var c = ensureClimate(state);
    return clamp(c.sentiment / 4000, -0.03, 0.03);
  }
  
  w.StockMarketClimate = {
    ensureClimate: ensureClimate,
    tickClimate: tickClimate,
    applyEventImpactToClimate: applyEventImpactToClimate,
    applyTradeImpactToClimate: applyTradeImpactToClimate,
    getVolatilityMultiplier: getVolatilityMultiplier,
    getTrendBias: getTrendBias
  };
})(window);