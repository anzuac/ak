
// =====================================================
// AI5.1.2 UI Tick Sync
//
// Only synchronizes:
// - realtime prices
// - price change display
// - market index updates
//
// Other UI systems remain unchanged.
// =====================================================


(function (w) {
  "use strict";

  if (
    !w.StockHub ||
    !w.StockStateManager ||
    !w.StockMarketEngine ||
    !w.StockMarketCurrency ||
    !w.StockMarketAssets
  ) {
    console.error("❌ stock_exchange_tab.js: 缺少依賴");
    return;
  }

  var SCALE = w.StockMarketEngine.SCALE || 1000;
  var TAB_ID = "exchange";
  var companyDetailAssetId = null;
  var activeCategory = "all";
  var detailHistoryDays = 10;
  var tradeModalState = null;
  var PAGE_SIZE = 10;
  var categoryPageMap = { all: 1, royal: 1, arcane: 1, energy: 1, military: 1, route: 1, livelihood: 1, risk: 1, etf: 1 };
  var SECTOR_CATEGORY_DEFS = [
    { id: "royal", label: "皇權", icon: "👑", codes: [] },
    { id: "arcane", label: "魔導/鍊金", icon: "🔮", codes: ["C", "L"] },
    { id: "energy", label: "魔晶/礦脈", icon: "💎", codes: ["G", "R"] },
    { id: "military", label: "軍工/建設", icon: "⚔️", codes: ["M", "D", "A"] },
    { id: "route", label: "天空航路", icon: "🪽", codes: ["H"] },
    { id: "livelihood", label: "民生/聖療", icon: "🌾", codes: ["F", "E", "B"] },
    { id: "risk", label: "冒險/黑市", icon: "🕶️", codes: ["V", "K", "X"] },
    { id: "etf", label: "ETF", icon: "📦", codes: ["ETF"] }
  ];

  function fmtCoinMilli(v) {
    return (Number(v || 0) / SCALE).toFixed(2);
  }

  function fmtSignedCoinMilli(v) {
    v = Number(v || 0);
    return (v >= 0 ? "+" : "-") + (Math.abs(v) / SCALE).toFixed(2);
  }


  function fmtAiMoodLabel(v) {
    v = String(v || "neutral");
    if (v === "bullish") return "偏多";
    if (v === "bearish") return "偏空";
    if (v === "panic") return "恐慌";
    if (v === "bubble") return "泡沫";
    if (v === "undervalued") return "低估";
    if (v === "overheated") return "過熱";
    return "中性";
  }

  function fmtAiStyleLabel(v) {
    v = String(v || "balanced");
    if (v === "value") return "價值型";
    if (v === "momentum") return "動能型";
    if (v === "contrarian") return "逆勢型";
    if (v === "panic") return "恐慌型";
    if (v === "fund") return "財團型";
    return "均衡型";
  }


  function fmtPct(v) {
    v = Number(v || 0);
    return (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
  }

  function fmtNum(v) {
    return Math.floor(Number(v || 0)).toLocaleString();
  }

  function fmtLots(shares) {
    var toLots = w.StockMarketAssets.toLots || function (n) {
      return Math.floor(Number(n || 0) / 1000);
    };
    return fmtNum(toLots(shares));
  }


  function getLiquidityDisplay(si) {
    var liq = (si && si.liquidityState) || {};
    return {
      icon: liq.icon || "🟢",
      label: liq.label || "正常流通",
      color: liq.color || "#22c55e",
      level: liq.level || "normal"
    };
  }

  function stripZero(text) {
    return String(text).replace(/\.0+$/, "").replace(/(\.\d*[1-9])0+$/, "$1");
  }

  function fmtCompactCoinMilli(v) {
    v = Number(v || 0);
    var coin = v / SCALE;
    var sign = coin < 0 ? "-" : "";
    var abs = Math.abs(coin);

    if (abs >= 1000000000000) return sign + stripZero((abs / 1000000000000).toFixed(2)) + "兆";
    if (abs >= 100000000) return sign + stripZero((abs / 100000000).toFixed(2)) + "億";
    if (abs >= 10000) return sign + stripZero((abs / 10000).toFixed(2)) + "萬";
    return sign + abs.toFixed(2);
  }

  function fmtRemain(sec) {
    sec = Math.max(0, Math.floor(Number(sec || 0)));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return m + "分" + String(s).padStart(2, "0") + "秒";
  }

  function getSignedColor(v) {
    v = Number(v || 0);
    if (v > 0) return "#22c55e";
    if (v < 0) return "#ef4444";
    return "#e5e7eb";
  }

  function getReasonText(reason, side) {
    switch (String(reason || "")) {
      case "market_not_enough_shares": return "市場可交易股數不足";
      case "market_closed": return "目前無法交易";
      case "asset_locked": return "此標的目前無法交易";
      case "holding_not_enough": return "持股數量不足";
      case "market_no_buyers": return "目前市場無人接盤，已可改用集中盤委託等待成交";
      case "pending_order_exists": return "已有同方向委託等待中，請先取消原委託";
      case "pending_order_missing": return "找不到等待中的委託";
      case "bad_order_side": return "委託方向錯誤";
      case "coin_not_enough": return "投資幣不足";
      case "gold_not_enough": return "金幣不足";
      default:
        if (side === "buy") return "買入失敗，請稍後再試";
        if (side === "sell") return "賣出失敗，請稍後再試";
        return "操作失敗，請稍後再試";
    }
  }

  function calcOpenChangePct(asset) {
    if (!asset || !asset.dayOpenPrice) return 0;
    return ((Number(asset.price || 0) - Number(asset.dayOpenPrice || 1)) / Number(asset.dayOpenPrice || 1)) * 100;
  }

  function isDividendDay(state) {
    return !!w.StockMarketEngine.isDividendSettlementDay(state);
  }


  function getSectorDefById(id) {
    id = String(id || "arcane");
    for (var i = 0; i < SECTOR_CATEGORY_DEFS.length; i++) {
      if (SECTOR_CATEGORY_DEFS[i].id === id) return SECTOR_CATEGORY_DEFS[i];
    }
    return SECTOR_CATEGORY_DEFS[0];
  }

  function isRoyalAsset(asset) {
    if (!asset) return false;
    if (asset.isRoyalEnterprise) return true;
    var tier = String(asset.royalTier || "").toLowerCase();
    var cls = String(asset.royalClass || "").toLowerCase();
    var tags = Array.isArray(asset.tags) ? asset.tags : [];
    return tier === "royal" || tier === "imperial" || tier === "crown" ||
      cls === "royal" || cls === "imperial" || cls === "crown" ||
      tags.indexOf("royal") >= 0 || tags.indexOf("state") >= 0 || asset.stateOwned;
  }

  function getAssetSectorCategory(asset) {
    if (!asset) return "arcane";
    if (asset.isETF || String(asset.assetType || "").toLowerCase() === "etf") return "etf";
    var code = String(asset.sectorCode || "X").toUpperCase();
    for (var i = 0; i < SECTOR_CATEGORY_DEFS.length; i++) {
      var def = SECTOR_CATEGORY_DEFS[i];
      if ((def.codes || []).indexOf(code) >= 0) return def.id;
    }
    return "arcane";
  }

  function getTierRank(asset) {
    var cat = getAssetSectorCategory(asset);
    for (var i = 0; i < SECTOR_CATEGORY_DEFS.length; i++) {
      if (SECTOR_CATEGORY_DEFS[i].id === cat) return i + 1;
    }
    return 99;
  }

  function getTierLabel(asset) {
    var def = getSectorDefById(getAssetSectorCategory(asset));
    return def.label;
  }

  function getRiskText(asset) {
    var risk = Number(asset.risk || 1);
    if (risk <= 1) return "低";
    if (risk === 2) return "中";
    if (risk === 3) return "高";
    return "極高";
  }

  function getImpactText(v) {
    v = Number(v || 0);
    if (v >= 0.12) return "極強偏多";
    if (v >= 0.06) return "明顯偏多";
    if (v >= 0.02) return "輕度偏多";
    if (v <= -0.12) return "極強偏空";
    if (v <= -0.06) return "明顯偏空";
    if (v <= -0.02) return "輕度偏空";
    return "中性";
  }

  function getAssetCategory(asset) {
    return getAssetSectorCategory(asset);
  }

  function getAssetList(state) {
    var arr = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;

      var holding = w.StockMarketEngine.getHolding(state, id);
      arr.push({
        asset: asset,
        holding: holding
      });
    }

    arr.sort(function (a, b) {
      if (b.holding.qty !== a.holding.qty) return b.holding.qty - a.holding.qty;
      var ta = getTierRank(a.asset);
      var tb = getTierRank(b.asset);
      if (ta !== tb) return ta - tb;
      return String(a.asset.name || "").localeCompare(String(b.asset.name || ""), "zh-Hant");
    });

    return arr;
  }

  function getGroupedRows(state) {
    var rows = getAssetList(state);
    var out = {};
    for (var d = 0; d < SECTOR_CATEGORY_DEFS.length; d++) out[SECTOR_CATEGORY_DEFS[d].id] = [];
    for (var i = 0; i < rows.length; i++) {
      var asset = rows[i].asset;
      var key = getAssetCategory(asset);
      if (!out[key]) out[key] = [];
      out[key].push(rows[i]);

      // 皇權是「權力階級」不是產業，所以採雙層歸類：
      // 產業分類仍保留原本軍工/建設/黑市等；皇權分類額外收納所有皇家股票。
      if (isRoyalAsset(asset)) {
        if (!out.royal) out.royal = [];
        out.royal.push(rows[i]);
      }
    }
    return out;
  }

  function getExchangeScrollTop() {
    var el = document.getElementById("stockExchangeScroll");
    return el ? el.scrollTop : 0;
  }

  function restoreExchangeScrollTop(top) {
    var el = document.getElementById("stockExchangeScroll");
    if (el) el.scrollTop = Number(top || 0);
  }

  function setText(body, id, text) {
    var el = body.querySelector("#" + id);
    if (el) el.textContent = text;
    return el;
  }

  function getPageForCategory(cat) {
    cat = String(cat || "all");
    if (!categoryPageMap[cat]) categoryPageMap[cat] = 1;
    return Math.max(1, Math.floor(Number(categoryPageMap[cat] || 1)));
  }

  function clampPage(cat, totalItems) {
    cat = String(cat || "all");
    var totalPages = Math.max(1, Math.ceil(Math.max(0, Number(totalItems || 0)) / PAGE_SIZE));
    var page = getPageForCategory(cat);
    if (page > totalPages) page = totalPages;
    categoryPageMap[cat] = page;
    return { page: page, totalPages: totalPages };
  }

  function getPagedRows(rows, cat) {
    var pageInfo = clampPage(cat, rows.length);
    var start = (pageInfo.page - 1) * PAGE_SIZE;
    return { rows: rows.slice(start, start + PAGE_SIZE), page: pageInfo.page, totalPages: pageInfo.totalPages, totalItems: rows.length };
  }

  function renderPagination(cat, pageInfo) {
    if (!pageInfo || pageInfo.totalPages <= 1) return "";
    return (
      "<div style='display:flex;align-items:center;justify-content:center;gap:10px;margin-top:12px;'>" +
        "<button data-ex-page-prev='" + cat + "' style='background:#111827;color:#fff;border:1px solid #334155;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:800;" + (pageInfo.page <= 1 ? "opacity:.5;pointer-events:none;" : "") + "'>上一頁</button>" +
        "<div style='font-size:13px;font-weight:800;color:#cbd5e1;min-width:80px;text-align:center;'>" + pageInfo.page + " / " + pageInfo.totalPages + "</div>" +
        "<button data-ex-page-next='" + cat + "' style='background:#111827;color:#fff;border:1px solid #334155;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:800;" + (pageInfo.page >= pageInfo.totalPages ? "opacity:.5;pointer-events:none;" : "") + "'>下一頁</button>" +
      "</div>"
    );
  }

  function renderMiniStat(id, label, value, color) {
    return (
      "<div style='background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;min-width:0;'>" +
        "<div style='font-size:12px;opacity:.72;white-space:nowrap;'>" + label + "</div>" +
        "<div id='" + id + "' style='font-size:18px;font-weight:900;margin-top:4px;color:" + (color || "#e5e7eb") + ";white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'>" + value + "</div>" +
      "</div>"
    );
  }

  function renderInfoRow(label, valueHtml) {
    return (
      "<div style='display:flex;justify-content:space-between;gap:10px;align-items:center;'>" +
        "<div style='font-size:12px;opacity:.72;white-space:nowrap;'>" + label + "</div>" +
        "<div style='font-size:13px;font-weight:700;text-align:right;'>" + valueHtml + "</div>" +
      "</div>"
    );
  }

  function renderCategoryTabs(state) {
    var groups = getGroupedRows(state);
    var total = getAssetList(state).length;

    var defs = [{ id: "all", label: "全部", icon: "📋", count: total }];
    for (var i = 0; i < SECTOR_CATEGORY_DEFS.length; i++) {
      var base = SECTOR_CATEGORY_DEFS[i];
      var count = (groups[base.id] || []).length;
      if (count <= 0) continue;
      defs.push({ id: base.id, label: base.label, icon: base.icon, count: count });
    }

    if (activeCategory !== "all" && !(groups[activeCategory] || []).length) activeCategory = "all";

    var html = "<div id='exchangeCategoryTabs' style='display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;white-space:nowrap;padding-bottom:4px;margin-bottom:12px;-webkit-overflow-scrolling:touch;scrollbar-width:none;'>";
    for (var j = 0; j < defs.length; j++) {
      var d = defs[j];
      var active = activeCategory === d.id;
      html +=
        "<button data-ex-cat='" + d.id + "' style='" +
          "background:" + (active ? "#2563eb" : "#111827") + ";" +
          "color:#fff;border:1px solid " + (active ? "#3b82f6" : "#334155") + ";" +
          "border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:800;white-space:nowrap;flex:0 0 auto;'>" +
          (d.icon ? d.icon + " " : "") + d.label + " " + d.count +
        "</button>";
    }
    html += "</div>";
    return html;
  }

  function renderSectionTitle(title) {
    return "<div style='font-size:15px;font-weight:900;color:#93c5fd;margin:4px 0 10px;'>" + title + "</div>";
  }

  function getEstimatedDividendPerShare(asset, state) {
    var cm = asset && asset.companyMetrics ? asset.companyMetrics : {};
    var v = Number(cm.estimatedDividendPerShareMilli || 0);
    if (!v && w.StockMarketEngine.getDividendInfo) {
      var info = w.StockMarketEngine.getDividendInfo(state) || {};
      var upcoming = info.upcomingDividends || [];
      for (var i = 0; i < upcoming.length; i++) {
        if (String(upcoming[i].assetId) === String(asset.id)) {
          v = Number(upcoming[i].estimatedDividendPerShareMilli || 0);
          break;
        }
      }
    }
    return v;
  }

  function renderCard(row, state) {
    var asset = row.asset;
    var div = getEstimatedDividendPerShare(asset, state);
    var tier = getTierLabel(asset);

    return (
      "<button data-act='exchange-detail-" + asset.id + "' style='width:100%;text-align:left;background:#111827;border:1px solid #1f2937;border-radius:16px;padding:14px;color:#e5e7eb;cursor:pointer;'>" +
        "<div style='display:flex;justify-content:space-between;gap:12px;align-items:flex-start;'>" +
          "<div style='min-width:0;'>" +
            "<div style='display:flex;align-items:center;gap:8px;flex-wrap:wrap;'>" +
              "<span style='background:#1e293b;color:#93c5fd;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:900;'>" + (asset.symbol || "----") + "</span>" +
              "<span style='font-size:17px;font-weight:900;word-break:break-word;color:" + ((String(asset.royalTier||'').toLowerCase()!=='none' && String(asset.royalTier||'')!=='') ? "#facc15" : "#e5e7eb") + ";'>" + asset.name + "</span>" +
            "</div>" +
            "<div style='font-size:12px;opacity:.7;margin-top:5px;'>" + tier + "｜資本：" + fmtCompactCoinMilli(asset.guildCapitalMilli || (asset.companyInfo && asset.companyInfo.guildCapitalMilli) || 0) + "｜" + (asset.guildCapitalTierLabel || (asset.companyInfo && asset.companyInfo.guildCapitalTierLabel) || "未分級") + "</div>" +
          "</div>" +

        "</div>" +
      "</button>"
    );
  }

  function renderCardsArea(state) {
    var groups = getGroupedRows(state);
    var html = renderCategoryTabs(state);
    var labelMap = { all: "📋 全部股票" };
    for (var lm = 0; lm < SECTOR_CATEGORY_DEFS.length; lm++) {
      labelMap[SECTOR_CATEGORY_DEFS[lm].id] = SECTOR_CATEGORY_DEFS[lm].icon + " " + SECTOR_CATEGORY_DEFS[lm].label;
    }

    var list;
    if (activeCategory === "all") {
      list = getAssetList(state);
    } else {
      list = groups[activeCategory] || [];
    }

    var pageInfo = getPagedRows(list, activeCategory);
    html += renderSectionTitle((labelMap[activeCategory] || "股票") + "｜每頁 " + PAGE_SIZE + " 檔");
    if (!pageInfo.rows.length) {
      html += "<div style='opacity:.75;'>此分類目前沒有股票。</div>";
    } else {
      html += "<div style='display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px;'>" +
        pageInfo.rows.map(function (row) { return renderCard(row, state); }).join("") +
      "</div>";
      html += renderPagination(activeCategory, pageInfo);
    }

    return html;
  }

  function getHistoryDeltaColor(delta) {
    if (delta > 0) return "#22c55e";
    if (delta < 0) return "#ef4444";
    return "#e5e7eb";
  }

  function renderHistoryRangeButtons() {
    var defs = [10];
    var html = '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">';
    for (var i = 0; i < defs.length; i++) {
      var d = defs[i];
      var active = detailHistoryDays === d;
      html += '<button data-act="exd-history-range-' + d + '" style="background:' + (active ? '#2563eb' : '#111827') + ';color:#fff;border:1px solid ' + (active ? '#3b82f6' : '#334155') + ';border-radius:10px;padding:6px 10px;cursor:pointer;font-weight:800;">' + d + '天</button>';
    }
    html += '</div>';
    return html;
  }

  function renderHistoryPanel(state, assetId) {
    var display = w.StockMarketDisplay;
    if (!display || !display.getCloseHistory) {
      return '<div style="opacity:.75;">歷史收盤資料尚未載入。</div>';
    }
    var data = display.getCloseHistory(state, assetId, detailHistoryDays);
    var listedPrice = Math.max(1, Number(data.listedPriceMilli || 0));
    var rows = data.history || [];
    var html = renderHistoryRangeButtons();
    html += '<div style="font-size:13px;line-height:1.8;margin-bottom:8px;">上市日：<b id="exd-listed-day">第' + Number(data.listedDay || 1) + '天</b><br>上市股價：<b id="exd-listed-price">' + fmtCoinMilli(listedPrice) + '</b></div>';
    html += '<div id="exd-history-scroll" style="max-height:260px;overflow:auto;padding-right:4px;">';
    if (!rows.length) {
      html += '<div style="opacity:.75;">目前沒有歷史收盤資料。</div>';
    } else {
      for (var i = rows.length - 1; i >= 0; i--) {
        var row = rows[i];
        var prev = i > 0 ? rows[i - 1] : null;
        var prevPrice = prev ? Number(prev.closePrice || 0) : listedPrice;
        var delta = Number(row.closePrice || 0) - prevPrice;
        var color = getHistoryDeltaColor(delta);
        var prefix = delta > 0 ? '+' : '';
        html += '<div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:' + (i > 0 ? '1px solid #1f2937' : '0') + ';">' +
          '<div>第' + Number(row.marketDay || 0) + '天</div>' +
          '<div style="text-align:right;">' +
            '<div style="font-weight:800;">' + fmtCoinMilli(row.closePrice || 0) + '</div>' +
            '<div style="font-size:12px;color:' + color + ';">' + prefix + fmtCoinMilli(delta) + '</div>' +
          '</div>' +
        '</div>';
      }
    }
    html += '</div>';
    return html;
  }

  function updateHistoryPanel(body, state, assetId) {
    var display = w.StockMarketDisplay;
    if (!display || !display.getCloseHistory) return;
    var info = display.getCloseHistory(state, assetId, detailHistoryDays);
    setText(body, 'exd-listed-day', '第' + Number(info.listedDay || 1) + '天');
    setText(body, 'exd-listed-price', fmtCoinMilli(info.listedPriceMilli || 0));
    var wrap = body.querySelector('#exd-history-scroll');
    if (!wrap) return;
    var oldTop = wrap.scrollTop;
    var rows = info.history || [];
    var listedPrice = Math.max(1, Number(info.listedPriceMilli || 0));
    var html = '';
    if (!rows.length) {
      html = '<div style="opacity:.75;">目前沒有歷史收盤資料。</div>';
    } else {
      for (var i = rows.length - 1; i >= 0; i--) {
        var row = rows[i];
        var prev = i > 0 ? rows[i - 1] : null;
        var prevPrice = prev ? Number(prev.closePrice || 0) : listedPrice;
        var delta = Number(row.closePrice || 0) - prevPrice;
        var color = getHistoryDeltaColor(delta);
        var prefix = delta > 0 ? '+' : '';
        html += '<div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:' + (i > 0 ? '1px solid #1f2937' : '0') + ';">' +
          '<div>第' + Number(row.marketDay || 0) + '天</div>' +
          '<div style="text-align:right;">' +
            '<div style="font-weight:800;">' + fmtCoinMilli(row.closePrice || 0) + '</div>' +
            '<div style="font-size:12px;color:' + color + ';">' + prefix + fmtCoinMilli(delta) + '</div>' +
          '</div>' +
        '</div>';
      }
    }
    wrap.innerHTML = html;
    wrap.scrollTop = oldTop;
    var defs = [10];
    for (var d = 0; d < defs.length; d++) {
      var btn = body.querySelector('[data-act="exd-history-range-' + defs[d] + '"]');
      if (btn) {
        var active = detailHistoryDays === defs[d];
        btn.style.background = active ? '#2563eb' : '#111827';
        btn.style.borderColor = active ? '#3b82f6' : '#334155';
      }
    }
  }


  function getQuarterDay(state) {
    var d = Math.max(1, Math.floor(Number(state && state.marketDay || 1)));
    return ((d - 1) % 30) + 1;
  }

  function isQuarterReportPublished(state) {
    return getQuarterDay(state) >= 25;
  }

  function renderQuarterReportPanel(state, detail) {
    var cm = (detail && detail.companyMetrics) || {};
    var ci = (detail && detail.companyInfo) || {};
    var qDay = getQuarterDay(state);

    if (!isQuarterReportPublished(state)) {
      return '' +
        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
          '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📊 季度財報公告</div>' +
          '<div style="line-height:1.9;color:#cbd5e1;">' +
            '<b style="color:#facc15;">本季度財報尚無公布消息</b><br>' +
            '季度進度：第 ' + qDay + ' / 30 天<br>' +
            '預計公布日：第 25 天<br>' +
            '股利預計發放日：第 30 天' +
          '</div>' +
        '</div>';
    }

    return '' +
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📊 季度財報公告</div>' +
        '<div style="line-height:1.85;">' +
          '狀態：<b style="color:#22c55e;">已公布</b><br>' +
          '季度營收：<b>' + fmtCoinMilli(cm.revenueMonthlyMilli) + '</b><br>' +
          '季度淨利：<b style="color:' + getSignedColor(cm.profitMonthlyMilli) + ';font-weight:700;">' + fmtSignedCoinMilli(cm.profitMonthlyMilli) + '</b><br>' +
          '資產額：<b>' + fmtCoinMilli(cm.assetsMilli) + '</b><br>' +
          '公司體質：<b>' + Math.round(Number(ci.quality || 0) * 100) + '</b><br>' +
          '穩定度：<b>' + Math.round(Number(ci.stability || 0) * 100) + '</b><br>' +
          '熱度：<b>' + Math.round(Number(ci.hype || 0) * 100) + '</b>' +
        '</div>' +
      '</div>';
  }

  function renderQuarterDividendPanel(state, detail) {
    var cm = (detail && detail.companyMetrics) || {};
    var holding = (detail && detail.playerHolding) || {};
    var qDay = getQuarterDay(state);
    var lastDividendText = Number(cm.lastDividendPerShareMilli || 0) > 0
      ? fmtCoinMilli(cm.lastDividendPerShareMilli)
      : '尚無資料';

    if (!isQuarterReportPublished(state)) {
      return '' +
        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
          '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">💰 季度股利公告</div>' +
          '<div style="line-height:1.9;color:#cbd5e1;">' +
            '<b style="color:#facc15;">本季度股利尚無公布消息</b><br>' +
            '季度進度：第 ' + qDay + ' / 30 天<br>' +
            '預計公布日：第 25 天<br>' +
            '預計發放日：第 30 天<br>' +
            '上季度股利：<b>' + lastDividendText + '</b>' +
          '</div>' +
        '</div>';
    }

    return '' +
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">💰 季度股利公告</div>' +
        '<div style="line-height:1.85;">' +
          '狀態：<b style="color:#22c55e;">已公布，將於第30天發放</b><br>' +
          '本季度每股股利：<b>' + fmtCoinMilli(cm.estimatedDividendPerShareMilli) + '</b><br>' +
          '目前配息率：<b>' + (Number(cm.currentPayoutRatio || 0) * 100).toFixed(2) + '%</b><br>' +
          '上季度股利：<b>' + lastDividendText + '</b><br>' +
          '你本季度預估股利：<b>' + fmtCoinMilli(holding.estimatedDividendMilli) + '</b>' +
        '</div>' +
      '</div>';
  }

  function renderDividendHistoryPanel(state, detail) {
    var cm = (detail && detail.companyMetrics) || {};
    var lastDividendText = Number(cm.lastDividendPerShareMilli || 0) > 0
      ? fmtCoinMilli(cm.lastDividendPerShareMilli)
      : '尚無資料';

    return '' +
      '<div id="exd-dividend-history-panel" style="display:none;flex-direction:column;gap:12px;">' +
        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
          '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📜 歷史股利</div>' +
          '<div style="line-height:1.9;">' +
            (lastDividendText === '尚無資料'
              ? '<b style="color:#94a3b8;">尚無資料</b><br><span style="color:#cbd5e1;">公司尚未完成任何一次股利發放。</span>'
              : '最近一次每股股利：<b style="color:#facc15;">' + lastDividendText + '</b><br><span style="color:#cbd5e1;">完整季度股利表可於後續版本擴充。</span>') +
          '</div>' +
        '</div>' +
      '</div>';
  }



  function renderPendingOrdersPanel(state, assetId) {
    var orders = w.StockMarketEngine.getPendingOrdersForAsset
      ? w.StockMarketEngine.getPendingOrdersForAsset(state, assetId)
      : {};

    var buy = orders && orders.buy;
    var sell = orders && orders.sell;

    function row(order, side) {
      if (!order) {
        return '<div style="opacity:.65;font-size:12px;padding:8px 0;">' + (side === "buy" ? '目前沒有買入等候。' : '目前沒有賣出等候。') + '</div>';
      }

      var color = side === "buy" ? '#22c55e' : '#ef4444';
      var title = side === "buy" ? '🟢 買入等候' : '🔴 賣出等候';
      var cancelText = side === "buy" ? '取消買入' : '取消賣出';

      return '' +
        '<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;border-top:1px solid #1f2937;padding:10px 0;">' +
          '<div style="line-height:1.75;min-width:0;">' +
            '<div style="font-weight:900;color:' + color + ';">' + title + '</div>' +
            '<div style="font-size:12px;opacity:.82;">委託價：<b>' + fmtCoinMilli(order.priceMilli) + '</b>｜剩餘：<b>' + fmtNum(order.remainingQty) + '</b> 股｜已成交：<b>' + fmtNum(order.filledQty) + '</b> 股</div>' +
          '</div>' +
          '<button data-act="exd-cancel-' + side + '" style="background:#334155;color:#fff;border:0;border-radius:10px;padding:9px 12px;cursor:pointer;font-weight:900;white-space:nowrap;">' + cancelText + '</button>' +
        '</div>';
    }

    return '' +
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="font-size:16px;font-weight:900;margin-bottom:6px;">⏳ 集中盤委託</div>' +
        '<div style="font-size:12px;opacity:.72;margin-bottom:6px;">下單會鎖定當下價格，買單鎖資金、賣單鎖股票，依市場流動性逐步成交。</div>' +
        row(buy, "buy") +
        row(sell, "sell") +
      '</div>';
  }


  function renderDetailView(state, assetId) {
    var detail = w.StockMarketEngine.getCompanyDetail(state, assetId);
    if (!detail) return null;

    var asset = state.assets[assetId];
    var ci = detail.companyInfo || {};
    var cm = detail.companyMetrics || {};
    var si = detail.shareInfo || {};
    var holding = detail.playerHolding || {};
    var control = detail.control || { ratio: 0, level: "正常", color: "#22c55e" };

    var tierText = getTierLabel(detail);

    var styleText = detail.style === "A" ? "A 型" : "B 型";
    var openPctColor = getSignedColor(detail.openChangePct);
    var dayChangeMilli = Number(detail.priceMilli || 0) - Number(asset && asset.dayOpenPrice || detail.priceMilli || 0);
    var dayChangeText = (dayChangeMilli >= 0 ? "▲ " : "▼ ") + fmtCoinMilli(Math.abs(dayChangeMilli)) + " " + fmtPct(detail.openChangePct);
    var trend5Color = getSignedColor(detail.trend5);
    var trend30Color = getSignedColor(detail.trend30);
    var basePayoutPct = Number(cm.basePayoutRatio || 0) * 100;
    var currentPayoutPct = Number(cm.currentPayoutRatio || 0) * 100;
    var playerImpactNet = Number(asset && asset.playerImpactBuy || 0) - Number(asset && asset.playerImpactSell || 0);
    var playerRecentNetFlow = Number(asset && asset.playerRecentNetFlow || 0);
    var lastPlayerTradeImpact = Number(asset && asset._lastPlayerTradeImpact || 0);

    return (
      '<div style="display:flex;flex-direction:column;gap:12px;">' +
        '<div>' +
          '<button id="stockExchangeBackBtn" style="background:#334155;color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:800;">← 返回交易所</button>' +
        '</div>' +

        '<div style="background:#0b1220;border:1px solid #263247;border-radius:16px;padding:14px;">' +
          '<div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">' +
            '<div>' +
              '<div style="font-size:22px;font-weight:900;">' + detail.name + ' <span style="font-size:14px;color:#93c5fd;">' + (detail.symbol || '-') + '</span></div>' +
              '<div style="font-size:12px;opacity:.72;margin-top:4px;">即時交易頁｜價格每秒更新，首頁只保留股利看板</div>' +
            '</div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap;"><button id="exd-company-toggle" style="display:none;" style="background:#334155;color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:900;">商會資訊</button><button id="exd-dividend-history-toggle" style="display:none;" style="background:#1e293b;color:#fde68a;border:1px solid #475569;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:900;">歷史股利</button></div>' +
          '</div>' +
          '<div style="margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">' +
            renderMiniStat('exd-trade-price', '目前股價', fmtCoinMilli(detail.priceMilli), '#facc15') +
            renderMiniStat('exd-trade-openpct', '今日漲跌', dayChangeText, openPctColor) +
          '</div>' +
          '<div style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">' +
            renderMiniStat('exd-trade-high', '最高', fmtCoinMilli(asset && asset.dayHighPrice || detail.priceMilli), '#e5e7eb') +
            renderMiniStat('exd-trade-lastclose', '昨收', fmtCoinMilli(asset && asset.lastClosePrice || detail.priceMilli), '#e5e7eb') +
          '</div>' +
          '<div style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">' +
            renderMiniStat('exd-trade-low', '最低', fmtCoinMilli(asset && asset.dayLowPrice || detail.priceMilli), '#e5e7eb') +
            renderMiniStat('exd-trade-open', '開盤', fmtCoinMilli(asset && asset.dayOpenPrice || detail.priceMilli), '#e5e7eb') +
          '</div>' +
          '<div style="margin-top:12px;background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;">' +
            '<div style="font-size:13px;opacity:.78;margin-bottom:8px;">輸入股數後直接買入 / 賣出</div>' +
            '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">' +
              '<input id="exdTradeQtyInput" type="number" min="1" step="1" value="1" style="flex:1;min-width:160px;background:#0b1220;color:#fff;border:1px solid #334155;border-radius:10px;padding:12px;font-size:16px;font-weight:900;box-sizing:border-box;">' +
              '<button data-act="exd-buy" style="background:#16a34a;color:#fff;border:0;border-radius:10px;padding:12px 18px;cursor:pointer;font-weight:900;">買入</button>' +
              '<button data-act="exd-sell" style="background:#dc2626;color:#fff;border:0;border-radius:10px;padding:12px 18px;cursor:pointer;font-weight:900;">賣出</button>' +
            '</div>' +
            '<div id="exd-trade-note" style="font-size:12px;color:#93c5fd;margin-top:8px;">撮合與休市期間不可交易；開市且非股利結算日才可下單。</div>' +
          '</div>' +
renderPendingOrdersPanel(state, assetId) +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🧾 你的持股</div>' +
            '<div style="line-height:1.9;">' +
              '你持有：<b id="exd-hold-qty">' + fmtNum(holding.qty) + '</b> 股<br>' +
              '均價：<b id="exd-hold-avg">' + fmtCoinMilli(holding.avgCostMilli) + '</b><br>' +
              '預估股利：<b id="exd-hold-div">' + (isQuarterReportPublished(state) ? fmtCoinMilli(holding.estimatedDividendMilli) : '尚無公布消息') + '</b>' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🏛 商會資訊</div>' +
            '<div style="line-height:1.9;">' +
              '資本額：<b id="exd-merchant-capital">' + fmtCompactCoinMilli(detail.guildCapitalMilli || 0) + '</b><br>' +
              '商會階級：<b id="exd-merchant-capital-tier">' + (detail.guildCapitalTierLabel || "未分級") + '</b><br>' +
              '發行模式：<b>' + ((detail.aiIssueMode || (ci && ci.aiIssueMode)) === "capital_liquidity_ai" ? "AI流通份額" : (((detail.aiIssueMode || (ci && ci.aiIssueMode)) === "capital_ai") ? "AI資本發行" : "傳統發行")) + '</b><br>' +
              '流通倍率：<b>' + Number(detail.liquidityShareMultiplier || 1).toFixed(1) + 'x</b><br>' +
              '預估EPS：<b id="exd-merchant-eps">' + fmtCoinMilli(cm.epsMilli || cm.estimatedDividendPerShareMilli || 0) + '</b><br>' +
              '預估股利：<b id="exd-merchant-dividend">' + fmtCoinMilli(cm.estimatedDividendPerShareMilli || 0) + '</b><br>' +
              'AI估值：<b id="exd-ai-fair">' + fmtCoinMilli(detail.aiFairValueMilli || detail.fairValueMilli || 0) + '</b><br>' +
              'AI狀態：<b id="exd-ai-mood">' + fmtAiMoodLabel(detail.aiMarketMood) + '</b><br>' +
              'AI交易：<b id="exd-ai-style">' + fmtAiStyleLabel(detail.aiTradingStyle) + '</b><br>' +
              'AI損益：<b id="exd-ai-pnl">' + fmtPct(Number(detail.aiUnrealizedPnl || 0) * 100) + '</b><br>' +
              '<div style="margin-top:6px;color:#f7c66b;font-size:11px;">※ 漲停買入將進入排隊委託 / 跌停賣出將進入排隊委託</div>' +
              '總發行股票額度：<b id="exd-merchant-total-lots">' + fmtLots(si.totalShares) + '</b> 張<br>' +
              '市場流通狀態：<b id="exd-merchant-liquidity" style="color:' + getLiquidityDisplay(si).color + ';">' + getLiquidityDisplay(si).icon + ' ' + getLiquidityDisplay(si).label + '</b>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div id="exd-company-info-panel" style="display:none;flex-direction:column;gap:12px;">' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;">' +
          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🏢 公司概況</div>' +
            '<div style="line-height:1.8;">' +
              '名稱：<b>' + detail.name + '</b><br>' +
              '代號：<b>' + (detail.symbol || '-') + '</b><br>' +
              '類型：<b>' + tierText + ' / ' + styleText + '</b><br>' +
              '商會階級：<b id="exd-guild-capital-tier">' + (detail.guildCapitalTierLabel || "未分級") + '</b><br>' +
              '資本額：<b id="exd-guild-capital">' + fmtCompactCoinMilli(detail.guildCapitalMilli || 0) + '</b><br>' +
              '股價：<b id="exd-price" style="font-size:18px;">' + fmtCoinMilli(detail.priceMilli) + '</b>　' +
              '<b id="exd-openpct" style="color:' + openPctColor + ';font-weight:700;">' + fmtPct(detail.openChangePct) + '</b><br>' +
              '平衡價：<b id="exd-fair">' + fmtCoinMilli(detail.fairValueMilli) + '</b><br>' +
              '5日趨勢：<b id="exd-trend5" style="color:' + trend5Color + ';font-weight:700;">' + fmtPct(detail.trend5) + '</b><br>' +
              '30日趨勢：<b id="exd-trend30" style="color:' + trend30Color + ';font-weight:700;">' + fmtPct(detail.trend30) + '</b>' +
            '</div>' +
          '</div>' +

          
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;">' +
          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📘 公司介紹</div>' +
            '<div style="line-height:1.85;word-break:break-word;">' +
              '分類：<b>' + (ci.category || "-") + '</b><br>' +
              '創立年：<b>' + fmtNum(ci.foundedYear || 0) + '</b><br>' +
              '資本月報：<b>' + (detail.guildCapitalLastUpdateDay ? ("第" + fmtNum(detail.guildCapitalLastUpdateDay) + "天") : "尚未月更") + '</b><br>' +
              '簡介：<div style="margin-top:6px;opacity:.9;">' + (ci.descriptionLong || detail.desc || "-") + '</div>' +
              (ci.notes ? ('<div style="margin-top:6px;color:#93c5fd;">備註：' + ci.notes + '</div>') : '') +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🏦 股本結構（張）</div>' +
            '<div style="line-height:1.85;">' +
              '總發行：<b id="exd-total-lots">' + fmtLots(si.totalShares) + '</b> 張<br>' +
              '流通：<b id="exd-float-lots">' + fmtLots(si.floatShares) + '</b> 張<br>' +
              '鎖倉：<b id="exd-locked-lots">' + fmtLots(si.lockedShares) + '</b> 張<br>' +
              '董事持股：<b id="exd-insider-lots">' + fmtLots(si.insiderShares) + '</b> 張<br>' +
              '策略持股：<b id="exd-core-lots">' + fmtLots((si.strategicHoldingShares != null ? si.strategicHoldingShares : si.strategicHoldingShares)) + '</b> 張<br>' +
              '做市持股：<b id="exd-trade-lots">' + fmtLots((si.marketMakerShares != null ? si.marketMakerShares : si.marketMakerShares)) + '</b> 張<br>' +
              '市場掛單：<b id="exd-avail-lots">' + fmtLots(si.availableShares) + '</b> 張' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📊 籌碼與量能</div>' +
            '<div style="line-height:1.85;">' +
              '玩家持股集中度：<b id="exd-control-ratio-2" style="color:' + control.color + ';font-weight:700;">' + fmtPct(control.ratio * 100) + '</b><br>' +
              '集中狀態：<b id="exd-control-level-2" style="color:' + control.color + ';font-weight:700;">' + control.level + '</b><br>' +
              '今日成交量：<b id="exd-vol-now">' + fmtNum(cm.latestDailyVolume) + '</b> 股<br>' +
              '5日均量：<b id="exd-vol-5">' + fmtNum(cm.avgVolume5) + '</b> 股<br>' +
              '30日均量：<b id="exd-vol-30">' + fmtNum(cm.avgVolume30) + '</b> 股' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🧠 玩家交易影響</div>' +
            '<div style="line-height:1.85;">' +
              '近期交易衝擊：<b id="exd-impact-net" style="color:' + getSignedColor(playerImpactNet) + ';font-weight:700;">' + fmtPct(playerImpactNet * 100) + '</b><br>' +
              '最近淨流向：<b id="exd-impact-flow" style="color:' + getSignedColor(playerRecentNetFlow) + ';font-weight:700;">' + fmtPct(playerRecentNetFlow * 100) + '</b><br>' +
              '最近單筆影響：<b id="exd-impact-last" style="color:' + getSignedColor(lastPlayerTradeImpact) + ';font-weight:700;">' + fmtPct(lastPlayerTradeImpact * 100) + '</b><br>' +
              '說明：<span style="opacity:.82;">當你連續大量買入會偏多，連續大量賣出會偏空，之後會隨時間逐步衰退。</span>' +
            '</div>' +
          '</div>' +

          renderQuarterReportPanel(state, detail) +

          renderQuarterDividendPanel(state, detail) +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📅 上市與歷史收盤</div>' +
            renderHistoryPanel(state, assetId) +
          '</div>' +
        '</div>' +
        '</div>' +
      '</div>'
    );
  }

  function getPhaseBadgeText(state) {
    if (isDividendDay(state)) return "🟡 股利結算日";
    if (state.marketPhase === "preopen") return "🟡 撮合中";
    if (state.marketPhase === "open") return "🟢 開市中";
    return "🔴 休市中";
  }

  function getPhaseCountdownLabel(state) {
    if (state.marketPhase === "preopen") return "撮合剩餘時間";
    if (state.marketPhase === "open") return "開市剩餘時間";
    return "休市剩餘時間";
  }

  function updateTopStats(body, state) {
    setText(body, "ex-top-phase", fmtRemain(w.StockMarketEngine.getSecondsToPhaseEnd(state)));
    setText(body, "ex-top-day", fmtRemain(w.StockMarketEngine.getSecondsToDayEnd(state)));

    var phaseText = getPhaseBadgeText(state);

    setText(body, "ex-phase-badge", phaseText);
    setText(body, "ex-world-badge", state.worldState ? state.worldState.label : "無明顯盤勢");
  }

  function updateCards(body, state) {
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;

      var holding = w.StockMarketEngine.getHolding(state, id);
      var openPct = calcOpenChangePct(asset);

      setText(body, "ex-price-" + id, fmtCoinMilli(asset.price));
      var openPctEl = setText(body, "ex-openpct-" + id, fmtPct(openPct));
      setText(body, "ex-open-" + id, fmtCoinMilli(asset.dayOpenPrice));
      setText(body, "ex-high-" + id, fmtCoinMilli(asset.dayHighPrice));
      setText(body, "ex-low-" + id, fmtCoinMilli(asset.dayLowPrice));
      setText(body, "ex-hold-" + id, fmtNum(holding.qty));
      setText(body, "ex-avg-" + id, fmtCoinMilli(holding.avgCostMilli));

      if (openPctEl) openPctEl.style.color = getSignedColor(openPct);

      var status = "正常";
      var color = "#e5e7eb";
      if (asset.marketType === "free" && asset.limitLocked) {
        if (asset.limitType === "up") {
          status = "漲停 🔒";
          color = "#22c55e";
        } else {
          status = "跌停 🔒";
          color = "#ef4444";
        }
      }
      var statusEl = setText(body, "ex-status-" + id, status);
      if (statusEl) statusEl.style.color = color;
    }
  }

  function updateDetailView(body, state, assetId) {
    var detail = w.StockMarketEngine.getCompanyDetail(state, assetId);
    if (!detail) {
      companyDetailAssetId = null;
      render(body);
      return;
    }

    var asset = state.assets[assetId];
    var cm = detail.companyMetrics || {};
    var si = detail.shareInfo || {};
    var holding = detail.playerHolding || {};
    var control = detail.control || { ratio: 0, level: "正常", color: "#22c55e" };
    var playerImpactNet = Number(asset && asset.playerImpactBuy || 0) - Number(asset && asset.playerImpactSell || 0);
    var playerRecentNetFlow = Number(asset && asset.playerRecentNetFlow || 0);
    var lastPlayerTradeImpact = Number(asset && asset._lastPlayerTradeImpact || 0);

    setText(body, "exd-price", fmtCoinMilli(detail.priceMilli));
    setText(body, "exd-guild-capital", fmtCompactCoinMilli(detail.guildCapitalMilli || 0));
    setText(body, "exd-guild-capital-tier", detail.guildCapitalTierLabel || "未分級");
    setText(body, "exd-trade-price", fmtCoinMilli(detail.priceMilli));
    var updDayChangeMilli = Number(detail.priceMilli || 0) - Number(asset && asset.dayOpenPrice || detail.priceMilli || 0);
    var updDayChangeText = (updDayChangeMilli >= 0 ? "▲ " : "▼ ") + fmtCoinMilli(Math.abs(updDayChangeMilli)) + " " + fmtPct(detail.openChangePct);
    var tradePctEl = setText(body, "exd-trade-openpct", updDayChangeText);
    if (tradePctEl) tradePctEl.style.color = getSignedColor(detail.openChangePct);
    setText(body, "exd-trade-high", fmtCoinMilli(asset && asset.dayHighPrice || detail.priceMilli));
    setText(body, "exd-trade-lastclose", fmtCoinMilli(asset && asset.lastClosePrice || detail.priceMilli));
    setText(body, "exd-trade-low", fmtCoinMilli(asset && asset.dayLowPrice || detail.priceMilli));
    setText(body, "exd-trade-open", fmtCoinMilli(asset && asset.dayOpenPrice || detail.priceMilli));
    var openPctEl = setText(body, "exd-openpct", fmtPct(detail.openChangePct));
    if (openPctEl) openPctEl.style.color = getSignedColor(detail.openChangePct);

    setText(body, "exd-fair", fmtCoinMilli(detail.fairValueMilli));

    var trend5El = setText(body, "exd-trend5", fmtPct(detail.trend5));
    if (trend5El) trend5El.style.color = getSignedColor(detail.trend5);

    var trend30El = setText(body, "exd-trend30", fmtPct(detail.trend30));
    if (trend30El) trend30El.style.color = getSignedColor(detail.trend30);

    setText(body, "exd-hold-qty", fmtNum(holding.qty));
    setText(body, "exd-hold-avg", fmtCoinMilli(holding.avgCostMilli));
    setText(body, "exd-merchant-capital", fmtCompactCoinMilli(detail.guildCapitalMilli || 0));
    setText(body, "exd-merchant-capital-tier", detail.guildCapitalTierLabel || "未分級");
    setText(body, "exd-merchant-eps", fmtCoinMilli(cm.epsMilli || cm.estimatedDividendPerShareMilli || 0));
    setText(body, "exd-merchant-dividend", fmtCoinMilli(cm.estimatedDividendPerShareMilli || 0));
    setText(body, "exd-ai-fair", fmtCoinMilli(detail.aiFairValueMilli || detail.fairValueMilli || 0));
    setText(body, "exd-ai-mood", fmtAiMoodLabel(detail.aiMarketMood));
    setText(body, "exd-ai-style", fmtAiStyleLabel(detail.aiTradingStyle));
    setText(body, "exd-ai-pnl", fmtPct(Number(detail.aiUnrealizedPnl || 0) * 100));
    setText(body, "exd-merchant-total-lots", fmtLots(si.totalShares));
    var liqDisp = getLiquidityDisplay(si);
    var liqEl = setText(body, "exd-merchant-liquidity", liqDisp.icon + " " + liqDisp.label);
    if (liqEl) liqEl.style.color = liqDisp.color;

    var ctrlRatio1 = setText(body, "exd-control-ratio", fmtPct(control.ratio * 100));
    var ctrlLevel1 = setText(body, "exd-control-level", control.level);
    var ctrlRatio2 = setText(body, "exd-control-ratio-2", fmtPct(control.ratio * 100));
    var ctrlLevel2 = setText(body, "exd-control-level-2", control.level);

    var shareholderLevelEl = setText(body, "exd-shareholder-level", control.shareholderLevel || "普通投資人");

    [ctrlRatio1, ctrlLevel1, ctrlRatio2, ctrlLevel2, shareholderLevelEl].forEach(function (el) {
      if (el) el.style.color = control.color;
    });

    setText(body, "exd-total-lots", fmtLots(si.totalShares));
    setText(body, "exd-float-lots", fmtLots(si.floatShares));
    setText(body, "exd-locked-lots", fmtLots(si.lockedShares));
    setText(body, "exd-insider-lots", fmtLots(si.insiderShares));
    setText(body, "exd-core-lots", fmtLots((si.strategicHoldingShares != null ? si.strategicHoldingShares : si.strategicHoldingShares)));
    setText(body, "exd-trade-lots", fmtLots((si.marketMakerShares != null ? si.marketMakerShares : si.marketMakerShares)));
    setText(body, "exd-avail-lots", fmtLots(si.availableShares));

    setText(body, "exd-vol-now", fmtNum(cm.latestDailyVolume));
    setText(body, "exd-vol-5", fmtNum(cm.avgVolume5));
    setText(body, "exd-vol-30", fmtNum(cm.avgVolume30));

    var impactNetEl = setText(body, "exd-impact-net", fmtPct(playerImpactNet * 100));
    var impactFlowEl = setText(body, "exd-impact-flow", fmtPct(playerRecentNetFlow * 100));
    var impactLastEl = setText(body, "exd-impact-last", fmtPct(lastPlayerTradeImpact * 100));

    if (impactNetEl) impactNetEl.style.color = getSignedColor(playerImpactNet);
    if (impactFlowEl) impactFlowEl.style.color = getSignedColor(playerRecentNetFlow);
    if (impactLastEl) impactLastEl.style.color = getSignedColor(lastPlayerTradeImpact);



    updateHistoryPanel(body, state, assetId);
  }


  function calcBuyPreview(priceMilli, qty) {
    qty = Math.max(1, Math.floor(Number(qty || 0)));
    var gross = Math.max(0, Math.floor(Number(priceMilli || 0))) * qty;
    var fee = Math.floor(gross * Number(w.StockMarketEngine.BUY_FEE_RATE || 0));
    return { grossMilli: gross, feeMilli: fee, totalMilli: gross + fee };
  }

  function calcSellPreview(priceMilli, qty) {
    qty = Math.max(1, Math.floor(Number(qty || 0)));
    var gross = Math.max(0, Math.floor(Number(priceMilli || 0))) * qty;
    var fee = Math.floor(gross * Number(w.StockMarketEngine.SELL_FEE_RATE || 0));
    var tax = Math.floor(gross * Number(w.StockMarketEngine.SELL_TAX_RATE || 0));
    return { grossMilli: gross, feeMilli: fee, taxMilli: tax, netMilli: gross - fee - tax };
  }

  function closeTradeModal() {
    tradeModalState = null;
    var modal = document.getElementById("stockExchangeTradeModal");
    if (modal) modal.remove();
  }


  function updateTradeModalContent(state) {
    if (!tradeModalState) return;
    var modal = document.getElementById("stockExchangeTradeModal");
    if (!modal) return;

    var asset = state.assets[tradeModalState.assetId];
    if (!asset || !asset.unlocked) {
      closeTradeModal();
      return;
    }

    var holding = w.StockMarketEngine.getHolding(state, asset.id);
    var isBuy = tradeModalState.mode === "buy";
    var maxQty = isBuy ? Math.max(0, Math.floor(Number(asset.availableShares || 0))) : Math.max(0, Math.floor(Number(holding.qty || 0)));
    if (maxQty <= 0) tradeModalState.qty = 0;
    else tradeModalState.qty = Math.min(Math.max(1, Math.floor(Number(tradeModalState.qty || 1))), maxQty);

    var qty = Math.max(0, Math.floor(Number(tradeModalState.qty || 0)));
    var preview = isBuy ? calcBuyPreview(asset.price, Math.max(1, qty || 1)) : calcSellPreview(asset.price, Math.max(1, qty || 1));
    var openPct = calcOpenChangePct(asset);
    var disabledTrade = state.marketPhase !== "open" || isDividendDay(state);
    var disabledAction = disabledTrade || qty <= 0 || maxQty <= 0;
    var helperValue = isBuy ? fmtNum(asset.availableShares) + " 股" : fmtNum(holding.qty) + " 股";

    setText(modal, "trade-title", (isBuy ? "買入" : "賣出") + "｜" + (asset.symbol || "----") + " " + asset.name);
    setText(modal, "trade-price", fmtCoinMilli(asset.price));
    var openPctEl = setText(modal, "trade-openpct", fmtPct(openPct));
    if (openPctEl) openPctEl.style.color = getSignedColor(openPct);

    var changeEl = setText(modal, "trade-change", fmtSignedCoinMilli(asset.lastChangeValue));
    if (changeEl) changeEl.style.color = getSignedColor(asset.lastChangeValue);

    setText(modal, "trade-avail", helperValue);
    setText(modal, "trade-maxqty", fmtNum(maxQty));
    setText(modal, "trade-qty", fmtNum(qty));

    var qtyInput = modal.querySelector("#exchangeTradeQtyInput");
    if (qtyInput) {
      var normalizedQty = qty > 0 ? String(qty) : "";
      if (document.activeElement !== qtyInput) {
        qtyInput.value = normalizedQty;
      }
      qtyInput.max = String(maxQty);
    }

    setText(modal, "trade-gross", fmtCoinMilli(preview.grossMilli));
    setText(modal, "trade-fee", fmtCoinMilli(preview.feeMilli));
    if (!isBuy) {
      setText(modal, "trade-tax", fmtCoinMilli(preview.taxMilli));
      setText(modal, "trade-avg", fmtCoinMilli(holding.avgCostMilli));
    }

    var totalEl = setText(modal, "trade-total", fmtCoinMilli(isBuy ? preview.totalMilli : preview.netMilli));
    if (totalEl) totalEl.style.color = isBuy ? "#facc15" : "#22c55e";

    var disabledTradeEl = modal.querySelector("#trade-disabled-note");
    if (disabledTradeEl) disabledTradeEl.style.display = disabledTrade ? "block" : "none";
    var emptyEl = modal.querySelector("#trade-empty-note");
    if (emptyEl) {
      emptyEl.style.display = maxQty <= 0 ? "block" : "none";
      emptyEl.textContent = isBuy ? "目前市場沒有可買股數。" : "目前沒有可賣持股。";
    }

    var confirmBtn = modal.querySelector("#exchangeTradeConfirm");
    if (confirmBtn) {
      confirmBtn.disabled = !!disabledAction;
      confirmBtn.style.opacity = disabledAction ? "0.6" : "1";
    }
  }

  function renderTradeModal(state) {
    if (!tradeModalState) return;
    var body = document.getElementById("stockHubBody");
    if (!body || String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return;

    var asset = state.assets[tradeModalState.assetId];
    if (!asset || !asset.unlocked) {
      closeTradeModal();
      return;
    }

    var isBuy = tradeModalState.mode === "buy";
    var modal = document.getElementById("stockExchangeTradeModal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "stockExchangeTradeModal";
      modal.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;z-index:10001;padding:16px;";
      document.body.appendChild(modal);
    }

    if (String(modal.getAttribute("data-mode") || "") !== String(tradeModalState.mode) ||
        String(modal.getAttribute("data-asset-id") || "") !== String(tradeModalState.assetId)) {
      var title = isBuy ? "買入" : "賣出";
      var helper = isBuy ? "市場可買" : "目前持有";
      var qtyButtons = [1, 10, 100].map(function (n) {
        return "<button data-trade-step='" + n + "' style='background:#1e293b;color:#fff;border:1px solid #334155;border-radius:10px;padding:8px 10px;cursor:pointer;font-weight:800;'>+" + n + "</button>";
      }).join("");
      var fastBtnLabel = isBuy ? "最大可買" : "全部賣出";

      modal.setAttribute("data-mode", String(tradeModalState.mode));
      modal.setAttribute("data-asset-id", String(tradeModalState.assetId));

      modal.innerHTML =
        "<div style='width:min(560px,96vw);background:#0b1220;border:1px solid #263247;border-radius:18px;box-shadow:0 20px 60px rgba(0,0,0,.45);overflow:hidden;'>" +
          "<div style='display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:14px 16px;border-bottom:1px solid #1f2937;'>" +
            "<div>" +
              "<div id='trade-title' style='font-size:18px;font-weight:900;'></div>" +
              "<div style='font-size:12px;opacity:.75;margin-top:4px;'>價格會持續更新，實際成交風險由玩家自行承擔</div>" +
            "</div>" +
            "<button id='exchangeTradeClose' style='background:#334155;color:#fff;border:0;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:800;'>關閉</button>" +
          "</div>" +
          "<div style='padding:16px;display:flex;flex-direction:column;gap:14px;'>" +
            "<div style='display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;'>" +
              renderMiniStat("trade-price", "目前價格", "") +
              renderMiniStat("trade-openpct", "今日漲跌", "") +
              renderMiniStat("trade-change", "即時變動", "") +
              renderMiniStat("trade-avail", helper, "", "#93c5fd") +
            "</div>" +
            "<div style='background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;'>" +
              "<div style='display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;'>" +
                "<div style='font-size:13px;opacity:.78;'>" + (isBuy ? "輸入欲買入股數" : "輸入欲賣出股數") + "</div>" +
                "<div style='display:flex;gap:8px;flex-wrap:wrap;'>" + qtyButtons +
                  "<button data-trade-max='1' style='background:#2563eb;color:#fff;border:0;border-radius:10px;padding:8px 10px;cursor:pointer;font-weight:800;'>" + fastBtnLabel + "</button>" +
                "</div>" +
              "</div>" +
              "<div style='margin-top:10px;display:flex;gap:10px;align-items:center;'>" +
                "<input id='exchangeTradeQtyInput' type='number' min='1' step='1' value='' style='flex:1;background:#0b1220;color:#fff;border:1px solid #334155;border-radius:10px;padding:12px;box-sizing:border-box;font-size:16px;font-weight:800;'>" +
                "<div style='font-size:12px;opacity:.75;white-space:nowrap;'>上限：<span id='trade-maxqty'></span> 股</div>" +
              "</div>" +
            "</div>" +
            "<div style='background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;display:grid;grid-template-columns:1fr;gap:8px;'>" +
              renderInfoRow(isBuy ? "買入股數" : "賣出股數", "<span id='trade-qty'></span> 股") +
              renderInfoRow("成交金額", "<span id='trade-gross'></span>") +
              renderInfoRow("手續費", "<span id='trade-fee'></span>") +
              (isBuy ? "" : renderInfoRow("交易稅", "<span id='trade-tax'></span>")) +
              renderInfoRow(isBuy ? "總支付" : "實收金額", "<span id='trade-total' style='font-weight:900;'></span>") +
              (isBuy ? "" : renderInfoRow("目前均價", "<span id='trade-avg'></span>")) +
            "</div>" +
            "<div id='trade-disabled-note' style='display:none;font-size:12px;color:#fca5a5;'>目前無法交易，請待開市且非股利結算日再操作。</div>" +
            "<div id='trade-empty-note' style='display:none;font-size:12px;color:#fca5a5;'></div>" +
            "<div style='display:flex;gap:10px;justify-content:flex-end;'>" +
              "<button id='exchangeTradeCancel' style='background:#334155;color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:800;'>取消</button>" +
              "<button id='exchangeTradeConfirm' style='background:" + (isBuy ? "#16a34a" : "#dc2626") + ";color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:800;'>確認" + title + "</button>" +
            "</div>" +
          "</div>" +
        "</div>";

      modal.onclick = function (e) {
        if (e.target === modal) closeTradeModal();
      };

      var closeBtn = modal.querySelector("#exchangeTradeClose");
      if (closeBtn) closeBtn.onclick = closeTradeModal;
      var cancelBtn = modal.querySelector("#exchangeTradeCancel");
      if (cancelBtn) cancelBtn.onclick = closeTradeModal;

      var qtyInput = modal.querySelector("#exchangeTradeQtyInput");
      function normalizeQty(v) {
        var n = Math.max(0, Math.floor(Number(v || 0)));
        var maxTextEl = modal.querySelector("#trade-maxqty");
        var max = maxTextEl ? Math.max(0, Math.floor(Number(String(maxTextEl.textContent || "0").replace(/,/g, "")))) : 0;
        if (max > 0) n = Math.min(max, Math.max(1, n || 1));
        tradeModalState.qty = n;
        updateTradeModalContent(w.StockStateManager.getState());
      }
      if (qtyInput) {
        qtyInput.oninput = function () {
          var n = Math.max(0, Math.floor(Number(qtyInput.value || 0)));
          tradeModalState.qty = n;
          var q = modal.querySelector('#trade-qty');
          if (q) q.textContent = fmtNum(n);
        };
        qtyInput.onchange = function () { normalizeQty(qtyInput.value); };
        setTimeout(function () {
          try {
            qtyInput.focus();
            qtyInput.select();
          } catch (_) {}
        }, 0);
      }

      var stepBtns = modal.querySelectorAll("button[data-trade-step]");
      for (var i = 0; i < stepBtns.length; i++) {
        stepBtns[i].onclick = (function (step) {
          return function () {
            normalizeQty((tradeModalState.qty || 0) + step);
          };
        })(Math.max(1, Math.floor(Number(stepBtns[i].getAttribute("data-trade-step") || 1))));
      }

      var maxBtn = modal.querySelector("button[data-trade-max]");
      if (maxBtn) {
        maxBtn.onclick = function () {
          var maxTextEl = modal.querySelector("#trade-maxqty");
          normalizeQty(maxTextEl ? Number(String(maxTextEl.textContent || "0").replace(/,/g, "")) : 0);
        };
      }

      var confirmBtn = modal.querySelector("#exchangeTradeConfirm");
      if (confirmBtn) {
        confirmBtn.onclick = function () {
          var s = w.StockStateManager.getState();
          w.StockStateManager.settleAndSave();
          var freshQty = Math.max(1, Math.floor(Number(tradeModalState.qty || 0)));
          var latestAsset = s.assets[tradeModalState.assetId];
          var res = w.StockMarketEngine.placePendingOrder ? w.StockMarketEngine.placePendingOrder(s, latestAsset.id, isBuy ? "buy" : "sell", freshQty) : (isBuy ? w.StockMarketEngine.buyAsset(s, latestAsset.id, freshQty) : w.StockMarketEngine.sellAsset(s, latestAsset.id, freshQty));
          if (!res.ok) {
            alert(getReasonText(res.reason, isBuy ? "buy" : "sell"));
            updateTradeModalContent(w.StockStateManager.getState());
            return;
          }
          w.StockStateManager.save();
          closeTradeModal();
          if (w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
          rerenderListOnly();
        };
      }
    }

    updateTradeModalContent(state);
  }

  function openTradeModal(mode, assetId) {
    tradeModalState = { mode: mode, assetId: assetId, qty: 1 };
    w.StockStateManager.settleAndSave();
    renderTradeModal(w.StockStateManager.getState());
  }

  function getListSignature(state) {
    var ids = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      ids.push(String(id));
    }
    ids.sort();
    return activeCategory + "|" + ids.join(",");
  }

  function rerenderListOnly() {
    var body = document.getElementById("stockHubBody");
    if (!body) return;
    if (String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return;
    if (companyDetailAssetId) return;

    var scrollTop = getExchangeScrollTop();
    var tabsEl = body.querySelector("#exchangeCategoryTabs");
    var tabsScrollLeft = tabsEl ? tabsEl.scrollLeft : 0;

    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();

    var wrap = body.querySelector("#stockExchangeCardsWrap");
    if (!wrap) return;

    wrap.innerHTML = renderCardsArea(state);
    wrap.setAttribute("data-signature", getListSignature(state));

    bindActions(body);
    updateTopStats(body, state);
    updateCards(body, state);

    restoreExchangeScrollTop(scrollTop);

    var newTabsEl = body.querySelector("#exchangeCategoryTabs");
    if (newTabsEl) {
      newTabsEl.scrollLeft = tabsScrollLeft;
      setTimeout(function () {
        newTabsEl.scrollLeft = tabsScrollLeft;
      }, 30);
    }

    setTimeout(function () {
      restoreExchangeScrollTop(scrollTop);
    }, 30);
  }

  function bindActions(body) {
    var state = w.StockStateManager.getState();

    var catBtns = body.querySelectorAll("button[data-ex-cat]");
    for (var c = 0; c < catBtns.length; c++) {
      catBtns[c].onclick = (function (cat) {
        return function () {
          activeCategory = cat;
          if (!categoryPageMap[cat]) categoryPageMap[cat] = 1;
          rerenderListOnly();
        };
      })(catBtns[c].getAttribute("data-ex-cat"));
    }

    var prevBtns = body.querySelectorAll("button[data-ex-page-prev]");
    for (var p = 0; p < prevBtns.length; p++) {
      prevBtns[p].onclick = (function (cat) {
        return function () {
          categoryPageMap[cat] = Math.max(1, getPageForCategory(cat) - 1);
          rerenderListOnly();
        };
      })(prevBtns[p].getAttribute("data-ex-page-prev"));
    }

    var nextBtns = body.querySelectorAll("button[data-ex-page-next]");
    for (var n = 0; n < nextBtns.length; n++) {
      nextBtns[n].onclick = (function (cat) {
        return function () {
          categoryPageMap[cat] = getPageForCategory(cat) + 1;
          rerenderListOnly();
        };
      })(nextBtns[n].getAttribute("data-ex-page-next"));
    }

    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;

      (function (assetId) {
        var buyBtn = body.querySelector('[data-act="exchange-buy-' + assetId + '"]');
        var sellBtn = body.querySelector('[data-act="exchange-sell-' + assetId + '"]');
        var detailBtn = body.querySelector('[data-act="exchange-detail-' + assetId + '"]');

        if (buyBtn) {
          buyBtn.onclick = function () {
            openTradeModal("buy", assetId);
          };
        }

        if (sellBtn) {
          sellBtn.onclick = function () {
            openTradeModal("sell", assetId);
          };
        }

        if (detailBtn) {
          detailBtn.onclick = function () {
            closeTradeModal();
            companyDetailAssetId = assetId;
            render(body);
          };
        }
      })(id);
    }

    var backBtn = body.querySelector("#stockExchangeBackBtn");
    if (backBtn) {
      backBtn.onclick = function () {
        companyDetailAssetId = null;
        render(body);
      };
    }

    var toggleBtn = body.querySelector("#exd-company-toggle");
    if (toggleBtn) {
      toggleBtn.onclick = function () {
        var panel = body.querySelector("#exd-company-info-panel");
        var historyPanel = body.querySelector("#exd-dividend-history-panel");
        if (!panel) return;
        var isHidden = panel.style.display === "none";
        panel.style.display = isHidden ? "flex" : "none";
        if (historyPanel) historyPanel.style.display = "none";
        toggleBtn.textContent = isHidden ? "收起商會資訊" : "商會資訊";
        var hBtn = body.querySelector("#exd-dividend-history-toggle");
        if (hBtn) hBtn.textContent = "歷史股利";
      };
    }

    var dividendHistoryBtn = body.querySelector("#exd-dividend-history-toggle");
    if (dividendHistoryBtn) {
      dividendHistoryBtn.onclick = function () {
        var panel = body.querySelector("#exd-dividend-history-panel");
        var companyPanel = body.querySelector("#exd-company-info-panel");
        if (!panel) return;
        var isHidden = panel.style.display === "none";
        panel.style.display = isHidden ? "flex" : "none";
        if (companyPanel) companyPanel.style.display = "none";
        dividendHistoryBtn.textContent = isHidden ? "收起歷史股利" : "歷史股利";
        var cBtn = body.querySelector("#exd-company-toggle");
        if (cBtn) cBtn.textContent = "商會資訊";
      };
    }

    var quickBuyBtn = body.querySelector('[data-act="exd-buy"]');
    var quickSellBtn = body.querySelector('[data-act="exd-sell"]');
    function getDetailQty() {
      var input = body.querySelector("#exdTradeQtyInput");
      return Math.max(1, Math.floor(Number(input && input.value || 1)));
    }
    function quickTrade(side) {
      if (!companyDetailAssetId) return;
      var s = w.StockStateManager.getState();
      w.StockStateManager.settleAndSave();
      var asset = s.assets[companyDetailAssetId];
      if (!asset) return;
      var qty = getDetailQty();
      var res = w.StockMarketEngine.placePendingOrder ? w.StockMarketEngine.placePendingOrder(s, asset.id, side, qty) : (side === "buy" ? w.StockMarketEngine.buyAsset(s, asset.id, qty) : w.StockMarketEngine.sellAsset(s, asset.id, qty));
      if (!res.ok) {
        alert(getReasonText(res.reason, side));
        updateDetailView(body, w.StockStateManager.getState(), companyDetailAssetId);
        return;
      }
      w.StockStateManager.save();
      if (w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
      updateDetailView(body, w.StockStateManager.getState(), companyDetailAssetId);
    }
    if (quickBuyBtn) quickBuyBtn.onclick = function () { quickTrade("buy"); };
    if (quickSellBtn) quickSellBtn.onclick = function () { quickTrade("sell"); };


    var cancelBuyOrderBtn = body.querySelector('[data-act="exd-cancel-buy"]');
    var cancelSellOrderBtn = body.querySelector('[data-act="exd-cancel-sell"]');

    function cancelPending(side) {
      if (!companyDetailAssetId || !w.StockMarketEngine.cancelPendingOrder) return;
      var s = w.StockStateManager.getState();
      w.StockStateManager.settleAndSave();
      var res = w.StockMarketEngine.cancelPendingOrder(s, companyDetailAssetId, side);
      if (!res.ok) {
        alert(getReasonText(res.reason, side));
        return;
      }
      w.StockStateManager.save();
      if (w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
      updateDetailView(body, w.StockStateManager.getState(), companyDetailAssetId);
    }

    if (cancelBuyOrderBtn) cancelBuyOrderBtn.onclick = function () { cancelPending("buy"); };
    if (cancelSellOrderBtn) cancelSellOrderBtn.onclick = function () { cancelPending("sell"); };

    var ranges = [10];
    for (var ri = 0; ri < ranges.length; ri++) {
      (function(days){
        var btn = body.querySelector('[data-act="exd-history-range-' + days + '"]');
        if (btn) {
          btn.onclick = function() {
            detailHistoryDays = days;
            if (companyDetailAssetId) render(body);
          };
        }
      })(ranges[ri]);
    }
  }

  function render(body) {
    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();

    if (companyDetailAssetId) {
      var detailHtml = renderDetailView(state, companyDetailAssetId);
      if (!detailHtml) {
        companyDetailAssetId = null;
      } else {
        body.innerHTML = detailHtml;
        bindActions(body);
        return;
      }
    }

    var phaseText = getPhaseBadgeText(state);

    var worldText = state.worldState ? state.worldState.label : "無明顯盤勢";
    var phaseRemain = w.StockMarketEngine.getSecondsToPhaseEnd(state);
    var dayRemain = w.StockMarketEngine.getSecondsToDayEnd(state);

    body.innerHTML =
      "<div style='display:flex;flex-direction:column;gap:12px;'>" +
        "<div style='background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;'>" +
          "<div style='display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;'>" +
            "<div>" +
              "<div style='font-size:20px;font-weight:900;'>🏛️ 交易所 V4.8.1</div>" +
              "<div style='font-size:12px;opacity:.72;margin-top:4px;'>市場看板只顯示股票名稱、代號與預估股利；點股票後進入即時交易頁。</div>" +
            "</div>" +
            "<div style='display:flex;gap:8px;flex-wrap:wrap;'>" +
              "<span id='ex-phase-badge' style='background:#1d4ed8;color:#fff;border-radius:999px;padding:5px 10px;font-size:12px;font-weight:800;'>" + phaseText + "</span>" +
              "<span id='ex-world-badge' style='background:#1e293b;color:#dbeafe;border-radius:999px;padding:5px 10px;font-size:12px;font-weight:800;'>" + worldText + "</span>" +
            "</div>" +
          "</div>" +

          "<div style='margin-top:10px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;'>" +
            renderMiniStat("ex-top-phase", getPhaseCountdownLabel(state), fmtRemain(phaseRemain), "#93c5fd") +
            renderMiniStat("ex-top-day", "本日剩餘", fmtRemain(dayRemain)) +
          "</div>" +
        "</div>" +

        "<div style='background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;'>" +
          "<div style='font-size:16px;font-weight:900;margin-bottom:8px;'>📈 股票清單</div>" +
          "<div id='stockExchangeScroll' style='max-height:720px;overflow:auto;padding-right:4px;'>" +
            "<div id='stockExchangeCardsWrap'>" +
              renderCardsArea(state) +
            "</div>" +
          "</div>" +
        "</div>" +
      "</div>";

    var wrap = body.querySelector("#stockExchangeCardsWrap");
    if (wrap) wrap.setAttribute("data-signature", getListSignature(state));
    bindActions(body);
  }

  function update(body) {
    if (!body) return;

    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();

    if (companyDetailAssetId) {
      updateDetailView(body, state, companyDetailAssetId);
      return;
    }

    var wrap = body.querySelector("#stockExchangeCardsWrap");
    var currentSignature = getListSignature(state);
    if (wrap && String(wrap.getAttribute("data-signature") || "") !== currentSignature) {
      rerenderListOnly();
      return;
    }

    updateTopStats(body, state);
    updateCards(body, state);
    renderTradeModal(state);
  }

  function onClose() {
    companyDetailAssetId = null;
    activeCategory = "all";
    closeTradeModal();
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "交易所",
    render: render,
    update: update,
    onClose: onClose,
    noAutoRerender: true
  });
})(window);
// V4.2.1 ETF 分類預留

// world news tab enabled
