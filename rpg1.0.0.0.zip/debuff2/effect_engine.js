// effect_engine.js

import { STATUS_REGISTRY } from "./status_registry.js";

export function applyEffect(target, effectData = {}) {

  const config =
    STATUS_REGISTRY[effectData.id];

  if (!config) return false;

  if (!target.effects) {
    target.effects = [];
  }

  const existing =
    target.effects.find(
      e => e.id === effectData.id
    );

  // stack
  if (existing) {

    existing.stacks =
      Math.min(
        (existing.stacks || 1) + (effectData.stacks || 1),
        config.maxStacks || 1
      );

    existing.remaining =
      effectData.duration ||
      config.defaultDuration;

    return true;
  }

  // runtime instance
  const runtimeEffect = {

    id: config.id,

    type: config.type,

    source: effectData.source || null,

    remaining:
      effectData.duration ||
      config.defaultDuration,

    stacks:
      effectData.stacks || 1,

    tickInterval:
      config.tickInterval || 0,

    tickTimer:
      config.tickInterval || 0,

    data:
      effectData.data || {}
  };

  target.effects.push(runtimeEffect);

  return true;
}

export function updateEffects(
  entity,
  delta,
  damageEngine
) {

  if (!entity.effects) return;

  for (let i = entity.effects.length - 1; i >= 0; i--) {

    const effect = entity.effects[i];

    const config =
      STATUS_REGISTRY[effect.id];

    if (!config) continue;

    effect.remaining -= delta;

    // tick effect
    if (effect.tickInterval > 0) {

      effect.tickTimer -= delta;

      if (effect.tickTimer <= 0) {

        if (config.onTick) {

          config.onTick({
            target: entity,
            source: effect.source,
            effect,
            damageEngine
          });
        }

        effect.tickTimer += effect.tickInterval;
      }
    }

    // expire
    if (effect.remaining <= 0) {

      entity.effects.splice(i, 1);
    }
  }
}

export function hasEffect(entity, effectId) {

  if (!entity.effects) return false;

  return entity.effects.some(
    e => e.id === effectId
  );
}

export function getEffect(entity, effectId) {

  if (!entity.effects) return null;

  return entity.effects.find(
    e => e.id === effectId
  );
}