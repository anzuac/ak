
// =====================================================
// AI5.1.2 UI Tick Sync
//
// Only synchronizes:
// - realtime prices
// - price change display
// - market index updates
//
// Other UI systems remain unchanged.
// =====================================================




// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function (w) {
  "use strict";

  if (!w.StockMarketEngine) {
    console.error("❌ stock_market_display.js: 缺少 StockMarketEngine");
    return;
  }

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function ensureDisplayState(state) {
    if (!state.marketDisplay || typeof state.marketDisplay !== "object") {
      state.marketDisplay = {
        version: 2,
        topbar: {
          lastSummaryText: "",
          lastMarkup: ""
        }
      };
    }
    if (!state.marketDisplay.topbar || typeof state.marketDisplay.topbar !== "object") {
      state.marketDisplay.topbar = {
        lastSummaryText: "",
        lastMarkup: ""
      };
    }
    if (typeof state.marketDisplay.topbar.lastSummaryText !== "string") {
      state.marketDisplay.topbar.lastSummaryText = "";
    }
    if (typeof state.marketDisplay.topbar.lastMarkup !== "string") {
      state.marketDisplay.topbar.lastMarkup = "";
    }
    return state.marketDisplay;
  }

  function getMarketStatusSummary(state) {
    if (!state) return null;
    ensureDisplayState(state);

    var marketDay = Math.max(1, Math.floor(Number(state.marketDay || 1)));
    var phase = String(state.marketPhase || "preopen");
    var isOpen = phase === "open";
    var isPreopen = phase === "preopen";
    var isDividend = !!(w.StockMarketEngine.isDividendSettlementDay && w.StockMarketEngine.isDividendSettlementDay(state));

    var phaseText = isPreopen ? "撮合中" : (isOpen ? "開市中" : "休市中");
    var dividendText = isDividend ? "股利結算日" : "";
    var dayText = "第" + marketDay + "天";
    var summaryText = dayText + "｜" + phaseText + (dividendText ? "｜" + dividendText : "");

    state.marketDisplay.topbar.lastSummaryText = summaryText;

    return {
      marketDay: marketDay,
      marketPhase: phase,
      isOpen: isOpen,
      isPreopen: isPreopen,
      isDividendSettlementDay: isDividend,
      dayText: dayText,
      phaseText: phaseText,
      dividendText: dividendText,
      summaryText: summaryText
    };
  }

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function buildTopbarStatusMarkup(state) {
    var info = getMarketStatusSummary(state);
    if (!info) return "";

    var phaseClass = info.isPreopen ? "market-preopen" : (info.isOpen ? "market-open" : "market-closed");
    var dividendClass = info.isDividendSettlementDay ? "market-dividend-yes" : "market-dividend-no";

    var markup = "" +
      '<span class="market-status-segment market-day-segment">' + escapeHtml(info.dayText) + '</span>' +
      '<span class="market-status-sep">｜</span>' +
      '<span class="market-status-segment market-phase-segment ' + phaseClass + '">' + escapeHtml(info.phaseText) + '</span>' +
      '<span class="market-status-sep">｜</span>' +
      '<span class="market-status-segment market-dividend-segment ' + dividendClass + '">' + escapeHtml(info.dividendText) + '</span>';

    ensureDisplayState(state).topbar.lastMarkup = markup;
    return markup;
  }

  function updateTopbarElement(target) {
    if (!target || !w.StockStateManager || !w.StockStateManager.getState) return false;
    var state = w.StockStateManager.getState();
    if (!state) return false;

    var info = getMarketStatusSummary(state);
    if (!info) return false;

    target.innerHTML = buildTopbarStatusMarkup(state);
    target.setAttribute("data-market-day", String(info.marketDay));
    target.setAttribute("data-market-phase", info.marketPhase);
    target.setAttribute("data-dividend-day", info.isDividendSettlementDay ? "1" : "0");
    target.setAttribute("title", info.summaryText);
    return true;
  }

  function syncTopbarStatus(targetId) {
    var el = document.getElementById(targetId || "market-status-text");
    if (!el) return false;
    return updateTopbarElement(el);
  }

  function startAutoTopbarSync(targetId, intervalMs) {
    targetId = targetId || "market-status-text";
    intervalMs = Math.max(500, Math.floor(Number(intervalMs || 1000)));

    if (!w.__stockMarketTopbarSync) {
      w.__stockMarketTopbarSync = { timers: {} };
    }

    if (w.__stockMarketTopbarSync.timers[targetId]) {
      clearInterval(w.__stockMarketTopbarSync.timers[targetId]);
    }

    syncTopbarStatus(targetId);
    w.__stockMarketTopbarSync.timers[targetId] = setInterval(function () {
      syncTopbarStatus(targetId);
    }, intervalMs);

    return w.__stockMarketTopbarSync.timers[targetId];
  }

  function autoMountTopbarSync() {
    if (typeof document === "undefined") return;

    function mount() {
      var el = document.getElementById("market-status-text");
      if (!el) return;
      startAutoTopbarSync("market-status-text", 1000);
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", mount, { once: true });
    } else {
      mount();
    }
  }

  function getRecentCloseHistory(state, assetId, limit) {
    if (!state || !state.assets || !state.assets[assetId]) return [];
    var asset = state.assets[assetId];
    var hist = Array.isArray(asset.trendHistory) ? asset.trendHistory.slice() : [];
    var out = [];

    for (var i = 0; i < hist.length; i++) {
      out.push({
        marketDay: Math.max(1, Math.floor(Number(hist[i].marketDay || (i + 1)))),
        closePrice: Math.max(0, Math.floor(Number(hist[i].closePrice || 0))),
        volume: Math.max(0, Math.floor(Number(hist[i].volume || 0)))
      });
    }

    var currentDay = Math.max(1, Math.floor(Number(state.marketDay || 1)));
    var currentPrice = Math.max(0, Math.floor(Number(asset.price || asset.basePrice || 0)));
    var latest = out.length ? out[out.length - 1] : null;
    if (!latest || latest.marketDay !== currentDay) {
      out.push({
        marketDay: currentDay,
        closePrice: currentPrice,
        volume: Math.max(0, Math.floor(Number(asset.companyMetrics && asset.companyMetrics.latestDailyVolume || 0)))
      });
    } else if (latest.closePrice <= 0 && currentPrice > 0) {
      latest.closePrice = currentPrice;
    }

    limit = Math.max(1, Math.floor(Number(limit || out.length || 1)));
    if (out.length > limit) out = out.slice(out.length - limit);
    return out;
  }

  function getListedInfo(state, assetId) {
    if (!state || !state.assets || !state.assets[assetId]) return null;
    var asset = state.assets[assetId];
    var listedDay = Math.max(1, Math.floor(Number(
      asset.listedDay ||
      (asset.registryMeta && asset.registryMeta.listedDay) ||
      (Array.isArray(asset.trendHistory) && asset.trendHistory.length ? asset.trendHistory[0].marketDay : 1) ||
      1
    )));
    var listedPriceMilli = Math.max(1, Math.floor(Number(
      asset.listedPriceMilli || asset.ipoPriceMilli || asset.dayOpenPrice || asset.basePrice || asset.price || 1
    )));
    return {
      assetId: assetId,
      symbol: asset.symbol || "----",
      name: asset.name || assetId,
      listedDay: listedDay,
      listedPriceMilli: listedPriceMilli
    };
  }

  function getCloseHistory(state, assetId, days) {
    var listed = getListedInfo(state, assetId);
    var history = getRecentCloseHistory(state, assetId, days);
    return {
      assetId: assetId,
      symbol: listed ? listed.symbol : "----",
      name: listed ? listed.name : assetId,
      listedDay: listed ? listed.listedDay : 1,
      listedPriceMilli: listed ? listed.listedPriceMilli : 0,
      rangeDays: Math.max(1, Math.floor(Number(days || 10))),
      history: history
    };
  }

  function getCompanyList(state) {
    var out = [];
    if (!state || !state.assets) return out;
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      var listed = getListedInfo(state, id) || { listedDay: 1, listedPriceMilli: 0 };
      out.push({
        assetId: id,
        symbol: asset.symbol || "----",
        name: asset.name || id,
        listedDay: listed.listedDay,
        listedPriceMilli: listed.listedPriceMilli,
        currentPriceMilli: Math.max(0, Math.floor(Number(asset.price || 0)))
      });
    }
    out.sort(function(a,b){ return String(a.symbol).localeCompare(String(b.symbol)); });
    return out;
  }

  function getLineChartPoints(history, width, height, padding) {
    history = Array.isArray(history) ? history : [];
    width = Math.max(80, Number(width || 320));
    height = Math.max(40, Number(height || 120));
    padding = Math.max(4, Number(padding || 12));
    if (!history.length) return [];

    var minPrice = Infinity, maxPrice = -Infinity;
    for (var i = 0; i < history.length; i++) {
      var p = Number(history[i].closePrice || 0);
      if (p < minPrice) minPrice = p;
      if (p > maxPrice) maxPrice = p;
    }
    if (!isFinite(minPrice) || !isFinite(maxPrice)) return [];
    if (minPrice === maxPrice) { minPrice -= 1; maxPrice += 1; }

    var usableW = width - padding * 2;
    var usableH = height - padding * 2;
    var points = [];

    for (var j = 0; j < history.length; j++) {
      var x = padding + (history.length === 1 ? usableW / 2 : usableW * (j / Math.max(1, history.length - 1)));
      var ratio = (Number(history[j].closePrice || 0) - minPrice) / Math.max(1e-9, (maxPrice - minPrice));
      var y = padding + usableH * (1 - clamp(ratio, 0, 1));
      points.push({ x: x, y: y, marketDay: history[j].marketDay, closePrice: history[j].closePrice });
    }

    return points;
  }

  function getSimpleLinePath(history, width, height, padding) {
    var pts = getLineChartPoints(history, width, height, padding);
    if (!pts.length) return "";
    var path = "M " + pts[0].x.toFixed(1) + " " + pts[0].y.toFixed(1);
    for (var i = 1; i < pts.length; i++) path += " L " + pts[i].x.toFixed(1) + " " + pts[i].y.toFixed(1);
    return path;
  }

  w.StockMarketDisplay = {
    ensureDisplayState: ensureDisplayState,
    getMarketStatusSummary: getMarketStatusSummary,
    buildTopbarStatusMarkup: buildTopbarStatusMarkup,
    updateTopbarElement: updateTopbarElement,
    syncTopbarStatus: syncTopbarStatus,
    startAutoTopbarSync: startAutoTopbarSync,
    getRecentCloseHistory: getRecentCloseHistory,
    getCloseHistory: getCloseHistory,
    getCompanyList: getCompanyList,
    getListedInfo: getListedInfo,
    getLineChartPoints: getLineChartPoints,
    getSimpleLinePath: getSimpleLinePath
  };

  autoMountTopbarSync();
})(window);


// =====================================================
// AI5.3.1 World Date Header UI
// =====================================================
(function(){

  function ensureWorldDateHeader(){
    try {

      var root =
        document.querySelector(".stock-market-panel") ||
        document.querySelector(".stock-panel") ||
        document.querySelector(".market-panel");

      if(!root) return;

      if(document.getElementById("ai5-world-date-box")){
        updateWorldDate();
        return;
      }

      var box = document.createElement("div");
      box.id = "ai5-world-date-box";

      box.style.margin = "12px";
      box.style.padding = "12px";
      box.style.borderRadius = "16px";
      box.style.background =
        "linear-gradient(180deg,#101b33,#0a1120)";
      box.style.border =
        "1px solid rgba(120,160,255,0.18)";
      box.style.boxShadow =
        "0 0 18px rgba(80,120,255,0.12)";
      box.style.color = "#dfe8ff";
      box.style.fontSize = "13px";
      box.style.lineHeight = "1.7";

      root.insertBefore(box, root.children[1]);

      updateWorldDate();

    } catch(e){
      console.error("World date header failed", e);
    }
  }

  function updateWorldDate(){

    var box =
      document.getElementById("ai5-world-date-box");

    if(!box) return;

    var state =
      window.__STOCK_MARKET_STATE__ ||
      window.stockMarketState ||
      window.marketState ||
      {};

    var wc =
      state.worldClimate || {};

    var era =
      (window.AI5_WORLD_ERAS &&
       window.AI5_WORLD_ERAS[0]) ||
      "阿斯特拉帝國曆";

    var year =
      wc.year || 417;

    var month =
      wc.month || "霜火月";

    var day =
      wc.day || 1;

    var season =
      wc.season || "春";

    var weather =
      wc.weather || "晴朗";

    var mood =
      wc.worldMood || "和平繁榮";

    box.innerHTML =
      "📜 <b>" + era + " " + year + "年</b><br>" +
      "🌙 " + month + " " + day + "日　" +
      "☀ " + season + "季<br>" +
      "🌦 天氣：" + weather + "<br>" +
      "🌍 世界狀態：" + mood;
  }

  setInterval(function(){
    ensureWorldDateHeader();
    updateWorldDate();
  }, 1000);

})();

