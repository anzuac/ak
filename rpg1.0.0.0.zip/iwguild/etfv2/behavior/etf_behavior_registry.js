
// =====================================================
// ETF Behavior Registry
// =====================================================

window.ETF_BEHAVIORS =
    window.ETF_BEHAVIORS || {};

ETF_BEHAVIORS.mad_dog = {

    id: 'mad_dog',

    name: '王國戰略資本',

    subtitle: '瘋狗基金',

    rebalanceIntervalDays: 1,

    aggression: 0.95,

    momentumBias: 2.0,

    volatilityBias: 2.5,

    dividendBias: 1.8,

    rapidRotation: true,

    fullLiquidationChance: 0.18
};
