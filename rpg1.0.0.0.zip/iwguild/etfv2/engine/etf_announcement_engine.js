// ETFV2 7.0.0 Announcement Engine
window.ETFAnnouncementEngine = {
  push(etf, text){
    if(!etf) return;

    etf.announcements = etf.announcements || [];
    etf.announcements.unshift({
      day: Date.now(),
      text
    });

    etf.announcements = etf.announcements.slice(0, 30);
  }
};
