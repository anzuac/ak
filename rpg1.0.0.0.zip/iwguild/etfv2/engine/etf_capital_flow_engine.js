// =====================================================
// ETFV2 7.4.0 Capital Flow Engine
// -----------------------------------------------------
// NPC ETF 資金流核心：
// - 只在中央市場日 marketDay 變化時處理一次
// - 資金流入會增加 ETF 現金池與總發行份額
// - 資金流出會消耗 ETF 現金池並回收份額
// - 不直接推升 ETF 市價，避免 ETF 吃自己
// - 實際 ETF 價格仍由 NAV / 權重 / 中央漲跌停控制
// =====================================================
(function(w){
  "use strict";

  var SCALE =
    (w.StockMarketEngine && w.StockMarketEngine.SCALE) ||
    (w.StockMarketCurrency && w.StockMarketCurrency.SCALE) ||
    1000;

  function num(v, d){
    v = Number(v);
    return isFinite(v) ? v : (d || 0);
  }

  function floor(v){
    return Math.floor(num(v, 0));
  }

  function clamp(v, lo, hi){
    v = num(v, lo);
    return Math.max(lo, Math.min(hi, v));
  }

  function getMarketDay(state){
    return Math.max(1, floor(state && state.marketDay || 1));
  }

  function getFundAumMilli(fund){
    return Math.max(
      0,
      floor(
        fund.totalAssetValueMilli ||
        (
          floor(fund.cashReserveMilli || 0) +
          floor(fund.stockAssetValueMilli || 0)
        ) ||
        0
      )
    );
  }

  function getNavMilli(fund){
    return Math.max(
      1,
      floor(
        fund.navMilli ||
        (
          getFundAumMilli(fund) /
          Math.max(1, floor(fund.totalShares || 1))
        ) ||
        (10 * SCALE)
      )
    );
  }

  function ensureFlowState(fund){
    if(!fund.capitalFlow || typeof fund.capitalFlow !== "object"){
      fund.capitalFlow = {
        lastProcessedMarketDay: 0,
        totalNpcInflowMilli: 0,
        totalNpcOutflowMilli: 0,
        lastNetFlowMilli: 0,
        lastFlowShares: 0,
        popularity: 0.50,
        history: []
      };
    }

    if(!Array.isArray(fund.capitalFlow.history)){
      fund.capitalFlow.history = [];
    }

    return fund.capitalFlow;
  }

  function pushFlowHistory(flow, rec){
    flow.history.unshift(rec);
    if(flow.history.length > 30){
      flow.history.length = 30;
    }
  }

  function pushAnnouncement(fund, type, text, marketDay){
    if(!fund) return;

    if(!Array.isArray(fund.announcements)){
      fund.announcements = [];
    }

    var key =
      String(type || "capital_flow") +
      ":" +
      String(marketDay || 0) +
      ":" +
      String(text || "");

    if(fund._lastCapitalFlowAnnouncementKey === key){
      return;
    }

    fund._lastCapitalFlowAnnouncementKey = key;

    fund.announcements.unshift({
      type: type || "capital_flow",
      marketDay: marketDay,
      text: String(text || "ETF 資金流更新")
    });

    if(fund.announcements.length > 30){
      fund.announcements.length = 30;
    }
  }

  function calcPopularity(fund, state){
    var pop = num(
      fund.capitalFlow && fund.capitalFlow.popularity,
      0.50
    );

    var diffPct =
      num(fund.diffPercent, 0);

    // ETF 表現好，NPC 信心微升；跌太多則下降。
    if(diffPct > 0){
      pop += Math.min(0.03, diffPct / 1000);
    }
    else if(diffPct < 0){
      pop -= Math.min(0.04, Math.abs(diffPct) / 800);
    }

    // 市場情緒影響 ETF 資金流。
    var sentiment =
      state && state.climate
        ? num(state.climate.sentiment, 50)
        : 50;

    if(sentiment >= 70) pop += 0.015;
    if(sentiment <= 30) pop -= 0.025;

    // 建倉期 NPC 較保守；上市後資金流較活躍。
    if(fund.status !== "listed"){
      pop -= 0.03;
    }

    return clamp(pop, 0.05, 0.95);
  }

  function processDaily(fund, state){
    if(!fund || !state) return null;

    var marketDay = getMarketDay(state);
    var flow = ensureFlowState(fund);

    // 每個市場日只處理一次，避免 UI getUIData 多次觸發造成資金暴增。
    if(flow.lastProcessedMarketDay === marketDay){
      return flow;
    }

    flow.lastProcessedMarketDay = marketDay;

    var aumMilli =
      Math.max(
        1000000 * SCALE,
        getFundAumMilli(fund)
      );

    var navMilli =
      getNavMilli(fund);

    var popularity =
      calcPopularity(fund, state);

    flow.popularity =
      popularity;

    // NAV 溢價 / 折價
    var nav =
      Math.max(1, navMilli / SCALE);

    var marketPrice =
      Number(
        fund.marketPrice ||
        fund.price ||
        nav
      );

    var premiumPct = 0;

    if(nav > 0){
      premiumPct =
        (marketPrice - nav) / nav;
    }


    // ETF Momentum System
    var buyPressure =
      Number(flow.buyPressure || 0);

    var sellPressure =
      Number(flow.sellPressure || 0);

    var momentum =
      buyPressure - sellPressure;

    // FOMO 追價
    if(premiumPct > 0.08){
      momentum += premiumPct * 2.5;
    }

    // 恐慌賣壓
    if(
      premiumPct < -0.08 &&
      diffPct <= -3
    ){
      momentum -= Math.abs(premiumPct) * 2.2;
    }

    // 抄底資金
    if(
      premiumPct < -0.12 &&
      diffPct > -8
    ){
      momentum += 0.35;
    }

    // 獲利了結
    if(
      premiumPct > 0.15 &&
      diffPct >= 8
    ){
      momentum -= 0.45;
    }

    flow.momentum = momentum;

    // 基礎 NPC ETF 資金流：每日約 AUM 的 0.02% ~ 0.18%
    // 上限保守，避免 NPC 資金使 ETF 爆炸。
    var baseRate =
      0.0002 +
      popularity * 0.0016;

    // 恐慌折返：市場差或 ETF 跌幅較大時可能淨流出。
    var diffPct =
      num(fund.diffPercent, 0);

    var sentiment =
      state && state.climate
        ? num(state.climate.sentiment, 50)
        : 50;

    // ETF 真正恐慌：
    // 必須同時：
    // 1. ETF 本身下跌
    // 2. ETF 出現明顯折價
    // 3. 市場情緒偏弱
    var panic =
      (
        premiumPct <= -0.08 &&
        diffPct <= -3 &&
        sentiment < 30
      );

    var netFlowMilli = 0;

    if(panic){

      // 恐慌市場：贖回增加
      var outRate =
        0.0003 +
        (0.80 - popularity) * 0.0015;

      netFlowMilli =
        -Math.floor(
          aumMilli *
          clamp(outRate, 0.0001, 0.0025)
        );

    }
    else{

      // ETF Momentum Market

      var flowRate =
        baseRate;

      flowRate +=
        (flow.momentum || 0) * 0.0012;

      flowRate =
        clamp(
          flowRate,
          -0.0035,
          0.0050
        );

      netFlowMilli =
        Math.floor(
          aumMilli *
          flowRate
        );


    }

    // 避免小數 / 低價造成 0 股發行。
    var shares =
      Math.floor(
        Math.abs(netFlowMilli) /
        Math.max(1, navMilli)
      );

    if(shares <= 0){
      flow.lastNetFlowMilli = 0;
      flow.lastFlowShares = 0;
      return flow;
    }

    if(netFlowMilli > 0){
      // NPC 認購：基金現金增加、份額同步增加，NAV 不會被憑空拉高。
      fund.cashReserveMilli =
        Math.max(0, floor(fund.cashReserveMilli || 0)) +
        netFlowMilli;

      fund.totalShares =
        Math.max(1, floor(fund.totalShares || 0)) +
        shares;

      flow.totalNpcInflowMilli =
        floor(flow.totalNpcInflowMilli || 0) +
        netFlowMilli;

      flow.lastNetFlowMilli =
        netFlowMilli;

      flow.lastFlowShares =
        shares;

      pushFlowHistory(flow, {
        marketDay: marketDay,
        type: "inflow",
        milli: netFlowMilli,
        shares: shares,
        popularity: Number(popularity.toFixed(3))
      });

      if(marketDay % 10 === 0){
        pushAnnouncement(
          fund,
          "npc_inflow",
          "ETF 買盤逐漸增強，市場熱度持續提升。",
          marketDay
        );
      }
    }
    else{
      // NPC 贖回：優先消耗現金池並回收份額。
      var outMilli =
        Math.min(
          Math.abs(netFlowMilli),
          Math.max(0, floor(fund.cashReserveMilli || 0))
        );

      if(outMilli > 0){
        var redeemShares =
          Math.min(
            shares,
            Math.max(0, floor(fund.totalShares || 0) - 1)
          );

        fund.cashReserveMilli =
          Math.max(
            0,
            floor(fund.cashReserveMilli || 0) -
            outMilli
          );

        fund.totalShares =
          Math.max(
            1,
            floor(fund.totalShares || 1) -
            redeemShares
          );

        flow.totalNpcOutflowMilli =
          floor(flow.totalNpcOutflowMilli || 0) +
          outMilli;

        flow.lastNetFlowMilli =
          -outMilli;

        flow.lastFlowShares =
          -redeemShares;

        pushFlowHistory(flow, {
          marketDay: marketDay,
          type: "outflow",
          milli: outMilli,
          shares: redeemShares,
          popularity: Number(popularity.toFixed(3))
        });

        pushAnnouncement(
          fund,
          "npc_outflow",
          "ETF 市場出現雙向交易，買賣資金持續流動。",
          marketDay
        );
      }
      else{
        flow.lastNetFlowMilli = 0;
        flow.lastFlowShares = 0;
      }
    }

    return flow;
  }

  function getSummary(fund){
    var flow =
      fund && fund.capitalFlow
        ? fund.capitalFlow
        : null;

    if(!flow){
      return {
        popularity: 0,
        lastNetFlowMilli: 0,
        lastFlowShares: 0,
        totalNpcInflowMilli: 0,
        totalNpcOutflowMilli: 0,
        history: []
      };
    }

    return {
      popularity: num(flow.popularity, 0),
      lastNetFlowMilli: floor(flow.lastNetFlowMilli || 0),
      lastFlowShares: floor(flow.lastFlowShares || 0),
      totalNpcInflowMilli: floor(flow.totalNpcInflowMilli || 0),
      totalNpcOutflowMilli: floor(flow.totalNpcOutflowMilli || 0),
      history: Array.isArray(flow.history) ? flow.history : []
    };
  }

  w.ETFCapitalFlowEngine = {
    processDaily: processDaily,
    getSummary: getSummary
  };

})(window);
