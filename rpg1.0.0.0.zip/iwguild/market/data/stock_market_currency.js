

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

// stock_market_currency.js
(function (w) {
  "use strict";

  var SCALE = 1000;

  function ensureCurrency(state) {
    if (!state.currency) {
      state.currency = {
        investCoinMilli: 0,
        dividendCoinMilli: 0,
        goldPerCoin: 10000, // 10000 金幣 = 1.000 投資幣
        stats: {
          fromGoldMilli: 0,
          spentMilli: 0,
          earnedMilli: 0,
          dividendReceivedMilli: 0,
          dividendExchangedMilli: 0
        }
      };
    }

    if (typeof state.currency.investCoinMilli !== "number") {
      state.currency.investCoinMilli = Math.max(0, Math.floor(Number(
        state.currency.investCoinMilli ??
        state.currency.milli ??
        state.currency.balanceMilli ??
        state.currency.coinMilli ??
        0
      )));
    }

    if (typeof state.currency.dividendCoinMilli !== "number") {
      state.currency.dividendCoinMilli = Math.max(0, Math.floor(Number(
        state.currency.dividendCoinMilli ??
        state.currency.dividendMilli ??
        state.currency.dividendBalanceMilli ??
        0
      )));
    }

    delete state.currency.milli;
    delete state.currency.balanceMilli;
    delete state.currency.coinMilli;
    delete state.currency.dividendMilli;
    delete state.currency.dividendBalanceMilli;

    if (!state.currency.stats) {
      state.currency.stats = {
        fromGoldMilli: 0,
        spentMilli: 0,
        earnedMilli: 0,
        dividendReceivedMilli: 0,
        dividendExchangedMilli: 0
      };
    }

    if (typeof state.currency.stats.dividendReceivedMilli !== "number") state.currency.stats.dividendReceivedMilli = 0;
    if (typeof state.currency.stats.dividendExchangedMilli !== "number") state.currency.stats.dividendExchangedMilli = 0;

    return state.currency;
  }

  function getMilli(state) {
    ensureCurrency(state);
    return Math.max(0, Math.floor(Number(state.currency.investCoinMilli || 0)));
  }

  function getInvestMilli(state) {
    return getMilli(state);
  }

  function getDividendMilli(state) {
    ensureCurrency(state);
    return Math.max(0, Math.floor(Number(state.currency.dividendCoinMilli || 0)));
  }

  function addMilli(state, amountMilli) {
    amountMilli = Math.max(0, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);
    state.currency.investCoinMilli += amountMilli;
    state.currency.stats.earnedMilli += amountMilli;
    return state.currency.investCoinMilli;
  }

  function addDividendMilli(state, amountMilli) {
    amountMilli = Math.max(0, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);
    state.currency.dividendCoinMilli += amountMilli;
    state.currency.stats.dividendReceivedMilli += amountMilli;
    return state.currency.dividendCoinMilli;
  }

  function spendMilli(state, amountMilli) {
    amountMilli = Math.max(0, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);

    if (state.currency.investCoinMilli < amountMilli) {
      return { ok: false, reason: "coin_not_enough" };
    }

    state.currency.investCoinMilli -= amountMilli;
    state.currency.stats.spentMilli += amountMilli;
    return { ok: true, remainMilli: state.currency.investCoinMilli };
  }

  function spendDividendMilli(state, amountMilli) {
    amountMilli = Math.max(0, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);

    if (state.currency.dividendCoinMilli < amountMilli) {
      return { ok: false, reason: "dividend_not_enough" };
    }

    state.currency.dividendCoinMilli -= amountMilli;
    return { ok: true, remainMilli: state.currency.dividendCoinMilli };
  }

  function exchangeDividendToInvest(state, amountMilli) {
    amountMilli = Math.max(1, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);

    if (state.currency.dividendCoinMilli < amountMilli) {
      return { ok: false, reason: "dividend_not_enough" };
    }

    state.currency.dividendCoinMilli -= amountMilli;
    state.currency.investCoinMilli += amountMilli;
    state.currency.stats.earnedMilli += amountMilli;
    state.currency.stats.dividendExchangedMilli += amountMilli;

    return {
      ok: true,
      spendMilli: amountMilli,
      gainMilli: amountMilli,
      remainDividendMilli: state.currency.dividendCoinMilli,
      remainInvestMilli: state.currency.investCoinMilli
    };
  }

  function exchangeGold(state, amountMilli) {
    amountMilli = Math.max(1, Math.floor(Number(amountMilli || 0)));
    ensureCurrency(state);

    if (!w.player) return { ok: false, reason: "player_missing" };

    var costGold = Math.round(amountMilli * state.currency.goldPerCoin / SCALE);
    var gold = Math.floor(Number(w.player.gold || 0));

    if (gold < costGold) return { ok: false, reason: "gold_not_enough" };

    w.player.gold = gold - costGold;
    state.currency.investCoinMilli += amountMilli;
    state.currency.stats.fromGoldMilli += amountMilli;

    if (typeof w.updateResourceUI === "function") {
      w.updateResourceUI();
    }

    return {
      ok: true,
      gainMilli: amountMilli,
      costGold: costGold,
      remainGold: w.player.gold
    };
  }

  w.StockMarketCurrency = {
    SCALE: SCALE,
    ensureCurrency: ensureCurrency,
    getMilli: getMilli,
    getInvestMilli: getInvestMilli,
    getDividendMilli: getDividendMilli,
    addMilli: addMilli,
    addInvestMilli: addMilli,
    addDividendMilli: addDividendMilli,
    spendMilli: spendMilli,
    spendInvestMilli: spendMilli,
    spendDividendMilli: spendDividendMilli,
    exchangeDividendToInvest: exchangeDividendToInvest,
    exchangeGold: exchangeGold
  };
})(window);