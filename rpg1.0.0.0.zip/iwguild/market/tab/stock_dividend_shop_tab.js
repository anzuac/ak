
(function(w){

  var TAB_ID = "dividend_shop";
  var activePage = "exchange";
  function getState(){
    return w.StockStateManager && w.StockStateManager.getState
      ? w.StockStateManager.getState()
      : null;
  }

  function getDividendMilli(){
    var state = getState();
    if(!state) return 0;
    if(w.StockMarketCurrency && typeof w.StockMarketCurrency.getDividendMilli === "function"){
      return Number(w.StockMarketCurrency.getDividendMilli(state) || 0);
    }
    return Number(state.currency && state.currency.dividendCoinMilli || 0);
  }

  function getInvestMilli(){
    var state = getState();
    if(!state) return 0;
    if(w.StockMarketCurrency && typeof w.StockMarketCurrency.getMilli === "function"){
      return Number(w.StockMarketCurrency.getMilli(state) || 0);
    }
    return Number(state.currency && state.currency.investCoinMilli || 0);
  }

  function spendDividendMilli(amountMilli){
    var state = getState();
    if(!state) return { ok:false, reason:"no_state" };
    if(w.StockMarketCurrency && typeof w.StockMarketCurrency.spendDividendMilli === "function"){
      return w.StockMarketCurrency.spendDividendMilli(state, amountMilli);
    }
    state.currency = state.currency || {};
    if(Number(state.currency.dividendCoinMilli || 0) < amountMilli){
      return { ok:false, reason:"dividend_not_enough" };
    }
    state.currency.dividendCoinMilli -= amountMilli;
    return { ok:true };
  }

  function addInvestMilli(amountMilli){
    var state = getState();
    if(!state) return;
    if(w.StockMarketCurrency && typeof w.StockMarketCurrency.addMilli === "function"){
      w.StockMarketCurrency.addMilli(state, amountMilli);
    }else{
      state.currency = state.currency || {};
      state.currency.investCoinMilli = Number(state.currency.investCoinMilli || 0) + amountMilli;
    }
  }

  function saveState(){
    if(w.StockStateManager && typeof w.StockStateManager.save === "function"){
      w.StockStateManager.save();
    }
  }
function showToast(msg){
    alert(msg);
  }

  function render(body){

    var playerDividendMilli = getDividendMilli();
    var playerInvestCoinMilli = getInvestMilli();
    var playerDividend = playerDividendMilli / 1000;
    var playerInvestCoin = playerInvestCoinMilli / 1000;

    body.innerHTML = `
    <style>

      .ds-wrap{
        display:flex;
        flex-direction:column;
        gap:12px;
        padding:10px;
        color:#fff;
      }

      .ds-tabs{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:8px;
      }

      .ds-tab{
        border:0;
        border-radius:12px;
        padding:11px;
        font-weight:900;
        background:#374151;
        color:#fff;
      }

      .ds-tab.active{
        background:#22c55e;
      }

      .ds-card{
        background:#0b1220;
        border:1px solid #263247;
        border-radius:16px;
        padding:12px;
      }

      .ds-title{
        font-size:18px;
        font-weight:900;
        margin-bottom:10px;
      }

      .ds-grid{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:8px;
      }

      .ds-stat{
        background:#111827;
        border-radius:12px;
        padding:10px;
      }

      .ds-label{
        opacity:.7;
        font-size:12px;
      }

      .ds-value{
        font-size:22px;
        font-weight:900;
        margin-top:4px;
      }

      .ds-input{
        width:100%;
        box-sizing:border-box;
        border:1px solid #334155;
        background:#0f172a;
        color:#fff;
        border-radius:12px;
        padding:12px;
        margin-top:10px;
      }

      .ds-btn{
        width:100%;
        border:0;
        border-radius:12px;
        padding:11px;
        font-weight:900;
        margin-top:10px;
        color:#fff;
      }

      .ds-blue{ background:#2563eb; }
      .ds-green{ background:#16a34a; }
      .ds-red{ background:#dc2626; }

      .ds-quick{
        display:grid;
        grid-template-columns:repeat(4,1fr);
        gap:6px;
        margin-top:10px;
      }

      .ds-quick button{
        border:1px solid #334155;
        background:#111827;
        color:#fff;
        border-radius:10px;
        padding:8px;
        font-weight:700;
      }

      .ds-item{
        background:#111827;
        border-radius:14px;
        padding:12px;
        margin-top:10px;
      }

      @media(max-width:768px){

        .ds-wrap{
          padding:8px;
        }

        .ds-value{
          font-size:18px;
        }

        .ds-quick{
          grid-template-columns:1fr 1fr;
        }

      }

    </style>

    <div class="ds-wrap">

      <div class="ds-tabs">
        <button id="exchangeTab"
          class="ds-tab ${activePage === 'exchange' ? 'active' : ''}">
          💱 股利兌換
        </button>

        <button id="shopTab"
          class="ds-tab ${activePage === 'shop' ? 'active' : ''}">
          🛒 股利商店
        </button>
      </div>

      <div style="font-size:14px;opacity:.9;">
        目前持有股利幣：
        <span style="color:#22c55e;font-weight:900;">
          ${playerDividend.toFixed(3)}
        </span>
      </div>

      <div id="exchangePage"
        style="display:${activePage === 'exchange' ? 'block' : 'none'}">

        <div class="ds-card">

          <div class="ds-title">💱 股利幣兌換投資幣</div>

          <div class="ds-grid">

            <div class="ds-stat">
              <div class="ds-label">股利幣</div>
              <div class="ds-value">
                ${playerDividend.toFixed(3)}
              </div>
            </div>

            <div class="ds-stat">
              <div class="ds-label">投資幣</div>
              <div class="ds-value" style="color:#facc15;">
                ${playerInvestCoin.toFixed(3)}
              </div>
            </div>

          </div>

          <input id="exchangeInput"
            class="ds-input"
            type="number"
            placeholder="輸入要兌換的股利幣">

          <button id="exchangeConfirm"
            class="ds-btn ds-blue">
            確認兌換
          </button>

          <div class="ds-quick">
            <button class="quickBtn" data-value="1">+1</button>
            <button class="quickBtn" data-value="5">+5</button>
            <button class="quickBtn" data-value="10">+10</button>
            <button id="allBtn">全部</button>
          </div>

        </div>

      </div>

      <div id="shopPage"
        style="display:${activePage === 'shop' ? 'block' : 'none'}">

        <div class="ds-card">

          <div class="ds-title">🎁 股利商品</div>

          ${renderShopItem("潛能方塊",4,"green")}
          ${renderShopItem("高級潛能方塊",10,"blue")}
          ${renderShopItem("緩爆護符",13,"red")}

        </div>

      </div>

    </div>
    `;

    bindEvents(body);

  }


  function getInventoryCount(name){

    if(typeof w.getItemQuantity === "function"){
      return Number(w.getItemQuantity(name) || 0);
    }

    if(w.Inventory && typeof w.Inventory.getItemQuantity === "function"){
      return Number(w.Inventory.getItemQuantity(name) || 0);
    }

    return 0;
  }


  function renderShopItem(name,cost,color){

    var btnClass = "ds-green";

    if(color === "blue") btnClass = "ds-blue";
    if(color === "red") btnClass = "ds-red";

    return `
      <div class="ds-item">

        <div style="font-size:20px;font-weight:900;">
          ${name}
        </div>

        <div style="opacity:.7;margin-top:6px;">
          需要 ${cost} 股利幣<br>目前背包：${getInventoryCount(name)} 個
        </div>

        <input
          type="number"
          class="ds-input itemAmount"
          data-cost="${cost}"
          placeholder="輸入購買數量">

        <button
          class="ds-btn ${btnClass} buyBtn"
          data-cost="${cost}"
          data-name="${name}">
          購買
        </button>

      </div>
    `;
  }

  function bindEvents(body){

    body.querySelector("#exchangeTab").onclick = function(){
      activePage = "exchange";
      render(body);
    };

    body.querySelector("#shopTab").onclick = function(){
      activePage = "shop";
      render(body);
    };

    var input = body.querySelector("#exchangeInput");

    body.querySelectorAll(".quickBtn").forEach(function(btn){

      btn.onclick = function(){

        var value = Number(btn.dataset.value || 0);
        var current = Number(input.value || 0);

        input.value = current + value;

      };

    });

    body.querySelector("#allBtn").onclick = function(){
      input.value = playerDividend;
    };

    body.querySelector("#exchangeConfirm").onclick = function(){

      var amount = Number(input.value || 0);

      if(amount <= 0){
        showToast("請輸入數量");
        return;
      }

      if(amount > playerDividend){
        showToast("股利幣數量不足");
        return;
      }

      var milli = Math.floor(amount * 1000);
      var spent = spendDividendMilli(milli);
      if(!spent || !spent.ok){
        showToast("股利幣數量不足");
        return;
      }
      addInvestMilli(milli);
      saveState();

      showToast("兌換成功");
      render(body);

    };

    body.querySelectorAll(".buyBtn").forEach(function(btn){

      btn.onclick = function(){

        var cost = Number(btn.dataset.cost || 0);
        var name = btn.dataset.name;

        var parent = btn.closest(".ds-item");
        var amountInput = parent.querySelector(".itemAmount");

        var amount = Number(amountInput.value || 0);

        if(amount <= 0){
          showToast("請輸入購買數量");
          return;
        }

        var totalCost = cost * amount;

        if(totalCost > playerDividend){
          showToast("股利幣數量不足");
          return;
        }

        var spent = spendDividendMilli(Math.floor(totalCost * 1000));
        if(!spent || !spent.ok){
          showToast("股利幣數量不足");
          return;
        }

        // 接線到背包 inventory.js
        if(typeof w.addItem === "function"){
          w.addItem(name, amount);
        }
        else if(w.Inventory && typeof w.Inventory.addItem === "function"){
          w.Inventory.addItem(name, amount);
        }

        showToast(
          "成功購買 " + amount + " 個 " + name + "（已送入背包）"
        );

        saveState();
        render(body);

      };

    });

  }

  function update(){}
  function onClose(){}

  w.StockHub = w.StockHub || {
    registerTab:function(){}
  };

  w.StockHub.registerTab({
    id:TAB_ID,
    title:"股利商店",
    render:render,
    update:update,
    onClose:onClose
  });

})(window);
