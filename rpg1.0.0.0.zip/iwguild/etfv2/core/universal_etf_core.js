// ETFV2 7.2.0 Universal ETF Core — Central State Integrated
(function(w){
  "use strict";

  var SCALE =
    (w.StockMarketEngine && w.StockMarketEngine.SCALE) ||
    (w.StockMarketCurrency && w.StockMarketCurrency.SCALE) ||
    1000;


  var ETF_TRADE_FEE_RATE = 0.0005;

  

  // ETF 市場買賣手續費 0.05%；認購不收

  function ensureGlobalStats(state){
    if(!state.stats || typeof state.stats !== "object"){
      state.stats = {};
    }
    state.stats.realizedProfitMilli = floor(state.stats.realizedProfitMilli || 0);
    state.stats.totalFeesMilli = floor(state.stats.totalFeesMilli || 0);
    return state.stats;
  }

  function calcEtfTradeFeeMilli(amountMilli){
    return Math.floor(Math.max(0, floor(amountMilli || 0)) * ETF_TRADE_FEE_RATE);
  }

  function payEtfDividendToPlayer(state, fund, perShareMilli, marketDay){
    if(!state || !fund || !perShareMilli) return 0;
    var h = getHolding(state, fund.id);
    var qty = Math.max(0, floor(h && h.qty || 0));
    if(qty <= 0) return 0;

    var payout = Math.floor(qty * floor(perShareMilli || 0));
    if(payout <= 0) return 0;

    if(w.StockMarketCurrency && typeof w.StockMarketCurrency.addDividendMilli === "function"){
      w.StockMarketCurrency.addDividendMilli(state, payout);
    }else{
      if(!state.currency) state.currency = {};
      state.currency.dividendCoinMilli = floor(state.currency.dividendCoinMilli || 0) + payout;
      if(!state.currency.stats) state.currency.stats = {};
      state.currency.stats.dividendReceivedMilli = floor(state.currency.stats.dividendReceivedMilli || 0) + payout;
    }

    var stats = ensureGlobalStats(state);
    stats.lastDividendIncomeMilli = payout;
    stats.totalDividendIncomeMilli = floor(stats.totalDividendIncomeMilli || 0) + payout;
    stats.lastEtfDividendMilli = payout;

    if(!state.currency) state.currency = {};
    if(!state.currency.stats) state.currency.stats = {};
    state.currency.stats.dividendReceivedMilli =
      floor(state.currency.stats.dividendReceivedMilli || 0) + payout;
    stats.totalEtfDividendMilli = floor(stats.totalEtfDividendMilli || 0) + payout;

    pushAnnouncement(
      fund,
      "player_dividend_paid",
      "玩家 ETF 配息入帳：" + (payout / SCALE).toFixed(3) + " 股利幣。",
      marketDay || state.marketDay || 1
    );

    return payout;
  }

  var ETF_NS = "etfV2";
  var registry = {};
  var activeIds = [];

  function num(v, d){
    v = Number(v);
    return isFinite(v) ? v : (d || 0);
  }

  function floor(v){
    return Math.floor(num(v, 0));
  }

  function clamp(v, lo, hi){
    v = num(v, lo);
    return Math.max(lo, Math.min(hi, v));
  }

  function marketState(){
    if(!w.StockStateManager || !w.StockStateManager.getState) return null;
    return w.StockStateManager.getState();
  }

  function saveMarketState(){
    if(w.StockStateManager && w.StockStateManager.save){
      w.StockStateManager.save();
    }
  }

  function ensureRoot(state){
    if(!state) return null;
    if(!state[ETF_NS] || typeof state[ETF_NS] !== "object"){
      state[ETF_NS] = {
        _ver: 2,
        funds: {},
        playerHoldings: {}
      };
    }
    if(!state[ETF_NS].funds) state[ETF_NS].funds = {};
    if(!state[ETF_NS].playerHoldings) state[ETF_NS].playerHoldings = {};
    return state[ETF_NS];
  }

  function defaultFund(config, state){
    var nowDay = Math.max(1, floor(state && state.marketDay || 1));
    var initialCapitalMilli = floor(num(config.initialCapital, 100000000) * SCALE);
    var initialPriceMilli = floor(num(config.initialPrice, 10) * SCALE);
    var totalShares = floor(num(config.totalShares, 10000000));

    return {
      id: config.id,
      name: config.title || "商會龍頭基金",
      type: "etf",
      fundType: "etf",
      isETF: true,
      status: "building",

      createdDay: nowDay,
      listedDay: null,
      lastProcessedMarketDay: 0,
      lastRebalanceDay: 0,
      lastDividendDay: 0,
      lastAnnouncementDay: 0,

      initialCapitalMilli: initialCapitalMilli,
      cashReserveMilli: initialCapitalMilli,
      totalShares: totalShares,

      navMilli: initialPriceMilli,
      marketPriceMilli: initialPriceMilli,
      dayOpenPriceMilli: initialPriceMilli,
      lastClosePriceMilli: initialPriceMilli,
      previousClosePrice: initialPriceMilli,
      currentPriceMilli: initialPriceMilli,

      totalAssetValueMilli: initialCapitalMilli,
      stockAssetValueMilli: 0,

      validCompanyCount: 0,
      maxHoldings: floor(num(config.maxHoldings, 20)),
      rebalanceDays: floor(num(config.rebalanceDays, 30)),
      playerOwnershipLimit: num(config.playerOwnershipLimit, 0.001),

      holdings: [],
      rebalanceChanges: [],
      announcements: [],
      dividendAnnouncement: "尚無公告",
      pendingDividendMilli: 0,
      marketBuyVolume: 0,
      marketSellVolume: 0,
      marketPressure: 0
    };
  }

  function pushAnnouncement(fund, type, text, marketDay){
    if(!fund) return;
    marketDay = Math.max(1, floor(marketDay || 1));

    // 同一天同類公告只保留一次，避免自動更新狂洗公告。
    var key = String(type || "notice") + ":" + String(marketDay) + ":" + String(text || "");
    if(fund._lastAnnouncementKey === key) return;

    fund._lastAnnouncementKey = key;
    if(!Array.isArray(fund.announcements)) fund.announcements = [];
    fund.announcements.unshift({
      type: type || "notice",
      marketDay: marketDay,
      text: String(text || "ETF 更新")
    });
    if(fund.announcements.length > 30) fund.announcements.length = 30;
  }

  function ensureFundInState(id, state){
    state = state || marketState();
    if(!state) return null;

    var root = ensureRoot(state);
    var config = registry[id] || {
      id: id,
      title: "商會龍頭基金",
      initialCapital: 100000000,
      initialPrice: 10,
      totalShares: 10000000,
      maxHoldings: 20,
      rebalanceDays: 30,
      playerOwnershipLimit: 0.001
    };

    if(!root.funds[id]){
      root.funds[id] = defaultFund(config, state);
      pushAnnouncement(root.funds[id], "create", "商會龍頭基金開始建倉。", state.marketDay || 1);
    }

    var f = root.funds[id];

    // 補舊資料欄位。
    if(!Array.isArray(f.holdings)) f.holdings = [];
    if(!Array.isArray(f.announcements)) f.announcements = [];
    if(!Array.isArray(f.rebalanceChanges)) f.rebalanceChanges = [];

    if(!(f.totalShares > 0)) f.totalShares = floor(num(config.totalShares, 10000000));
    if(!(f.cashReserveMilli >= 0)) f.cashReserveMilli = floor(num(config.initialCapital, 100000000) * SCALE);
    if(!(f.navMilli > 0)) f.navMilli = floor(num(config.initialPrice, 10) * SCALE);
    if(!(f.marketPriceMilli > 0)) f.marketPriceMilli = f.navMilli;
    if(!(f.dayOpenPriceMilli > 0)) f.dayOpenPriceMilli = f.marketPriceMilli;
    if(!(f.lastClosePriceMilli > 0)) f.lastClosePriceMilli = f.dayOpenPriceMilli;
    if(!(f.currentPriceMilli > 0)) f.currentPriceMilli = f.marketPriceMilli;
    if(!f.status) f.status = "building";
    if(!(f.maxHoldings > 0)) f.maxHoldings = floor(num(config.maxHoldings, 20));
    if(!(f.rebalanceDays > 0)) f.rebalanceDays = floor(num(config.rebalanceDays, 30));
    if(!(f.playerOwnershipLimit > 0)) f.playerOwnershipLimit = num(config.playerOwnershipLimit, 0.001);
    if(!f.name) f.name = config.title || "商會龍頭基金";
    f.isETF = true;
    f.fundType = "etf";
    f.type = "etf";

    return f;
  }

  function getAssets(state){
    var arr = [];
    if(!state || !state.assets) return arr;

    for(var id in state.assets){
      if(!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var a = state.assets[id];
      if(!a) continue;
      if(!a.unlocked) continue;
      if(a.isDelisted) continue;

      var price = floor(a.price || a.currentPriceMilli || a.priceMilli || 0);
      if(price <= 0) continue;

      arr.push(a);
    }

    arr.sort(function(a,b){
      var ap = floor(a.price || a.currentPriceMilli || a.priceMilli || 0);
      var bp = floor(b.price || b.currentPriceMilli || b.priceMilli || 0);
      var ac = ap * Math.max(1, floor(a.totalShares || a.floatShares || 1));
      var bc = bp * Math.max(1, floor(b.totalShares || b.floatShares || 1));
      return bc - ac;
    });

    return arr;
  }

  function targetWeights(count){
    // 金字塔權重基準，成分不足時自動 normalize。
    var base = [0.30,0.20,0.12,0.08,0.05,0.04,0.035,0.03,0.025,0.02,0.015,0.012,0.01,0.009,0.008,0.007,0.006,0.005,0.004,0.001];
    var out = [];
    var sum = 0;
    for(var i=0;i<count;i++){
      out.push(base[i] || 0.001);
      sum += out[i];
    }
    if(sum <= 0) sum = count || 1;
    for(var j=0;j<out.length;j++) out[j] = out[j] / sum;
    return out;
  }

  function repriceHoldings(fund, state){
    var assets = state && state.assets ? state.assets : {};
    var stockValue = 0;
    var holdings = [];

    for(var i=0;i<(fund.holdings || []).length;i++){
      var h = fund.holdings[i] || {};
      var a = assets[h.assetId];
      if(!a || a.isDelisted){
        continue;
      }
      var price = Math.max(1, floor(a.price || a.currentPriceMilli || a.priceMilli || h.priceMilli || 1));
      var shares = Math.max(0, floor(h.sharesHeld || 0));
      var mv = shares * price;

      h.priceMilli = price;
      h.marketValueMilli = mv;
      h.marketValue = mv;
      h.name = h.name || a.name || a.shortName || h.assetId;
      stockValue += mv;
      holdings.push(h);
    }

    fund.holdings = holdings;
    fund.stockAssetValueMilli = stockValue;
    fund.totalAssetValueMilli = Math.max(1, floor(fund.cashReserveMilli || 0) + stockValue);
    fund.navMilli = Math.max(1, Math.floor(fund.totalAssetValueMilli / Math.max(1, floor(fund.totalShares || 1))));
    fund.currentPriceMilli = fund.marketPriceMilli;
  }

  function clampETFPrice(fund, nextPriceMilli){
    nextPriceMilli = Math.max(1, floor(nextPriceMilli));
    if(w.AI5MarketControl && typeof w.AI5MarketControl.applyMarketLimitClamp === "function"){
      return w.AI5MarketControl.applyMarketLimitClamp(fund, nextPriceMilli);
    }
    return nextPriceMilli;
  }

  function updateETFMarketPrice(fund){

    if(
      fund &&
      fund.trackingMode === "mad_dog"
    ){
      return;
    }
    var prev = Math.max(1, floor(fund.lastClosePriceMilli || fund.dayOpenPriceMilli || fund.marketPriceMilli || fund.navMilli || 10000));
    var nav = Math.max(1, floor(fund.navMilli || prev));

    var buyVolume = Math.max(0, floor(fund.marketBuyVolume || 0));
    var sellVolume = Math.max(0, floor(fund.marketSellVolume || 0));
    var totalShares = Math.max(1, floor(fund.totalShares || 1));

    var netFlow = buyVolume - sellVolume;

    var pressure = netFlow / totalShares;

    // 非線性市場推力
    var impact = pressure * 0.45;

    if(Math.abs(pressure) > 0.08){
      impact *= 2.2;
    }

    fund.marketPressure =
      Number(fund.marketPressure || 0) + impact;

    // 市場情緒緩慢衰退
    fund.marketPressure *= 0.92;

    // ETF 市價以 NAV 為核心，再受市場資金流影響
    var targetPrice =
      nav * (1 + fund.marketPressure);

    var gap = targetPrice - prev;

    // 每次只收斂部分，避免瞬間暴衝
    var next = prev + Math.floor(gap * 0.22);

    if(fund.status !== "listed"){
      next = nav;
    }

    next = clampETFPrice(fund, next);

    fund.marketPriceMilli = Math.max(1, next);

    // 重置市場成交量
    fund.marketBuyVolume = 0;
    fund.marketSellVolume = 0;
    fund.currentPriceMilli = fund.marketPriceMilli;
    if(!(fund.dayHighPriceMilli > 0) || fund.marketPriceMilli > fund.dayHighPriceMilli) fund.dayHighPriceMilli = fund.marketPriceMilli;
    if(!(fund.dayLowPriceMilli > 0) || fund.marketPriceMilli < fund.dayLowPriceMilli) fund.dayLowPriceMilli = fund.marketPriceMilli;

    fund.diffMilli = fund.marketPriceMilli - prev;
    fund.diffPercent = prev > 0 ? (fund.diffMilli / prev) * 100 : 0;
  }

  function dailyPassiveBuy(fund, state, marketDay){

    if(
      fund &&
      fund.trackingMode === "mad_dog"
    ){
      return;
    }
    var assets = getAssets(state);
    fund.validCompanyCount = assets.length;

    var max = Math.max(1, floor(fund.maxHoldings || 20));
    var selected = assets.slice(0, max);
    var weights = targetWeights(selected.length);
    var oldMap = {};
    var changes = [];

    for(var oi=0; oi<(fund.holdings || []).length; oi++){
      var oh = fund.holdings[oi] || {};
      if(oh.assetId) oldMap[oh.assetId] = oh;
    }

    var next = [];
    var dailyBudget = 0;

    if(selected.length > 0 && fund.cashReserveMilli > 0){
      // 每個市場日最多投入剩餘現金 8%，最低保留 3% 現金。
      var reserveFloor = Math.floor(fund.totalAssetValueMilli * 0.03);
      var usable = Math.max(0, floor(fund.cashReserveMilli) - reserveFloor);
      dailyBudget = Math.min(usable, Math.floor(fund.cashReserveMilli * 0.08));
    }

    for(var i=0;i<selected.length;i++){
      var a = selected[i];
      var price = Math.max(1, floor(a.price || a.currentPriceMilli || a.priceMilli || 1));
      var id = a.id;
      var old = oldMap[id] || {};
      var oldShares = Math.max(0, floor(old.sharesHeld || 0));
      var buyBudget = Math.floor(dailyBudget * (weights[i] || 0));
      var addShares = buyBudget > 0 ? Math.floor(buyBudget / price) : 0;
      var spend = addShares * price;

      if(spend > fund.cashReserveMilli){
        addShares = Math.floor(fund.cashReserveMilli / price);
        spend = addShares * price;
      }

      fund.cashReserveMilli = Math.max(0, floor(fund.cashReserveMilli) - spend);

      var shares = oldShares + addShares;
      var marketValue = shares * price;
      var oldCost = floor(old.avgCostMilli || price);
      var avgCost = shares > 0
        ? Math.floor(((oldShares * oldCost) + spend) / Math.max(1, shares))
        : price;

      var action = !old.assetId ? "new" : (addShares > 0 ? "increase" : "same");

      next.push({
        assetId: id,
        symbol: a.symbol,
        name: a.name || a.shortName || id,
        rank: i + 1,
        weight: weights[i] || 0,
        sharesHeld: shares,
        oldSharesHeld: oldShares,
        avgCostMilli: avgCost,
        priceMilli: price,
        marketValueMilli: marketValue,
        marketValue: marketValue,
        etfOwnershipPercent: (shares / Math.max(1, floor(a.totalShares || a.floatShares || 1))) * 100,
        tier: a.tier,
        marketType: a.marketType,
        changeType: action,
        rankStatus: action === "new" ? "（新）" : ""
      });

      if(action !== "same"){
        changes.push({
          action: action,
          assetId: id,
          name: a.name || a.shortName || id,
          oldShares: oldShares,
          newShares: shares
        });
      }
    }

    // 被移除成分，只在月重平衡公告顯示；此版直接移出 ETF 持倉，資產回收為現金。
    for(var oldId in oldMap){
      if(!Object.prototype.hasOwnProperty.call(oldMap, oldId)) continue;
      var exists = false;
      for(var ni=0; ni<next.length; ni++){
        if(next[ni].assetId === oldId){ exists = true; break; }
      }
      if(!exists){
        var removed = oldMap[oldId];
        fund.cashReserveMilli += floor(removed.marketValueMilli || removed.marketValue || 0);
        changes.push({
          action: "removed",
          assetId: oldId,
          name: removed.name || oldId,
          oldShares: floor(removed.sharesHeld || 0),
          newShares: 0
        });
      }
    }

    fund.holdings = next;
    fund.rebalanceChanges = changes;

    var minToList = max;

if (
  fund &&
  fund.id === "mad_dog_fund"
) {
  minToList = 10;
}

if (
  fund.holdings &&
  fund.holdings.length >= minToList &&
  fund.status === "building"
) {
      fund.status = "listed";
      fund.listedDay = marketDay;
      pushAnnouncement(fund, "listing", "商會龍頭基金建倉完成，正式進入上市追蹤。", marketDay);
    }

    if(marketDay > 1 && marketDay % Math.max(1, floor(fund.rebalanceDays || 30)) === 0 && fund.lastRebalanceDay !== marketDay){
      fund.lastRebalanceDay = marketDay;
      pushAnnouncement(fund, "rebalance", "商會龍頭基金完成月度龍頭成分調整。", marketDay);
    }

    // 股利公告 / 發放，只按市場日觸發，不可每秒觸發。
    var cycle = (w.AI5MarketControl && w.AI5MarketControl.config && w.AI5MarketControl.config.DIVIDEND_CYCLE_DAYS) || 30;
    var announceDay = (w.AI5MarketControl && w.AI5MarketControl.config && w.AI5MarketControl.config.DIVIDEND_ANNOUNCE_DAY) || 25;
    var dayInCycle = ((marketDay - 1) % cycle) + 1;

    if(dayInCycle === announceDay && fund.lastAnnouncementDay !== marketDay){
      fund.lastAnnouncementDay = marketDay;
      fund.pendingDividendMilli = Math.max(0, Math.floor((fund.navMilli || 10000) * 0.002));
      fund.dividendAnnouncement = "預估配息 " + ((fund.pendingDividendMilli || 0) / SCALE).toFixed(3) + "｜第 " + cycle + " 天發放";
      pushAnnouncement(fund, "dividend_announce", fund.dividendAnnouncement, marketDay);
    }

    if(dayInCycle === cycle && fund.lastDividendDay !== marketDay){
      fund.lastDividendDay = marketDay;
      if(fund.pendingDividendMilli > 0){
        // 除息：NAV/市價扣除配息，現金等額流出。
        var totalDividend = Math.floor(fund.pendingDividendMilli * Math.max(1, floor(fund.totalShares || 1)));
        fund.cashReserveMilli = Math.max(0, floor(fund.cashReserveMilli || 0) - totalDividend);
        fund.navMilli = Math.max(1, floor(fund.navMilli || 10000) - floor(fund.pendingDividendMilli || 0));
        fund.marketPriceMilli = Math.max(1, floor(fund.marketPriceMilli || fund.navMilli) - floor(fund.pendingDividendMilli || 0));

        var playerDividend = payEtfDividendToPlayer(state, fund, fund.pendingDividendMilli, marketDay);
        pushAnnouncement(
          fund,
          "dividend_paid",
          "商會龍頭基金完成配息並除息。" + (playerDividend > 0 ? " 玩家入帳 " + (playerDividend / SCALE).toFixed(3) + " 股利幣。" : ""),
          marketDay
        );
      }
      fund.pendingDividendMilli = 0;
      fund.dividendAnnouncement = "尚無公告";
    }
  }

  function syncFund(id, options){
    var state = marketState();
    if(!state) return null;

    var fund = ensureFundInState(id, state);
    if(!fund) return null;

    var marketDay = Math.max(1, floor(state.marketDay || 1));

    // 每次可重新估值，但買入/公告/重平衡一天只執行一次。
    repriceHoldings(fund, state);

    if(options && options.force){
      fund.lastProcessedMarketDay = 0;
    }

    if(fund.lastProcessedMarketDay !== marketDay){
      fund.lastProcessedMarketDay = marketDay;

      // 每個新市場日重設 ETF 開盤基準。
      fund.lastClosePriceMilli = Math.max(1, floor(fund.marketPriceMilli || fund.navMilli || 10000));
      fund.dayOpenPriceMilli = fund.lastClosePriceMilli;
      fund.dayHighPriceMilli = fund.dayOpenPriceMilli;
      fund.dayLowPriceMilli = fund.dayOpenPriceMilli;
      fund.previousClosePrice = fund.dayOpenPriceMilli;

      dailyPassiveBuy(fund, state, marketDay);

      if(
        fund &&
        fund.trackingMode === "mad_dog" &&
        w.MadDogETFEngine &&
        typeof w.MadDogETFEngine.update === "function"
      ){
        w.MadDogETFEngine.update(
          fund,
          state,
          marketDay
        );
      }
      repriceHoldings(fund, state);

      // ETFV2 7.4.0：NPC ETF 資金流由中央市場日驅動，每日只處理一次。
      if(w.ETFCapitalFlowEngine && typeof w.ETFCapitalFlowEngine.processDaily === "function"){
        try{
          w.ETFCapitalFlowEngine.processDaily(fund, state);
        }catch(e){
          console.error("ETFCapitalFlowEngine processDaily error", e);
        }
      }

      repriceHoldings(fund, state);
    }

    updateETFMarketPrice(fund);

    return fund;
  }

  function getHolding(state, id){
    var root = ensureRoot(state);
    var h = root.playerHoldings[id];
    if(!h){
      h = root.playerHoldings[id] = {
        qty: 0,
        avgCostMilli: 0
      };
    }
    return h;
  }

  function maxPlayerShares(fund){
    return Math.max(1, Math.floor(Math.max(1, floor(fund.totalShares || 1)) * num(fund.playerOwnershipLimit, 0.001)));
  }

  function spend(state, milli){
    if(w.StockMarketCurrency && w.StockMarketCurrency.spendMilli){
      return w.StockMarketCurrency.spendMilli(state, milli);
    }
    if(!state.currency) state.currency = {};
    var cur = floor(state.currency.investCoinMilli || 0);
    if(cur < milli) return { ok:false, reason:"coin_not_enough" };
    state.currency.investCoinMilli = cur - milli;
    return { ok:true };
  }

  
  function addMarketFlow(fund, buyVolume, sellVolume){
    if(!fund) return;

    fund.marketBuyVolume =
      Math.max(0, floor(fund.marketBuyVolume || 0))
      + Math.max(0, floor(buyVolume || 0));

    fund.marketSellVolume =
      Math.max(0, floor(fund.marketSellVolume || 0))
      + Math.max(0, floor(sellVolume || 0));
  }

function addCoin(state, milli){
    if(w.StockMarketCurrency && w.StockMarketCurrency.addMilli){
      w.StockMarketCurrency.addMilli(state, milli);
      return;
    }
    if(!state.currency) state.currency = {};
    state.currency.investCoinMilli = floor(state.currency.investCoinMilli || 0) + floor(milli || 0);
  }

  function buyOrSubscribe(id, qty, subscribe){
    var state = marketState();
    if(!state) return { ok:false, reason:"no_state" };
    var fund = syncFund(id);
    if(!fund) return { ok:false, reason:"no_fund" };

    qty = Math.max(1, floor(qty || 1));

    if(!subscribe && fund.status !== "listed"){
      return { ok:false, reason:"fund_building" };
    }

    var h = getHolding(state, id);
    var max = maxPlayerShares(fund);
    if(h.qty + qty > max){
      return { ok:false, reason:"etf_holding_limit" };
    }

    var price = subscribe ? (10 * SCALE) : Math.max(1, floor(fund.marketPriceMilli || fund.navMilli || 10000));
    var grossCost = price * qty;
    var feeMilli = subscribe ? 0 : calcEtfTradeFeeMilli(grossCost);
    var totalCost = grossCost + feeMilli;
    var paid = spend(state, totalCost);
    if(!paid || !paid.ok) return paid || { ok:false, reason:"coin_not_enough" };

    if(!subscribe && feeMilli > 0){
      ensureGlobalStats(state).totalFeesMilli += feeMilli;
    }

    var oldQty = floor(h.qty || 0);
    h.avgCostMilli = Math.floor(((oldQty * floor(h.avgCostMilli || price)) + grossCost) / Math.max(1, oldQty + qty));
    h.qty = oldQty + qty;

    if(subscribe){
      fund.cashReserveMilli += grossCost;
      fund.totalShares += qty;
      pushAnnouncement(fund, "subscription", "玩家完成基金建倉認購。", state.marketDay || 1);
    }

    repriceHoldings(fund, state);
    updateETFMarketPrice(fund);
    saveMarketState();

    return { ok:true, priceMilli:price, qty:qty, feeMilli:feeMilli || 0 };
  }

  function sell(id, qty){
    var state = marketState();
    if(!state) return { ok:false, reason:"no_state" };
    var fund = syncFund(id);
    if(!fund) return { ok:false, reason:"no_fund" };
    if(fund.status !== "listed") return { ok:false, reason:"fund_building" };

    qty = Math.max(1, floor(qty || 1));
    var h = getHolding(state, id);
    if(floor(h.qty || 0) < qty) return { ok:false, reason:"holding_not_enough" };

    var price = Math.max(1, floor(fund.marketPriceMilli || fund.navMilli || 10000));
    var gross = price * qty;
    var feeMilli = calcEtfTradeFeeMilli(gross);
    var avgCost = floor(h.avgCostMilli || price);
    var realized = gross - (avgCost * qty) - feeMilli;

    h.qty -= qty;
    if(h.qty <= 0){
      h.qty = 0;
      h.avgCostMilli = 0;
    }

    addCoin(state, Math.max(0, gross - feeMilli));

    var stats = ensureGlobalStats(state);
    stats.totalFeesMilli += feeMilli;
    stats.realizedProfitMilli += realized;
    stats.etfRealizedProfitMilli = floor(stats.etfRealizedProfitMilli || 0) + realized;
    stats.etfTotalFeesMilli = floor(stats.etfTotalFeesMilli || 0) + feeMilli;

    saveMarketState();
    return { ok:true, priceMilli:price, qty:qty, feeMilli:feeMilli, realizedMilli:realized };
  }

  function getUIData(id){
    var state = marketState();
    var fund = syncFund(id || "guild_leader_fund");
    if(!fund) return null;

    var h = getHolding(state, fund.id);
    var max = maxPlayerShares(fund);
    var price = Math.max(1, floor(fund.marketPriceMilli || fund.navMilli || 10000));
    var diff = floor(fund.diffMilli || 0);
    var dayOpen = Math.max(1, floor(fund.dayOpenPriceMilli || fund.lastClosePriceMilli || price));
    var rebalanceDays = Math.max(1, floor(fund.rebalanceDays || 30));
    var marketDay = Math.max(1, floor(state && state.marketDay || 1));
    var daysToRebalance = rebalanceDays - ((marketDay - 1) % rebalanceDays);
    if(daysToRebalance === rebalanceDays) daysToRebalance = 0;

    return {
      id: fund.id,
      name: fund.name || "商會龍頭基金",
      status: fund.status || "building",
      listed: fund.status === "listed",
      isMarketOpen: state && state.marketPhase === "open",

      nav: (fund.navMilli || price) / SCALE,
      navMilli: fund.navMilli || price,
      marketPrice: price / SCALE,
      marketPriceMilli: price,
      currentPriceMilli: price,
      dayOpenPriceMilli: dayOpen,
      dayHighPriceMilli: fund.dayHighPriceMilli || price,
      dayLowPriceMilli: fund.dayLowPriceMilli || price,

      diffMilli: diff,
      diffPercent: num(fund.diffPercent, 0),

      totalShares: floor(fund.totalShares || 0),
      totalUnits: floor(fund.totalShares || 0),
      cashReserve: floor(fund.cashReserveMilli || 0),
      cashReserveMilli: floor(fund.cashReserveMilli || 0),
      stockAssetValueMilli: floor(fund.stockAssetValueMilli || 0),
      totalAssetValue: floor(fund.totalAssetValueMilli || 0),
      totalAssetValueMilli: floor(fund.totalAssetValueMilli || 0),

      validCompanyCount: floor(fund.validCompanyCount || 0),
      holdings: fund.holdings || [],
      topHoldings: (fund.holdings || []).slice(0,5),
      rebalanceChanges: fund.rebalanceChanges || [],
      announcements: fund.announcements || [],

      dividendAnnouncement: fund.dividendAnnouncement || "尚無公告",
      pendingDividendMilli: floor(fund.pendingDividendMilli || 0),
      daysToRebalance: daysToRebalance,

      holdingQty: floor(h.qty || 0),
      holdingAvgCostMilli: floor(h.avgCostMilli || 0),
      playerMaxUnits: max,
      playerRemainingUnits: Math.max(0, max - floor(h.qty || 0)),

      capitalFlow: w.ETFCapitalFlowEngine && w.ETFCapitalFlowEngine.getSummary
        ? w.ETFCapitalFlowEngine.getSummary(fund)
        : null
    };
  }

  function registerETF(config){
    if(!config || !config.id) return null;
    registry[config.id] = config;
    var state = marketState();
    if(state) return ensureFundInState(config.id, state);
    return null;
  }

  function activateETF(id){
    if(activeIds.indexOf(id) < 0) activeIds.push(id);
    return ensureFundInState(id);
  }

  function startRuntime(){
    // 7.2.0：ETF 禁止自跑 setInterval。
    // 由 StockStateManager / StockHub / UI getUIData 觸發同步，且每日邏輯依 marketDay 去重。
    return true;
  }

  w.calcEtfMarketFeeMilli = calcEtfTradeFeeMilli;

  w.UniversalETF = {
    registerETF: registerETF,
    activateETF: activateETF,
    startRuntime: startRuntime,
    getState: function(id){ return ensureFundInState(id || "guild_leader_fund"); },
    getUIData: getUIData,
    syncFund: syncFund,
    buy: function(id, qty){ return buyOrSubscribe(id || "guild_leader_fund", qty, false); },
    subscribe: function(id, qty){ return buyOrSubscribe(id || "guild_leader_fund", qty, true); },
    sell: function(id, qty){ return sell(id || "guild_leader_fund", qty); },
    addMarketFlow: addMarketFlow,
    _debugState: function(){ var s=marketState(); return s && s[ETF_NS]; }
  };

})(window);
