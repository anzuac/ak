(function(w){
  "use strict";

  if(!w.StockHub || !w.StockStateManager || !w.UniversalETF){
    console.error("❌ stock_etf_tab.js: 缺少 UniversalETF");
    return;
  }

  var TAB_ID = "etfChamber";
  var SCALE = (w.StockMarketEngine && w.StockMarketEngine.SCALE) || 1000;
  var selectedFund = "passive";
  var passiveHoldingsOpen = false; // lazy render holdings
  var passivePanel = "holdings";

  var STYLE = '' +
  '<style>' +
  '.etf-root{display:flex;flex-direction:column;gap:14px;color:#e5e7eb;}' +
  '.etf-switch{display:grid;grid-template-columns:1fr 1fr;gap:10px;}' +
  '.etf-switch button{border:0;border-radius:12px;padding:12px;font-weight:1000;color:#fff;cursor:pointer;background:#334155;}' +
  '.etf-switch button.active{background:#16a34a;}' +
  '.etf-hero{background:linear-gradient(180deg,#172554,#08111f);border:1px solid #334155;border-radius:18px;padding:16px;box-shadow:0 0 0 1px rgba(255,255,255,.03) inset;}' +
  '.etf-hero.activeFund{background:linear-gradient(180deg,#3b2506,#08111f);border-color:#854d0e;}' +
  '.etf-title{font-size:20px;font-weight:1000;text-align:center;}' +
  '.etf-price{font-size:44px;font-weight:1000;text-align:center;margin-top:8px;}' +
  '.etf-diff{text-align:center;font-size:18px;font-weight:1000;margin-top:6px;}' +
  '.etf-card{background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;}' +
  '.etf-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;}' +
  '.etf-label{font-size:12px;opacity:.68;font-weight:800;}' +
  '.etf-value{font-size:18px;font-weight:1000;margin-top:6px;}' +
  '.etf-trade-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}' +
  '.etf-input{width:100%;box-sizing:border-box;background:#111827;color:#e5e7eb;border:1px solid #334155;border-radius:12px;padding:12px;font-weight:900;outline:none;}' +
  '.etf-btn{border:0;border-radius:12px;padding:12px;font-weight:1000;color:#fff;cursor:pointer;}' +
  '.etf-btn:disabled{opacity:.45;cursor:not-allowed;}' +
  '.etf-holding-row{display:flex;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #1f2937;padding:9px 0;}' +
  '.etf-holding-row:last-child{border-bottom:0;}' +
  '.etf-detail-btn{width:100%;border:0;border-radius:12px;padding:12px;background:#475569;color:#fff;font-weight:1000;cursor:pointer;}' +  '.etf-mini-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;}' +  '.etf-mini-tab{flex:1;border:0;border-radius:10px;padding:10px;background:#334155;color:#fff;font-weight:900;font-size:13px;cursor:pointer;min-width:90px;}' +  '.etf-mini-panel{margin-top:10px;}' +
  '.etf-change-up{color:#22c55e;font-weight:1000;}' +
  '.etf-change-down{color:#ef4444;font-weight:1000;}' +
  '.etf-change-new{color:#facc15;font-weight:1000;}' +
  '.etf-change-flat{color:#cbd5e1;font-weight:1000;}' +
  '@media (min-width:760px){.etf-grid{grid-template-columns:repeat(4,minmax(0,1fr));}.etf-price{font-size:58px;}}' +
  '</style>';

  function num(v){
    var n = Number(v);
    return isFinite(n) ? n : 0;
  }

  function safe(v){
    return String(v == null ? "" : v)
      .replace(/&/g,"&amp;")
      .replace(/</g,"&lt;")
      .replace(/>/g,"&gt;")
      .replace(/\"/g,"&quot;")
      .replace(/'/g,"&#39;");
  }

  function fmtInt(v){
    return Math.floor(num(v)).toLocaleString();
  }

  function fmtCoin(v){
    return (num(v) / SCALE).toFixed(3);
  }

  function fmtFundAum(v){
    var n = num(v) / SCALE;
    if(Math.abs(n) >= 1000000000000) return (n / 1000000000000).toFixed(2) + "兆";
    if(Math.abs(n) >= 100000000) return (n / 100000000).toFixed(2) + "億";
    if(Math.abs(n) >= 10000) return (n / 10000).toFixed(2) + "萬";
    return n.toFixed(0);
  }

  
  function getMarketFlowText(s){
    var p = Number(s.marketPressure || 0);

    if(p >= 0.12){
      return '<span style="color:#facc15;">🔥 資金強力流入</span>';
    }

    if(p >= 0.03){
      return '<span style="color:#4ade80;">🟢 市場偏多</span>';
    }

    if(p <= -0.12){
      return '<span style="color:#ef4444;">⚠ 大量賣壓</span>';
    }

    if(p <= -0.03){
      return '<span style="color:#fb7185;">🔴 市場偏空</span>';
    }

    return '<span style="color:#cbd5e1;">⚖ 市場平穩</span>';
  }

function fmtPct(v){
    v = num(v);
    return (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
  }

  function fmtWeightPct(h, s){
    h = h || {};
    s = s || {};

    var w = Number(h.weightPct);
    if(isFinite(w) && w > 0){
      return w.toFixed(2) + "%";
    }

    w = Number(h.weight);
    if(isFinite(w) && w > 0){
      // 相容兩種資料格式：
      // 0.31 = 31%
      // 31   = 31%
      if(w <= 1) w = w * 100;
      return w.toFixed(2) + "%";
    }

    var shares = num(h.sharesHeld);
    var price = num(h.price || h.currentPriceMilli || h.stockPriceMilli || h.marketPriceMilli);
    var total = num(s.totalAssetValueMilli || s.totalAssetValue || s.stockAssetValueMilli);

    if(shares > 0 && price > 0 && total > 0){
      return ((shares * price / total) * 100).toFixed(2) + "%";
    }

    return "0.00%";
  }

  function color(v){
    v = num(v);
    if(v > 0) return "#22c55e";
    if(v < 0) return "#ef4444";
    return "#cbd5e1";
  }

  function arrow(v){
    v = num(v);
    if(v > 0) return "▲";
    if(v < 0) return "▼";
    return "━";
  }

  function getBody(){
    var body = document.getElementById("stockHubBody");
    if(!body) return null;
    if(String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return null;
    return body;
  }

  function getState(){
    w.StockStateManager.settleAndSave();
    return w.StockStateManager.getState();
  }

  function renderSwitch(){
    return '' +
      '<div class="etf-switch">' +
        '<button id="etfSwitchPassive" class="' + (selectedFund === "passive" ? "active" : "") + '">🏛 商會龍頭基金<br><span style="font-size:11px;opacity:.8;">被動追蹤</span></button>' +
        '<button id="etfSwitchActive" class="' + (selectedFund === "active" ? "active" : "") + '">⚔ 王國戰略資本<br><span style="font-size:11px;opacity:.8;">主動基金</span></button>' +
      '</div>';
  }

  function bindSwitch(){
    var p = document.getElementById("etfSwitchPassive");
    var a = document.getElementById("etfSwitchActive");
    if(p) p.onclick = function(){ selectedFund = "passive"; update(); };
    if(a) a.onclick = function(){ selectedFund = "active"; update(); };
  }

  function renderHoldings(list, mode){
    if(!Array.isArray(list) || !list.length){
      return '<div style="opacity:.7;padding:8px 0;">尚未建立成分股。</div>';
    }

    var html = '';
    for(var i=0;i<list.length;i++){
      var h = list[i] || {};
      var right = mode === "active"
        ? fmtWeightPct(h, s)
        : fmtWeightPct(h, s);

      var sub = mode === "active"
        ? '<div style="font-size:12px;opacity:.65;margin-top:2px;">持有 ' + fmtInt(h.qty) + ' 股</div>'
        : '';

      html += '' +
        '<div class="etf-holding-row">' +
          '<div style="min-width:0;">' +
            '<div style="font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">#' + fmtInt(i + 1) + ' ' + safe(h.name || h.assetId) + '</div>' + sub +
          '</div>' +
          '<div style="font-weight:1000;color:#facc15;white-space:nowrap;font-size:16px;">' + right + '</div>' +
        '</div>';
    }
    return html;
  }


  function changeClass(action){
    if(action === "increase") return "etf-change-up";
    if(action === "decrease" || action === "removed") return "etf-change-down";
    if(action === "new") return "etf-change-new";
    return "etf-change-flat";
  }

  function changeIcon(action){
    if(action === "increase") return "↑";
    if(action === "decrease") return "↓";
    if(action === "new") return "（新）";
    if(action === "removed") return "（移除）";
    return "─";
  }

  function renderHoldingDetails(s){

    var panelButtons = '' +
      '<div class="etf-mini-tabs">' +
        '<button id="etfPanelHoldings" class="etf-mini-tab">📦 基金持倉</button>' +
        '<button id="etfPanelStatus" class="etf-mini-tab">📊 基金狀態</button>' +
        '<button id="etfPanelNotice" class="etf-mini-tab">📢 ETF公告</button>' +
      '</div>';

    if(passivePanel === "status"){

      return '<div class="etf-card">' + panelButtons +
        '<div class="etf-mini-panel">' +
          '<div style="font-size:16px;font-weight:1000;margin-bottom:10px;">📊 基金狀態</div>' +

          '<div class="etf-grid">' +

            '<div class="etf-card">' +
              '<div class="etf-label">基金總資產</div>' +
              '<div class="etf-value">' + fmtFundAum(s.totalAssetValue || 100000000) + '</div>' +
            '</div>' +

            '<div class="etf-card">' +
              '<div class="etf-label">現金餘額</div>' +
              '<div class="etf-value">' + fmtFundAum(s.cashReserve || 0) + '</div>' +
            '</div>' +

            '<div class="etf-card">' +
              '<div class="etf-label">股票持倉</div>' +
              '<div class="etf-value">' + fmtFundAum((s.totalAssetValue || 0) - (s.cashReserve || 0)) + '</div>' +
            '</div>' +

            '<div class="etf-card">' +
              '<div class="etf-label">追蹤商會</div>' +
              '<div class="etf-value">' + fmtInt((s.holdings || []).length) + ' 間</div>' +
            '</div>' +

            '<div class="etf-card">' +
              '<div class="etf-label">基金份額</div>' +
              '<div class="etf-value">' + fmtInt(s.totalShares || s.totalUnits || 0) + '</div>' +
            '</div>' +

            '<div class="etf-card">' +
              '<div class="etf-label">基金淨值 NAV</div>' +
              '<div class="etf-value">' + fmtCoin((s.nav || 10) * 1000) + '</div>' +
            '</div>' +

          '</div>' +
        '</div>' +
      '</div>';
    }

    if(passivePanel === "notice"){

      var notices = Array.isArray(s.announcements) ? s.announcements.slice(0,30) : [];

      var noticeHtml = '';

      if(!notices.length){
        noticeHtml = '<div style="opacity:.7;">尚無公告。</div>';
      }

      for(var ni=0;ni<Math.min(notices.length,5);ni++){
        var n = notices[ni] || {};
        noticeHtml += '<div class="etf-holding-row">' +
          '<div style="font-size:13px;line-height:1.6;">📢 ' + safe(n.text || "ETF 更新") + '</div>' +
        '</div>';
      }

      return '<div class="etf-card">' + panelButtons +
        '<div class="etf-mini-panel">' +
          '<div style="font-size:16px;font-weight:1000;margin-bottom:10px;">📢 ETF公告</div>' +
          noticeHtml +
        '</div>' +
      '</div>';
    }
    if(!passiveHoldingsOpen){
      return '<div class="etf-card">' +
        panelButtons +
      '</div>';
    }

    var html = '' +
      '<div class="etf-card">' +
        panelButtons +
        '<div style="font-size:16px;font-weight:1000;margin:12px 0 8px;">🏦 ETF 真實持倉</div>' +
        '<div style="font-size:12px;opacity:.72;margin-bottom:8px;line-height:1.6;">持倉明細每日/月結快取更新；未展開時僅背景維護資料，減少 UI 負擔。</div>';

    var list = Array.isArray(s.holdings) ? s.holdings : [];
    if(!list.length){
      html += '<div style="opacity:.7;padding:8px 0;">尚未建立持倉。</div>';
    }

    for(var i=0;i<list.length;i++){
      var h = list[i] || {};
      var oldShares = num(h.oldSharesHeld);
      var newShares = num(h.sharesHeld);
      oldShares = isFinite(oldShares)?oldShares:0;
      newShares = isFinite(newShares)?newShares:0;
      var diff = newShares - oldShares;
      var action = diff > 0 ? "increase" : (diff < 0 ? "decrease" : (String(h.rankStatus||"") === "（新）" ? "new" : "same"));
      var cls = changeClass(action);

      html += '' +
        '<div class="etf-holding-row">' +
          '<div style="min-width:0;">' +
            '<div style="font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">#' + fmtInt(h.rank || (i+1)) + ' ' + safe(h.name || h.assetId) + ' ' + safe(h.rankStatus || '') + '</div>' +
            '<div style="font-size:12px;opacity:.72;margin-top:2px;">持股 ' + fmtInt(oldShares) + ' → ' + fmtInt(newShares) + ' 股</div>' +
            '<div style="font-size:12px;opacity:.82;margin-top:4px;color:#93c5fd;">權重 ' + (function(){
              var totalAssets = num(s.totalAssets || s.navAssets || s.totalFundAssets || 0);
              var stockPrice = num(h.price || h.stockPrice || h.currentPrice || 0);
              var holdingValue = stockPrice * newShares;
              var weight = num(h.weight || h.weightPct || 0);

              if(weight <= 0 && totalAssets > 0 && holdingValue > 0){
                weight = (holdingValue / totalAssets) * 100;
              }

              if(!isFinite(weight) || weight < 0){
                weight = 0;
              }

              return (weight * 100).toFixed(2) + '%';
            })() + '</div>' +
          '</div>' +
          '<div class="' + cls + '" style="white-space:nowrap;">' + changeIcon(action) + ' ' + (diff >= 0 ? '+' : '') + fmtInt(diff) + '</div>' +
        '</div>';
    }

    var changes = Array.isArray(s.rebalanceChanges) ? s.rebalanceChanges : [];
    var removed = changes.filter(function(c){ return c && c.action === "removed"; });
    if(removed.length){
      html += '<div style="font-size:16px;font-weight:1000;margin:14px 0 8px;">📉 本月移除</div>';
      for(var r=0;r<removed.length;r++){
        var c = removed[r] || {};
        html += '' +
          '<div class="etf-holding-row">' +
            '<div style="font-weight:900;">' + safe(c.name || c.assetId) + '</div>' +
            '<div class="etf-change-down">（移除） ' + fmtInt(c.oldShares) + ' → 0</div>' +
          '</div>';
      }
    }

    html += '</div>';
    return html;
  }

  function bindHoldingToggle(){

    var h = document.getElementById("etfPanelHoldings");
    var s = document.getElementById("etfPanelStatus");
    var n = document.getElementById("etfPanelNotice");

    if(h){
      h.onclick = function(){

        if(passivePanel === "holdings" && passiveHoldingsOpen){
          passiveHoldingsOpen = false;
        }else{
          passivePanel = "holdings";
          passiveHoldingsOpen = true;
        }

        update();
      };
    }

    if(s){
      s.onclick = function(){

        if(passivePanel === "status"){
          passiveHoldingsOpen = false;
          passivePanel = "holdings";
        }else{
          passivePanel = "status";
          passiveHoldingsOpen = false;
        }

        update();
      };
    }

    if(n){
      n.onclick = function(){

        if(passivePanel === "notice"){
          passiveHoldingsOpen = false;
          passivePanel = "holdings";
        }else{
          passivePanel = "notice";
          passiveHoldingsOpen = false;
        }

        update();
      };
    }


  }


  function renderPassive(root, state){
    var s = (w.ETFUIAdapter && w.ETFUIAdapter.get)
      ? w.ETFUIAdapter.get("guild_leader_fund")
      : w.UniversalETF.getUIData("guild_leader_fund");
    if(!s){
      root.innerHTML = renderSwitch() + '<div class="etf-card">ETF 系統尚未載入。</div>';
      bindSwitch();
      return;
    }

    if(!s){
      root.innerHTML = '<div class="etf-root">' + renderSwitch() +
        '<div class="etf-card">ETFV2 尚未初始化。</div></div>';
      bindSwitch();
      return;
    }

    var diff = num(s.diffMilli);
    var diffText = arrow(diff) + fmtCoin(Math.abs(diff)) + '（' + fmtPct(s.diffPercent) + '）';
    var remainBuy = Math.max(0, num(s.playerMaxUnits || s.playerRemainingUnits) - num(s.holdingQty));
    var tradeDisabled = !s.isMarketOpen || s.status !== "listed";
    var phaseText = s.status === "listed"
      ? (s.isMarketOpen ? '🟢 開盤可交易' : '🔴 非開盤時間')
      : '🟡 建倉中，可認購，尚未開放交易';

    root.innerHTML = '' +
      '<div class="etf-root">' + renderSwitch() +
        '<div class="etf-hero">' +
          '<div class="etf-title">🏛 ' + safe(s.name || "商會龍頭基金") + '</div>' +
          '<div class="etf-price">' + fmtCoin(s.currentPriceMilli) + '</div>' +
          '<div class="etf-diff" style="color:' + color(diff) + ';">' + diffText + '</div>' +
          '<div style="text-align:center;font-size:12px;opacity:.75;margin-top:8px;">追蹤市場前20龍頭商會｜月結換股｜王國可加入</div>' +

'<div style="text-align:center;font-size:12px;margin-top:8px;color:' 
+ (s.isMarketOpen ? '#4ade80' : '#fca5a5') 
+ ';font-weight:900;">' 
+ phaseText + 
'</div>' +

'<div style="text-align:center;font-size:11px;margin-top:6px;font-weight:900;opacity:.92;">'
+ getMarketFlowText(s) +
'</div>' +

'</div>' +
        '<div class="etf-grid">' +
          '<div class="etf-card"><div class="etf-label">股利公告</div><div class="etf-value">' + safe(s.dividendAnnouncement || "尚無公告") + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">今日開盤</div><div class="etf-value">' + fmtCoin(s.dayOpenPriceMilli) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">總發行份額</div><div class="etf-value">' + fmtInt(s.totalShares || s.totalUnits) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">距離月結</div><div class="etf-value">' + fmtInt(s.daysToRebalance) + ' 天</div></div>' +
        '</div>' +
        renderTradeCard("ETF", s, remainBuy, tradeDisabled) +
        renderHoldingDetails(s) +
      '</div>';
    bindSwitch();
    bindTrade("passive");
    bindHoldingToggle();
  }

  function renderActive(root, state){
    if(!w.StockActiveETFSystem){
      root.innerHTML = '<div class="etf-root">' + renderSwitch() + '<div class="etf-card">王國戰略資本系統尚未載入。</div></div>';
      bindSwitch();
      return;
    }

    var s = w.StockActiveETFSystem.getSummary(state);
    var diff = num(s.diffMilli);
    var diffText = arrow(diff) + fmtCoin(Math.abs(diff)) + '（' + fmtPct(s.diffPercent) + '）';
    var remainBuy = Math.max(0, num(s.playerMaxUnits) - num(s.holdingQty));
    var tradeDisabled = !s.isMarketOpen || !s.listed || s.limitLocked;
    var phaseText = s.isMarketOpen ? '🟢 開盤可交易' : '🔴 非開盤時間';
    
    
    
    if(!s.listed) phaseText = '🟡 建倉中，尚未開放交易';
    if(s.limitLocked && s.limitType === "up") phaseText = '🔒 漲停鎖定';
    if(s.limitLocked && s.limitType === "down") phaseText = '🔒 跌停鎖定';
    var report = s.lastReport || { added:[], removed:[] };

    root.innerHTML = '' +
      '<div class="etf-root">' + renderSwitch() +
        '<div class="etf-hero activeFund">' +
          '<div class="etf-title">⚔ ' + safe(s.name || "商會龍頭基金") + '</div>' +
          '<div class="etf-price">' + fmtCoin(s.currentPriceMilli) + '</div>' +
          '<div class="etf-diff" style="color:' + color(diff) + ';">' + diffText + '</div>' +
          '<div style="text-align:center;font-size:12px;opacity:.75;margin-top:8px;">主動型基金｜經理人操作｜會透過真實持倉影響個股</div>' +
          '<div style="text-align:center;font-size:12px;margin-top:8px;color:' + (s.isMarketOpen ? '#4ade80' : '#fca5a5') + ';font-weight:900;">' + phaseText + '</div>' +
        '</div>' +

        '<div class="etf-grid">' +
          '<div class="etf-card"><div class="etf-label">基金總資產</div><div class="etf-value">' + fmtFundAum(s.totalAssetsMilli) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">今日開盤</div><div class="etf-value">' + fmtCoin(s.dayOpenPriceMilli) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">今日最高 / 最低</div><div class="etf-value">' + fmtCoin(s.dayHighPriceMilli) + ' / ' + fmtCoin(s.dayLowPriceMilli) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">距離季結</div><div class="etf-value">' + fmtInt(s.daysToQuarter) + ' 天</div></div>' +
        '</div>' +

        '<div class="etf-grid">' +
          '<div class="etf-card"><div class="etf-label">現金部位</div><div class="etf-value">' + fmtPct(s.cashRatio * 100).replace("+","") + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">股票持倉</div><div class="etf-value">' + fmtPct(s.stockRatio * 100).replace("+","") + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">經理人</div><div class="etf-value" style="font-size:14px;line-height:1.4;">' + safe(s.managerStyle) + '</div></div>' +
          '<div class="etf-card"><div class="etf-label">總發行份額</div><div class="etf-value">' + fmtInt(s.totalUnits) + '</div></div>' +
        '</div>' +

        '<div class="etf-card">' +
          '<div style="font-size:16px;font-weight:1000;margin-bottom:8px;">🏗 基金狀態</div>' +
          '<div style="line-height:1.8;">上市狀態：<b>' + (s.listed ? "已完成建倉並開放交易" : "建倉中，暫停買賣") + '</b></div>' +
          '<div style="line-height:1.8;">建倉進度：<b>' + fmtInt(s.buildHoldingCount || 0) + ' / ' + fmtInt(s.buildTargetCount || 15) + '</b></div>' +
          '<div style="line-height:1.8;">股票部位門檻：<b>' + fmtPct((s.buildStockRatio || 0) * 100).replace("+","") + ' / 85.00%</b></div>' +
          '<div style="line-height:1.8;">公開資料日：<b>' + (s.disclosureDay ? ("第 " + fmtInt(s.disclosureDay) + " 日休市") : "尚未日結") + '</b></div>' +
          '<div style="font-size:12px;opacity:.7;margin-top:6px;">基金總資產與持倉資訊只在休市日結後更新。</div>' +
        '</div>' +

        renderTradeCard("基金", s, remainBuy, tradeDisabled) +

        '<div class="etf-card">' +
          '<div style="font-size:16px;font-weight:1000;margin-bottom:8px;">📣 季度公開資訊</div>' +
          '<div style="font-size:13px;line-height:1.8;opacity:.9;">本季新增：' + safe((report.added || []).slice(0,5).join("、") || "尚無") + '</div>' +
          '<div style="font-size:13px;line-height:1.8;opacity:.9;">本季移除：' + safe((report.removed || []).slice(0,5).join("、") || "尚無") + '</div>' +
        '</div>' +

        '<div class="etf-card"><div style="font-size:16px;font-weight:1000;margin-bottom:8px;">🏦 前五大持股</div>' + renderHoldings(s.topHoldings, "active") + '</div>' +
        '<div class="etf-card"><div style="font-size:16px;font-weight:1000;margin-bottom:8px;">📊 季度公布持股</div>' + renderHoldings(s.holdings, "active") + '</div>' +
      '</div>';

    bindSwitch();
    bindTrade("active");
  }

  function renderTradeCard(label, s, remainBuy, tradeDisabled){
    return '' +
      '<div class="etf-card">' +
        '<div style="font-size:16px;font-weight:1000;margin-bottom:8px;">📦 你的持有</div>' +
        '<div style="line-height:1.8;">持有：<b>' + fmtInt(s.holdingQty) + '</b> 份</div>' +
        '<div style="line-height:1.8;">均價：<b>' + fmtCoin(s.holdingAvgCostMilli) + '</b></div>' +
        '<div style="line-height:1.8;">持有上限：<b>' + fmtInt(s.playerMaxUnits) + '</b> 份</div>' +
        '<div style="line-height:1.8;">尚可買入：<b>' + fmtInt(remainBuy) + '</b> 份</div>' +
      '</div>' +
      '<div class="etf-card">' +
        '<div style="font-size:16px;font-weight:1000;margin-bottom:10px;">🧾 ' + label + '交易</div>' +
        '<input id="etfQtyInput" class="etf-input" type="number" min="1" step="1" value="1" placeholder="輸入份數">' +
        '<div class="etf-trade-row" style="margin-top:10px;">' +
          '<button id="etfBuyBtn" class="etf-btn" style="background:#16a34a;" ' + (tradeDisabled ? 'disabled' : '') + '>買入</button>' +
          '<button id="etfSellBtn" class="etf-btn" style="background:#dc2626;" ' + (tradeDisabled ? 'disabled' : '') + '>賣出</button>' +        '</div>' +        '<div class="etf-trade-row" style="margin-top:10px;">' +          '<button id="etfSubscribeBtn" class="etf-btn" style="background:#2563eb;" ' + ((s.status === 'listed') ? 'disabled' : '') + '>認購</button>' +          '<button class="etf-btn" style="background:#475569;opacity:.9;cursor:default;">建倉期限定</button>' +
        '</div>' +
        '<div style="font-size:12px;opacity:.7;margin-top:8px;line-height:1.6;">只在開盤時間可交易；成交價格以目前價格計算。</div>' +
      '</div>';
  }

  function render(body){
    body.setAttribute("data-tab-owner", TAB_ID);
    body.innerHTML = STYLE + '<div id="etfRoot"></div>';
    update();
  }

  function update(){
    var body = getBody();
    if(!body) return;
    var root = document.getElementById("etfRoot");
    if(!root) return;

    try{
      var qtyInput = document.getElementById("etfQtyInput");
      var active = document.activeElement;
      if(qtyInput && active === qtyInput){
        return;
      }

      if(window.__ETF_LAST_RENDER__ && Date.now() - window.__ETF_LAST_RENDER__ < 500){
        return;
      }
      window.__ETF_LAST_RENDER__ = Date.now();

      var state = getState();
      if(selectedFund === "active") renderActive(root, state);
      else renderPassive(root, state);
    }catch(e){
      root.innerHTML = '<div style="color:#ef4444;padding:16px;">ETF 渲染錯誤：' + safe(e && e.message ? e.message : e) + '</div>';
      console.error("ETF tab error", e);
    }
  }

  function readQty(){
    var qtyInput = document.getElementById("etfQtyInput");
    return Math.max(1, Math.floor(Number(qtyInput && qtyInput.value || 1)));
  }

  function bindTrade(mode){
    var buyBtn = document.getElementById("etfBuyBtn");
    if(buyBtn){
      buyBtn.onclick = function(){
        var res;
        if(mode === "passive" && w.UniversalETF){
          res = w.UniversalETF.buy("guild_leader_fund", readQty());
        }else{
          var st = w.StockStateManager.getState();
          var sys = mode === "active" ? w.StockActiveETFSystem : null;
          res = sys && sys.buy ? sys.buy(st, readQty()) : { ok:false, reason:"system_missing" };
        }
        if(!res.ok){ alert(reasonText(res.reason)); return; }
        w.StockStateManager.save();
        if(w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
        update();
      };
    }

    var sellBtn = document.getElementById("etfSellBtn");
    if(sellBtn){
      sellBtn.onclick = function(){
        var res;
        if(mode === "passive" && w.UniversalETF){
          res = w.UniversalETF.sell("guild_leader_fund", readQty());
        }else{
          var st = w.StockStateManager.getState();
          var sys = mode === "active" ? w.StockActiveETFSystem : null;
          res = sys && sys.sell ? sys.sell(st, readQty()) : { ok:false, reason:"system_missing" };
        }
        if(!res.ok){ alert(reasonText(res.reason)); return; }
        w.StockStateManager.save();
        if(w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
        update();
      };
    }

    var subBtn = document.getElementById("etfSubscribeBtn");
    if(subBtn){
      subBtn.onclick = function(){
        if(mode !== "passive" || !w.UniversalETF) return;
        var res = w.UniversalETF.subscribe("guild_leader_fund", readQty());
        if(!res.ok){ alert(reasonText(res.reason)); return; }
        w.StockStateManager.save();
        if(w.StockHub && w.StockHub.requestRerender) w.StockHub.requestRerender();
        update();
      };
    }
  }

  function reasonText(reason){
    switch(reason){
      case "market_closed": return "目前不是開盤時間，暫停買賣。";
      case "etf_disabled": return "ETF 尚未開放，需有效商會達20間。";
      case "etf_holding_limit": return "已達玩家持有上限。";
      case "holding_not_enough": return "持有數量不足。";
      case "coin_not_enough": return "投資幣不足。";
      case "system_missing": return "系統尚未載入。";
      case "no_state": return "市場資料尚未載入。";
      case "fund_building": return "基金仍在建倉中，完成25檔配置並公布發行份額後才開放交易。";
      case "limit_up": return "基金目前漲停鎖定，暫時無法買入。";
      case "limit_down": return "基金目前跌停鎖定，暫時無法賣出。";
      default: return "操作失敗，請稍後再試。";
    }
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "🏛 商會龍頭基金",
    render: render,
    update: update,
    tick: function(){
      // ETFV2 Runtime handled by UniversalETF
    }
  });

})(window);


window.__ETF_HOLDINGS_OPEN__ =
  window.__ETF_HOLDINGS_OPEN__ || false;
