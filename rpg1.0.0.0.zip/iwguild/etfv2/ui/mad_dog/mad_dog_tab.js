// =====================================================
// mad_dog_tab.js
// StockHub 獨立掛載
// =====================================================

(function(w){
  "use strict";

  if(!w.StockHub){
    console.error("[MadDogETF] StockHub Missing");
    return;
  }

  var TAB_ID = "mad_dog_etf";

  function render(root){
    if(!w.MadDogRender || !w.MadDogRender.render){
      root.innerHTML = '<div style="padding:16px;color:white;">MadDogRender 尚未載入。</div>';
      return;
    }
    w.MadDogRender.render(root);
  }

  function update(root){
    if(w.MadDogRender && w.MadDogRender.update){
      w.MadDogRender.update(root);
    }
  }

  function tick(){
    if(w.MadDogRender && w.MadDogRender.tick){
      w.MadDogRender.tick();
    }
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "⚔ 王國戰略資本",
    render: render,
    update: update,
    tick: tick
  });

})(window);
