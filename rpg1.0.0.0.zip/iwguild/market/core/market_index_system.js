
// =====================================================
// AI5.1.2 UI Tick Sync
//
// Only synchronizes:
// - realtime prices
// - price change display
// - market index updates
//
// Other UI systems remain unchanged.
// =====================================================




// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function(w) {
  "use strict";

  if (!w.StockMarketEngine) {
    console.error("❌ market_index_system.js: 缺少 StockMarketEngine");
    return;
  }

  // =========================================
  // 基準點數
  // =========================================
  var BASE_INDEX = 10000.00;

  // =========================================
  // 歷史上限
  // =========================================
  var MAX_HISTORY = 240;

  // =========================================
  // State 初始化
  // =========================================
  function ensureState(state) {

    if (!state) return null;

    if (
      !state.marketIndexSystem ||
      typeof state.marketIndexSystem !== "object"
    ) {
      state.marketIndexSystem = {};
    }

    var sys = state.marketIndexSystem;

    if (!(Number(sys.currentIndex) > 0)) {
      sys.currentIndex = BASE_INDEX;
    }

    if (!(Number(sys.previousIndex) > 0)) {
      sys.previousIndex = BASE_INDEX;
    }

    if (!(Number(sys.highIndex) > 0)) {
      sys.highIndex = BASE_INDEX;
    }

    if (!(Number(sys.lowIndex) > 0)) {
      sys.lowIndex = BASE_INDEX;
    }

    if (!Array.isArray(sys.history)) {
      sys.history = [];
    }

    if (!Array.isArray(sys.sectors)) {
      sys.sectors = [];
    }

    if (!sys.royalIndex || typeof sys.royalIndex !== "object") {
      sys.royalIndex = {
        currentIndex: BASE_INDEX,
        previousIndex: BASE_INDEX,
        diff: 0,
        diffPercent: 0,
        listedCount: 0,
        totalMarketCap: 0
      };
    }

    return sys;
  }

  // =========================================
  // Assets Object
  // =========================================
  function getAssetsObject(state) {

    if (!state) return {};

    if (
      state.assets &&
      typeof state.assets === "object"
    ) {
      return state.assets;
    }

    return {};
  }

  // =========================================
  // 是否上市
  // =========================================
  function isListedAsset(asset) {

    return !!(
      asset &&
      asset.unlocked &&
      !asset.isDelisted &&
      !asset.delisted
    );

  }

  // =========================================
  // 上市商會
  // =========================================
  function getListedCompanies(state) {

    var assets =
      getAssetsObject(state);

    var list = [];

    Object.keys(assets).forEach(function(id) {

      var asset = assets[id];

      if (isListedAsset(asset) && !asset.excludeFromIndex && !asset.isRoyalEnterprise) {
        list.push(asset);
      }

    });

    return list;
  }

  // =========================================
  // 皇室 / 國力指數成分
  // =========================================
  function getRoyalListedCompanies(state) {

    var assets = getAssetsObject(state);
    var list = [];

    Object.keys(assets).forEach(function(id) {
      var asset = assets[id];
      if (isListedAsset(asset) && (asset.royalIndexEligible || asset.isRoyalEnterprise)) {
        list.push(asset);
      }
    });

    return list;
  }

  // =========================================
  // 數字
  // =========================================
  function num(v, fallback) {

    var n = Number(v);

    return isFinite(n)
      ? n
      : Number(fallback || 0);

  }

  // =========================================
  // 股價
  // =========================================
  function getPrice(asset) {

    return Math.max(
      0,
      num(asset && asset.price, 0)
    );

  }

  // =========================================
  // 前收
  // =========================================
  function getPreviousPrice(asset) {

    if (!asset) return 0;

    var p =
      num(asset.lastClosePrice, NaN);

    if (isFinite(p) && p > 0) {
      return p;
    }

    if (
      Array.isArray(asset.trendHistory) &&
      asset.trendHistory.length
    ) {

      var last =
        asset.trendHistory[
          asset.trendHistory.length - 1
        ];

      p =
        num(
          last && last.closePrice,
          NaN
        );

      if (isFinite(p) && p > 0) {
        return p;
      }

    }

    return getPrice(asset);
  }

  // =========================================
  // 股數
  // =========================================
  function getShares(asset) {

    if (!asset) return 0;

    return Math.max(
      1,
      Math.floor(
        num(
          asset.floatShares ||
          asset.totalShares ||
          asset.sharesOutstanding ||
          asset.availableShares ||
          1,
          1
        )
      )
    );

  }

  // =========================================
  // 類股
  // =========================================
  function getSectorName(asset) {

    if (!asset) {
      return "綜合市場";
    }

    var info =
      asset.companyInfo || {};

    return String(

      asset.sectorLabel ||
      asset.industryLabel ||
      info.industryLabel ||
      info.industry ||
      asset.sectorCode ||
      "綜合市場"

    );

  }

  // =========================================
  // 市值
  // =========================================
  function getMarketCap(asset) {

    if (!asset) return 0;

    // 異世界加權指數讀取「背景市值 / 經濟規模」。
    // 不再用即時股價 × 股數，避免股價炒作直接放大或壓低世界經濟權重。
    if (
      w.StockMarketEngine &&
      typeof w.StockMarketEngine.getEconomicMarketCapMilli === "function"
    ) {
      var cap =
        w.StockMarketEngine.getEconomicMarketCapMilli(asset);

      if (cap > 0) return cap;
    }

    var cm =
      asset.companyMetrics || {};

    var saved =
      num(
        cm.economicMarketCapMilli ||
        cm.marketCapMilli ||
        asset.economicMarketCapMilli ||
        asset.marketCapMilli,
        0
      );

    if (saved > 0) return saved;

    return (
      getPrice(asset) *
      getShares(asset)
    );

  }

  // =========================================
  // IPO 基準
  // 第一次進入市場時記錄
  // =========================================
  function ensureReferenceCap(asset) {

    // V2：停用舊 indexReferenceCap。
    // 權重只在計算時即時讀取市值，不寫回公司資料。
    return;
  }

  // =========================================
  // 市場情緒
  // =========================================
  function calcMood(diffPercent) {

    diffPercent =
      num(diffPercent, 0);

    if (diffPercent >= 4) {

      return {
        label: "全面狂熱",
        tone: "strongUp",
        color: "#22c55e"
      };

    }

    if (diffPercent >= 1.5) {

      return {
        label: "市場樂觀",
        tone: "up",
        color: "#4ade80"
      };

    }

    if (diffPercent <= -4) {

      return {
        label: "市場恐慌",
        tone: "strongDown",
        color: "#ef4444"
      };

    }

    if (diffPercent <= -1.5) {

      return {
        label: "市場悲觀",
        tone: "down",
        color: "#fb923c"
      };

    }

    return {
      label: "中性整理",
      tone: "neutral",
      color: "#cbd5e1"
    };

  }

  // =========================================
  // 類股分析
  // =========================================
  function calcSectorData(companies) {

    var map = {};

    companies.forEach(function(asset) {

      var sector =
        getSectorName(asset);

      if (!map[sector]) {

        map[sector] = {
          sector: sector,
          totalCap: 0,
          weightedChange: 0,
          count: 0,
          advancing: 0,
          declining: 0
        };

      }

      var row =
        map[sector];

      var currentCap =
        getMarketCap(asset);

      var price =
        getPrice(asset);

      var prev =
        getPreviousPrice(asset);

      var changeRate =
        prev > 0
          ? (price - prev) / prev
          : 0;

      row.totalCap += currentCap;
      row.weightedChange += changeRate * currentCap;
      row.count += 1;

      if (price > prev) {
        row.advancing += 1;
      }
      else if (price < prev) {
        row.declining += 1;
      }

    });

    var result = [];

    Object.keys(map).forEach(function(key) {

      var row = map[key];

      var diffPercent =
        row.totalCap > 0
          ? (row.weightedChange / row.totalCap) * 100
          : 0;

      result.push({

        sector: row.sector,
        count: row.count,
        currentCap: row.totalCap,
        referenceCap: row.totalCap,
        diffPercent: diffPercent,
        advancing: row.advancing,
        declining: row.declining

      });

    });

    result.sort(function(a, b) {

      return (
        Math.abs(b.diffPercent) -
        Math.abs(a.diffPercent)
      );

    });

    return result;
  }

  // =========================================
  // 皇室國力指數
  // =========================================
  function updateRoyalIndex(state, day) {

    var sys = ensureState(state);
    var royal = sys.royalIndex;
    var companies = getRoyalListedCompanies(state);

    var totalCap = 0;
    var weightedChange = 0;

    companies.forEach(function(asset) {
      totalCap += getMarketCap(asset);
    });

    totalCap = Math.max(1, totalCap);

    companies.forEach(function(asset) {
      var cap = getMarketCap(asset);
      var weight = cap / totalCap;
      var price = getPrice(asset);
      var prev = getPreviousPrice(asset);
      var changeRate = prev > 0 ? (price - prev) / prev : 0;
      weightedChange += changeRate * weight;
    });

    if (!(Number(royal.previousIndex) > 0)) {
      royal.previousIndex = BASE_INDEX;
    }

    if (royal.lastMarketDay !== day) {
      royal.lastMarketDay = day;
      royal.previousIndex = num(royal.currentIndex, BASE_INDEX);
    }

    var base = num(royal.previousIndex, BASE_INDEX);
    var current = base * (1 + weightedChange);

    if (!isFinite(current) || current <= 0) current = base;
    current = Math.max(base * 0.90, Math.min(base * 1.10, current));

    royal.currentIndex = current;
    royal.diff = current - base;
    royal.diffPercent = base > 0 ? ((current - base) / base) * 100 : 0;
    royal.listedCount = companies.length;
    royal.totalMarketCap = totalCap;

    return royal;
  }

  // =========================================
  // 更新
  // =========================================
  function update(state) {

    var sys =
      ensureState(state);

    if (!sys) return null;

    var companies =
      getListedCompanies(state);

    var day =
      Math.max(
        1,
        Math.floor(
          num(
            state &&
            state.marketDay,
            1
          )
        )
      );

    var tick =
      Math.max(
        0,
        Math.floor(
          num(
            state &&
            state.marketDayTick,
            0
          )
        )
      );

    var key =
      day + ":" + tick;

    var totalMarketCap = 0;

    companies.forEach(function(asset) {

      totalMarketCap +=
        getMarketCap(asset);

    });

    totalMarketCap =
      Math.max(1, totalMarketCap);

    var marketChange = 0;

    var weightLeaders = [];

    var advancing = 0;
    var declining = 0;
    var unchanged = 0;

    companies.forEach(function(asset) {

      var currentCap =
        getMarketCap(asset);

      var weight =
        currentCap / totalMarketCap;

      weightLeaders.push({

        title:
          asset.name ||
          asset.companyName ||
          "未知商會",

        label:
          getSectorName(asset),

        weightPercent:
          weight * 100

      });

      var price =
        getPrice(asset);

      var prev =
        getPreviousPrice(asset);

      var changeRate =
        prev > 0
          ? (price - prev) / prev
          : 0;

      marketChange +=
        changeRate * weight;

      if (price > prev) {
        advancing += 1;
      }
      else if (price < prev) {
        declining += 1;
      }
      else {
        unchanged += 1;
      }

    });

    // =========================================
// 日基準初始化
// =========================================
if (!(Number(sys.previousCloseIndex) > 0)) {
  
  sys.previousCloseIndex =
    BASE_INDEX;
  
}

// =========================================
// 每日開盤時更新昨日收盤基準
// =========================================
// =========================================
// 新的一天開始
// =========================================
if (sys.lastMarketDay !== day) {
  
  sys.lastMarketDay = day;
  
  // 前日收盤 → 今日開盤
  sys.previousCloseIndex =
    num(
      sys.currentIndex,
      BASE_INDEX
    );
  
  // 重置今日最高 / 最低
  sys.highIndex =
    sys.previousCloseIndex;
  
  sys.lowIndex =
    sys.previousCloseIndex;
  
}

// =========================================
// 加權指數計算
// 永遠以「昨日收盤」為基準
// 不再 tick 疊加
// =========================================
var baseForDay =
  num(
    sys.previousCloseIndex,
    BASE_INDEX
  );

var currentIndex =
  baseForDay *
  (1 + marketChange);

// 防止異常
if (
  !isFinite(currentIndex) ||
  currentIndex <= 0
) {
  currentIndex = baseForDay;
}

// 最低保護
currentIndex =
  Math.max(100, currentIndex);

// 單日漲跌限制 ±10%
var maxIndex =
  baseForDay * 1.10;

var minIndex =
  baseForDay * 0.90;

currentIndex =
  Math.max(
    minIndex,
    Math.min(maxIndex, currentIndex)
  );

// 寫入目前加權
sys.currentIndex =
  currentIndex;
  
    
    sys.totalMarketCap =
      totalMarketCap;

    sys.listedCount =
      companies.length;

    sys.advancing =
      advancing;

    sys.declining =
      declining;

    sys.unchanged =
      unchanged;

    sys.highIndex =
      Math.max(
        num(sys.highIndex, currentIndex),
        currentIndex
      );

    sys.lowIndex =
      Math.min(
        num(sys.lowIndex, currentIndex),
        currentIndex
      );

    weightLeaders.sort(function(a, b) {

      return (
        num(b.weightPercent) -
        num(a.weightPercent)
      );

    });

    sys.weightLeaders =
      weightLeaders.slice(0, 2);

    sys.sectors =
      calcSectorData(companies);

    if (
      sys.lastHistoryKey !== key
    ) {

      sys.lastHistoryKey = key;

      sys.history.push({

        day: day,
        tick: tick,
        ts: Date.now(),
        value: currentIndex,
        totalMarketCap: totalMarketCap

      });

      if (
        sys.history.length >
        MAX_HISTORY
      ) {

        sys.history.splice(
          0,
          sys.history.length - MAX_HISTORY
        );

      }

    }
    else if (sys.history.length) {

      var last =
        sys.history[
          sys.history.length - 1
        ];

      last.value =
        currentIndex;

      last.totalMarketCap =
        totalMarketCap;

      last.ts =
        Date.now();

    }

    updateRoyalIndex(state, day);

    return sys;
  }

  // =========================================
  // Summary
  // =========================================
  function getSummary(state) {

    var sys =
      update(state) ||
      ensureState(state);

    if (!sys) {

      return {

        currentIndex:
          BASE_INDEX,

        previousIndex:
          BASE_INDEX,

        diff: 0,
        diffPercent: 0,

        highIndex:
          BASE_INDEX,

        lowIndex:
          BASE_INDEX,

        listedCount: 0,

        totalMarketCap: 0,

        advancing: 0,
        declining: 0,
        unchanged: 0,

        mood:
          calcMood(0),

        sectors: [],

        history: [],

        royalIndex: {
          currentIndex: BASE_INDEX,
          previousIndex: BASE_INDEX,
          diff: 0,
          diffPercent: 0,
          listedCount: 0,
          totalMarketCap: 0
        }

      };

    }

    var current =
      num(
        sys.currentIndex,
        BASE_INDEX
      );

    var prev =
  num(
    sys.previousCloseIndex,
    BASE_INDEX
  );

    var diff =
      current - prev;

    var diffPercent =
      prev > 0
        ? (diff / prev) * 100
        : 0;

    return {

      baseIndex:
        BASE_INDEX,

      currentIndex:
        current,

      previousIndex:
        prev,

      diff:
        diff,

      diffPercent:
        diffPercent,

      highIndex:
        num(
          sys.highIndex,
          current
        ),

      lowIndex:
        num(
          sys.lowIndex,
          current
        ),

      listedCount:
        Math.floor(
          num(
            sys.listedCount,
            0
          )
        ),

      totalMarketCap:
        num(
          sys.totalMarketCap,
          0
        ),

      advancing:
        Math.floor(
          num(
            sys.advancing,
            0
          )
        ),

      declining:
        Math.floor(
          num(
            sys.declining,
            0
          )
        ),

      unchanged:
        Math.floor(
          num(
            sys.unchanged,
            0
          )
        ),

      mood:
        calcMood(
          diffPercent
        ),

      sectors:
        Array.isArray(sys.sectors)
          ? sys.sectors.slice(0, 8)
          : [],

      weightLeaders:
        Array.isArray(sys.weightLeaders)
          ? sys.weightLeaders.slice()
          : [],

      history:
        Array.isArray(sys.history)
          ? sys.history.slice()
          : [],

      royalIndex:
        sys.royalIndex || {
          currentIndex: BASE_INDEX,
          previousIndex: BASE_INDEX,
          diff: 0,
          diffPercent: 0,
          listedCount: 0,
          totalMarketCap: 0
        }

    };

  }

  // =========================================
  // Export
  // =========================================
  w.MarketIndexSystem = {

    BASE_INDEX:
      BASE_INDEX,

    update:
      update,

    getSummary:
      getSummary,

    getListedCompanies:
      getListedCompanies,

    getRoyalListedCompanies:
      getRoyalListedCompanies

  };

  console.log(
    "📈 RPG文明市場加權指數 已載入"
  );

})(window);