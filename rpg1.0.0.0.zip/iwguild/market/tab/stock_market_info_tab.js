

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function(w) {
  "use strict";

  if (!w.StockHub || !w.StockStateManager || !w.StockMarketEngine || !w.StockMarketRegistry) {
    console.error("❌ stock_market_info_tab.js: 缺少依賴");
    return;
  }

  var TAB_ID = "marketInfo";
  var SCALE = w.StockMarketEngine.SCALE || 1000;
  var RESPONSIVE_MARKET_STYLE = `
  <style>
  .market-overview-grid{
    display:grid;
    grid-template-columns:1fr;
    gap:12px;
  }
  .market-inline-row{
    display:flex;
    justify-content:space-between;
    gap:12px;
    flex-wrap:wrap;
    align-items:flex-start;
  }
  .market-industry-row{
    margin-top:8px;
    font-size:11px;
    opacity:.72;
    line-height:1.8;
  }
  @media (min-width: 900px){
    .market-overview-grid{
      grid-template-columns:1fr 1fr;
    }
  }
  </style>
  `;


  function fmtCoinMilli(v) {
    return (Number(v || 0) / SCALE).toFixed(2);
  }

  function fmtNum(v) {
    return Math.floor(Number(v || 0)).toLocaleString();
  }

  function safe(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getBody() {
    var body = document.getElementById("stockHubBody");
    if (!body) return null;
    if (String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return null;
    return body;
  }

  function getTierLabel(tier) {
    if (tier === "large") return "大型股";
    if (tier === "small") return "小型股";
    if (tier === "starter") return "新手盤";
    return "中型股";
  }

  function getSeverityLabel(severity) {
    if (severity === "bankrupt") return "破產清算";
    if (severity === "private") return "私有化退出";
    return "經營惡化";
  }

  function getSeverityColor(severity) {
    if (severity === "bankrupt") return "#ef4444";
    if (severity === "private") return "#f59e0b";
    return "#f97316";
  }

  function getRiskColor(days) {
    days = Number(days || 0);
    if (days >= 5) return "#ef4444";
    if (days >= 3) return "#f97316";
    return "#facc15";
  }

  function getRiskLabel(days) {
    days = Number(days || 0);
    if (days >= 5) return "高風險";
    if (days >= 3) return "觀察名單";
    return "初步警示";
  }

  function renderSection(title, subtitle, innerHtml, maxHeight) {
    return (
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;">' +
          '<div>' +
            '<div style="font-size:18px;font-weight:900;">' + title + '</div>' +
            (subtitle ? '<div style="font-size:12px;opacity:.72;margin-top:4px;line-height:1.55;">' + subtitle + '</div>' : '') +
          '</div>' +
        '</div>' +
        '<div style="margin-top:10px;max-height:' + (maxHeight || 260) + 'px;overflow:auto;padding-right:4px;">' + innerHtml + '</div>' +
      '</div>'
    );
  }

  function renderEmpty(text) {
    return '<div style="padding:8px 0;opacity:.72;line-height:1.7;">' + safe(text) + '</div>';
  }

  function renderStatusCard(title, value, sub, color) {
    return (
      '<div class="market-status-card" style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="font-size:15px;font-weight:900;opacity:.92;">' + title + '</div>' +
        '<div style="display:flex;align-items:flex-end;gap:8px;margin-top:6px;flex-wrap:wrap;">' +
          '<div style="font-size:18px;font-weight:900;color:' + (color || '#e5e7eb') + ';">' + value + '</div>' +
          (sub ? '<div style="font-size:11px;opacity:.65;line-height:1.4;">' + sub + '</div>' : '') +
        '</div>' +
      '</div>'
    );
  }

  function renderPendingListings(list) {
    if (!list.length) return renderEmpty("目前沒有即將上市的公司。");
    var html = '';
    var max = Math.min(5, list.length);
    for (var i = 0; i < max; i++) {
      var p = list[i] || {};
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap;">' +
            '<div style="font-weight:900;color:#86efac;">' + safe(p.name || '-') + '</div>' +
            '<div style="background:#14532d;color:#dcfce7;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">預估上市</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.9;">' +
            '狀態：' + safe(p.ipoHeatLabel || '審核中') + '<br>' +
            '預計時間：' + (Number(p.etaDays || 0) <= 0 ? '即將掛牌' : '約 ' + Number(p.etaDays || 0) + ' 天後') + '<br>' +
            '類型：' + getTierLabel(p.tier) + (p.industryLabel ? '｜產業：' + safe(p.industryLabel) : '') +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function renderDelistWarnings(list) {
    if (!list.length) return renderEmpty("目前沒有明顯下市風險公司。");
    var html = '';
    var max = Math.min(5, list.length);
    for (var i = 0; i < max; i++) {
      var d = list[i] || {};
      var color = getRiskColor(d.riskDays);
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap;">' +
            '<div style="font-weight:900;color:' + color + ';">' + safe(d.name || '-') + '</div>' +
            '<div style="background:' + color + ';color:#111827;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:900;">預估下市</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.9;">' +
            '狀態：' + getRiskLabel(d.riskDays) + '<br>' +
            '市場觀察：' + safe(d.reasonText || '經營風險升高') + (d.industryLabel ? '<br>產業：' + safe(d.industryLabel) : '') +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function renderListedHistory(list) {
    if (!list.length) return renderEmpty("目前沒有上市紀錄。");
    var html = '';
    var max = Math.min(10, list.length);
    for (var i = 0; i < max; i++) {
      var l = list[i] || {};
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;">' +
            '<div style="font-weight:900;color:#22c55e;">' + safe(l.name || '-') + ' 正式掛牌上市</div>' +
            '<div style="background:#14532d;color:#dcfce7;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">上市</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.88;">' +
            '掛牌日：第 ' + Number(l.marketDay || 0) + ' 交易日' +
            (l.industryLabel ? '<br>產業：' + safe(l.industryLabel) : '') +
            '<br>市場紀錄：新公司進入公開交易市場' +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function renderDelistedHistory(list) {
    if (!list.length) return renderEmpty("目前沒有下市紀錄。");
    var html = '';
    var max = Math.min(10, list.length);
    for (var i = 0; i < max; i++) {
      var d = list[i] || {};
      var color = getSeverityColor(d.severity);
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;">' +
            '<div style="font-weight:900;color:' + color + ';">' + safe(d.name || '-') + ' 終止交易</div>' +
            '<div style="background:' + color + ';color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">' + getSeverityLabel(d.severity) + '</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.88;">' +
            '下市日：第 ' + Number(d.marketDay || 0) + ' 交易日<br>' +
            '市場紀錄：' + safe(d.reason || '公司不再符合交易條件') +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function renderMarketMood(state) {
    var climate = state.climate || {};
    var sentiment = Number(climate.sentiment || 0);
    var stability = Number(climate.stability || 0);
    var volatility = Number(climate.volatilityLevel || 1);
    var mood = '中性觀望';
    if (sentiment >= 65) mood = '市場偏向樂觀';
    if (sentiment <= 35) mood = '市場避險情緒升高';
    if (volatility >= 1.35) mood = '市場波動明顯升高';
    if (stability <= 35) mood = '市場穩定度偏低';

    return (
      '<div style="display:flex;flex-direction:column;gap:8px;line-height:1.7;">' +
        '<div style="font-weight:900;color:#93c5fd;">' + mood + '</div>' +
        '<div style="font-size:13px;opacity:.86;">市場目前以事件觀察為主，不直接提供漲跌答案，玩家需要自行判斷後續影響。</div>' +
      '</div>'
    );
  }

  function renderSectorEvents(state) {
    var list = [];
    if (w.StockMarketEngine && w.StockMarketEngine.getAIIndustryEvents) {
      list = w.StockMarketEngine.getAIIndustryEvents(state) || [];
    }
    if (!list.length) return renderEmpty("目前沒有 AI 判定的產業事件。");
    var html = '';
    var max = Math.min(6, list.length);
    for (var i = 0; i < max; i++) {
      var e = list[i] || {};
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;">' +
            '<div style="font-weight:900;color:#bfdbfe;">' + safe(e.title || 'AI產業事件') + '</div>' +
            '<div style="background:#334155;color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">' + safe(e.industryId || e.sectorLabel || e.sectorCode || '產業') + '</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.88;">' +
            safe(e.description || e.detail || 'AI 判定該產業的需求、資金或風險正在變化。') + '<br>' +
            'AI持續觀察：剩餘約 ' + Number(e.remainingDays || 0).toFixed(1) + ' 天｜強度：' + Number(e.intensity || 0).toFixed(2) +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function render(body) {
    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();
    var regSummary = w.StockMarketRegistry.getRegistrySummary ? (w.StockMarketRegistry.getRegistrySummary(state) || {}) : {};
    var pendingListings = w.StockMarketRegistry.getPendingListings ? (w.StockMarketRegistry.getPendingListings(state) || []) : [];
    var delistWarnings = w.StockMarketRegistry.getDelistWarnings ? (w.StockMarketRegistry.getDelistWarnings(state) || []) : [];
    var listedHistory = regSummary.listedHistory || [];
    var delistedHistory = regSummary.delistedHistory || [];
    var activeCount = Number(regSummary.activeCompanyCount || 0);
    var softMax = Number(regSummary.softMaxActiveCompanies || 0);
    var maxCount = Number(regSummary.maxActiveCompanies || 0);
    var minCount = Number(regSummary.minActiveCompanies || 0);

    var html =
      '<div style="display:flex;flex-direction:column;gap:12px;">' +
        '<div style="background:linear-gradient(135deg,#0b1220,#111827);border:1px solid #263247;border-radius:16px;padding:14px;">' +
          '<div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">' +
            '<div>' +
              '<div style="font-size:22px;font-weight:1000;">🏛️ 上下市紀錄</div>' +
              '<div style="font-size:12px;opacity:.72;margin-top:5px;line-height:1.6;">集中顯示預估上市、預估下市與交易所活動。此頁只描述市場正在發生什麼，不直接給玩家漲跌答案。</div>' +
            '</div>' +
            '<div style="background:#1e293b;color:#dbeafe;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900;">下次更新 ' + w.StockMarketEngine.getSecondsToNextTick(state) + ' 秒</div>' +
          '</div>' +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">' +
          renderStatusCard('上市商會', fmtNum(activeCount) + ' / ' + fmtNum(maxCount), '保底 ' + fmtNum(minCount) + '｜軟上限 ' + fmtNum(softMax), '#e5e7eb') +
          renderStatusCard('預估上市', fmtNum(pendingListings.length) + ' 家', '即將進入公開市場', '#86efac') +
          renderStatusCard('預估下市', fmtNum(delistWarnings.length) + ' 家', '市場觀察名單', '#fca5a5') +
          renderStatusCard('市場活動', '+' + fmtNum(regSummary.listedToday || 0) + ' / -' + fmtNum(regSummary.delistedToday || 0), '上市 / 下市', '#facc15') +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;">' +
          renderSection('🆕 預估上市商會', '放在最上層，讓玩家先看到市場未來可能新增的公司。', renderPendingListings(pendingListings), 260) +
          renderSection('⚠️ 預估下市公司', '只顯示風險狀態與市場觀察，不顯示精準機率。', renderDelistWarnings(delistWarnings), 260) +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;">' +
          renderSection('📗 上市紀錄', '已完成掛牌的市場活動紀錄。', renderListedHistory(listedHistory), 320) +
          renderSection('📕 下市紀錄', '已完成終止交易或清算的市場活動紀錄。', renderDelistedHistory(delistedHistory), 320) +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;">' +
          renderSection('🌡️ 市場氣氛', '簡短描述目前市場狀態。', renderMarketMood(state), 180) +
          renderSection('🏭 產業事件', '只保留少量重要產業事件，避免資訊爆炸。', renderSectorEvents(state), 260) +
        '</div>' +
      '</div>';

    body.innerHTML = RESPONSIVE_MARKET_STYLE + html;
  }

  function update(body) {
    var scrollTop = body ? Number(body.scrollTop || 0) : 0;
    render(body);
    if (body) body.scrollTop = scrollTop;
    setTimeout(function() {
      var b = body || getBody();
      if (b) b.scrollTop = scrollTop;
    }, 0);
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "上下市紀錄",
    render: render,
    update: update
  });
})(window);
