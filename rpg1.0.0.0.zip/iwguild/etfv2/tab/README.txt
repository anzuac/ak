已修正 stock_etf_tab.js

修改內容：

1. 移除 StockActiveETFSystem 依賴
2. 改為使用 UniversalETF
3. active tab 現在讀取：
   mad_dog_fund
4. 買賣功能改成：
   UniversalETF.buy/sell()
5. UI 文案改為：
   瘋狗基金

請直接覆蓋：
iwguild/etfv2/tab/stock_etf_tab.js
