
(function(){
  window.EXD_WORLD_NEWS = window.EXD_WORLD_NEWS || {
    active: [],
    history: [],
    capitalActive: [],
    capitalHistory: []
  };


  function safe(v){
    return String(v == null ? "" : v)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;")
      .replace(/>/g,"&gt;").replace(/"/g,"&quot;")
      .replace(/'/g,"&#39;");
  }

  function getStockState(){
    try{
      if(window.StockStateManager && window.StockStateManager.getState){
        return window.StockStateManager.getState();
      }
    }catch(e){}
    return null;
  }

  function getAIWorldData(){
    var state = getStockState();
    var engine = window.StockMarketEngine || {};
    return {
      state: state,
      stabilizer: engine.getWorldStabilizerInfo ? engine.getWorldStabilizerInfo(state) : null,
      world: engine.getAIWorldEvents ? engine.getAIWorldEvents(state) : [],
      industry: engine.getAIIndustryEvents ? engine.getAIIndustryEvents(state) : [],
      history: engine.getAIEventHistory ? engine.getAIEventHistory(state) : []
    };
  }


  function pushNews(type, title, desc, days){
    const item = {
      id: Date.now() + "_" + Math.random().toString(36).slice(2),
      type: type || "world",
      title: title || "世界局勢變化",
      desc: desc || "",
      remainingDays: days || 0,
      createdAt: Date.now()
    };

    window.EXD_WORLD_NEWS.active.unshift(item);
    window.EXD_WORLD_NEWS.active = window.EXD_WORLD_NEWS.active.slice(0, 10);
    return item;
  }


  function pushCapitalNews(type, title, desc, days){
    const item = {
      id: Date.now() + "_" + Math.random().toString(36).slice(2),
      type: type || "capital",
      title: title || "世界資本動向",
      desc: desc || "",
      remainingDays: days || 0,
      createdAt: Date.now()
    };

    window.EXD_WORLD_NEWS.capitalActive = window.EXD_WORLD_NEWS.capitalActive || [];
    window.EXD_WORLD_NEWS.capitalActive.unshift(item);
    window.EXD_WORLD_NEWS.capitalActive = window.EXD_WORLD_NEWS.capitalActive.slice(0, 8);
    return item;
  }

  function tickNewsDay(){
    const active = window.EXD_WORLD_NEWS.active || [];
    const history = window.EXD_WORLD_NEWS.history || [];
    const capitalActive = window.EXD_WORLD_NEWS.capitalActive || [];
    const capitalHistory = window.EXD_WORLD_NEWS.capitalHistory || [];

    for(let c = capitalActive.length - 1; c >= 0; c--){
      capitalActive[c].remainingDays--;

      if(capitalActive[c].remainingDays <= 0){
        capitalHistory.unshift({
          title: capitalActive[c].title,
          desc: capitalActive[c].desc,
          ended: true,
          endedAt: Date.now()
        });

        capitalHistory.splice(20);
        capitalActive.splice(c,1);
      }
    }

    for(let i = active.length - 1; i >= 0; i--){
      active[i].remainingDays--;

      if(active[i].remainingDays <= 0){
        history.unshift({
          title: active[i].title,
          desc: active[i].desc,
          ended: true,
          endedAt: Date.now()
        });

        history.splice(10);
        active.splice(i,1);
      }
    }
  }

  function renderWorldNewsTab(container){
    if(!container) return;

    var data = getAIWorldData();
    var stabilizer = data.stabilizer || { name:"世界維穩聯盟", active:false };
    var worldEvents = data.world || [];
    var industryEvents = data.industry || [];
    var history = data.history || [];

    let html = '';

    html += '<div style="display:flex;flex-direction:column;gap:12px;">';
var state = getStockState() || {};
var wc = (state.worldClimate || {});

var era =
  (window.AI5_WORLD_ERAS &&
   window.AI5_WORLD_ERAS[0]) ||
  "阿斯特拉帝國曆";

html += `
<div style="
background:linear-gradient(180deg,#101b33,#0a1120);
border:1px solid rgba(120,160,255,.18);
border-radius:16px;
padding:14px;
box-shadow:0 0 18px rgba(80,120,255,.12);
">

<div style="
font-size:18px;
font-weight:900;
color:#dbeafe;
margin-bottom:8px;
">
📜 ${safe(era)} ${Number(wc.year || 417)}年
</div>

<div style="
font-size:13px;
line-height:1.8;
color:#cbd5e1;
">
🌙 ${safe(wc.month || "霜火月")} ${Number(wc.day || 1)}日<br>
☀ ${safe(wc.season || "春")}季 ｜ 
🌦 ${safe(wc.weather || "晴朗")}<br>
🌍 世界狀態：${safe(wc.worldMood || "和平繁榮")}
</div>

</div>
`;
    html += '<div style="background:linear-gradient(180deg,#111827,#070b12);border:1px solid #854d0e;border-radius:14px;padding:14px;box-shadow:0 0 0 1px rgba(250,204,21,.08) inset;">';
    html += '<div style="font-size:18px;font-weight:900;margin-bottom:8px;color:#facc15;">🛡️ 世界維穩國家</div>';
    html += '<div style="font-size:20px;font-weight:1000;color:#fde68a;">' + safe(stabilizer.name || "世界維穩聯盟") + '</div>';
    html += '<div style="font-size:12px;opacity:.76;margin-top:6px;line-height:1.6;">資金：3000京｜國力：？？？｜指數：？？？｜此勢力不參與一般市場，只在文明接近崩潰時出手。</div>';
    if(stabilizer.active){
      html += '<div style="margin-top:10px;padding:10px;border-radius:12px;background:rgba(239,68,68,.16);border:1px solid rgba(239,68,68,.45);color:#fecaca;font-weight:900;">目前援助國家：' + safe(stabilizer.targetName || stabilizer.targetKingdom || '未知王國') + '｜剩餘約 ' + Number(stabilizer.remainingDays || 0).toFixed(1) + ' 天</div>';
    }else{
      html += '<div style="margin-top:10px;color:#86efac;font-size:13px;font-weight:900;">目前沒有啟動最後援助。</div>';
    }
    html += '</div>';

    html += '<div style="background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;">';
    html += '<div style="font-size:18px;font-weight:900;margin-bottom:12px;">🌍 AI 世界事件</div>';

    if(worldEvents.length === 0){
      html += '<div style="opacity:.8;">AI 尚未判定重大世界事件。</div>';
    }else{
      worldEvents.slice(0,8).forEach(function(n){
        html += '<div style="padding:10px 0;border-bottom:1px solid #1f2937;">';
        html += '<div style="font-weight:900;margin-bottom:4px;">' + safe(n.title || '世界事件') + '</div>';
        html += '<div style="opacity:.85;font-size:13px;margin-bottom:6px;">' + safe(n.description || 'AI 世界局勢發生變化。') + '</div>';
        html += '<div style="font-size:12px;color:#93c5fd;">剩餘：約 ' + Number(n.remainingDays || 0).toFixed(1) + ' 天｜強度：' + Number(n.intensity || 0).toFixed(2) + '</div>';
        html += '</div>';
      });
    }

    html += '</div>';

    html += '<div style="background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;">';
    html += '<div style="font-size:18px;font-weight:900;margin-bottom:12px;">🏭 AI 產業事件</div>';

    if(industryEvents.length === 0){
      html += '<div style="opacity:.8;">目前沒有 AI 判定的產業級事件。</div>';
    }else{
      industryEvents.slice(0,8).forEach(function(n){
        html += '<div style="padding:10px 0;border-bottom:1px solid #1f2937;">';
        html += '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;">';
        html += '<div style="font-weight:900;color:#bfdbfe;">' + safe(n.title || '產業事件') + '</div>';
        html += '<div style="background:#334155;color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">' + safe(n.industryId || '產業') + '</div>';
        html += '</div>';
        html += '<div style="opacity:.85;font-size:13px;margin-top:6px;">' + safe(n.description || '產業資金與需求出現變化。') + '</div>';
        html += '<div style="font-size:12px;color:#93c5fd;margin-top:4px;">剩餘：約 ' + Number(n.remainingDays || 0).toFixed(1) + ' 天</div>';
        html += '</div>';
      });
    }

    html += '</div>';

    html += '<div style="background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;">';
    html += '<div style="font-size:16px;font-weight:900;margin-bottom:12px;">📜 AI 事件歷史</div>';

    if(history.length === 0){
      html += '<div style="opacity:.7;">尚無 AI 事件歷史。</div>';
    }else{
      history.slice(0,20).forEach(function(n){
        var color = n.danger ? '#ef4444' : '#e5e7eb';
        html += '<div style="padding:8px 0;border-bottom:1px solid #1f2937;">';
        html += '<div style="font-weight:800;color:' + color + ';">' + safe(n.title || '事件紀錄') + '</div>';
        html += '<div style="opacity:.7;font-size:12px;line-height:1.5;">' + safe(n.description || '') + '｜第 ' + Number(n.createdDay || 0) + ' 天</div>';
        html += '</div>';
      });
    }

    html += '</div>';
    html += '</div>';

    container.innerHTML = html;
  }

  window.pushWorldNews = pushNews;
  window.pushCapitalNews = pushCapitalNews;
  window.tickWorldNewsDay = tickNewsDay;
  window.renderWorldNewsTab = renderWorldNewsTab;
})();
if (window.StockHub) {
  window.StockHub.registerTab({
    id: "world_news",
    title: "📰 世界新聞",

    render: function(container) {
      renderWorldNewsTab(container);
    },

    update: function(container) {
      renderWorldNewsTab(container);
    },

    tick: function() {
      // 不用每秒扣天數
      // 留給每日結算
    },

    onOpen: function(){},
    onClose: function(){}
  });
}

// =====================================================
// AI5.3.0 World Calendar Config
// =====================================================

window.AI5_WORLD_ERAS = [
  "阿斯特拉帝國曆",
  "聖王聯邦紀元",
  "星環文明曆",
  "蒼穹聯盟紀元",
  "永夜王朝曆",
  "白銀皇室紀元"
];

window.AI5_WORLD_NEWS_NETWORKS = [
  "皇家經濟院",
  "世界觀測局",
  "地下情報網",
  "星環魔導院"
];







