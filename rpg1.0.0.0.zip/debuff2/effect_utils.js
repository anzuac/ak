// effect_utils.js

import { STATUS_REGISTRY } from "./status_registry.js";

export function canAct(entity) {

  if (!entity.effects) return true;

  for (const effect of entity.effects) {

    const config =
      STATUS_REGISTRY[effect.id];

    if (config?.blockActions) {
      return false;
    }
  }

  return true;
}

export function getEffectDisplay(entity) {

  if (!entity.effects?.length) {
    return "無";
  }

  return entity.effects.map(effect => {

    const config =
      STATUS_REGISTRY[effect.id];

    if (!config) return null;

    return `${config.icon} ${config.name}`;

  }).filter(Boolean).join("、");
}