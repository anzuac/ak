// ETFV2 7.0.0 NAV Engine
window.ETFNavEngine = {
  updateNAV(etf){
    if(!etf) return;

    let total = etf.cashReserve || 0;

    (etf.holdings || []).forEach(h => {
      total += (h.marketValue || 0);
    });

    etf.totalAssetValue = total;
    etf.nav = Math.max(10, total / Math.max(1, etf.totalShares));
  }
};
