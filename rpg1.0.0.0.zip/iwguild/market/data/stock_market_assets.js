

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function(w) {
  "use strict";

  var SCALE = 1000;

  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function coin(n) {
    return Math.round(Number(n || 0) * SCALE);
  }

  function toLots(shares) {
    return Math.floor(Number(shares || 0) / 1000);
  }

  // ------------------------------------------------------
  // 股權結構正規化
  // 兼容舊 shareConfig，也支援新 equityConfig
  // ------------------------------------------------------
  function normalizeEquityConfig(def) {
    var raw = clone(def.equityConfig || def.shareConfig || {});

    var totalShares = Math.max(
  100000000,
  Math.floor(
    Number(
      raw.totalShares ||
      (
        def.tier === "large" ? 36000000000 : (def.tier === "small" ? 20000000000 : 26000000000)
      )
    )
  )
);
    var publicFloatShares = Math.max(
  50000000,
  Math.floor(
    Number(
      raw.publicFloatShares ||
      raw.floatShares ||
      totalShares * 0.60
    )
  )
);
    publicFloatShares = Math.min(totalShares, publicFloatShares);

    var boardControlRatio = Number(raw.boardControlRatio);
    var stateHoldingRatio = Number(raw.stateHoldingRatio);
    var strategicHoldingRatio = Number(raw.strategicHoldingRatio);
    var marketMakerRatio = Number(raw.marketMakerRatio);

    if (!(boardControlRatio >= 0 && boardControlRatio <= 1)) {
      boardControlRatio = def.tier === "large" ? 0.30 : (def.tier === "small" ? 0.12 : 0.22);
    }

    if (!(stateHoldingRatio >= 0 && stateHoldingRatio <= 1)) {
      stateHoldingRatio = def.stateOwned ? (def.tier === "starter" ? 0.52 : 0.18) : 0;
    }

    if (!(strategicHoldingRatio >= 0 && strategicHoldingRatio <= 1)) {
      strategicHoldingRatio = def.tier === "large" ? 0.28 : (def.tier === "small" ? 0.22 : 0.28);
    }

    if (!(marketMakerRatio >= 0 && marketMakerRatio <= 1)) {
      marketMakerRatio = def.tier === "large" ? 0.18 : (def.tier === "small" ? 0.32 : 0.22);
    }

    var totalReservedRatio = boardControlRatio + stateHoldingRatio + strategicHoldingRatio + marketMakerRatio;
    if (totalReservedRatio > 0.94) {
      var scale = 0.94 / totalReservedRatio;
      boardControlRatio *= scale;
      stateHoldingRatio *= scale;
      strategicHoldingRatio *= scale;
      marketMakerRatio *= scale;
    }

    var boardControlShares = Math.floor(publicFloatShares * boardControlRatio);
    var stateHoldingShares = Math.floor(publicFloatShares * stateHoldingRatio);
    var strategicHoldingShares = Math.floor(publicFloatShares * strategicHoldingRatio);
    var marketMakerShares = Math.floor(publicFloatShares * marketMakerRatio);

    var publicTradableShares = publicFloatShares - boardControlShares - stateHoldingShares - strategicHoldingShares - marketMakerShares;

    if (publicTradableShares < 1000) {
      publicTradableShares = 1000;

      if (marketMakerShares >= 1000) marketMakerShares -= 1000;
      else if (strategicHoldingShares >= 1000) strategicHoldingShares -= 1000;
      else if (stateHoldingShares >= 1000) stateHoldingShares -= 1000;
      else if (boardControlShares >= 1000) boardControlShares -= 1000;
    }

    // 股權欄位統一：
    // insiderShares     = 董事會控制 + 國家持股
    // strategicHoldingShares = 策略型長期持股
    // marketMakerShares = 做市 / 交易持股
    // availableShares   = 公開可交易股
    return {
      totalShares: totalShares,
      floatShares: publicFloatShares,
      lockedShares: Math.max(0, totalShares - publicFloatShares),

      boardControlShares: Math.max(0, boardControlShares),
      stateHoldingShares: Math.max(0, stateHoldingShares),
      strategicHoldingShares: Math.max(0, strategicHoldingShares),
      marketMakerShares: Math.max(0, marketMakerShares),
      publicTradableShares: Math.max(1000, publicTradableShares),

      totalLots: toLots(totalShares),
      floatLots: toLots(publicFloatShares),

      insiderShares: Math.max(0, boardControlShares + stateHoldingShares),
      availableShares: Math.max(1000, publicTradableShares),

      // 市場深度擴張版
      marketDepth:
        def.tier === "large"
          ? 2500000000
          : (def.tier === "small" ? 120000000 : 650000000),

      npcDailyVolume:
        def.tier === "large"
          ? 6000000
          : (def.tier === "small" ? 300000 : 1800000),

      playerImpactWeight:
        def.tier === "large"
          ? 0.08
          : (def.tier === "small" ? 0.42 : 0.22),

    };
  }


  // =====================================================
  // F4.1 商會資本階級工具
  // =====================================================
  function getGuildCapitalTierFromMilli(capitalMilli, def){
    var capitalCoin = Number(capitalMilli || 0) / SCALE;

    if(def && (def.isRoyalEnterprise || def.royalIndexEligible || def.tier === "royal" || def.stateOwned)){
      return {
        id: "sovereign",
        label: "王國最高級別",
        rank: 5
      };
    }

    if(capitalCoin < 3000000){
      return {
        id: "declining",
        label: "沒落商會",
        rank: 0
      };
    }

    if(capitalCoin < 30000000){
      return {
        id: "small_guild",
        label: "小型公會",
        rank: 1
      };
    }

    if(capitalCoin < 100000000){
      return {
        id: "medium_chamber",
        label: "中型商會",
        rank: 2
      };
    }

    return {
      id: "large_alliance",
      label: "大型商盟",
      rank: 3
    };
  }


  // ------------------------------------------------------
  // 公司資料正規化
  // 兼容舊 companyInfo，也支援新 companyProfile
  // ------------------------------------------------------
  function normalizeCompanyProfile(def) {
    var c = clone(def.companyProfile || def.companyInfo || {});
    return {
      shortName: c.shortName || def.name,
      category: c.category || (def.tier === "large" ? "大型股" : (def.tier === "small" ? "小型股" : (def.tier === "starter" ? "新手盤" : "中型股"))),
      descriptionLong: c.descriptionLong || def.desc || "",
      foundedYear: Math.floor(Number(c.foundedYear || 100)),

      assetBaseMilli: Math.max(0, Math.floor(Number(c.assetBaseMilli || 0))),
      revenueBaseMilli: Math.max(0, Math.floor(Number(c.revenueBaseMilli || 0))),
      profitBaseMilli: Math.max(0, Math.floor(Number(c.profitBaseMilli || 0))),

      guildCapitalMilli: Math.max(0, Math.floor(Number(c.guildCapitalMilli || c.capitalMilli || c.assetBaseMilli || 0))),
      guildCapitalBaseMilli: Math.max(0, Math.floor(Number(c.guildCapitalBaseMilli || c.guildCapitalMilli || c.capitalMilli || c.assetBaseMilli || 0))),
      guildCapitalTierId: c.guildCapitalTierId || "",
      guildCapitalTierLabel: c.guildCapitalTierLabel || "",
      guildCapitalTierRank: Math.max(0, Math.floor(Number(c.guildCapitalTierRank || 0))),
      guildCapitalLastUpdateDay: Math.max(0, Math.floor(Number(c.guildCapitalLastUpdateDay || 0))),

      payoutRatio: Math.max(0, Math.min(1, Number(c.payoutRatio || 0.2))),

      quality: Math.max(0, Math.min(1, Number(c.quality || 0.5))),
      stability: Math.max(0, Math.min(1, Number(c.stability || 0.5))),
      hype: Math.max(0, Math.min(1, Number(c.hype || 0.2))),

      notes: c.notes || "",
      ownerType: c.ownerType || (def.stateOwned ? "國營" : "民營")
    };
  }

  // ------------------------------------------------------
  // 市場設定正規化
  // 兼容舊 marketConfig，也支援新 tradingProfile
  // ------------------------------------------------------

  function inferSectorCode(def, company) {
    if (def && def.stateOwned) return "A";
    var category = String(company && company.category || "");
    var tags = Array.isArray(def && def.tags) ? def.tags : [];
    if (/聖療|醫療|生醫/.test(category) || tags.indexOf("holy_care") >= 0 || tags.indexOf("medical") >= 0) return "E";
    if (/金契|金融|金控|證券/.test(category) || tags.indexOf("gold_contract") >= 0 || tags.indexOf("finance") >= 0) return "B";
    if (/魔導|科技|半導體|智能|資訊/.test(category) || tags.indexOf("arcane") >= 0 || tags.indexOf("tech") >= 0) return "C";
    if (/皇家建設|建設|製造|工業|機械|重工/.test(category) || tags.indexOf("royal_build") >= 0 || tags.indexOf("manufacturing") >= 0) return "D";
    if (/魔晶能源|能源|電力|綠能/.test(category) || tags.indexOf("crystal_energy") >= 0 || tags.indexOf("energy") >= 0) return "G";
    if (/天空航路|航路|航運|物流|貨運/.test(category) || tags.indexOf("sky_route") >= 0 || tags.indexOf("shipping") >= 0) return "H";
    if (/糧食|食品|農產|民生/.test(category) || tags.indexOf("grain") >= 0 || tags.indexOf("food") >= 0) return "F";
    if (/古代遺跡|遺跡|資源|材料|礦/.test(category) || tags.indexOf("relic") >= 0 || tags.indexOf("resource") >= 0) return "R";
    if (/王國軍工|軍工|兵裝|媒體|娛樂/.test(category) || tags.indexOf("royal_military") >= 0 || tags.indexOf("media") >= 0) return "M";
    if (/鍊金/.test(category) || tags.indexOf("alchemy") >= 0) return "L";
    if (/冒險/.test(category) || tags.indexOf("adventurer") >= 0) return "V";
    if (/黑市|密貿/.test(category) || tags.indexOf("black_market") >= 0) return "K";
    return "X";
  }

  function formatSymbol(prefix, seq) {
    prefix = String(prefix || "X").toUpperCase().replace(/[^A-Z]/g, "") || "X";
    seq = Math.max(1, Math.floor(Number(seq || 1)));
    return prefix + String(seq).padStart(4, "0");
  }

  function normalizeTradingProfile(def) {
    var m = clone(def.tradingProfile || def.marketConfig || {});
    return {
      liquidity: Number(
        m.liquidity ||
        def.liquidity ||
        (def.tier === "large"
          ? 2500000000
          : (def.tier === "small" ? 120000000 : 650000000))
      ),
      baseVolatility: Number(m.baseVolatility || def.baseVolatility || 0.08),
      risk: Math.max(1, Math.floor(Number(m.risk || def.risk || 1))),
      limitUp: Number(m.limitUp || def.limitUp || 0.10),
      limitDown: Number(m.limitDown || def.limitDown || 0.10),
      style: String(m.style || def.style || "A")
    };
  }

  // ------------------------------------------------------
  // 預設公司
  // 核心股：不下市
  // 動態股：可上下市
  // ------------------------------------------------------
  function createDefaultAssets() {

  // F2.5.3：
  // 王國／皇室核心資產
  // 不納入一般商會加權與 ETF
  // 專門納入「國力指數」

  return {

    // =====================================================
    // 王室聯合商會
    // =====================================================

    royal_union_chamber: {

      id: "royal_union_chamber",
      marketType: "free",
      tier: "royal",
      style: "R",

      name: "王室聯合商會",

      desc:
        "皇室控制的核心商會，負責王國公告、金錢流通與重大消息傳遞。",

      basePrice: coin(80),
      startPrice: coin(80),

      baseTrend: 0,
      unlocked: true,

      stateOwned: true,

      isRoyalEnterprise: true,
      royalTier: "crown",
      royalClass: "王權核心",
      royalIndexEligible: true,

      excludeFromIndex: true,
      excludeFromEtf: true,
      excludeFromDividend: true,

      isCoreListed: true,

      delistProtected: true,
      allowAutoDelist: false,
      allowAutoReplace: false,

      equityConfig: {

        // 2億張 × 1000 股
        totalShares: 200000000000,

        // 60% 市場流通
        publicFloatShares: 120000000000,

        boardControlRatio: 0.10,
        stateHoldingRatio: 0.40,
        strategicHoldingRatio: 0.25,
        marketMakerRatio: 0.15
      },

      tradingProfile: {

        liquidity: 2.20,

        baseVolatility: 0.010,

        risk: 1,

        limitUp: 0.10,
        limitDown: 0.10,

        style: "R"
      },

      companyProfile: {

        shortName: "王室聯合商會",

        category: "皇家產業 / 王室金流",

        descriptionLong:
          "王室聯合商會由皇室直接控制，負責王國級消息發布、金錢流通與王室信用維護。此類資產屬國力核心，不參與一般商會加權。",

        foundedYear: 1,

        assetBaseMilli: coin(4000000000),

        revenueBaseMilli: coin(0),
        profitBaseMilli: coin(0),

        payoutRatio: 0,

        quality: 0.98,
        stability: 0.99,
        hype: 0.02,

        notes:
          "皇家核心資產，不發放股利，不列入一般加權。",

        ownerType: "皇室控制"
      },

      tags: [
        "royal",
        "state",
        "sovereign",
        "finance",
        "news",
        "no_dividend",
        "exclude_index"
      ]
    },

    // =====================================================
    // 七侯聯合商盟
    // =====================================================

    seven_lords_union: {

      id: "seven_lords_union",

      marketType: "free",

      tier: "royal",

      style: "R",

      name: "七侯聯合商盟",

      desc:
        "七大貴族聯合創辦的商盟，負責王國內部大型事務與貴族資本協調。",

      basePrice: coin(35),

      startPrice: coin(35),

      baseTrend: 0,

      unlocked: true,

      stateOwned: false,

      isRoyalEnterprise: true,
      royalTier: "imperial",
      royalClass: "皇權商會",
      royalIndexEligible: true,

      excludeFromIndex: true,
      excludeFromEtf: true,
      excludeFromDividend: true,

      isCoreListed: true,

      delistProtected: true,
      allowAutoDelist: false,
      allowAutoReplace: false,

      equityConfig: {

        // 8000萬張 × 1000 股
        totalShares: 80000000000,

        // 60% 流通
        publicFloatShares: 48000000000,

        boardControlRatio: 0.35,
        stateHoldingRatio: 0.05,
        strategicHoldingRatio: 0.30,
        marketMakerRatio: 0.15
      },

      tradingProfile: {

        liquidity: 1.40,

        baseVolatility: 0.018,

        risk: 1,

        limitUp: 0.10,
        limitDown: 0.10,

        style: "R"
      },

      companyProfile: {

        shortName: "七侯聯合商盟",

        category: "皇家產業 / 貴族商盟",

        descriptionLong:
          "七侯聯合商盟由七大貴族共同設立，用於協調貴族資本、領地資源與王國大型行政事務。此類資產屬國力核心，不參與一般商會加權。",

        foundedYear: 8,

        assetBaseMilli: coin(2800000000),

        revenueBaseMilli: coin(0),
        profitBaseMilli: coin(0),

        payoutRatio: 0,

        quality: 0.94,
        stability: 0.96,
        hype: 0.04,

        notes:
          "貴族聯合控制，不發放股利，不列入一般加權。",

        ownerType: "貴族聯合"
      },

      tags: [
        "royal",
        "noble",
        "state",
        "administration",
        "no_dividend",
        "exclude_index"
      ]
    },

    // =====================================================
    // 外交聯合商會
    // =====================================================

    diplomatic_union_chamber: {

      id: "diplomatic_union_chamber",

      marketType: "free",

      tier: "royal",

      style: "R",

      name: "外交聯合商會",

      desc:
        "負責外交事務、跨國貿易與王國對外金流往來的核心商會。",

      basePrice: coin(730),

      startPrice: coin(730),

      baseTrend: 0,

      unlocked: true,

      stateOwned: true,

      isRoyalEnterprise: true,
      royalTier: "royal",
      royalClass: "皇家戰略",
      royalIndexEligible: true,

      excludeFromIndex: true,
      excludeFromEtf: true,
      excludeFromDividend: true,

      isCoreListed: true,

      delistProtected: true,
      allowAutoDelist: false,
      allowAutoReplace: false,

      equityConfig: {

        // 3000萬張 × 1000 股
        totalShares: 30000000000,

        // 60% 流通
        publicFloatShares: 18000000000,

        boardControlRatio: 0.20,
        stateHoldingRatio: 0.35,
        strategicHoldingRatio: 0.25,
        marketMakerRatio: 0.10
      },

      tradingProfile: {

        liquidity: 1.20,

        baseVolatility: 0.016,

        risk: 1,

        limitUp: 0.10,
        limitDown: 0.10,

        style: "R"
      },

      companyProfile: {

        shortName: "外交聯合商會",

        category: "皇家產業 / 外交貿易",

        descriptionLong:
          "外交聯合商會負責王國外交事務、跨國貿易、外交禮品與對外金流往來，是王國對外信用的核心窗口。此類資產屬國力核心，不參與一般商會加權。",

        foundedYear: 12,

        assetBaseMilli: coin(83600000000),

        revenueBaseMilli: coin(0),
        profitBaseMilli: coin(0),

        payoutRatio: 0,

        quality: 0.96,
        stability: 0.97,
        hype: 0.03,

        notes:
          "王國外交核心資產，不發放股利，不列入一般加權。",

        ownerType: "王國外交署"
      },

      tags: [
        "royal",
        "state",
        "diplomacy",
        "trade",
        "no_dividend",
        "exclude_index"
      ]
    }
  };
}

  function createRuntimeAssets() {
    var defs = createDefaultAssets();
    var out = {};
    var symbolCounters = {};
    var id, def, equity, trading, company;

    for (id in defs) {
      if (!Object.prototype.hasOwnProperty.call(defs, id)) continue;
      def = defs[id];

      trading = normalizeTradingProfile(def);
      company = normalizeCompanyProfile(def);

      var capitalTier = getGuildCapitalTierFromMilli(
        company.guildCapitalMilli || company.assetBaseMilli,
        def
      );

      company.guildCapitalTierId = capitalTier.id;
      company.guildCapitalTierLabel = capitalTier.label;
      company.guildCapitalTierRank = capitalTier.rank;

      if(!(company.guildCapitalBaseMilli > 0)){
        company.guildCapitalBaseMilli = company.guildCapitalMilli || company.assetBaseMilli || 0;
      }


      if (def.marketType === "free") {
        equity = normalizeEquityConfig(def);
      } else {
        equity = {
          totalShares: 0,
          floatShares: 0,
          lockedShares: 0,

          boardControlShares: 0,
          stateHoldingShares: 0,
          strategicHoldingShares: 0,
          marketMakerShares: 0,
          publicTradableShares: 0,

          totalLots: 0,
          floatLots: 0,

          insiderShares: 0,
          strategicHoldingShares: 0,
          marketMakerShares: 0,
          availableShares: 0
        };
      }

      var sectorCode = inferSectorCode(def, company);
      symbolCounters[sectorCode] = Math.max(0, Number(symbolCounters[sectorCode] || 0)) + 1;

      out[id] = {
        id: def.id,
        marketType: def.marketType || "starter",
        tier: def.tier || "starter",
        style: def.style || trading.style || "A",
        name: def.name,
        shortName: company.shortName,
        sectorCode: sectorCode,
        symbol: formatSymbol(sectorCode, symbolCounters[sectorCode]),
        desc: def.desc || "",
        basePrice: def.basePrice,
        price: def.startPrice,
        startPrice: def.startPrice,
        baseTrend: Number(def.baseTrend || 0),
        unlocked: !!def.unlocked,
        tags: clone(def.tags || []),

        // 新增市場定位
        stateOwned: !!def.stateOwned,
        isCoreListed: !!def.isCoreListed,
        delistProtected: !!def.delistProtected,
        allowAutoDelist: !!def.allowAutoDelist,
        allowAutoReplace: !!def.allowAutoReplace,
        isRoyalEnterprise: !!def.isRoyalEnterprise,
        royalTier: String(def.royalTier || (def.isRoyalEnterprise ? "royal" : "none")),
        royalClass: String(def.royalClass || ""),
        royalIndexEligible: !!def.royalIndexEligible,
        excludeFromIndex: !!def.excludeFromIndex,
        excludeFromEtf: !!def.excludeFromEtf,
        excludeFromDividend: !!def.excludeFromDividend,

        risk: trading.risk,
        limitUp: trading.limitUp,
        limitDown: trading.limitDown,
        liquidity: trading.liquidity,
        baseVolatility: trading.baseVolatility,

        dayOpenPrice: def.startPrice,
        dayHighPrice: def.startPrice,
        dayLowPrice: def.startPrice,
        lastClosePrice: def.startPrice,
        lastChangePct: 0,
        lastChangeValue: 0,

        totalShares: equity.totalShares,
        floatShares: equity.floatShares,
        lockedShares: equity.lockedShares,

        insiderShares: equity.insiderShares,
        availableShares: equity.availableShares,

        boardControlShares: equity.boardControlShares,
        stateHoldingShares: equity.stateHoldingShares,
        strategicHoldingShares: equity.strategicHoldingShares,
        marketMakerShares: equity.marketMakerShares,
        publicTradableShares: equity.publicTradableShares,

        companyInfo: company,

        guildCapitalMilli: company.guildCapitalMilli || company.assetBaseMilli || 0,
        guildCapitalBaseMilli: company.guildCapitalBaseMilli || company.guildCapitalMilli || company.assetBaseMilli || 0,
        guildCapitalTierId: company.guildCapitalTierId,
        guildCapitalTierLabel: company.guildCapitalTierLabel,
        guildCapitalTierRank: company.guildCapitalTierRank,
        guildCapitalLastUpdateDay: 0,


        companyMetrics: {
          assetsMilli: company.assetBaseMilli,
          revenueMonthlyMilli: company.revenueBaseMilli,
          profitMonthlyMilli: company.profitBaseMilli,
          estimatedDividendPerShareMilli: 0,
          lastDividendPerShareMilli: 0,

          avgVolume5: 0,
          avgVolume30: 0,
          latestDailyVolume: 0,
          basePayoutRatio: company.payoutRatio,
          currentPayoutRatio: company.payoutRatio
        },

        trendHistory: [],
        volumeHistory: [],

        _npcBuy: 0,
        _npcSell: 0,
        _lastPressure: 0,
        _lastFlowRatio: 0,
        _lastFairValue: def.startPrice,
        _lastPlayerTradeImpact: 0,
        meanPrice: def.startPrice,
        momentum: 0,
        limitLocked: false,
        limitType: null,

        playerImpactBuy: 0,
        playerImpactSell: 0,
        playerImpactDecay: 0.92,
        playerRecentNetFlow: 0
      };
    }

    return out;
  }

  w.StockMarketAssets = {
    SCALE: SCALE,
    coin: coin,
    toLots: toLots,

    normalizeEquityConfig: normalizeEquityConfig,
    normalizeCompanyProfile: normalizeCompanyProfile,
    normalizeTradingProfile: normalizeTradingProfile,
    getGuildCapitalTierFromMilli: getGuildCapitalTierFromMilli,

    createDefaultAssets: createDefaultAssets,
    createRuntimeAssets: createRuntimeAssets
  };
})(window);