

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

// ======================================================
// stock_market_company_templates.js
// 公司固定模板：產業 / tier / 董事會態度
// ======================================================
(function (w) {
  "use strict";

  var SCALE = (w.StockMarketEngine && w.StockMarketEngine.SCALE) || 1000;

  function randRange(min, max) {
    min = Number(min || 0);
    max = Number(max || 0);
    return min + Math.random() * (max - min);
  }

  function randInt(min, max) {
    min = Math.floor(Number(min || 0));
    max = Math.floor(Number(max || 0));
    return Math.floor(randRange(min, max + 1));
  }

  function pick(arr) {
    if (!arr || !arr.length) return null;
    return arr[randInt(0, arr.length - 1)];
  }

  function clamp(v, min, max) {
    v = Number(v || 0);
    return Math.max(min, Math.min(max, v));
  }

  function percentOf(total, ratio) {
    return Math.floor(Number(total || 0) * Number(ratio || 0));
  }

  var INDUSTRY_TEMPLATES = {
    arcane: {
      id: "arcane",
      label: "魔導工坊",
      descriptionPool: [
        "專精魔導器、符印核心與奧術設備，成長性與題材性高。",
        "技術突破會快速推升市場期待，但研發失敗也會放大波動。",
        "屬於高成長產業，適合作為世界技術進步的主要受惠者。"
      ],
      priceRangeMilli: [70000, 220000],
      qualityRange: [0.48, 0.86],
      stabilityRange: [0.38, 0.72],
      hypeRange: [0.50, 0.95],
      basePayoutRange: [0.04, 0.18],
      volatilityRange: [1.08, 1.45],
      liquidityBase: [0.90, 1.18],
      profitMarginRange: [0.07, 0.30],
      revenueFactor: [0.95, 1.28],
      shareBoostRange: [0.00, 0.28],
      riskByTier: { starter: 2, small: 4, mid: 3, large: 2 }
    },

    crystal_energy: {
      id: "crystal_energy",
      label: "魔晶能源",
      descriptionPool: [
        "掌握魔晶供應、能源轉換與城市動力，是文明運轉的基礎。",
        "冬季取暖與夏季控溫需求會使成交量與波動提高。",
        "受資源供需、氣候與王國政策影響明顯。"
      ],
      priceRangeMilli: [60000, 180000],
      qualityRange: [0.48, 0.80],
      stabilityRange: [0.45, 0.78],
      hypeRange: [0.30, 0.68],
      basePayoutRange: [0.10, 0.30],
      volatilityRange: [0.98, 1.32],
      liquidityBase: [0.95, 1.28],
      profitMarginRange: [0.05, 0.23],
      revenueFactor: [0.96, 1.24],
      shareBoostRange: [0.15, 0.45],
      riskByTier: { starter: 1, small: 4, mid: 3, large: 2 }
    },

    royal_military: {
      id: "royal_military",
      label: "王國軍工",
      descriptionPool: [
        "承接王國軍備、城防器械與戰略物資，戰亂時成交量會放大。",
        "平時營運穩定，戰事與邊境衝突會帶來明顯題材。",
        "具政策色彩，適合成為戰爭與防衛事件的核心產業。"
      ],
      priceRangeMilli: [55000, 170000],
      qualityRange: [0.50, 0.82],
      stabilityRange: [0.50, 0.82],
      hypeRange: [0.28, 0.72],
      basePayoutRange: [0.08, 0.26],
      volatilityRange: [0.96, 1.30],
      liquidityBase: [1.00, 1.35],
      profitMarginRange: [0.06, 0.22],
      revenueFactor: [0.95, 1.25],
      shareBoostRange: [0.20, 0.70],
      riskByTier: { starter: 1, small: 3, mid: 3, large: 2 }
    },

    sky_route: {
      id: "sky_route",
      label: "天空航路",
      descriptionPool: [
        "經營飛艇、傳送門補給與跨域航線，景氣與天候影響極高。",
        "黑霧、暴雪與戰亂會壓抑航線，和平與貿易活絡時受惠。",
        "屬於循環型產業，波動通常高於防禦型商會。"
      ],
      priceRangeMilli: [45000, 150000],
      qualityRange: [0.42, 0.76],
      stabilityRange: [0.34, 0.66],
      hypeRange: [0.34, 0.70],
      basePayoutRange: [0.06, 0.25],
      volatilityRange: [1.08, 1.48],
      liquidityBase: [0.88, 1.18],
      profitMarginRange: [0.03, 0.24],
      revenueFactor: [0.92, 1.25],
      shareBoostRange: [0.00, 0.30],
      riskByTier: { starter: 2, small: 4, mid: 3, large: 3 }
    },

    grain: {
      id: "grain",
      label: "糧食聯盟",
      descriptionPool: [
        "負責糧食、酒館供應與民生配送，屬於防禦型基礎產業。",
        "豐收季穩定，寒冬、封鎖與災害可能使需求或成本上升。",
        "通常波動較低，適合作為市場穩定器。"
      ],
      priceRangeMilli: [40000, 120000],
      qualityRange: [0.55, 0.82],
      stabilityRange: [0.65, 0.90],
      hypeRange: [0.16, 0.45],
      basePayoutRange: [0.22, 0.45],
      volatilityRange: [0.78, 1.05],
      liquidityBase: [0.92, 1.20],
      profitMarginRange: [0.06, 0.18],
      revenueFactor: [0.90, 1.12],
      shareBoostRange: [0.00, 0.22],
      riskByTier: { starter: 1, small: 2, mid: 2, large: 1 }
    },

    holy_care: {
      id: "holy_care",
      label: "聖療教院",
      descriptionPool: [
        "提供治療術、聖藥與復原服務，受災害與戰後需求影響。",
        "研發與教院認證會帶來估值變化，但整體需求穩定。",
        "兼具防禦與成長特性。"
      ],
      priceRangeMilli: [50000, 160000],
      qualityRange: [0.50, 0.84],
      stabilityRange: [0.48, 0.80],
      hypeRange: [0.28, 0.65],
      basePayoutRange: [0.08, 0.26],
      volatilityRange: [0.92, 1.22],
      liquidityBase: [0.86, 1.12],
      profitMarginRange: [0.06, 0.24],
      revenueFactor: [0.88, 1.18],
      shareBoostRange: [0.00, 0.20],
      riskByTier: { starter: 1, small: 3, mid: 2, large: 2 }
    },

    gold_contract: {
      id: "gold_contract",
      label: "金契商會",
      descriptionPool: [
        "經營金契、保證金、王都票據與商會清算，屬於穩定權值產業。",
        "信心與監管事件會影響估值，但平時波動較低。",
        "配息能力與資產信任度是核心。"
      ],
      priceRangeMilli: [60000, 160000],
      qualityRange: [0.56, 0.85],
      stabilityRange: [0.65, 0.92],
      hypeRange: [0.12, 0.38],
      basePayoutRange: [0.24, 0.50],
      volatilityRange: [0.76, 1.02],
      liquidityBase: [1.00, 1.30],
      profitMarginRange: [0.10, 0.26],
      revenueFactor: [0.94, 1.12],
      shareBoostRange: [0.10, 0.30],
      riskByTier: { starter: 1, small: 2, mid: 2, large: 1 }
    },

    royal_build: {
      id: "royal_build",
      label: "皇家建設",
      descriptionPool: [
        "負責城牆、道路、港口與戰後重建，受王國預算與災後需求帶動。",
        "平時穩定，重大工程與戰後重建會提高成交量。",
        "具政策與景氣雙重屬性。"
      ],
      priceRangeMilli: [42000, 135000],
      qualityRange: [0.46, 0.80],
      stabilityRange: [0.52, 0.84],
      hypeRange: [0.18, 0.52],
      basePayoutRange: [0.14, 0.35],
      volatilityRange: [0.88, 1.16],
      liquidityBase: [0.92, 1.22],
      profitMarginRange: [0.05, 0.19],
      revenueFactor: [0.92, 1.20],
      shareBoostRange: [0.10, 0.35],
      riskByTier: { starter: 1, small: 3, mid: 2, large: 2 }
    },

    alchemy: {
      id: "alchemy",
      label: "鍊金工坊",
      descriptionPool: [
        "製作藥劑、強化素材與實驗性消耗品，題材與事件率偏高。",
        "配方突破可帶來短期熱潮，事故也可能快速壓低信心。",
        "波動較高，但成長機會明顯。"
      ],
      priceRangeMilli: [35000, 140000],
      qualityRange: [0.42, 0.80],
      stabilityRange: [0.34, 0.70],
      hypeRange: [0.40, 0.82],
      basePayoutRange: [0.05, 0.22],
      volatilityRange: [1.08, 1.48],
      liquidityBase: [0.82, 1.12],
      profitMarginRange: [0.04, 0.27],
      revenueFactor: [0.90, 1.26],
      shareBoostRange: [-0.05, 0.18],
      riskByTier: { starter: 2, small: 4, mid: 3, large: 2 }
    },

    adventurer: {
      id: "adventurer",
      label: "冒險公會",
      descriptionPool: [
        "承接探索、護衛與素材委託，受世界事件與魔獸活動影響。",
        "成交量與人氣常隨冒險潮而波動。",
        "兼具高成長與高風險特色。"
      ],
      priceRangeMilli: [30000, 130000],
      qualityRange: [0.38, 0.78],
      stabilityRange: [0.30, 0.66],
      hypeRange: [0.44, 0.88],
      basePayoutRange: [0.04, 0.20],
      volatilityRange: [1.12, 1.55],
      liquidityBase: [0.80, 1.12],
      profitMarginRange: [0.03, 0.24],
      revenueFactor: [0.88, 1.30],
      shareBoostRange: [-0.08, 0.20],
      riskByTier: { starter: 2, small: 4, mid: 4, large: 3 }
    },

    black_market: {
      id: "black_market",
      label: "黑市密貿",
      descriptionPool: [
        "經營禁物、情報與地下交易，流動性不穩且波動極高。",
        "黑霧、查緝與戰亂會使成交量暴增或瞬間枯竭。",
        "屬於高風險題材產業。"
      ],
      priceRangeMilli: [25000, 110000],
      qualityRange: [0.30, 0.72],
      stabilityRange: [0.22, 0.55],
      hypeRange: [0.50, 0.95],
      basePayoutRange: [0.00, 0.12],
      volatilityRange: [1.25, 1.75],
      liquidityBase: [0.65, 0.98],
      profitMarginRange: [0.02, 0.30],
      revenueFactor: [0.82, 1.35],
      shareBoostRange: [-0.20, 0.10],
      riskByTier: { starter: 3, small: 5, mid: 4, large: 4 }
    },

    relic: {
      id: "relic",
      label: "古代遺跡",
      descriptionPool: [
        "探索遺跡、古代裝置與失落素材，收益不穩但爆發力強。",
        "新遺跡發現會帶來高度題材，失敗則容易回落。",
        "適合作為高波動概念型產業。"
      ],
      priceRangeMilli: [28000, 125000],
      qualityRange: [0.32, 0.76],
      stabilityRange: [0.24, 0.60],
      hypeRange: [0.48, 0.92],
      basePayoutRange: [0.00, 0.16],
      volatilityRange: [1.18, 1.65],
      liquidityBase: [0.70, 1.02],
      profitMarginRange: [0.02, 0.28],
      revenueFactor: [0.80, 1.32],
      shareBoostRange: [-0.30, 0.00],
      riskByTier: { starter: 3, small: 5, mid: 4, large: 4 }
    }
  };


  var INDUSTRY_SECTOR_CODES = {
    arcane: "C",
    crystal_energy: "G",
    royal_military: "M",
    sky_route: "H",
    grain: "F",
    holy_care: "E",
    gold_contract: "B",
    royal_build: "D",
    alchemy: "L",
    adventurer: "V",
    black_market: "K",
    relic: "R"
  };

  var TIER_TEMPLATES = {
    starter: {
      id: "starter",
      label: "皇家基準股",
      totalSharesRange: [20000000000, 24000000000],
      assetsRangeCoin: [800000000, 2600000000],
      revenueRangeCoin: [40000000, 140000000],
      floatRatioRange: [0.56, 0.64],
      insiderRatioRange: [0.18, 0.24],
      strategicHoldingRatioRange: [0.12, 0.18],
      marketMakerRatioRange: [0.08, 0.14]
    },

    small: {
      id: "small",
      label: "地方商會",
      totalSharesRange: [20000000000, 28000000000],
      assetsRangeCoin: [900000000, 4200000000],
      revenueRangeCoin: [45000000, 180000000],
      floatRatioRange: [0.56, 0.64],
      insiderRatioRange: [0.18, 0.25],
      strategicHoldingRatioRange: [0.12, 0.20],
      marketMakerRatioRange: [0.08, 0.16]
    },

    mid: {
      id: "mid",
      label: "城邦商會",
      totalSharesRange: [22000000000, 36000000000],
      assetsRangeCoin: [1800000000, 9000000000],
      revenueRangeCoin: [90000000, 360000000],
      floatRatioRange: [0.56, 0.64],
      insiderRatioRange: [0.18, 0.24],
      strategicHoldingRatioRange: [0.14, 0.22],
      marketMakerRatioRange: [0.08, 0.15]
    },

    large: {
      id: "large",
      label: "王國財團",
      totalSharesRange: [26000000000, 50000000000],
      assetsRangeCoin: [6000000000, 36000000000],
      revenueRangeCoin: [240000000, 1600000000],
      floatRatioRange: [0.56, 0.64],
      insiderRatioRange: [0.16, 0.22],
      strategicHoldingRatioRange: [0.14, 0.22],
      marketMakerRatioRange: [0.08, 0.14]
    }
  };

  var BOARD_TEMPLATES = {
    conservative: {
      id: "conservative",
      label: "保守釋股",
      floatAdjustRange: [-0.08, -0.03],
      priceAdjustRange: [0.03, 0.12],
      liquidityAdjustRange: [-0.10, -0.04]
    },

    neutral: {
      id: "neutral",
      label: "正常上市",
      floatAdjustRange: [-0.02, 0.02],
      priceAdjustRange: [-0.03, 0.03],
      liquidityAdjustRange: [-0.02, 0.02]
    },

    aggressive: {
      id: "aggressive",
      label: "積極募資",
      floatAdjustRange: [0.04, 0.12],
      priceAdjustRange: [-0.08, -0.02],
      liquidityAdjustRange: [0.05, 0.15]
    }
  };

  var INDUSTRY_SEQUENCE = [
    "arcane", "crystal_energy", "royal_military", "sky_route",
    "grain", "holy_care", "gold_contract", "royal_build",
    "alchemy", "adventurer", "black_market", "relic"
  ];

  var industryCursor = randInt(0, INDUSTRY_SEQUENCE.length - 1);

  function toMilliFromCoin(coin) {
    return Math.floor(Number(coin || 0) * SCALE);
  }

  function pickIndustryId() {
    // 配額輪替：避免 50~60 間公司過度集中在單一產業。
    if (!INDUSTRY_SEQUENCE.length) return pick(Object.keys(INDUSTRY_TEMPLATES));
    var id = INDUSTRY_SEQUENCE[industryCursor % INDUSTRY_SEQUENCE.length];
    industryCursor++;
    return id;
  }

  function pickTierId() {
    var roll = Math.random();
    if (roll < 0.35) return "small";
    if (roll < 0.82) return "mid";
    return "large";
  }

  function pickBoardId() {
    var roll = Math.random();
    if (roll < 0.30) return "conservative";
    if (roll < 0.75) return "neutral";
    return "aggressive";
  }


  // =====================================================
  // F4.1 商會資本階級
  // =====================================================
  function rollGuildCapitalCoin(tierId){
    tierId = String(tierId || "small");

    var bonus = 1;
    if(Math.random() < 0.08) bonus = randRange(1.25, 2.80);

    if(tierId === "large"){
      return randRange(100000000, 200000000) * bonus;
    }

    if(tierId === "mid"){
      return randRange(30000000, 80000000) * bonus;
    }

    if(tierId === "starter"){
      return randRange(100000000, 200000000) * bonus;
    }

    return randRange(3000000, 15000000) * bonus;
  }

  function getGuildCapitalTierFromCoin(capitalCoin, tierId, isRoyal){
    capitalCoin = Number(capitalCoin || 0);

    if(isRoyal || tierId === "royal" || tierId === "starter"){
      return {
        id: "sovereign",
        label: "王國最高級別",
        rank: 5
      };
    }

    if(capitalCoin < 3000000){
      return {
        id: "declining",
        label: "沒落商會",
        rank: 0
      };
    }

    if(capitalCoin < 30000000){
      return {
        id: "small_guild",
        label: "小型公會",
        rank: 1
      };
    }

    if(capitalCoin < 100000000){
      return {
        id: "medium_chamber",
        label: "中型商會",
        rank: 2
      };
    }

    return {
      id: "large_alliance",
      label: "大型商盟",
      rank: 3
    };
  }



  // =====================================================
  // F4.1.2 / F4.2 AI 股票發行核心
  // =====================================================
  function chooseAiParValueMilli(industry, tier, board, capitalCoin){
    var base;

    if(tier && tier.id === "large") base = randRange(12, 28);
    else if(tier && tier.id === "mid") base = randRange(6, 18);
    else base = randRange(2, 10);

    var label =
      String((industry && industry.label) || "") +
      " " +
      String((board && board.label) || "");

    if(/黑市|冒險|新創|成長|魔導/.test(label)){
      base *= randRange(0.55, 0.95);
    }

    if(/王國|軍工|建設|金契|金融/.test(label)){
      base *= randRange(1.05, 1.65);
    }

    if(capitalCoin > 100000000){
      base *= randRange(1.10, 1.60);
    }

    return Math.max(1, Math.floor(base * SCALE));
  }

  function chooseAiPERatio(industry, tier, board){
    var label =
      String((industry && industry.label) || "") +
      " " +
      String((board && board.label) || "");

    var pe = randRange(8, 22);

    if(/魔導|科技|新創|成長/.test(label)){
      pe = randRange(18, 42);
    }

    if(/黑市|冒險/.test(label)){
      pe = randRange(6, 55);
    }

    if(/軍工|能源/.test(label)){
      pe = randRange(10, 30);
    }

    if(/王國|金契|金融|建設/.test(label)){
      pe = randRange(8, 20);
    }

    if(tier && tier.id === "large"){
      pe *= randRange(0.85, 1.20);
    }

    return Math.max(4, pe);
  }


  // =====================================================
  // F4.2.1 異世界市場份額核心
  // =====================================================
  function chooseLiquidityShareMultiplier(tierId, capitalTier){
    tierId = String(tierId || "small");
    var capitalTierId = String((capitalTier && capitalTier.id) || "");

    // 股票份額不再等於真實資本額，而是市場流動性容器。
    if(capitalTierId === "sovereign" || tierId === "royal" || tierId === "starter"){
      return randRange(1200, 3200);
    }

    if(capitalTierId === "large_alliance" || tierId === "large"){
      return randRange(320, 900);
    }

    if(capitalTierId === "medium_chamber" || tierId === "mid"){
      return randRange(120, 360);
    }

    if(capitalTierId === "declining"){
      return randRange(20, 80);
    }

    return randRange(60, 180);
  }

  function getMinimumLotsByCapitalTier(tierId, capitalTier){
    tierId = String(tierId || "small");
    var capitalTierId = String((capitalTier && capitalTier.id) || "");

    // 單位：張。1張=1000股。
    if(capitalTierId === "sovereign" || tierId === "royal" || tierId === "starter"){
      return randInt(50000000, 180000000);
    }

    if(capitalTierId === "large_alliance" || tierId === "large"){
      return randInt(20000000, 80000000);
    }

    if(capitalTierId === "medium_chamber" || tierId === "mid"){
      return randInt(3000000, 12000000);
    }

    if(capitalTierId === "declining"){
      return randInt(800000, 2500000);
    }

    return randInt(1000000, 6000000);
  }

  function computeLiquiditySharesFromCapital(capitalCoin, parValueMilli, tierId, capitalTier){
    var multiplier =
      chooseLiquidityShareMultiplier(tierId, capitalTier);

    var rawShares =
      Math.floor(
        (capitalCoin * SCALE * multiplier) /
        Math.max(1, parValueMilli)
      );

    var minimumShares =
      getMinimumLotsByCapitalTier(tierId, capitalTier) *
      1000;

    return Math.max(
      minimumShares,
      rawShares
    );
  }


  function chooseAiPayoutRatio(industry, tier, board, basePayout){
    var label =
      String((industry && industry.label) || "") +
      " " +
      String((board && board.label) || "");

    var payout = Number(basePayout || 0.2);

    if(/王國|金契|金融|建設|民生/.test(label)){
      payout += randRange(0.08, 0.22);
    }

    if(/魔導|新創|成長/.test(label)){
      payout -= randRange(0.05, 0.18);
    }

    if(/黑市|冒險/.test(label)){
      payout *= randRange(0.15, 0.75);
    }

    return clamp(payout, 0.01, 0.78);
  }


  function buildBaseProfile(industryId, tierId, boardId) {
    var industry = INDUSTRY_TEMPLATES[industryId];
    var tier = TIER_TEMPLATES[tierId];
    var board = BOARD_TEMPLATES[boardId];

    if (!industry || !tier || !board) {
      throw new Error("無效的模板參數: industry=" + industryId + ", tier=" + tierId + ", board=" + boardId);
    }

    var totalShares = randInt(tier.totalSharesRange[0], tier.totalSharesRange[1]);

    // F2.5.1：全部公司以 2000 萬張 ×1000 股為基準，再依產業資本需求微調。
    var shareBoostRange = industry.shareBoostRange || [0, 0];
    totalShares = Math.max(
      20000000000,
      Math.floor(totalShares * (1 + randRange(shareBoostRange[0], shareBoostRange[1])))
    );

    var baseFloatRatio = randRange(tier.floatRatioRange[0], tier.floatRatioRange[1]);
    var insiderRatio = randRange(tier.insiderRatioRange[0], tier.insiderRatioRange[1]);
    var strategicHoldingRatioRange = tier.strategicHoldingRatioRange;
    var marketMakerRatioRange = tier.marketMakerRatioRange;

    var strategicHoldingRatio = randRange(strategicHoldingRatioRange[0], strategicHoldingRatioRange[1]);
    var marketMakerRatio = randRange(marketMakerRatioRange[0], marketMakerRatioRange[1]);

    var floatAdjust = randRange(board.floatAdjustRange[0], board.floatAdjustRange[1]);
    var finalFloatRatio = clamp(baseFloatRatio + floatAdjust, 0.12, 0.55);

    var insiderShares = percentOf(totalShares, insiderRatio);
    var strategicHoldingShares = percentOf(totalShares, strategicHoldingRatio);
    var marketMakerShares = percentOf(totalShares, marketMakerRatio);

    var lockedShares = insiderShares + strategicHoldingShares;
    var floatShares = percentOf(totalShares, finalFloatRatio);

    if (floatShares + lockedShares > totalShares) {
      floatShares = Math.max(0, totalShares - lockedShares);
    }

    var availableShares = Math.max(0, Math.min(floatShares, marketMakerShares + Math.floor(floatShares * 0.35)));

    var basePrice = randInt(industry.priceRangeMilli[0], industry.priceRangeMilli[1]);
    var finalPrice = Math.floor(basePrice * (1 + randRange(board.priceAdjustRange[0], board.priceAdjustRange[1])));

    var quality = randRange(industry.qualityRange[0], industry.qualityRange[1]);
    var stability = randRange(industry.stabilityRange[0], industry.stabilityRange[1]);
    var hype = randRange(industry.hypeRange[0], industry.hypeRange[1]);
    var basePayoutRatio = randRange(industry.basePayoutRange[0], industry.basePayoutRange[1]);
    var currentPayoutRatio = clamp(basePayoutRatio + randRange(-0.04, 0.04), 0.02, 0.75);

    var assetsCoinBase = randRange(tier.assetsRangeCoin[0], tier.assetsRangeCoin[1]);
    var revenueCoinBase = randRange(tier.revenueRangeCoin[0], tier.revenueRangeCoin[1]) * randRange(industry.revenueFactor[0], industry.revenueFactor[1]);
    var profitMargin = randRange(industry.profitMarginRange[0], industry.profitMarginRange[1]);
    var profitCoin = revenueCoinBase * profitMargin;

    var guildCapitalCoin = rollGuildCapitalCoin(tierId);
    var guildCapitalTier = getGuildCapitalTierFromCoin(guildCapitalCoin, tierId, false);

    // F4.1.2：股票發行改由資本額與AI面額決定
    var aiParValueMilli =
      chooseAiParValueMilli(industry, tier, board, guildCapitalCoin);

    // F4.2.1：
    // 資本額決定商會實力與股價基礎，
    // 股票份額改由市場流動性倍率決定。
    // 因此小型商會也會有大量市場份額，不再被資本額直接限制。
    var liquidityShareMultiplier =
      chooseLiquidityShareMultiplier(tierId, guildCapitalTier);

    totalShares =
      computeLiquiditySharesFromCapital(
        guildCapitalCoin,
        aiParValueMilli,
        tierId,
        guildCapitalTier
      );

    var aiPeRatio =
      chooseAiPERatio(industry, tier, board);


    // F4.1.2：依AI資本股數重新分配股權
    insiderShares = percentOf(totalShares, insiderRatio);
    strategicHoldingShares = percentOf(totalShares, strategicHoldingRatio);
    marketMakerShares = percentOf(totalShares, marketMakerRatio);
    lockedShares = insiderShares + strategicHoldingShares;
    floatShares = percentOf(totalShares, finalFloatRatio);

    if (floatShares + lockedShares > totalShares) {
      floatShares = Math.max(0, totalShares - lockedShares);
    }

    availableShares = Math.max(1000, Math.min(floatShares, marketMakerShares + Math.floor(floatShares * 0.35)));

    // AI以EPS與本益比反推上市價格；保留隨機市場人氣
    currentPayoutRatio = chooseAiPayoutRatio(industry, tier, board, basePayoutRatio);

    // F4.2.1 EPS：
    // 股利會讀取市場份額，但股價不再被巨大份額直接壓到失真。
    // 這裡使用「經濟份額」作為EPS估值基礎，流通份額則影響市場深度與波動。
    var economicShares =
      Math.max(
        100000,
        Math.floor(
          (guildCapitalCoin * SCALE) /
          Math.max(1, aiParValueMilli)
        )
      );

    var liquidityDamping =
      Math.sqrt(
        Math.max(1, totalShares) /
        Math.max(1, economicShares)
      );

    var epsMilli =
      Math.max(
        1,
        Math.floor(
          (
            toMilliFromCoin(profitCoin) /
            Math.max(1, economicShares)
          ) /
          Math.max(1, liquidityDamping * 0.35)
        )
      );

    var aiPrice =
      epsMilli *
      aiPeRatio *
      randRange(0.80, 1.35);

    finalPrice =
      Math.max(
        Math.floor(1 * SCALE),
        Math.floor(aiPrice)
      );

    basePrice = finalPrice;

    var liquidity = clamp(
      randRange(industry.liquidityBase[0], industry.liquidityBase[1]) *
      (1 + randRange(board.liquidityAdjustRange[0], board.liquidityAdjustRange[1])),
      0.60,
      1.60
    );

    var risk = Number(industry.riskByTier[tierId] || 2);
    var volatilityLevel = randRange(industry.volatilityRange[0], industry.volatilityRange[1]);

    return {
      industryId: industry.id,
      industryLabel: industry.label,
      industryDescription: pick(industry.descriptionPool),
      sectorCode: INDUSTRY_SECTOR_CODES[industry.id] || "X",

      tierId: tier.id,
      tierLabel: tier.label,

      boardId: board.id,
      boardLabel: board.label,

      totalShares: totalShares,
      floatShares: floatShares,
      lockedShares: lockedShares,
      insiderShares: insiderShares,
      strategicHoldingShares: strategicHoldingShares,
      marketMakerShares: marketMakerShares,
      availableShares: availableShares,

      priceMilli: finalPrice,
      fairValueMilli: finalPrice,

      quality: quality,
      stability: stability,
      hype: hype,
      basePayoutRatio: basePayoutRatio,
      currentPayoutRatio: currentPayoutRatio,

      assetsMilli: toMilliFromCoin(assetsCoinBase),
      revenueMonthlyMilli: toMilliFromCoin(revenueCoinBase),
      profitMonthlyMilli: toMilliFromCoin(profitCoin),

      guildCapitalMilli: toMilliFromCoin(guildCapitalCoin),
      guildCapitalBaseMilli: toMilliFromCoin(guildCapitalCoin),
      guildCapitalTierId: guildCapitalTier.id,
      guildCapitalTierLabel: guildCapitalTier.label,
      guildCapitalTierRank: guildCapitalTier.rank,
      guildCapitalLastUpdateDay: 0,

      aiParValueMilli: aiParValueMilli,
      aiPeRatio: aiPeRatio,
      aiGeneratedEPSMilli: epsMilli,
      aiIssueMode: "capital_liquidity_ai",
      liquidityShareMultiplier: liquidityShareMultiplier,
      economicShares: economicShares,
      marketSharesMode: "liquidity_unit",

      liquidity: liquidity,
      risk: risk,
      volatilityLevel: volatilityLevel
    };
  }

  w.StockMarketCompanyTemplates = {
    SCALE: SCALE,

    INDUSTRY_TEMPLATES: INDUSTRY_TEMPLATES,
    INDUSTRY_SECTOR_CODES: INDUSTRY_SECTOR_CODES,
    TIER_TEMPLATES: TIER_TEMPLATES,
    BOARD_TEMPLATES: BOARD_TEMPLATES,

    randRange: randRange,
    randInt: randInt,
    pick: pick,
    clamp: clamp,
    percentOf: percentOf,
    toMilliFromCoin: toMilliFromCoin,

    pickIndustryId: pickIndustryId,
    pickTierId: pickTierId,
    pickBoardId: pickBoardId,

    buildBaseProfile: buildBaseProfile
  };
})(window);