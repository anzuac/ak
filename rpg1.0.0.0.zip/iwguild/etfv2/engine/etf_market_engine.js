// ETFV2 7.0.0 Market Engine
window.ETFMarketEngine = {
  subscribe(etf, shares){
    if(!etf) return false;

    const cost = shares * 10;
    etf.cashReserve += cost;
    etf.totalShares += shares;

    return true;
  }
};


// ETF 市場交易手續費（認購不收）
window.calcEtfMarketFeeMilli = window.calcEtfMarketFeeMilli || function(amountMilli){ return Math.floor(Number(amountMilli || 0) * 0.0005); };


window.recordEtfTradeStats = function(type, amountMilli, feeMilli, realizedMilli){
  window.state = window.state || {};
  state.stats = state.stats || {};

  state.stats.totalFeesMilli =
    Number(state.stats.totalFeesMilli || 0) + Number(feeMilli || 0);

  if(type === "sell"){
    state.stats.realizedProfitMilli =
      Number(state.stats.realizedProfitMilli || 0) + Number(realizedMilli || 0);
  }
};

window.calcEtfUnrealizedPnlMilli = function(holding){
  if(!holding) return 0;

  var shares = Number(holding.shares || holding.amount || 0);
  var avg = Number(holding.avgPriceMilli || holding.avgCostMilli || 0);
  var current = Number(holding.priceMilli || holding.navMilli || avg);

  return (current - avg) * shares;
};
