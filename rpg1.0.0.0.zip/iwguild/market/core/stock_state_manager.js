(function (w) {
  "use strict";

  if (!w.SaveHub || !w.StockMarketEngine || !w.StockMarketCurrency) {
    console.error("❌ stock_state_manager.js: 缺少依賴");
    return;
  }

  var NS = "town:stockMarketV13";
  var _state = null;

  function ensureLoaded() {
    if (_state) return _state;

    var s = w.SaveHub.get(NS, null);
    if (!s || Number(s._ver || 0) !== 18) s = w.StockMarketEngine.createDefaultState();

    w.StockMarketEngine.ensureState(s);
    w.StockMarketCurrency.ensureCurrency(s);

    _state = s;
    return _state;
  }

  function getState() {
    return ensureLoaded();
  }

  function save() {
    if (!_state) return;
    w.SaveHub.set(NS, _state, { replace: true });
  }

  function syncETFCore(){
    try{
      if(
        w.UniversalETF &&
        typeof w.UniversalETF.syncFund === "function"
      ){
        w.UniversalETF.syncFund("guild_leader_fund");
      }
    }catch(e){
      console.error("❌ ETFV2 sync error", e);
    }
  }

  function settleAndSave() {
    ensureLoaded();
    w.StockMarketEngine.settleToNow(_state);
    syncETFCore();
    save();
  }



  // 真實時間同步循環（避免 setInterval 漂移）
  var _rtLoopStarted = false;

  function startRealtimeLoop() {
    if (_rtLoopStarted) return;
    _rtLoopStarted = true;

    function loop() {
      try {
        if (_state) {
          w.StockMarketEngine.settleToNow(_state);
        }
      } catch (e) {
        console.error("❌ realtime loop error", e);
      }

      if (typeof requestAnimationFrame === "function") {
        requestAnimationFrame(loop);
      } else {
        setTimeout(loop, 250);
      }
    }

    loop();
  }

  function reload() {
    _state = null;
    return ensureLoaded();
  }

  startRealtimeLoop();

  w.StockStateManager = {
    ns: NS,
    getState: getState,
    save: save,
    settleAndSave: settleAndSave,
    reload: reload
  };
})(window);