

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function (w) {
  "use strict";

  var DEFAULT_TICKS_PER_DAY = 600;
  var MAX_SECTOR_EVENTS_PER_DAY = 1;

  // 事件雙層判定：
  // 第一道 gate 決定「今天是否允許抽事件」，第二道 chance 才是真正事件發生率。
  // 世界事件：事件結束後 10 天完全鎖定，之後每天 gate +2%，最高 100%。
  // 產業事件：事件後 7 天完全鎖定，之後每天 gate +4%，最高 100%。
  var SECTOR_EVENT_CHANCE = 0.11;
  var WORLD_EVENT_CHANCE = 0.04;
  var WORLD_EVENT_COOLDOWN_DAYS = 10;
  var WORLD_EVENT_GATE_STEP = 0.02;
  var SECTOR_EVENT_COOLDOWN_DAYS = 7;
  var SECTOR_EVENT_GATE_STEP = 0.04;

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function rand(min, max) {
    return min + Math.random() * (max - min);
  }

  function randInt(min, max) {
    min = Math.floor(Number(min || 0));
    max = Math.floor(Number(max || 0));
    if (max < min) max = min;
    return Math.floor(rand(min, max + 1));
  }

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function pickWeighted(arr) {
    if (!arr || !arr.length) return null;
    var total = 0;
    var i;
    for (i = 0; i < arr.length; i++) total += Math.max(0, Number(arr[i] && arr[i].weight || 1));
    if (total <= 0) return pick(arr);
    var r = Math.random() * total;
    for (i = 0; i < arr.length; i++) {
      r -= Math.max(0, Number(arr[i] && arr[i].weight || 1));
      if (r <= 0) return arr[i];
    }
    return arr[arr.length - 1];
  }

  function getTicksPerDay() {
    return Math.max(1, Math.floor(Number((w.StockMarketEngine && w.StockMarketEngine.MARKET_OPEN_SEC) || DEFAULT_TICKS_PER_DAY)));
  }

  function daysToTicks(days) {
    return Math.max(1, Math.floor(Number(days || 1) * getTicksPerDay()));
  }

  
  // =========================================
  // 餘波事件系統
  // =========================================
  function createRippleEvent(state, baseEvent) {

    if (!state || !baseEvent) return;

    var rippleTitles = [
      "市場避險情緒升溫",
      "大型商會開始調整資產",
      "軍工與資源成交量提升",
      "市場開始擔憂長期成本",
      "貴族資金流向防禦資產",
      "和平談判傳聞出現",
      "戰後重建需求增加"
    ];

    var ripple = {
      id: "ripple_" + Date.now(),
      kind: "ripple",
      title: pick(rippleTitles),
      remainingDays: randInt(3, 8),
      volumeBoost: rand(0.12, 0.35),
      volatilityBoost: rand(0.04, 0.12),
      relatedWorldEvent: baseEvent.title || "世界事件"
    };

    if (!Array.isArray(state.events.activeRippleEvents)) {
      state.events.activeRippleEvents = [];
    }

    state.events.activeRippleEvents.push(ripple);

    // 串連世界新聞
    if (typeof w.pushWorldNews === "function") {
      w.pushWorldNews(
        "ripple",
        "📡 " + ripple.title,
        "受到「" + ripple.relatedWorldEvent + "」影響，市場成交量與波動仍持續升溫。",
        ripple.remainingDays
      );
    }
  }


  function ensureEvents(state) {
    if (!state.events) {
      state.events = {
        nextId: 1,
        active: [],
        history: [],
        activeSectorEvents: [],
        openingWorldEvent: null,
        pendingAnnouncements: [],
        cooldownBySector: {},
        sectorEventGateBySector: {},
        worldCooldownDays: 0,
        worldEventGate: 1,
        dailyQuota: 0,
        triggeredToday: 0,
        lastPreparedDay: 0
      };
    }

    if (typeof state.events.nextId !== "number") state.events.nextId = 1;
    if (!Array.isArray(state.events.active)) state.events.active = [];
    if (!Array.isArray(state.events.history)) state.events.history = [];
    if (!Array.isArray(state.events.activeSectorEvents)) state.events.activeSectorEvents = state.events.active.slice();
    if (!Array.isArray(state.events.activeRippleEvents)) state.events.activeRippleEvents = [];
    if (!Array.isArray(state.events.pendingAnnouncements)) state.events.pendingAnnouncements = [];
    if (!state.events.cooldownBySector || typeof state.events.cooldownBySector !== "object") state.events.cooldownBySector = {};
    if (!state.events.sectorEventGateBySector || typeof state.events.sectorEventGateBySector !== "object") state.events.sectorEventGateBySector = {};
    if (typeof state.events.worldCooldownDays !== "number") state.events.worldCooldownDays = 0;
    if (typeof state.events.worldEventGate !== "number") state.events.worldEventGate = 1;
    if (typeof state.events.dailyQuota !== "number") state.events.dailyQuota = 0;
    if (typeof state.events.triggeredToday !== "number") state.events.triggeredToday = 0;
    if (typeof state.events.lastPreparedDay !== "number") state.events.lastPreparedDay = 0;
    if (!Object.prototype.hasOwnProperty.call(state.events, "openingWorldEvent")) state.events.openingWorldEvent = null;

    normalizeEvents(state);
    
    // =========================================
    // 餘波事件 Tick
    // =========================================
    if (Array.isArray(state.events.activeRippleEvents)) {

      for (var rr = state.events.activeRippleEvents.length - 1; rr >= 0; rr--) {

        var rippleEvt = state.events.activeRippleEvents[rr];

        rippleEvt.remainingDays--;

        if (rippleEvt.remainingDays <= 0) {
          state.events.activeRippleEvents.splice(rr, 1);
        }

      }

    }


    return state.events;
  }

  function hasOwn(obj, key) {
    return !!obj && Object.prototype.hasOwnProperty.call(obj, key);
  }

  function numberOr(value, fallback) {
    var n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function getEventGate(map, key, fallback) {
    if (!map || !Object.prototype.hasOwnProperty.call(map, key)) return fallback;
    return clamp(numberOr(map[key], fallback), 0, 1);
  }

  function setEventGate(map, key, value) {
    if (!map) return;
    map[key] = clamp(numberOr(value, 0), 0, 1);
  }

  function normalizeOneEvent(evt, kind) {
    if (!evt) return evt;
    evt.kind = kind || evt.kind || "sector";
    if (!evt.durationDays) {
      if (evt.durationWeeks) evt.durationDays = Math.max(1, Number(evt.durationWeeks || 1) * 7);
      else if (evt.totalTicks) evt.durationDays = Math.max(1, Math.ceil(Number(evt.totalTicks || 0) / getTicksPerDay()));
      else evt.durationDays = 1;
    }
    evt.totalTicks = Math.max(1, Math.floor(numberOr(evt.totalTicks, daysToTicks(evt.durationDays))));

    // 關鍵修復：remainingTicks = 0 代表事件已結束，不能再用 || 還原成 totalTicks。
    var rawRemaining = hasOwn(evt, "remainingTicks") && evt.remainingTicks != null ? evt.remainingTicks : evt.totalTicks;
    evt.remainingTicks = clamp(Math.floor(numberOr(rawRemaining, 0)), 0, evt.totalTicks);
    evt.remainingDays = Math.max(0, Math.ceil(evt.remainingTicks / getTicksPerDay()));
    evt.directionLabel = evt.directionLabel || (evt.direction === "positive" ? "利多" : evt.direction === "negative" ? "利空" : "混合");
    evt.instanceId = evt.instanceId || [evt.kind, evt.id || evt.key || "event", evt.sectorCode || "WORLD", evt.createdDay || 0, evt.createdTick || 0].join(":");
    if (evt.remainingTicks <= 0) evt.finished = true;
    return evt;
  }

  function isLiveEvent(evt) {
    return !!evt && !evt.finished && Number.isFinite(Number(evt.remainingTicks)) && Number(evt.remainingTicks) > 0;
  }

  function syncActiveList(events) {
    // active 維持舊版語意：只放產業事件；世界事件由 openingWorldEvent 管理。
    events.active = events.activeSectorEvents.slice();
  }

  function normalizeEvents(state) {
    var events = state.events;
    var source = [];
    var i;

    if (Array.isArray(events.activeSectorEvents)) source = source.concat(events.activeSectorEvents);
    if (Array.isArray(events.active)) {
      for (i = 0; i < events.active.length; i++) {
        if (events.active[i] && String(events.active[i].kind || "sector") !== "world") source.push(events.active[i]);
      }
    }

    var bySector = {};
    var cleaned = [];
    for (i = 0; i < source.length; i++) {
      var evt = normalizeOneEvent(source[i], "sector");
      if (!isLiveEvent(evt)) continue;
      var code = String(evt.sectorCode || "X").toUpperCase();
      evt.sectorCode = code;
      if (bySector[code]) {
        // 每個產業只保留一個作用中事件，防止舊存檔重複疊加。
        if (numberOr(evt.remainingTicks, 0) > numberOr(bySector[code].remainingTicks, 0)) bySector[code] = evt;
      } else {
        bySector[code] = evt;
      }
    }
    for (var code in bySector) {
      if (Object.prototype.hasOwnProperty.call(bySector, code)) cleaned.push(bySector[code]);
    }
    events.activeSectorEvents = cleaned;

    if (events.openingWorldEvent) {
      normalizeOneEvent(events.openingWorldEvent, "world");
      if (!isLiveEvent(events.openingWorldEvent)) events.openingWorldEvent = null;
    }

    var pending = [];
    var seenPending = {};
    for (i = 0; i < events.pendingAnnouncements.length; i++) {
      var p = normalizeOneEvent(events.pendingAnnouncements[i], events.pendingAnnouncements[i] && events.pendingAnnouncements[i].kind || "sector");
      if (!isLiveEvent(p)) continue;
      var pid = p.instanceId || (String(p.kind || "sector") + ":" + String(p.id || p.key || i));
      if (seenPending[pid]) continue;
      seenPending[pid] = true;
      pending.push(p);
    }
    events.pendingAnnouncements = pending;

    if (events.history.length > 120) events.history.length = 120;
    syncActiveList(events);
  }

  function getAssetList(state, filterFn) {
    var out = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      if (filterFn && !filterFn(asset)) continue;
      out.push(asset);
    }
    return out;
  }

  function getAvailableSectorCodes(state) {
    var seen = {};
    var out = [];
    var assets = getAssetList(state);
    for (var i = 0; i < assets.length; i++) {
      var code = String(assets[i].sectorCode || "X").toUpperCase();
      if (seen[code]) continue;
      seen[code] = true;
      out.push(code);
    }
    return out;
  }

  function getSectorLabel(code) {
    var map = {
      A: "能源",
      B: "金融",
      C: "科技",
      D: "科技",
      E: "醫療",
      F: "消費",
      G: "能源",
      H: "航運",
      R: "能源",
      M: "科技",
      ETF: "ETF",
      X: "科技"
    };
    return map[String(code || "X").toUpperCase()] || "綜合";
  }

  function buildSectorTemplates() {
    return {
      A: [
        { key: "a_budget_expand", title: "公共建設預算擴張", detail: "基礎建設與公用體系需求升溫。", direction: "positive", durationDays: [2, 4], bias: 0.010, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.03 }, weight: 1.2 },
        { key: "a_energy_upgrade", title: "公用設備升級案啟動", detail: "電網、水務與交通設施更新需求增加。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0011, meta: { confidenceImpact: 0.14, revenueAdjust: 0.05, profitAdjust: 0.04, payoutAdjust: 0.02 }, weight: 1.0 },
        { key: "a_public_demand", title: "公共需求穩步走升", detail: "基礎公共服務需求提升，帶動訂單與現金流。", direction: "positive", durationDays: [2, 4], bias: 0.008, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.08, revenueAdjust: 0.04, profitAdjust: 0.03 }, weight: 1.1 },
        { key: "a_budget_delay", title: "公共預算撥付延宕", detail: "國營與公用體系專案驗收及撥款節奏放慢。", direction: "negative", durationDays: [2, 4], bias: -0.010, volatilityBonus: 0.0014, meta: { confidenceImpact: -0.12, revenueAdjust: -0.04, profitAdjust: -0.04 }, weight: 1.0 },
        { key: "a_policy_review", title: "公用費率調整受審", detail: "市場觀望費率與政策調整結果，公用族群波動放大。", direction: "mixed", durationDays: [2, 5], bias: -0.003, volatilityBonus: 0.0019, meta: { confidenceImpact: -0.04, payoutAdjust: -0.01 }, weight: 0.8 },
        { key: "a_efficiency_push", title: "效率改革壓力升高", detail: "營運改善與改革要求提高，短期成本壓力浮現。", direction: "negative", durationDays: [2, 4], bias: -0.009, volatilityBonus: 0.0015, meta: { confidenceImpact: -0.10, profitAdjust: -0.05 }, weight: 0.9 }
      ],
      B: [
        { key: "b_margin_expand", title: "金融利差改善", detail: "金融族群受惠利差擴大。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.11, revenueAdjust: 0.04, profitAdjust: 0.06, payoutAdjust: 0.03 }, weight: 1.2 },
        { key: "b_capital_markets_hot", title: "資本市場交投升溫", detail: "承銷、財管與手續費收入表現改善。", direction: "positive", durationDays: [2, 5], bias: 0.010, volatilityBonus: 0.0014, meta: { liquidityShift: 0.02, confidenceImpact: 0.10, revenueAdjust: 0.05, profitAdjust: 0.05 }, weight: 1.0 },
        { key: "b_loan_demand_up", title: "放款需求回升", detail: "商會與個人融資需求增加，金融業獲利預期轉強。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.08, revenueAdjust: 0.04, profitAdjust: 0.04 }, weight: 1.0 },
        { key: "b_credit_stress", title: "信用風險升溫", detail: "金融族群對呆帳與風控疑慮升高。", direction: "negative", durationDays: [2, 5], bias: -0.012, volatilityBonus: 0.0016, meta: { confidenceImpact: -0.14, profitAdjust: -0.08, payoutAdjust: -0.04 }, weight: 1.0 },
        { key: "b_regulation_tighten", title: "金融監管收緊", detail: "資本要求與合規成本上升，金融族群承壓。", direction: "negative", durationDays: [2, 4], bias: -0.010, volatilityBonus: 0.0015, meta: { confidenceImpact: -0.11, profitAdjust: -0.05 }, weight: 0.9 },
        { key: "b_rate_volatility", title: "利率路徑不明", detail: "金融市場對利率走勢分歧，族群表現出現明顯震盪。", direction: "mixed", durationDays: [2, 5], bias: -0.002, volatilityBonus: 0.0020, meta: { liquidityShift: -0.01, confidenceImpact: -0.03 }, weight: 0.8 }
      ],
      C: [
        { key: "c_ai_boom", title: "AI 需求加速擴散", detail: "科技族群再度獲得資金追捧。", direction: "positive", durationDays: [2, 5], bias: 0.014, volatilityBonus: 0.0020, meta: { liquidityShift: 0.04, npcFomoBuyBoost: 0.18, confidenceImpact: 0.18, revenueAdjust: 0.06 }, weight: 1.2 },
        { key: "c_cloud_growth", title: "雲端支出持續成長", detail: "商會擴大上雲，帶動科技服務與基礎建設需求。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0015, meta: { liquidityShift: 0.02, confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.04 }, weight: 1.0 },
        { key: "c_platform_standard", title: "新平台標準確立", detail: "軟硬體生態逐漸統一，市場重新上修科技成長預期。", direction: "positive", durationDays: [2, 4], bias: 0.010, volatilityBonus: 0.0014, meta: { confidenceImpact: 0.11, revenueAdjust: 0.04, hype: 0.10 }, weight: 0.9 },
        { key: "c_chip_shortage", title: "晶片供應緊張", detail: "科技供應鏈交貨壓力上升，部分訂單遞延。", direction: "negative", durationDays: [2, 5], bias: -0.012, volatilityBonus: 0.0021, meta: { liquidityShift: -0.02, confidenceImpact: -0.12, revenueAdjust: -0.04, profitAdjust: -0.05 }, weight: 1.0 },
        { key: "c_security_incident", title: "資安風險擴大", detail: "科技產業對資安與系統穩定疑慮升溫。", direction: "negative", durationDays: [2, 5], bias: -0.013, volatilityBonus: 0.0022, meta: { liquidityShift: -0.03, npcPanicSellBoost: 0.16, confidenceImpact: -0.16, profitAdjust: -0.05 }, weight: 0.9 },
        { key: "c_overseas_regulation", title: "海外監管壓力升高", detail: "跨境營運與資料合規成本增加，科技族群評價承壓。", direction: "negative", durationDays: [2, 4], bias: -0.010, volatilityBonus: 0.0017, meta: { confidenceImpact: -0.11, profitAdjust: -0.04 }, weight: 0.8 },
        { key: "c_bubble_talk", title: "科技泡沫討論升溫", detail: "市場一面看多成長，一面擔憂估值過熱，族群波動顯著放大。", direction: "mixed", durationDays: [2, 6], bias: -0.004, volatilityBonus: 0.0030, meta: { liquidityShift: -0.01, npcFomoBuyBoost: 0.08, npcPanicSellBoost: 0.08, confidenceImpact: -0.03 }, weight: 0.6 }
      ],
      D: [
        { key: "d_restock", title: "製造鏈補庫存", detail: "工業與製造鏈訂單回升。", direction: "positive", durationDays: [2, 4], bias: 0.010, volatilityBonus: 0.0014, meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.04 }, weight: 1.2 },
        { key: "d_order_rebound", title: "外部訂單回流", detail: "製造業出口與代工需求改善，接單能見度上升。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.13, revenueAdjust: 0.06, profitAdjust: 0.05 }, weight: 1.0 },
        { key: "d_cost_ease", title: "原料成本回落", detail: "製造成本壓力緩解，毛利率預期回升。", direction: "positive", durationDays: [2, 4], bias: 0.008, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.09, profitAdjust: 0.05 }, weight: 0.9 },
        { key: "d_cost_surge", title: "製造成本急升", detail: "原料與物流成本侵蝕製造毛利。", direction: "negative", durationDays: [2, 4], bias: -0.011, volatilityBonus: 0.0016, meta: { confidenceImpact: -0.12, revenueAdjust: -0.03, profitAdjust: -0.07 }, weight: 1.0 },
        { key: "d_supply_chain_break", title: "供應鏈斷裂風險", detail: "零組件與交付環節受阻，製造鏈表現轉弱。", direction: "negative", durationDays: [2, 5], bias: -0.012, volatilityBonus: 0.0018, meta: { confidenceImpact: -0.14, revenueAdjust: -0.05, profitAdjust: -0.05 }, weight: 0.9 },
        { key: "d_destocking_cycle", title: "去庫存周期延長", detail: "市場仍處於去庫存過程，短期需求與價格都偏保守。", direction: "mixed", durationDays: [2, 5], bias: -0.004, volatilityBonus: 0.0019, meta: { confidenceImpact: -0.05, revenueAdjust: -0.02 }, weight: 0.8 }
      ],
      E: [
        { key: "e_trial_success", title: "醫療研發突破", detail: "醫療與生技族群情緒升溫。", direction: "positive", durationDays: [2, 5], bias: 0.013, volatilityBonus: 0.0018, meta: { liquidityShift: 0.04, npcFomoBuyBoost: 0.16, confidenceImpact: 0.20, revenueAdjust: 0.04, profitAdjust: 0.05 }, weight: 1.1 },
        { key: "e_demand_up", title: "醫療需求穩步上升", detail: "醫療服務與器材需求增加，市場重新評價成長性。", direction: "positive", durationDays: [2, 4], bias: 0.010, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.10, revenueAdjust: 0.05, profitAdjust: 0.04 }, weight: 1.0 },
        { key: "e_subsidy", title: "醫療補助政策加碼", detail: "醫療與生技獲得政策資源，市場情緒改善。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0011, meta: { confidenceImpact: 0.09, revenueAdjust: 0.03, profitAdjust: 0.03, payoutAdjust: 0.02 }, weight: 0.8 },
        { key: "e_review_delay", title: "醫療審查進度延後", detail: "醫療法規與審查流程放慢。", direction: "negative", durationDays: [2, 5], bias: -0.013, volatilityBonus: 0.0018, meta: { liquidityShift: -0.03, npcPanicSellBoost: 0.14, confidenceImpact: -0.18, revenueAdjust: -0.04, profitAdjust: -0.05 }, weight: 0.9 },
        { key: "e_trial_failure", title: "新藥試驗受挫", detail: "生技研發進程遭遇挫折，市場預期快速降溫。", direction: "negative", durationDays: [2, 5], bias: -0.016, volatilityBonus: 0.0026, meta: { liquidityShift: -0.04, npcPanicSellBoost: 0.20, confidenceImpact: -0.22, profitAdjust: -0.06 }, weight: 0.5 },
        { key: "e_reimbursement_shift", title: "給付制度調整", detail: "醫療費用支付規則調整，市場對醫療族群出現分歧。", direction: "mixed", durationDays: [2, 5], bias: -0.004, volatilityBonus: 0.0020, meta: { confidenceImpact: -0.05, payoutAdjust: -0.02 }, weight: 0.8 }
      ],
      F: [
        { key: "f_demand_pickup", title: "民生消費回溫", detail: "零售與民生需求回升。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.10, revenueAdjust: 0.05, profitAdjust: 0.03 }, weight: 1.2 },
        { key: "f_festival_boost", title: "節慶檔期帶動銷售", detail: "品牌與零售通路迎來短期旺季。", direction: "positive", durationDays: [2, 4], bias: 0.010, volatilityBonus: 0.0011, meta: { confidenceImpact: 0.09, revenueAdjust: 0.06, profitAdjust: 0.04 }, weight: 1.0 },
        { key: "f_brand_upgrade", title: "品牌升級帶動溢價", detail: "消費品牌產品力提升，帶動利潤結構改善。", direction: "positive", durationDays: [2, 4], bias: 0.008, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.08, profitAdjust: 0.05 }, weight: 0.8 },
        { key: "f_margin_squeeze", title: "原料成本侵蝕毛利", detail: "民生消費面臨原料成本壓力。", direction: "negative", durationDays: [2, 4], bias: -0.010, volatilityBonus: 0.0012, meta: { confidenceImpact: -0.10, profitAdjust: -0.06 }, weight: 1.0 },
        { key: "f_demand_soft", title: "消費動能疲弱", detail: "市場對零售與民生需求前景轉趨保守。", direction: "negative", durationDays: [2, 5], bias: -0.011, volatilityBonus: 0.0013, meta: { confidenceImpact: -0.11, revenueAdjust: -0.05, profitAdjust: -0.04 }, weight: 0.9 },
        { key: "f_price_war", title: "通路價格戰升溫", detail: "促銷競爭加劇，營收衝高但獲利表現分化。", direction: "mixed", durationDays: [2, 4], bias: -0.003, volatilityBonus: 0.0017, meta: { confidenceImpact: -0.03, revenueAdjust: 0.02, profitAdjust: -0.04 }, weight: 0.8 }
      ],
      G: [
        { key: "g_price_surge", title: "能源價格走高", detail: "能源族群報價轉強。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0014, meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.06 }, weight: 1.2 },
        { key: "g_subsidy", title: "新能源補貼加碼", detail: "政策推動能源轉型，相關族群熱度升溫。", direction: "positive", durationDays: [2, 5], bias: 0.010, volatilityBonus: 0.0013, meta: { confidenceImpact: 0.11, revenueAdjust: 0.04, profitAdjust: 0.04 }, weight: 0.9 },
        { key: "g_supply_tight", title: "供給趨緊支撐報價", detail: "供給面收縮，能源市場報價更具支撐。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.08, revenueAdjust: 0.03, profitAdjust: 0.04 }, weight: 0.9 },
        { key: "g_price_crash", title: "能源價格急跌", detail: "能源商品價格快速回落，市場轉趨保守。", direction: "negative", durationDays: [2, 5], bias: -0.013, volatilityBonus: 0.0018, meta: { confidenceImpact: -0.14, revenueAdjust: -0.06, profitAdjust: -0.07 }, weight: 0.8 },
        { key: "g_supply_shock", title: "能源供應受阻", detail: "能源供應鏈出現擾動。", direction: "mixed", durationDays: [2, 5], bias: -0.006, volatilityBonus: 0.0020, meta: { liquidityShift: -0.02, confidenceImpact: -0.04, profitAdjust: -0.03 }, weight: 1.0 },
        { key: "g_transition_cost", title: "能源轉型成本升高", detail: "轉型與設備升級支出增加，短線獲利受到壓力。", direction: "mixed", durationDays: [2, 5], bias: -0.004, volatilityBonus: 0.0018, meta: { confidenceImpact: -0.04, profitAdjust: -0.03 }, weight: 0.8 }
      ],
      H: [
        { key: "h_freight_rebound", title: "運價回升", detail: "航運與物流需求改善。", direction: "positive", durationDays: [2, 5], bias: 0.011, volatilityBonus: 0.0014, meta: { confidenceImpact: 0.14, revenueAdjust: 0.07, profitAdjust: 0.06 }, weight: 1.2 },
        { key: "h_trade_recover", title: "國際貿易動能回升", detail: "航運、港口與物流接單能見度提高。", direction: "positive", durationDays: [2, 5], bias: 0.010, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.10, revenueAdjust: 0.05, profitAdjust: 0.05 }, weight: 1.0 },
        { key: "h_capacity_tight", title: "運能吃緊", detail: "可用運能偏緊，支撐運價與族群情緒。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0013, meta: { confidenceImpact: 0.09, revenueAdjust: 0.04 }, weight: 0.9 },
        { key: "h_route_disruption", title: "航線調度受阻", detail: "航運與物流調度受到干擾。", direction: "negative", durationDays: [2, 5], bias: -0.011, volatilityBonus: 0.0016, meta: { confidenceImpact: -0.14, revenueAdjust: -0.05, profitAdjust: -0.06 }, weight: 1.0 },
        { key: "h_freight_drop", title: "運價轉弱", detail: "航運景氣降溫，市場下修後續獲利預期。", direction: "negative", durationDays: [2, 5], bias: -0.010, volatilityBonus: 0.0014, meta: { confidenceImpact: -0.11, revenueAdjust: -0.05, profitAdjust: -0.04 }, weight: 0.9 },
        { key: "h_route_rebalance", title: "航線重整期", detail: "航線調整與成本重估並存，族群短線波動加劇。", direction: "mixed", durationDays: [2, 4], bias: -0.003, volatilityBonus: 0.0019, meta: { confidenceImpact: -0.03 }, weight: 0.8 }
      ],
      R: [
        { key: "r_price_up", title: "原物料報價上揚", detail: "資源與原物料族群價格轉強。", direction: "positive", durationDays: [2, 5], bias: 0.010, volatilityBonus: 0.0013, meta: { confidenceImpact: 0.12, revenueAdjust: 0.06, profitAdjust: 0.05 }, weight: 1.2 },
        { key: "r_demand_up", title: "原物料需求增加", detail: "下游補庫存與基建需求帶動資源族群走強。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0011, meta: { confidenceImpact: 0.09, revenueAdjust: 0.05, profitAdjust: 0.04 }, weight: 1.0 },
        { key: "r_supply_constrained", title: "供應受限支撐價格", detail: "產地供給偏緊，市場對資源價格預期上修。", direction: "positive", durationDays: [2, 4], bias: 0.009, volatilityBonus: 0.0012, meta: { confidenceImpact: 0.08, revenueAdjust: 0.04 }, weight: 0.9 },
        { key: "r_inventory_pressure", title: "庫存壓力升高", detail: "資源族群面臨庫存與需求疑慮。", direction: "negative", durationDays: [2, 5], bias: -0.010, volatilityBonus: 0.0015, meta: { confidenceImpact: -0.12, revenueAdjust: -0.04, profitAdjust: -0.05 }, weight: 1.0 },
        { key: "r_price_drop", title: "原物料價格回落", detail: "商品價格修正，市場下修資源族群獲利預期。", direction: "negative", durationDays: [2, 5], bias: -0.011, volatilityBonus: 0.0014, meta: { confidenceImpact: -0.10, revenueAdjust: -0.05, profitAdjust: -0.05 }, weight: 0.9 },
        { key: "r_cycle_turn", title: "景氣循環轉折", detail: "市場對景氣方向意見分歧，資源股表現出現明顯震盪。", direction: "mixed", durationDays: [2, 5], bias: -0.003, volatilityBonus: 0.0020, meta: { confidenceImpact: -0.03 }, weight: 0.8 }
      ],
      X: [
        { key: "x_generic_up", title: "市場需求帶動接單", detail: "綜合型商會受惠景氣改善，表現轉強。", direction: "positive", durationDays: [2, 4], bias: 0.008, volatilityBonus: 0.0010, meta: { confidenceImpact: 0.08, revenueAdjust: 0.03, profitAdjust: 0.03 }, weight: 1.0 },
        { key: "x_generic_down", title: "市場觀望情緒升高", detail: "綜合型商會短線承壓，資金態度轉趨保守。", direction: "negative", durationDays: [2, 4], bias: -0.008, volatilityBonus: 0.0012, meta: { confidenceImpact: -0.08, revenueAdjust: -0.03, profitAdjust: -0.03 }, weight: 1.0 },
        { key: "x_generic_mix", title: "題材輪動加快", detail: "市場輪動速度變快，綜合型商會表現分化。", direction: "mixed", durationDays: [2, 4], bias: -0.002, volatilityBonus: 0.0016, meta: { confidenceImpact: -0.02 }, weight: 0.8 }
      ]
    };
  }

  function buildWorldTemplates() {
    return [
      { key: "world_capital_mist", title: "資金霧流", detail: "大型基金近期持續調整持倉。", direction: "mixed", durationWeeks: [1, 2], bias: 0.004, volatilityBonus: 0.0016, meta: { liquidityShift: 0.02, confidenceImpact: 0.04 } },
      { key: "world_risk_shadow", title: "避險陰影", detail: "市場避險情緒似乎正在升溫。", direction: "negative", durationWeeks: [1, 2], bias: -0.008, volatilityBonus: 0.0020, meta: { liquidityShift: -0.03, npcPanicSellBoost: 0.14, confidenceImpact: -0.12 } },
      { key: "world_hot_money", title: "熱錢流徑", detail: "大量資金近期持續流入未知領域。", direction: "positive", durationWeeks: [1, 2], bias: 0.008, volatilityBonus: 0.0018, meta: { liquidityShift: 0.04, npcFomoBuyBoost: 0.14, confidenceImpact: 0.12 } },
      { key: "world_quiet_rotation", title: "沉默輪動", detail: "資金似乎正逐漸流向穩定型產業。", direction: "mixed", durationWeeks: [1, 2], bias: -0.002, volatilityBonus: 0.0014, meta: { liquidityShift: 0.01, confidenceImpact: 0.02 } },
      { key: "world_low_price_noise", title: "低價雜訊", detail: "低價股近期討論度異常提高。", direction: "mixed", durationWeeks: [1, 1], bias: 0.003, volatilityBonus: 0.0024, meta: { npcFomoBuyBoost: 0.10, npcPanicSellBoost: 0.06, confidenceImpact: 0.02 } }
    ];
  }

  function createSectorEvent(state, sectorCode) {
    var pools = buildSectorTemplates();
    var code = String(sectorCode || "X").toUpperCase();
    var list = pools[code] || pools.X || [];
    if (!list.length) return null;
    var template = pickWeighted(list);
    var days = randInt(template.durationDays[0], template.durationDays[1]);
    return normalizeOneEvent({
      id: state.events.nextId++,
      kind: "sector",
      key: template.key,
      title: template.title,
      detail: template.detail,
      sectorCode: code,
      sectorLabel: getSectorLabel(code),
      direction: template.direction,
      bias: Number(template.bias || 0),
      volatilityBonus: Number(template.volatilityBonus || 0),
      durationDays: days,
      totalTicks: daysToTicks(days),
      remainingTicks: daysToTicks(days),
      meta: template.meta || {},
      createdDay: Number(state.marketDay || 1)
    }, "sector");
  }

  function createWorldEvent(state) {
    var template = pick(buildWorldTemplates());
    if (!template) return null;
    var weeks = randInt(template.durationWeeks[0], template.durationWeeks[1]);
    var days = Math.max(1, weeks * 7);
    return normalizeOneEvent({
      id: state.events.nextId++,
      kind: "world",
      key: template.key,
      title: template.title,
      detail: template.detail,
      direction: template.direction,
      bias: Number(template.bias || 0),
      volatilityBonus: Number(template.volatilityBonus || 0),
      durationWeeks: weeks,
      durationDays: days,
      totalTicks: daysToTicks(days),
      remainingTicks: daysToTicks(days),
      meta: template.meta || {},
      createdDay: Number(state.marketDay || 1)
    }, "world");
  }

  function prepareDailyQuota(state) {
    return prepareOvernightEvents(state);
  }

  function maybeCreateEvent(state) {
    ensureEvents(state);
    if (!state.events.pendingAnnouncements.length) return null;
    state.events.triggeredToday += 1;
    return state.events.pendingAnnouncements.shift() || null;
  }

  function prepareOvernightEvents(state) {
    ensureEvents(state);
    if (state.events.lastPreparedDay === state.marketDay) return state.events.dailyQuota || 0;

    var climateMods =
      (w.WorldClimateSystem && typeof w.WorldClimateSystem.getModifiers === "function")
        ? w.WorldClimateSystem.getModifiers(state)
        : { worldEventBoost: 1, sectorEventBoost: 1, tradeBoost: 1 };

    var worldChance =
      clamp(WORLD_EVENT_CHANCE * Number(climateMods.worldEventBoost || 1), 0, 0.20);

    var sectorChance =
      clamp(SECTOR_EVENT_CHANCE * Number(climateMods.sectorEventBoost || 1), 0, 0.35);
    state.events.lastPreparedDay = state.marketDay;
    state.events.triggeredToday = 0;
    state.events.pendingAnnouncements = [];

    var code;
    for (code in state.events.cooldownBySector) {
      if (!Object.prototype.hasOwnProperty.call(state.events.cooldownBySector, code)) continue;
      state.events.cooldownBySector[code] = Math.max(0, numberOr(state.events.cooldownBySector[code], 0) - 1);
      if (state.events.cooldownBySector[code] > 0) {
        setEventGate(state.events.sectorEventGateBySector, code, 0);
      } else {
        delete state.events.cooldownBySector[code];
      }
    }

    // 世界事件第一道鎖：世界事件仍在持續或冷卻中時，完全禁止抽取。
    if (state.events.openingWorldEvent && isLiveEvent(state.events.openingWorldEvent)) {
      state.events.worldEventGate = 0;
    } else if (numberOr(state.events.worldCooldownDays, 0) > 0) {
      state.events.worldCooldownDays = Math.max(0, numberOr(state.events.worldCooldownDays, 0) - 1);
      state.events.worldEventGate = 0;
    } else {
      state.events.worldEventGate = clamp(numberOr(state.events.worldEventGate, 1) + WORLD_EVENT_GATE_STEP, 0, 1);
    }

    // 餘波事件每日扣天
    if (Array.isArray(state.events.activeRippleEvents)) {
      for (var rr = state.events.activeRippleEvents.length - 1; rr >= 0; rr--) {
        var rippleEvt = state.events.activeRippleEvents[rr];
        rippleEvt.remainingDays = Math.max(0, Number(rippleEvt.remainingDays || 0) - 1);
        if (rippleEvt.remainingDays <= 0) {
          state.events.activeRippleEvents.splice(rr, 1);
        }
      }
    }

    var quota = 0;
    var activeSectorCodes = {};
    for (var i = 0; i < state.events.activeSectorEvents.length; i++) {
      activeSectorCodes[String(state.events.activeSectorEvents[i].sectorCode || "X").toUpperCase()] = true;
    }

    var sectorCandidates = getAvailableSectorCodes(state).filter(function (sectorCode) {
      var code2 = String(sectorCode || "X").toUpperCase();
      if (code2 === "ETF") return false;
      if (activeSectorCodes[code2]) return false;
      if (numberOr(state.events.cooldownBySector[code2], 0) > 0) return false;

      // 產業事件第一道鎖：冷卻結束後每天 +4%，通過後才會進入 10~12% 的事件抽取。
      var gate = getEventGate(state.events.sectorEventGateBySector, code2, 1);
      setEventGate(state.events.sectorEventGateBySector, code2, gate + SECTOR_EVENT_GATE_STEP);
      return Math.random() < gate;
    });

    if (sectorCandidates.length && quota < MAX_SECTOR_EVENTS_PER_DAY && Math.random() < sectorChance) {
      var evt = createSectorEvent(state, pick(sectorCandidates));
      if (evt) {
        state.events.activeSectorEvents.push(evt);
        state.events.active = state.events.activeSectorEvents.slice();
        state.events.history.unshift(evt);
        state.events.pendingAnnouncements.push(evt);
        state.events.cooldownBySector[evt.sectorCode] = SECTOR_EVENT_COOLDOWN_DAYS;
        setEventGate(state.events.sectorEventGateBySector, evt.sectorCode, 0);
        quota += 1;
      }
    }

    // 世界事件第二道抽取：第一道 gate 通過後，才抽 3~5% 的基礎機率。
    if (!state.events.openingWorldEvent &&
        numberOr(state.events.worldCooldownDays, 0) <= 0 &&
        Math.random() < clamp(numberOr(state.events.worldEventGate, 1), 0, 1) &&
        Math.random() < worldChance) {
      var worldEvt = createWorldEvent(state);
      if (worldEvt) {
        state.events.openingWorldEvent = worldEvt;
        state.events.history.unshift(worldEvt);
        state.events.pendingAnnouncements.push(worldEvt);
        state.events.worldEventGate = 0;
        quota += 1;
      }
    }

    // 不再 fallback 強制補事件；沒有事件的日子就是市場盤整日。

    if (state.events.history.length > 120) state.events.history.length = 120;
    state.events.dailyQuota = quota;
    return quota;
  }

  function consumePendingAnnouncements(state) {
    ensureEvents(state);
    var out = state.events.pendingAnnouncements.slice();
    state.events.pendingAnnouncements = [];
    state.events.triggeredToday += out.length;
    return out;
  }

  function tickActiveEvents(state) {
    ensureEvents(state);
    for (var i = 0; i < state.events.activeSectorEvents.length; i++) {
      var evt = state.events.activeSectorEvents[i];
      evt.remainingTicks = Math.max(0, numberOr(evt.remainingTicks, 0) - 1);
      evt.remainingDays = Math.max(0, Math.ceil(numberOr(evt.remainingTicks, 0) / getTicksPerDay()));
      if (evt.remainingTicks <= 0) evt.finished = true;
    }
    // 世界事件現在有完整持續期；持續結束後才進入 10 天冷卻。
    if (state.events.openingWorldEvent) {
      var worldEvt = state.events.openingWorldEvent;
      worldEvt.remainingTicks = Math.max(0, numberOr(worldEvt.remainingTicks, 0) - 1);
      worldEvt.remainingDays = Math.max(0, Math.ceil(numberOr(worldEvt.remainingTicks, 0) / getTicksPerDay()));
      if (worldEvt.remainingTicks <= 0) {
        worldEvt.finished = true;
        state.events.openingWorldEvent = null;
        state.events.worldCooldownDays = WORLD_EVENT_COOLDOWN_DAYS;
        state.events.worldEventGate = 0;

        // 世界事件結束後進入餘波期
        if (Math.random() < 0.85) {
          createRippleEvent(state, worldEvt);
        }
      }
    }

    syncActiveList(state.events);
  }

  function cleanupExpiredEvents(state) {
    ensureEvents(state);
    state.events.activeSectorEvents = state.events.activeSectorEvents.filter(isLiveEvent);
    syncActiveList(state.events);

  }

  function applyMeta(out, meta, scale) {
    if (!meta) return;
    scale = Number(scale || 1);
    out.liquidityShift += Number(meta.liquidityShift || 0) * scale;
    out.npcPanicSellBoost += Number(meta.npcPanicSellBoost || 0) * scale;
    out.npcFomoBuyBoost += Number(meta.npcFomoBuyBoost || 0) * scale;
    out.strategicHoldingReleaseBoost += Number(meta.strategicHoldingReleaseBoost || 0) * scale;
    out.npcAbsorbBoost += Number(meta.npcAbsorbBoost || 0) * scale;
    out.shortPressureBoost += Number(meta.shortPressureBoost || 0) * scale;
    out.confidenceImpact += Number(meta.confidenceImpact || 0) * scale;
    out.revenueAdjust += Number(meta.revenueAdjust || 0) * scale;
    out.profitAdjust += Number(meta.profitAdjust || 0) * scale;
    out.payoutAdjust += Number(meta.payoutAdjust || 0) * scale;
  }

  function getCombinedEffectForAsset(state, assetId) {
    ensureEvents(state);
    var asset = state.assets && state.assets[assetId];
    if (!asset) return { bias: 0, volatilityBonus: 0 };

    var bias = 0;
    var volatilityBonus = 0;
    var sectorCode = String(asset.sectorCode || "X").toUpperCase();

    for (var i = 0; i < state.events.activeSectorEvents.length; i++) {
      var evt = state.events.activeSectorEvents[i];
      if (String(evt.sectorCode || "X").toUpperCase() !== sectorCode) continue;
      bias += Number(evt.bias || 0) * 0.7;
      volatilityBonus += Number(evt.volatilityBonus || 0) * 0.7;
    }

    var worldEvt = state.events.openingWorldEvent;
    if (worldEvt) {
      bias += Number(worldEvt.bias || 0) * 0.5;
      volatilityBonus += Number(worldEvt.volatilityBonus || 0) * 0.5;
    }

    return {
      bias: clamp(bias, -0.08, 0.08),
      volatilityBonus: clamp(volatilityBonus, 0, 0.020)
    };
  }

  function getCombinedMetaForAsset(state, assetId) {
    ensureEvents(state);
    var asset = state.assets && state.assets[assetId];
    var out = {
      liquidityShift: 0,
      npcPanicSellBoost: 0,
      npcFomoBuyBoost: 0,
      strategicHoldingReleaseBoost: 0,
      npcAbsorbBoost: 0,
      shortPressureBoost: 0,
      confidenceImpact: 0,
      revenueAdjust: 0,
      profitAdjust: 0,
      payoutAdjust: 0
    };
    if (!asset) return out;

    var sectorCode = String(asset.sectorCode || "X").toUpperCase();
    for (var i = 0; i < state.events.activeSectorEvents.length; i++) {
      var evt = state.events.activeSectorEvents[i];
      if (String(evt.sectorCode || "X").toUpperCase() !== sectorCode) continue;
      applyMeta(out, evt.meta, 0.7);
    }
    if (state.events.openingWorldEvent) applyMeta(out, state.events.openingWorldEvent.meta, 0.5);

    out.liquidityShift = clamp(out.liquidityShift, -0.30, 0.30);
    out.npcPanicSellBoost = clamp(out.npcPanicSellBoost, 0, 1.5);
    out.npcFomoBuyBoost = clamp(out.npcFomoBuyBoost, 0, 1.5);
    out.strategicHoldingReleaseBoost = clamp(out.strategicHoldingReleaseBoost, 0, 1.0);
    out.npcAbsorbBoost = clamp(out.npcAbsorbBoost, 0, 1.0);
    out.shortPressureBoost = clamp(out.shortPressureBoost, -1.0, 1.5);
    out.confidenceImpact = clamp(out.confidenceImpact, -0.6, 0.6);
    out.revenueAdjust = clamp(out.revenueAdjust, -0.25, 0.25);
    out.profitAdjust = clamp(out.profitAdjust, -0.30, 0.30);
    out.payoutAdjust = clamp(out.payoutAdjust, -0.20, 0.20);
    return out;
  }

  function getCurrentWorldEvent(state) {
    ensureEvents(state);
    return state.events.openingWorldEvent || null;
  }

  function getActiveSectorEvents(state) {
    ensureEvents(state);
    return state.events.activeSectorEvents || [];
  }

  
  // =========================================
  // 市場餘波倍率
  // =========================================
  function getRippleMarketBoost(state) {

    var result = {
      volumeBoost: 0,
      volatilityBoost: 0
    };

    if (
      !state ||
      !state.events ||
      !Array.isArray(state.events.activeRippleEvents)
    ) {
      return result;
    }

    state.events.activeRippleEvents.forEach(function(r) {

      result.volumeBoost += Number(r.volumeBoost || 0);
      result.volatilityBoost += Number(r.volatilityBoost || 0);

    });

    return result;
  }


  w.StockMarketEvents = {
    ensureEvents: ensureEvents,
    prepareDailyQuota: prepareDailyQuota,
    maybeCreateEvent: maybeCreateEvent,
    prepareOvernightEvents: prepareOvernightEvents,
    consumePendingAnnouncements: consumePendingAnnouncements,
    tickActiveEvents: tickActiveEvents,
    cleanupExpiredEvents: cleanupExpiredEvents,
    getCombinedEffectForAsset: getCombinedEffectForAsset,
    getCombinedMetaForAsset: getCombinedMetaForAsset,
    getCurrentWorldEvent: getCurrentWorldEvent,
    getActiveSectorEvents: getActiveSectorEvents,
    getSectorLabel: getSectorLabel,
    normalizeEvents: normalizeEvents,
    cleanupExpiredEventsNow: cleanupExpiredEvents,
    getRippleMarketBoost: getRippleMarketBoost
  };
})(window);
