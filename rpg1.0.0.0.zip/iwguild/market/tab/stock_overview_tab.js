
// =====================================================
// AI5.1.2 UI Tick Sync
//
// Only synchronizes:
// - realtime prices
// - price change display
// - market index updates
//
// Other UI systems remain unchanged.
// =====================================================


(function(w) {
  "use strict";

  if (!w.StockHub || !w.StockStateManager || !w.MarketIndexSystem) {
    console.error("❌ stock_overview_tab.js: 缺少依賴");
    return;
  }

  var TAB_ID = "marketOverview";
  var SCALE = (w.StockMarketEngine && w.StockMarketEngine.SCALE) || 1000;

  var STYLE = '' +
  '<style>' +
  '.index-root{display:flex;flex-direction:column;gap:14px;color:#e5e7eb;}' +
  '.index-hero{background:linear-gradient(180deg,#101827,#07101d);border:1px solid #263247;border-radius:18px;padding:18px;box-shadow:0 0 0 1px rgba(255,255,255,.03) inset;}' +
  '.index-title{font-size:18px;font-weight:900;text-align:center;opacity:.95;}' +
  '.index-value{font-size:46px;font-weight:1000;text-align:center;margin-top:10px;letter-spacing:1px;line-height:1.05;}' +
  '.index-diff{text-align:center;font-size:22px;font-weight:1000;margin-top:8px;}' +
  '.index-sub{text-align:center;font-size:13px;font-weight:800;margin-top:10px;opacity:.9;}' +
  '.index-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;}' +
  '.index-card{background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;min-height:68px;}' +
  '.index-card-title{font-size:12px;font-weight:800;opacity:.68;}' +
  '.index-card-value{margin-top:8px;font-size:20px;font-weight:1000;line-height:1.2;}' +
  '.index-section{background:#0b1220;border:1px solid #263247;border-radius:14px;padding:14px;}' +
  '.index-section-title{font-size:16px;font-weight:1000;margin-bottom:8px;}' +
  '.index-sector-row{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid #1f2937;}' +
  '.index-sector-row:last-child{border-bottom:0;}' +
  '.index-sector-left{min-width:0;}' +
  '.index-sector-name{font-size:14px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}' +
  '.index-sector-meta{font-size:11px;opacity:.62;margin-top:3px;}' +
  '.index-sector-value{font-size:14px;font-weight:1000;white-space:nowrap;}' +
  '.index-bar{height:8px;background:#111827;border-radius:999px;overflow:hidden;margin-top:12px;border:1px solid #1f2937;}' +
  '.index-bar-inner{height:100%;border-radius:999px;}' +
'.index-weight-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #1f2937;gap:10px;}' +
'.index-weight-row:last-child{border-bottom:0;}' +
'.index-weight-name{font-size:14px;font-weight:900;color:#f8fafc;}' +
'.index-weight-meta{font-size:12px;opacity:.7;margin-top:2px;color:#94a3b8;}' +
'.index-weight-value{font-size:16px;font-weight:1000;white-space:nowrap;color:#facc15;}' +
'.index-weight-crown{margin-right:6px;color:#facc15;}' +
'.royal-index-box{background:linear-gradient(180deg,#1e1b4b,#0f172a);border:1px solid #facc15;border-radius:16px;padding:14px;box-shadow:0 0 18px rgba(250,204,21,.08);}' +
'.royal-index-title{font-size:16px;font-weight:1000;color:#fde68a;text-align:center;}' +
'.royal-index-value{font-size:34px;font-weight:1000;text-align:center;margin-top:6px;}' +
'.royal-index-diff{text-align:center;font-size:16px;font-weight:1000;margin-top:4px;}' +

  '@media (min-width:760px){.index-grid{grid-template-columns:repeat(4,minmax(0,1fr));}.index-value{font-size:64px;}}' +
  '</style>';

  function safe(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function num(v) {
    var n = Number(v);
    return isFinite(n) ? n : 0;
  }

  function fmtInt(v) {
    return Math.floor(num(v)).toLocaleString();
  }

  function fmtCoinMilli(v) {
    var n = num(v) / SCALE;
    if (Math.abs(n) >= 1000000000000) return (n / 1000000000000).toFixed(2) + "兆";
    if (Math.abs(n) >= 100000000) return (n / 100000000).toFixed(2) + "億";
    if (Math.abs(n) >= 10000) return (n / 10000).toFixed(2) + "萬";
    return n.toFixed(0);
  }

  function color(v) {
    v = num(v);
    if (v > 0) return "#22c55e";
    if (v < 0) return "#ef4444";
    return "#cbd5e1";
  }

  function arrow(v) {
    v = num(v);
    if (v > 0) return "▲";
    if (v < 0) return "▼";
    return "━";
  }

  function getBody() {
    var body = document.getElementById("stockHubBody");
    if (!body) return null;
    if (String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return null;
    return body;
  }

  function getState() {
    w.StockStateManager.settleAndSave();
    return w.StockStateManager.getState();
  }

  function render() {
    var body = document.getElementById("stockHubBody");
    if (!body) return;

    body.setAttribute("data-tab-owner", TAB_ID);
    body.innerHTML = STYLE + '<div id="stockIndexRoot"></div>';

    update();
  }

  function renderSectorRows(sectors) {
    if (!Array.isArray(sectors) || !sectors.length) {
      return '<div style="opacity:.7;padding:8px 0;line-height:1.7;">目前尚無類股資料。</div>';
    }

    var html = '';
    var max = Math.min(6, sectors.length);

    for (var i = 0; i < max; i++) {
      var row = sectors[i] || {};
      var pct = num(row.diffPercent);
      html += '' +
        '<div class="index-sector-row">' +
          '<div class="index-sector-left">' +
            '<div class="index-sector-name">' + safe(row.sector || "綜合市場") + '</div>' +
            '<div class="index-sector-meta">成分 ' + fmtInt(row.count || 0) + '｜上漲 ' + fmtInt(row.advancing || 0) + '｜下跌 ' + fmtInt(row.declining || 0) + '</div>' +
          '</div>' +
          '<div class="index-sector-value" style="color:' + color(pct) + ';">' +
            arrow(pct) + Math.abs(pct).toFixed(2) + '%' +
          '</div>' +
        '</div>';
    }

    return html;
  }


  function renderWeightLeaders(summary) {

    var companies =
      Array.isArray(summary.weightLeaders)
        ? summary.weightLeaders
        : [];

    if (!companies.length) {

      return '<div style="opacity:.7;padding:8px 0;">目前尚無權重資料。</div>';

    }

    var html = '';

    for (var i = 0; i < companies.length; i++) {

      var c = companies[i] || {};

      var crown =
        i === 0
          ? '👑 股王'
          : '💠 股后';

      html += '' +

        '<div class="index-weight-row">' +

          '<div>' +

            '<div class="index-weight-name">' +
              '<span class="index-weight-crown">' +
                crown +
              '</span>' +

              safe(
                c.title ||
                "未知商會"
              ) +
            '</div>' +

            '<div class="index-weight-meta">' +
              safe(
                c.label ||
                "綜合市場"
              ) +
            '</div>' +

          '</div>' +

          '<div class="index-weight-value">' +
            num(c.weightPercent).toFixed(2) +
            '%' +
          '</div>' +

        '</div>';

    }

    return html;
}


  function update() {
    var body = getBody();
    if (!body) return;

    var root = document.getElementById("stockIndexRoot");
    if (!root) return;

    try {
      var state = getState();
      var summary = w.MarketIndexSystem.getSummary(state);

      var diff = num(summary.diff);
      var pct = num(summary.diffPercent);
      var totalBreadth = Math.max(1, num(summary.advancing) + num(summary.declining) + num(summary.unchanged));
      var upRatio = Math.max(0, Math.min(100, (num(summary.advancing) / totalBreadth) * 100));

      var diffText = arrow(diff) + fmtInt(Math.abs(diff)) + '（' + Math.abs(pct).toFixed(2) + '%）';

      var royal = summary.royalIndex || {};
      var royalDiff = num(royal.diff);
      var royalPct = num(royal.diffPercent);
      var royalText = arrow(royalDiff) + fmtInt(Math.abs(royalDiff)) + '（' + Math.abs(royalPct).toFixed(2) + '%）';

      root.innerHTML = '' +
        '<div class="index-root">' +
          '<div class="index-hero">' +
            '<div class="index-title">異世界商會加權指數</div>' +
            '<div class="index-value">' + fmtInt(summary.currentIndex) + '</div>' +
            '<div class="index-diff" style="color:' + color(diff) + ';">' + diffText + '</div>' +
            '<div class="index-sub" style="color:' + safe(summary.mood && summary.mood.color || '#cbd5e1') + ';">市場情緒：' + safe(summary.mood && summary.mood.label || '中性整理') + '</div>' +
          '</div>' +

          '<div class="royal-index-box">' +
            '<div class="royal-index-title">👑 皇室加權國力指數</div>' +
            '<div class="royal-index-value">' + fmtInt(royal.currentIndex || 10000) + '</div>' +
            '<div class="royal-index-diff" style="color:' + color(royalDiff) + ';">' + royalText + '</div>' +
            '<div style="text-align:center;font-size:12px;opacity:.72;margin-top:6px;">王國核心資產 ' + fmtInt(royal.listedCount || 0) + ' 檔｜不列入一般商會加權</div>' +
          '</div>' +

          '<div class="index-grid">' +
            '<div class="index-card"><div class="index-card-title">上市商會</div><div class="index-card-value">' + fmtInt(summary.listedCount) + '</div></div>' +
            '<div class="index-card"><div class="index-card-title">市場總市值</div><div class="index-card-value">' + fmtCoinMilli(summary.totalMarketCap) + '</div></div>' +
'<div class="index-card"><div class="index-card-title">今日開盤</div><div class="index-card-value">' + fmtInt(summary.previousIndex || summary.baseIndex || 10000) + '</div></div>' +
'<div class="index-card"><div class="index-card-title">今日最高</div><div class="index-card-value">' + fmtInt(summary.highIndex) + '</div></div>' +
'<div class="index-card"><div class="index-card-title">今日最低</div><div class="index-card-value">' + fmtInt(summary.lowIndex) + '</div></div>' +
'<div class="index-card"><div class="index-card-title">預估收盤</div><div class="index-card-value">' + fmtInt(summary.currentIndex) + '</div></div>' +
          '</div>' +

          '<div class="index-section">' +
            '<div class="index-section-title">市場廣度</div>' +
            '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;font-size:13px;font-weight:900;">' +
              '<span style="color:#22c55e;">上漲 ' + fmtInt(summary.advancing) + '</span>' +
              '<span style="color:#ef4444;">下跌 ' + fmtInt(summary.declining) + '</span>' +
              '<span style="color:#cbd5e1;">平盤 ' + fmtInt(summary.unchanged) + '</span>' +
            '</div>' +
            '<div class="index-bar"><div class="index-bar-inner" style="width:' + upRatio.toFixed(2) + '%;background:#22c55e;"></div></div>' +
          '</div>' +

          '<div class="index-section">' +
            '<div class="index-section-title">👑 市場核心權重</div>' +
            renderWeightLeaders(summary) +
          '</div>' +

          '<div class="index-section">' +
            '<div class="index-section-title">類股強弱</div>' +
            renderSectorRows(summary.sectors) +
          '</div>' +
        '</div>';
    } catch (e) {
      root.innerHTML = '<div style="color:#ef4444;padding:16px;line-height:1.7;">渲染發生錯誤：' + safe(e && e.message ? e.message : e) + '</div>';
      console.error("❌ stock_overview_tab.js render error", e);
    }
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "異世界商會指數",
    render: render,
    update: update
  });
})(window);
