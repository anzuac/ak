// =====================================================
// mad_dog_core.js
// 王國戰略資本：全新獨立核心
// 不再使用 UniversalETF lifecycle
// =====================================================

(function(w){
  "use strict";

  var ID = "mad_dog_fund";
  var SCALE = 1000;
  var NS = "madDogCapital";
  var VER = 1;

  var CONFIG = {
    id: ID,
    title: "王國戰略資本",
    initialCapital: 50000000,
    initialPrice: 10,
    totalShares: 5000000,
    listHoldingCount: 20,
    maxHoldings: 20,
    playerOwnershipLimit: 0.003,
    minPositionRatio: 0.006
  };

  function num(v,d){
    v = Number(v);
    return isFinite(v) ? v : (d || 0);
  }

  function floor(v){
    return Math.floor(num(v,0));
  }

  function rand(min,max){
    return min + Math.random() * (max - min);
  }

  function clamp(v,min,max){
    return Math.max(min, Math.min(max, v));
  }

  function getScale(){
    return (w.StockMarketEngine && w.StockMarketEngine.SCALE) ||
           (w.StockMarketCurrency && w.StockMarketCurrency.SCALE) ||
           SCALE;
  }

  function getState(){
    if(w.StockStateManager && w.StockStateManager.getState){
      return w.StockStateManager.getState();
    }
    return null;
  }

  function save(){
    if(w.StockStateManager && w.StockStateManager.save){
      w.StockStateManager.save();
    }
  }

  function getRoot(state){
    if(!state) return null;

    if(!state[NS]){
      state[NS] = {
        _ver: VER,
        fund: null,
        playerHolding: {
          qty: 0,
          avgCostMilli: 0,
          costBasisMilli: 0,
          realizedPnlMilli: 0,
          feesPaidMilli: 0
        }
      };
    }

    if(!state[NS].playerHolding){
      state[NS].playerHolding = {
        qty: 0,
        avgCostMilli: 0,
        costBasisMilli: 0,
        realizedPnlMilli: 0,
        feesPaidMilli: 0
      };
    }

    return state[NS];
  }

  function createFund(state){
    var scale = getScale();
    var day = Math.max(1, floor(state && state.marketDay || 1));
    var nav = floor(CONFIG.initialPrice * scale);
    var capital = floor(CONFIG.initialCapital * scale);

    return {
      id: ID,
      name: CONFIG.title,
      title: CONFIG.title,
      type: "mad_dog_capital",
      fundType: "mad_dog",
      trackingMode: "mad_dog_core",
      status: "building",

      createdDay: day,
      listedDay: null,
      lastProcessedMarketDay: 0,

      initialCapitalMilli: capital,
      cashReserveMilli: capital,
      stockAssetValueMilli: 0,
      totalAssetValueMilli: capital,

      totalShares: floor(CONFIG.totalShares),

      navMilli: nav,
      marketPriceMilli: nav,
      currentPriceMilli: nav,
      dayOpenPriceMilli: nav,
      dayHighPriceMilli: nav,
      dayLowPriceMilli: nav,
      lastClosePriceMilli: nav,
      diffMilli: 0,
      diffPercent: 0,

      marketPressure: 0,
      marketBuyVolume: 0,
      marketSellVolume: 0,
      marketPremiumPct: 0,

      issueCount: 0,
      issuedSharesTotal: 0,
      lastIssueDay: 0,
      lastIssueShares: 0,
      lastIssuePriceMilli: 0,
      lastIssueReason: "",
      lastIssueNavMilli: nav,

      buybackCount: 0,
      buybackSharesTotal: 0,
      lastBuybackDay: 0,
      lastBuybackShares: 0,
      lastBuybackPriceMilli: 0,

      splitCount: 0,
      totalSplitRatio: 1,
      lastSplitDay: 0,
      lastSplitRatio: 1,
      lastSplitPriceMilli: 0,

      maxHoldings: CONFIG.maxHoldings,
      listHoldingCount: CONFIG.listHoldingCount,
      playerOwnershipLimit: CONFIG.playerOwnershipLimit,

      strategyStatus: "BUILDING THE PACK",
      dividendAnnouncement: "瘋狗資本不發放股利｜所有收益全面再投資",
      pendingDividendMilli: 0,
      dividendEnabled: false,

      holdings: [],
      rebalanceChanges: [],
      announcements: []
    };
  }

  function ensureFund(){
    var state = getState();
    var root = getRoot(state);
    if(!root) return null;

    if(!root.fund || root.fund._coreVer !== VER){
      root.fund = createFund(state);
      root.fund._coreVer = VER;
      save();
    }

    return root.fund;
  }

  function assetsArray(state){
    var arr = [];
    if(!state || !state.assets) return arr;

    for(var id in state.assets){
      if(!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var a = state.assets[id];
      if(!a) continue;
      if(!a.unlocked) continue;
      if(a.isDelisted) continue;
      if(a.excludeFromEtf) continue;

      var price = priceOf(a);
      if(price <= 0) continue;

      arr.push(a);
    }

    return arr;
  }

  function priceOf(a){
    return Math.max(
      1,
      floor(
        (a && (
          a.price ||
          a.currentPriceMilli ||
          a.priceMilli ||
          a.lastClosePrice ||
          a.startPrice
        )) || 0
      )
    );
  }

  function assetName(a){
    return (a && (a.name || a.shortName || a.symbol || a.id)) || "未知商會";
  }

  function momentumScore(a){
    if(!a) return -999999;

    var price = priceOf(a);
    var open = Math.max(1, floor(a.dayOpenPrice || a.dayOpenPriceMilli || a.lastClosePrice || a.lastClosePriceMilli || a.startPrice || price));
    var prev = Math.max(1, floor(a.lastClosePrice || a.lastClosePriceMilli || open));
    var changeFromOpen = (price - open) / open;
    var changeFromPrev = (price - prev) / prev;

    var liquidity = num(a.liquidity, 1);
    var trend = num(a.baseTrend, 0);
    var risk = num(a.risk, 1);
    var cap = num(a.marketCap || a.worldMarketCap, 1);

    var score = 0;

    score += changeFromOpen * 900;
    score += changeFromPrev * 700;
    score += trend * 18;
    score += liquidity * 0.08;
    score += risk * 2;
    score += Math.log(Math.max(1, cap)) * 0.06;

    if(changeFromOpen > 0.08) score *= 1.35;
    if(changeFromPrev < -0.06) score -= 18;

    return score;
  }

  function rankAssets(state){
    var arr = assetsArray(state);

    arr.forEach(function(a){
      a.__madDogScore = momentumScore(a);
    });

    arr.sort(function(a,b){
      return num(b.__madDogScore,0) - num(a.__madDogScore,0);
    });

    return arr;
  }

  function mapHoldings(fund){
    var map = {};
    (fund.holdings || []).forEach(function(h){
      if(h && h.assetId) map[h.assetId] = h;
    });
    return map;
  }

  function repriceHoldings(fund, state){
    var assets = state && state.assets ? state.assets : {};
    var next = [];
    var stockValue = 0;

    (fund.holdings || []).forEach(function(h){
      if(!h || !h.assetId) return;

      var a = assets[h.assetId];
      if(!a || a.isDelisted) return;

      var price = priceOf(a);
      var shares = Math.max(0, floor(h.sharesHeld || 0));
      if(shares <= 0) return;

      h.priceMilli = price;
      h.name = h.name || assetName(a);
      h.symbol = h.symbol || a.symbol;
      h.oldSharesHeld = floor(h.oldSharesHeld || shares);
      h.marketValueMilli = shares * price;
      h.marketValue = h.marketValueMilli;
      h.momentumScore = momentumScore(a);

      stockValue += h.marketValueMilli;
      next.push(h);
    });

    fund.holdings = next;
    fund.stockAssetValueMilli = stockValue;
    fund.totalAssetValueMilli = Math.max(1, floor(fund.cashReserveMilli || 0) + stockValue);
    fund.navMilli = Math.max(1, Math.floor(fund.totalAssetValueMilli / Math.max(1, floor(fund.totalShares || 1))));

    next.forEach(function(h){
      h.weight = h.marketValueMilli / Math.max(1, fund.totalAssetValueMilli);
    });
  }

  function pushLog(fund, type, text, day){
    if(!fund) return;
    if(!Array.isArray(fund.announcements)) fund.announcements = [];

    var key = String(type) + ":" + String(day) + ":" + String(text);
    if(fund._lastLogKey === key) return;
    fund._lastLogKey = key;

    fund.announcements.unshift({
      type: type || "mad_dog",
      marketDay: day || 1,
      text: text || "王國戰略資本完成調整。"
    });

    if(fund.announcements.length > 24){
      fund.announcements.length = 24;
    }
  }

  function markOldShares(fund){
    (fund.holdings || []).forEach(function(h){
      h.oldSharesHeld = floor(h.sharesHeld || 0);
    });
  }

  function sellHolding(fund, h, ratio){
    ratio = clamp(num(ratio,1), 0, 1);
    var shares = floor((h.sharesHeld || 0) * ratio);
    if(shares <= 0) return 0;

    var value = shares * Math.max(1, floor(h.priceMilli || 1));
    h.sharesHeld = Math.max(0, floor(h.sharesHeld || 0) - shares);
    fund.cashReserveMilli = floor(fund.cashReserveMilli || 0) + value;

    return value;
  }

  function removeHolding(fund, h){
    if(!h) return 0;
    var value = floor(h.sharesHeld || 0) * Math.max(1, floor(h.priceMilli || 1));
    fund.cashReserveMilli = floor(fund.cashReserveMilli || 0) + value;
    fund.holdings = (fund.holdings || []).filter(function(x){
      return x !== h;
    });
    return value;
  }

  function buyAsset(fund, asset, budgetMilli, targetWeight){
    if(!asset) return null;

    var price = priceOf(asset);
    var budget = Math.max(0, Math.min(floor(budgetMilli || 0), floor(fund.cashReserveMilli || 0)));
    var shares = Math.floor(budget / price);

    if(shares <= 0) return null;

    var spend = shares * price;
    fund.cashReserveMilli = Math.max(0, floor(fund.cashReserveMilli || 0) - spend);

    var h = {
      assetId: asset.id,
      symbol: asset.symbol,
      name: assetName(asset),
      rank: 0,
      weight: 0,
      sharesHeld: shares,
      oldSharesHeld: 0,
      avgCostMilli: price,
      priceMilli: price,
      marketValueMilli: spend,
      marketValue: spend,
      conviction: rand(55,100),
      targetWeight: targetWeight || 0,
      holdingDays: 0,
      changeType: "new"
    };

    fund.holdings.push(h);
    return h;
  }

  function buildToListing(fund, state, day){
    var ranked = rankAssets(state);
    var map = mapHoldings(fund);
    var need = Math.max(0, CONFIG.listHoldingCount - (fund.holdings || []).length);
    if(need <= 0) return;

    // 建倉期穩定補到20，不追求30。
    var dailyAdds = Math.min(need, 4);
    var added = 0;

    for(var i=0;i<ranked.length && added<dailyAdds;i++){
      var a = ranked[i];
      if(map[a.id]) continue;

      var positionBudget = Math.min(
        floor((fund.totalAssetValueMilli || fund.initialCapitalMilli) * rand(0.025, 0.055)),
        floor((fund.cashReserveMilli || 0) * 0.28)
      );

      var h = buyAsset(fund, a, positionBudget, rand(2,5));
      if(h){
        map[a.id] = true;
        added++;
        pushLog(fund, "build", "建倉 " + h.name, day);
      }
    }
  }

  function rotateAfterListing(fund, state, day){
    var ranked = rankAssets(state);
    var map = mapHoldings(fund);
    var holdings = fund.holdings || [];

    // 1) 先淘汰弱勢股與低持股垃圾倉。
    var removed = 0;
    holdings.slice().forEach(function(h){
      var score = num(h.momentumScore, 0);
      var valueRatio = num(h.marketValueMilli,0) / Math.max(1, num(fund.totalAssetValueMilli,1));

      if(score < -18 || valueRatio < CONFIG.minPositionRatio * 0.45){
        removeHolding(fund, h);
        removed++;
        pushLog(fund, "remove", "淘汰 " + (h.name || h.assetId), day);
      }else if(score < -6 && Math.random() < 0.35){
        sellHolding(fund, h, rand(0.35, 0.75));
        h.changeType = "reduce";
        pushLog(fund, "reduce", "減倉 " + (h.name || h.assetId), day);
      }
    });

    repriceHoldings(fund, state);
    map = mapHoldings(fund);

    // 2) 如果滿20，只允許「更強標的」替換最弱。
    var capacity = CONFIG.maxHoldings;
    var currentCount = (fund.holdings || []).length;

    var candidates = ranked.filter(function(a){
      return !map[a.id] && num(a.__madDogScore,0) > 10;
    });

    var replacements = 0;
    if(candidates.length){
      fund.holdings.sort(function(a,b){
        return num(a.momentumScore,0) - num(b.momentumScore,0);
      });

      for(var c=0;c<candidates.length && replacements<2;c++){
        var best = candidates[c];

        if((fund.holdings || []).length < capacity){
          // 只有被淘汰產生空位時補位，不主動擴張。
          var budget = Math.min(
            floor(fund.totalAssetValueMilli * rand(0.025, 0.07)),
            floor(fund.cashReserveMilli * 0.35)
          );
          var added = buyAsset(fund, best, budget, rand(2,7));
          if(added){
            replacements++;
            pushLog(fund, "add", "補位 " + added.name, day);
          }
          continue;
        }

        var worst = fund.holdings[0];
        if(!worst) break;

        var margin = num(best.__madDogScore,0) - num(worst.momentumScore,0);

        // 滿倉後，只有明顯更強才替換。
        if(margin > 18 || (num(best.__madDogScore,0) > 35 && Math.random() < 0.25)){
          removeHolding(fund, worst);

          var b = Math.min(
            floor(fund.totalAssetValueMilli * rand(0.035, 0.09)),
            floor(fund.cashReserveMilli * 0.45)
          );

          var nh = buyAsset(fund, best, b, rand(3,9));
          if(nh){
            replacements++;
            pushLog(fund, "rotate", "替換 " + (worst.name || worst.assetId) + " → " + nh.name, day);
          }
        }
      }
    }

    // 3) 重壓強勢股，弱勢自然被賣。
    rebalanceWeights(fund, state, day);
  }

  function rebalanceWeights(fund, state, day){
    repriceHoldings(fund, state);

    var holdings = fund.holdings || [];
    if(!holdings.length) return;

    holdings.sort(function(a,b){
      return num(b.momentumScore,0) - num(a.momentumScore,0);
    });

    var pressure = num(fund.marketPressure,0);
    var reserveRatio = pressure < -0.08 ? rand(0.20,0.34) : rand(0.06,0.16);
    var investable = Math.max(1, floor(fund.totalAssetValueMilli * (1 - reserveRatio)));

    var totalRaw = 0;

    holdings.forEach(function(h, idx){
      var score = num(h.momentumScore,0);
      var raw;

      if(idx === 0 && score > 25 && Math.random() < 0.35){
        raw = rand(28, 42); // 偶發重壓
        h.changeType = "heavy";
      }else if(idx < 3){
        raw = clamp(16 + score * 0.18, 12, 30);
      }else{
        raw = clamp(2.5 + score * 0.06, 0.7, 8);
      }

      h._rawWeight = raw;
      totalRaw += raw;
    });

    holdings.forEach(function(h){
      var targetValue = Math.floor(investable * (h._rawWeight / Math.max(1,totalRaw)));
      var currentValue = floor(h.marketValueMilli || 0);
      var price = Math.max(1, floor(h.priceMilli || 1));
      var gap = targetValue - currentValue;

      if(gap > price){
        var buyBudget = Math.min(gap, floor(fund.cashReserveMilli || 0));
        var add = Math.floor(buyBudget / price);
        if(add > 0){
          var spend = add * price;
          var oldShares = floor(h.sharesHeld || 0);
          var oldCost = floor(h.avgCostMilli || price);

          h.sharesHeld = oldShares + add;
          h.avgCostMilli = Math.floor(((oldShares * oldCost) + spend) / Math.max(1, h.sharesHeld));
          fund.cashReserveMilli -= spend;
          h.changeType = h.changeType === "heavy" ? "heavy" : "increase";
        }
      }else if(gap < -price){
        var sellShares = Math.floor(Math.abs(gap) / price);
        sellShares = Math.min(sellShares, floor(h.sharesHeld || 0));
        if(sellShares > 0){
          h.sharesHeld -= sellShares;
          fund.cashReserveMilli += sellShares * price;
          h.changeType = "reduce";
        }
      }
    });

    // 移除賣到太小的持倉。
    repriceHoldings(fund, state);
    fund.holdings = (fund.holdings || []).filter(function(h){
      var ratio = num(h.marketValueMilli,0) / Math.max(1, num(fund.totalAssetValueMilli,1));
      if(ratio < CONFIG.minPositionRatio && fund.status === "listed"){
        fund.cashReserveMilli += floor(h.marketValueMilli || 0);
        pushLog(fund, "dust", "清除低效倉位 " + (h.name || h.assetId), day);
        return false;
      }
      return true;
    });

    repriceHoldings(fund, state);

    fund.holdings.forEach(function(h, idx){
      h.rank = idx + 1;
      h.weight = num(h.marketValueMilli,0) / Math.max(1, num(fund.totalAssetValueMilli,1));
    });
  }

  function updatePersonality(fund){
    var p = num(fund.marketPressure,0);

    if(p > 0.16){
      fund.strategyStatus = "BERSERK MANIA";
    }else if(p > 0.06){
      fund.strategyStatus = "PREDATOR BUYING";
    }else if(p < -0.12){
      fund.strategyStatus = "PANIC ROTATION";
    }else if(fund.status !== "listed"){
      fund.strategyStatus = "BUILDING THE PACK";
    }else{
      fund.strategyStatus = "BERSERK ACTIVE";
    }
  }

  function updateMarketPressure(fund){
    var buy = Math.max(0, floor(fund.marketBuyVolume || 0));
    var sell = Math.max(0, floor(fund.marketSellVolume || 0));
    var net = buy - sell;

    var flowPressure = net / Math.max(1, floor(fund.totalShares || 1));

    // 市場壓力只能是少量溢折價來源，不可以主導 ETF 價格。
    var nav = Math.max(1, floor(fund.navMilli || CONFIG.initialPrice * getScale()));
    var lastNav = Math.max(1, floor(fund.lastPriceNavMilli || fund._lastNavMilli || nav));
    var navReturn = (nav - lastNav) / lastNav;

    fund.marketPressure =
      num(fund.marketPressure,0) * 0.72 +
      flowPressure * 0.18 +
      navReturn * 0.06 +
      rand(-0.0015,0.0015);

    fund.marketPressure = clamp(fund.marketPressure, -0.08, 0.12);
    fund.marketBuyVolume = 0;
    fund.marketSellVolume = 0;
    fund._lastNavMilli = nav;
  }

  function updateMarketPrice(fund){
    var nav = Math.max(1, floor(fund.navMilli || CONFIG.initialPrice * getScale()));

    // 尚無持倉：沒有真實資產變化，不允許 fake diff。
    if(!(fund.holdings && fund.holdings.length)){
      fund.marketPriceMilli = nav;
      fund.currentPriceMilli = nav;
      fund.dayOpenPriceMilli = nav;
      fund.dayHighPriceMilli = nav;
      fund.dayLowPriceMilli = nav;
      fund.lastClosePriceMilli = nav;
      fund.marketPremiumPct = 0;
      fund.diffMilli = 0;
      fund.diffPercent = 0;
      fund.lastPriceNavMilli = nav;
      return;
    }

    // 建倉期：尚未形成公開交易價格，價格跟 NAV；
    // 但 diff 仍然由 NAV 與昨收/開盤計算，不可固定假 0。
    if(fund.status !== "listed"){
      fund.marketPriceMilli = nav;
      fund.currentPriceMilli = nav;
      fund.marketPremiumPct = 0;

      if(!(fund.dayHighPriceMilli > 0) || nav > fund.dayHighPriceMilli){
        fund.dayHighPriceMilli = nav;
      }
      if(!(fund.dayLowPriceMilli > 0) || nav < fund.dayLowPriceMilli){
        fund.dayLowPriceMilli = nav;
      }

      var buildBase = Math.max(1, floor(fund.lastClosePriceMilli || fund.dayOpenPriceMilli || nav));
      fund.diffMilli = nav - buildBase;
      fund.diffPercent = (fund.diffMilli / buildBase) * 100;
      fund.lastPriceNavMilli = nav;
      return;
    }

    var prevPrice = Math.max(1, floor(fund.marketPriceMilli || nav));
    var lastNav = Math.max(1, floor(fund.lastPriceNavMilli || nav));
    var p = num(fund.marketPressure,0);

    // 合理 ETF 價格模型：主方向由成分股/NAV 決定，市場交易只造成少量溢折價。
    // 瘋狗的高波動應來自重壓與高換股造成的 NAV 波動，而不是 ETF 價格自行亂飆。
    var listedAge = Math.max(0, floor(fund.lastProcessedMarketDay || 0) - floor(fund.listedDay || fund.lastProcessedMarketDay || 0));
    var prevPremium = (prevPrice - nav) / Math.max(1, nav);

    var noise = listedAge < 30 ? rand(-0.0015, 0.0020) : rand(-0.0025, 0.0030);
    var pressurePremium = clamp(p * 0.10, -0.006, 0.010);

    var targetPremium = prevPremium * 0.62 + pressurePremium + noise;

    // 溢折價合理範圍：早期更貼近 NAV，時間越久才稍微放寬。
    var premiumLimit = listedAge < 30 ? 0.08 : (listedAge < 90 ? 0.12 : 0.18);
    var discountLimit = listedAge < 30 ? 0.08 : (listedAge < 90 ? 0.10 : 0.15);
    targetPremium = clamp(targetPremium, -discountLimit, premiumLimit);

    var next = nav * (1 + targetPremium);

    fund.marketPriceMilli = Math.max(1, floor(next));
    fund.currentPriceMilli = fund.marketPriceMilli;
    fund.marketPremiumPct = ((fund.marketPriceMilli - nav) / Math.max(1, nav)) * 100;

    if(!(fund.dayHighPriceMilli > 0) || fund.marketPriceMilli > fund.dayHighPriceMilli){
      fund.dayHighPriceMilli = fund.marketPriceMilli;
    }
    if(!(fund.dayLowPriceMilli > 0) || fund.marketPriceMilli < fund.dayLowPriceMilli){
      fund.dayLowPriceMilli = fund.marketPriceMilli;
    }

    // diff 永遠只由市場價格與昨收計算，不可獨立亂數。
    var base = Math.max(1, floor(fund.lastClosePriceMilli || fund.dayOpenPriceMilli || prevPrice));
    fund.diffMilli = fund.marketPriceMilli - base;
    fund.diffPercent = (fund.diffMilli / base) * 100;
    fund.lastPriceNavMilli = nav;
  }

  function capitalOperations(fund, state, day){
    if(!fund || fund.status !== "listed") return;

    var nav = Math.max(1, floor(fund.navMilli || CONFIG.initialPrice * getScale()));
    var price = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || nav));
    var totalAssets = Math.max(1, floor(fund.totalAssetValueMilli || 1));
    var cash = Math.max(0, floor(fund.cashReserveMilli || 0));

    var premium = (price - nav) / nav;
    var cashRatio = cash / totalAssets;
    var pressure = num(fund.marketPressure,0);
    var lastIssueDay = floor(fund.lastIssueDay || 0);
    var lastBuybackDay = floor(fund.lastBuybackDay || 0);

    // 經理人增發：
    // 市價明顯高於 NAV，且現金偏低或市場資金流強，才趁溢價募集資金。
    // 增發後：總發行份額增加、現金增加，NAV 會重新計算。
    if(
      premium > 0.10 &&
      (cashRatio < 0.12 || pressure > 0.045) &&
      day - lastIssueDay >= 7
    ){
      var issueRatio = clamp(
        0.004 + premium * 0.045 + Math.max(0, pressure) * 0.025,
        0.004,
        0.035
      );

      var newShares = Math.max(1000, floor(fund.totalShares * issueRatio));
      var raised = newShares * price;

      fund.totalShares = Math.max(1, floor(fund.totalShares || 1) + newShares);
      fund.cashReserveMilli = cash + raised;

      fund.issueCount = floor(fund.issueCount || 0) + 1;
      fund.issuedSharesTotal = floor(fund.issuedSharesTotal || 0) + newShares;
      fund.lastIssueDay = day;
      fund.lastIssueShares = newShares;
      fund.lastIssuePriceMilli = price;
      fund.lastIssueNavMilli = nav;
      fund.lastIssueReason = "市價溢價募資";

      pushLog(
        fund,
        "issue",
        "經理人判斷市價高於淨值，增發 " + newShares.toLocaleString() + " 份額募集戰爭資金。",
        day
      );

      return;
    }

    // 經理人回購：
    // 市價明顯低於 NAV 且現金充足時，用現金回購份額。
    if(
      premium < -0.12 &&
      cashRatio > 0.22 &&
      day - lastBuybackDay >= 7
    ){
      var buybackRatio = clamp(Math.abs(premium) * 0.025, 0.003, 0.020);
      var buybackShares = Math.max(1000, floor(fund.totalShares * buybackRatio));
      var cost = buybackShares * price;

      if(cost < fund.cashReserveMilli && buybackShares < fund.totalShares * 0.2){
        fund.totalShares = Math.max(1, floor(fund.totalShares || 1) - buybackShares);
        fund.cashReserveMilli = Math.max(0, floor(fund.cashReserveMilli || 0) - cost);

        fund.buybackCount = floor(fund.buybackCount || 0) + 1;
        fund.buybackSharesTotal = floor(fund.buybackSharesTotal || 0) + buybackShares;
        fund.lastBuybackDay = day;
        fund.lastBuybackShares = buybackShares;
        fund.lastBuybackPriceMilli = price;

        pushLog(
          fund,
          "buyback",
          "經理人判斷市價低估，回購 " + buybackShares.toLocaleString() + " 份額。",
          day
        );
      }
    }
  }

  function updateIntradayMarket(fund, state){
    if(!fund || !state) return;

    // 盤中更新只處理即時 NAV / 少量市場溢折價 / 價格 / diff。
    // 不執行輪替、增發、回購，避免一天內重複資本操作。
    repriceHoldings(fund, state);

    if(state.marketPhase === "open"){
      updateMarketPressure(fund);
      updateMarketPrice(fund);
    }else{
      syncDerivedFields(fund);
    }

    updatePersonality(fund);
  }

  function dailyUpdate(fund, state){
    var day = Math.max(1, floor(state && state.marketDay || 1));

    repriceHoldings(fund, state);

    if(fund.lastProcessedMarketDay === day){
      updateIntradayMarket(fund, state);
      return;
    }

    fund.lastProcessedMarketDay = day;

    // 份額分割在新市場日前處理，確保昨收 / 開盤 / 漲跌基準都用調整後價格。
    maybeSplitFund(fund, state, day);
    repriceHoldings(fund, state);

    fund.lastClosePriceMilli = Math.max(1, floor(fund.marketPriceMilli || fund.navMilli || 10000));
    fund.dayOpenPriceMilli = fund.lastClosePriceMilli;
    fund.dayHighPriceMilli = fund.dayOpenPriceMilli;
    fund.dayLowPriceMilli = fund.dayOpenPriceMilli;

    markOldShares(fund);

    if(fund.status !== "listed"){
      buildToListing(fund, state, day);
    }else{
      rotateAfterListing(fund, state, day);
    }

    repriceHoldings(fund, state);

    if(fund.status === "building" && (fund.holdings || []).length >= CONFIG.listHoldingCount){
      fund.status = "listed";
      fund.listedDay = day;
      pushLog(fund, "listing", "王國戰略資本完成20檔初始建倉，正式上市。", day);
    }

    fund.dividendEnabled = false;
    fund.pendingDividendMilli = 0;
    fund.dividendAnnouncement = "瘋狗資本不發放股利｜所有收益全面再投資";

    updateMarketPressure(fund);
    updatePersonality(fund);
    updateMarketPrice(fund);

    // 價值經理人資本操作：依 NAV / 市價溢折價 / 現金水位判斷增發或回購。
    capitalOperations(fund, state, day);

    // 增發 / 回購會改變現金與總發行份額，必須重算 NAV，並同步市價與 diff。
    repriceHoldings(fund, state);
    updateMarketPrice(fund);

    save();
  }

  function ensureUpdated(){
    var fund = ensureFund();
    var state = getState();
    if(!fund || !state) return fund;

    dailyUpdate(fund, state);
    return fund;
  }

  function normalizePlayerHolding(h){
    if(!h) return h;

    h.qty = Math.max(0, floor(h.qty || 0));
    h.avgCostMilli = Math.max(0, floor(h.avgCostMilli || 0));
    h.costBasisMilli = Math.max(0, floor(h.costBasisMilli || 0));
    h.realizedPnlMilli = floor(h.realizedPnlMilli || 0);
    h.feesPaidMilli = Math.max(0, floor(h.feesPaidMilli || 0));

    // 舊存檔相容：舊版只有 qty + avgCost。
    if(h.qty > 0 && h.costBasisMilli <= 0 && h.avgCostMilli > 0){
      h.costBasisMilli = h.qty * h.avgCostMilli;
    }

    if(h.qty > 0){
      h.avgCostMilli = Math.floor(h.costBasisMilli / Math.max(1, h.qty));
    }else{
      h.avgCostMilli = 0;
      h.costBasisMilli = 0;
    }

    return h;
  }

  function getSplitRatio(priceMilli){
    var scale = getScale();
    var price = priceMilli / Math.max(1, scale);

    if(price >= 120) return 10;
    if(price >= 80) return 5;
    if(price >= 50) return 3;
    if(price >= 35) return 2;

    return 1;
  }

  function adjustPriceForSplit(v, ratio){
    return Math.max(1, floor((v || 0) / Math.max(1, ratio)));
  }

  function maybeSplitFund(fund, state, day){
    if(!fund || fund.status !== "listed") return;
    if(!fund.marketPriceMilli || fund.marketPriceMilli <= 0) return;

    var lastSplitDay = floor(fund.lastSplitDay || 0);
    if(day - lastSplitDay < 30) return;

    var ratio = getSplitRatio(fund.marketPriceMilli);
    if(ratio <= 1) return;

    var oldPrice = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || fund.navMilli || 1));

    fund.totalShares = Math.max(1, floor(fund.totalShares || 1) * ratio);

    // 基金分割不改變總資產，只調整每份價格與基準價。
    fund.navMilli = adjustPriceForSplit(fund.navMilli, ratio);
    fund.marketPriceMilli = adjustPriceForSplit(fund.marketPriceMilli, ratio);
    fund.currentPriceMilli = adjustPriceForSplit(fund.currentPriceMilli, ratio);
    fund.dayOpenPriceMilli = adjustPriceForSplit(fund.dayOpenPriceMilli, ratio);
    fund.dayHighPriceMilli = adjustPriceForSplit(fund.dayHighPriceMilli, ratio);
    fund.dayLowPriceMilli = adjustPriceForSplit(fund.dayLowPriceMilli, ratio);
    fund.lastClosePriceMilli = adjustPriceForSplit(fund.lastClosePriceMilli, ratio);
    fund.lastPriceNavMilli = adjustPriceForSplit(fund.lastPriceNavMilli, ratio);

    fund.diffMilli = 0;
    fund.diffPercent = 0;

    fund.splitCount = floor(fund.splitCount || 0) + 1;
    fund.totalSplitRatio = Math.max(1, floor(fund.totalSplitRatio || 1)) * ratio;
    fund.lastSplitDay = day;
    fund.lastSplitRatio = ratio;
    fund.lastSplitPriceMilli = oldPrice;

    // 玩家持有份額跟著分割倍增；總成本、已實現損益、手續費不變。
    var root = getRoot(state || getState());
    if(root && root.playerHolding){
      var ph = normalizePlayerHolding(root.playerHolding);
      if(ph.qty > 0){
        ph.qty = ph.qty * ratio;
        ph.avgCostMilli = Math.floor(ph.costBasisMilli / Math.max(1, ph.qty));
      }
    }

    pushLog(
      fund,
      "split",
      "基金價格過高，經理人執行 1 拆 " + ratio + " 份額分割，總資產不變、每份價格調整。",
      day
    );
  }

  function playerHolding(){
    var root = getRoot(getState());

    if(!root.playerHolding){
      root.playerHolding = {
        qty: 0,
        avgCostMilli: 0,
        costBasisMilli: 0,
        realizedPnlMilli: 0,
        feesPaidMilli: 0
      };
    }

    return normalizePlayerHolding(root.playerHolding);
  }

  function maxPlayerShares(fund){
    return Math.max(1, Math.floor(Math.max(1, floor(fund.totalShares || 1)) * CONFIG.playerOwnershipLimit));
  }

  function spend(state, milli){
    if(w.StockMarketCurrency && w.StockMarketCurrency.spendMilli){
      return w.StockMarketCurrency.spendMilli(state, milli);
    }

    if(!state.currency) state.currency = {};
    var cur = floor(state.currency.investCoinMilli || 0);
    if(cur < milli) return { ok:false, reason:"coin_not_enough" };
    state.currency.investCoinMilli = cur - milli;
    return { ok:true };
  }

  function addCoin(state, milli){
    if(w.StockMarketCurrency && w.StockMarketCurrency.addMilli){
      w.StockMarketCurrency.addMilli(state, milli);
      return;
    }

    if(!state.currency) state.currency = {};
    state.currency.investCoinMilli = floor(state.currency.investCoinMilli || 0) + floor(milli || 0);
  }

  function buy(qty){
    var state = getState();
    var fund = ensureFund();
    if(!state || !fund) return { ok:false, reason:"no_state" };

    if(fund.status !== "listed"){
      return { ok:false, reason:"fund_building_locked" };
    }

    qty = Math.max(1, floor(qty || 1));

    var h = playerHolding();
    var max = maxPlayerShares(fund);

    if(floor(h.qty || 0) + qty > max){
      return { ok:false, reason:"etf_holding_limit" };
    }

    var price = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || fund.navMilli || 10000));
    var gross = price * qty;
    var fee = Math.floor(gross * 0.0005);
    var paid = spend(state, gross + fee);

    if(!paid || !paid.ok){
      return paid || { ok:false, reason:"coin_not_enough" };
    }

    var oldQty = floor(h.qty || 0);

    h.costBasisMilli = floor(h.costBasisMilli || 0) + gross + fee;
    h.feesPaidMilli = floor(h.feesPaidMilli || 0) + fee;
    h.qty = oldQty + qty;
    h.avgCostMilli = Math.floor(h.costBasisMilli / Math.max(1, h.qty));

    // 玩家持有限制很小，不影響價格。
    save();
    return { ok:true, priceMilli:price, qty:qty, feeMilli:fee };
  }

  function sell(qty){
    var state = getState();
    var fund = ensureFund();
    if(!state || !fund) return { ok:false, reason:"no_state" };

    if(fund.status !== "listed"){
      return { ok:false, reason:"fund_building" };
    }

    qty = Math.max(1, floor(qty || 1));
    var h = playerHolding();

    if(floor(h.qty || 0) < qty){
      return { ok:false, reason:"holding_not_enough" };
    }

    var price = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || fund.navMilli || 10000));
    var gross = price * qty;
    var fee = Math.floor(gross * 0.0005);

    var oldQty = Math.max(1, floor(h.qty || 0));
    var oldCostBasis = floor(h.costBasisMilli || (oldQty * floor(h.avgCostMilli || price)));
    var removedCost = Math.floor(oldCostBasis * (qty / oldQty));
    var realized = gross - fee - removedCost;

    h.qty = oldQty - qty;
    h.costBasisMilli = Math.max(0, oldCostBasis - removedCost);
    h.feesPaidMilli = floor(h.feesPaidMilli || 0) + fee;
    h.realizedPnlMilli = floor(h.realizedPnlMilli || 0) + realized;

    if(h.qty <= 0){
      h.qty = 0;
      h.avgCostMilli = 0;
      h.costBasisMilli = 0;
    }else{
      h.avgCostMilli = Math.floor(h.costBasisMilli / Math.max(1, h.qty));
    }

    addCoin(state, Math.max(0, gross - fee));

    save();
    return { ok:true, priceMilli:price, qty:qty, feeMilli:fee, realizedMilli:realized };
  }

  function subscribe(){
    return { ok:false, reason:"fund_building_locked" };
  }

  function syncDerivedFields(fund){
    if(!fund) return;

    var nav = Math.max(1, floor(fund.navMilli || CONFIG.initialPrice * getScale()));
    var price = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || nav));
    var base = Math.max(1, floor(fund.lastClosePriceMilli || fund.dayOpenPriceMilli || price));

    fund.marketPriceMilli = price;
    fund.currentPriceMilli = price;
    fund.marketPremiumPct = ((price - nav) / Math.max(1, nav)) * 100;
    fund.diffMilli = price - base;
    fund.diffPercent = (fund.diffMilli / base) * 100;
  }

  function getUIData(){
    var fund = ensureFund();
    var state = getState();
    if(!fund) return null;

    syncDerivedFields(fund);

    var h = playerHolding();
    var max = maxPlayerShares(fund);
    var price = Math.max(1, floor(fund.marketPriceMilli || fund.currentPriceMilli || fund.navMilli || 10000));
    var day = Math.max(1, floor(state && state.marketDay || 1));

    var holdingQty = floor(h.qty || 0);
    var costBasisMilli = floor(h.costBasisMilli || 0);
    var investmentValueMilli = holdingQty * price;
    var unrealizedPnlMilli = investmentValueMilli - costBasisMilli;
    var unrealizedPnlPercent = costBasisMilli > 0
      ? (unrealizedPnlMilli / costBasisMilli) * 100
      : 0;

    return {
      id: ID,
      name: fund.name || CONFIG.title,
      status: fund.status || "building",
      listed: fund.status === "listed",
      isMarketOpen: state && state.marketPhase === "open",

      nav: floor(fund.navMilli || price) / getScale(),
      navMilli: floor(fund.navMilli || price),
      marketPrice: price / getScale(),
      marketPriceMilli: price,
      currentPriceMilli: price,

      dayOpenPriceMilli: floor(fund.dayOpenPriceMilli || price),
      dayHighPriceMilli: floor(fund.dayHighPriceMilli || price),
      dayLowPriceMilli: floor(fund.dayLowPriceMilli || price),
      diffMilli: floor(fund.diffMilli || 0),
      diffPercent: num(fund.diffPercent, 0),

      totalShares: floor(fund.totalShares || 0),
      totalUnits: floor(fund.totalShares || 0),
      issueCount: floor(fund.issueCount || 0),
      issuedSharesTotal: floor(fund.issuedSharesTotal || 0),
      lastIssueShares: floor(fund.lastIssueShares || 0),
      lastIssuePriceMilli: floor(fund.lastIssuePriceMilli || 0),
      lastIssueReason: fund.lastIssueReason || "",
      buybackCount: floor(fund.buybackCount || 0),
      buybackSharesTotal: floor(fund.buybackSharesTotal || 0),
      lastBuybackShares: floor(fund.lastBuybackShares || 0),
      lastBuybackPriceMilli: floor(fund.lastBuybackPriceMilli || 0),
      splitCount: floor(fund.splitCount || 0),
      totalSplitRatio: floor(fund.totalSplitRatio || 1),
      lastSplitDay: floor(fund.lastSplitDay || 0),
      lastSplitRatio: floor(fund.lastSplitRatio || 1),
      lastSplitPriceMilli: floor(fund.lastSplitPriceMilli || 0),
      cashReserveMilli: floor(fund.cashReserveMilli || 0),
      stockAssetValueMilli: floor(fund.stockAssetValueMilli || 0),
      totalAssetValueMilli: floor(fund.totalAssetValueMilli || 0),
      totalAssetsMilli: floor(fund.totalAssetValueMilli || 0),
      cashRatio: floor(fund.cashReserveMilli || 0) / Math.max(1, floor(fund.totalAssetValueMilli || 1)),
      stockRatio: floor(fund.stockAssetValueMilli || 0) / Math.max(1, floor(fund.totalAssetValueMilli || 1)),

      holdings: fund.holdings || [],
      topHoldings: (fund.holdings || []).slice(0,5),
      rebalanceChanges: fund.rebalanceChanges || [],
      announcements: fund.announcements || [],

      dividendAnnouncement: fund.dividendAnnouncement,
      pendingDividendMilli: 0,
      daysToRebalance: 0,
      daysToQuarter: 0,
      buildHoldingCount: (fund.holdings || []).length,
      buildTargetCount: CONFIG.listHoldingCount,
      buildStockRatio: floor(fund.stockAssetValueMilli || 0) / Math.max(1, floor(fund.totalAssetValueMilli || 1)),
      disclosureDay: fund.listedDay || fund.lastProcessedMarketDay || 0,
      lastReport: fund.lastReport || { added:[], removed:[] },
      managerStyle: "BERSERK",

      holdingQty: holdingQty,
      holdingAvgCostMilli: floor(h.avgCostMilli || 0),
      holdingCostBasisMilli: costBasisMilli,
      investmentValueMilli: investmentValueMilli,
      unrealizedPnlMilli: unrealizedPnlMilli,
      unrealizedPnlPercent: unrealizedPnlPercent,
      realizedPnlMilli: floor(h.realizedPnlMilli || 0),
      feesPaidMilli: floor(h.feesPaidMilli || 0),
      playerMaxUnits: max,
      playerRemainingUnits: Math.max(0, max - floor(h.qty || 0)),

      marketPressure: num(fund.marketPressure,0),
      marketPremiumPct: num(fund.marketPremiumPct,0),
      strategyStatus: fund.strategyStatus || "BERSERK ACTIVE"
    };
  }

  function addMarketFlow(buyVolume, sellVolume){
    var fund = ensureFund();
    if(!fund) return;

    fund.marketBuyVolume = floor(fund.marketBuyVolume || 0) + Math.max(0, floor(buyVolume || 0));
    fund.marketSellVolume = floor(fund.marketSellVolume || 0) + Math.max(0, floor(sellVolume || 0));
  }

  w.MadDogCore = {
    ID: ID,
    ensureFund: ensureFund,
    dailyUpdate: ensureUpdated,
    tick: ensureUpdated,
    getSummary: getUIData,
    getUIData: getUIData,
    buy: buy,
    sell: sell,
    subscribe: subscribe,
    addMarketFlow: addMarketFlow,
    getScale: getScale,
    _debug: function(){
      var root = getRoot(getState());
      return root;
    }
  };

})(window);
