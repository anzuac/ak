(function (w) {
  "use strict";

  if (!w.StockHub || !w.StockStateManager || !w.StockMarketEngine || !w.StockMarketCompanyDynamics) {
    console.error("❌ stock_dynamics_tab.js: 缺少依賴");
    return;
  }

  var TAB_ID = "dynamics";

  function safe(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getDirectionLabel(direction) {
    if (direction === "positive") return "正面發展";
    if (direction === "negative") return "負面事件";
    if (direction === "mixed") return "影響未明";
    return "公司事件";
  }

  function getDirectionColor(direction) {
    if (direction === "positive") return "#22c55e";
    if (direction === "negative") return "#ef4444";
    if (direction === "mixed") return "#facc15";
    return "#e5e7eb";
  }


  function normalizeAICompanyEvent(state, evt) {
    evt = evt || {};
    var asset = state.assets && evt.assetId ? state.assets[evt.assetId] : null;
    return {
      id: evt.id,
      target: evt.assetId,
      assetName: asset ? asset.name : (evt.assetName || evt.assetId || "-"),
      title: evt.title || "AI公司事件",
      direction: evt.positive ? "positive" : "negative",
      type: evt.positive ? "positive" : "negative",
      levelLabel: Number(evt.intensity || 0) >= 0.65 ? "大" : (Number(evt.intensity || 0) >= 0.35 ? "中" : "小"),
      remainingDays: evt.remainingDays || 0,
      createdDay: evt.startDay || evt.createdDay || 0,
      description: evt.description || ""
    };
  }

  function getAICompanyEvents(state) {
    if (w.StockMarketEngine && w.StockMarketEngine.getAICompanyEvents) {
      return (w.StockMarketEngine.getAICompanyEvents(state) || []).map(function(evt) {
        return normalizeAICompanyEvent(state, evt);
      });
    }
    return [];
  }

  function getAICompanyHistory(state) {
    if (w.StockMarketEngine && w.StockMarketEngine.getAIEventHistory) {
      return (w.StockMarketEngine.getAIEventHistory(state) || [])
        .filter(function(evt){ return evt && evt.type === "company"; })
        .map(function(evt){ return normalizeAICompanyEvent(state, evt); });
    }
    return [];
  }

  function getDynamicTypeLabel(type) {
    switch (String(type || "")) {
      case "positive": return "經營利多";
      case "negative": return "經營壓力";
      case "decision": return "董事會";
      case "neutral_vol": return "高波動";
      case "extreme_up": return "重大突破";
      case "extreme_down": return "重大危機";
      default: return "公司動態";
    }
  }

  function getVoteLabel(vote) {
    if (vote === "agree") return "已投同意";
    if (vote === "reject") return "已投反對";
    if (vote === "abstain") return "已投棄權";
    if (vote === "ineligible") return "不可參與";
    return "尚未投票";
  }

  function getDecisionAccessSummary(state) {
    var assets = state && state.assets ? state.assets : {};
    var eligibleCount = 0;
    var topRatio = 0;
    for (var id in assets) {
      if (!Object.prototype.hasOwnProperty.call(assets, id)) continue;
      var asset = assets[id];
      if (!asset || String(asset.sectorCode || "").toUpperCase() === "A") continue;
      var ratio = w.StockMarketEngine && w.StockMarketEngine.getPlayerControlRatio ? Number(w.StockMarketEngine.getPlayerControlRatio(state, id) || 0) : 0;
      if (ratio > topRatio) topRatio = ratio;
      if (ratio >= 0.30) eligibleCount += 1;
    }
    return { eligibleCount: eligibleCount, topRatio: topRatio, hasAccess: eligibleCount > 0 };
  }

  function renderSummaryCard(id, title, value, sub, color) {
    return (
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;min-height:88px;display:flex;flex-direction:column;justify-content:center;">' +
        '<div style="font-size:14px;font-weight:900;opacity:.9;">' + title + '</div>' +
        '<div id="' + id + '" style="font-size:22px;font-weight:900;color:' + (color || '#e5e7eb') + ';margin-top:6px;">' + value + '</div>' +
        '<div id="' + id + '-sub" style="font-size:12px;opacity:.72;margin-top:4px;line-height:1.45;">' + (sub || '') + '</div>' +
      '</div>'
    );
  }

  function renderSectionShell(title, subtitle, scrollId, contentId, maxHeight) {
    return (
      '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
        '<div style="font-size:18px;font-weight:900;">' + title + '</div>' +
        (subtitle ? '<div style="font-size:12px;opacity:.72;margin-top:4px;line-height:1.55;">' + subtitle + '</div>' : '') +
        '<div id="' + scrollId + '" style="margin-top:10px;max-height:' + (maxHeight || 260) + 'px;overflow-y:auto;padding-right:4px;">' +
          '<div id="' + contentId + '"></div>' +
        '</div>' +
      '</div>'
    );
  }

  function rememberScrollPositions(body) {
    var ids = ["dyn-decision-scroll", "dyn-active-scroll", "dyn-history-scroll"];
    var map = {};
    for (var i = 0; i < ids.length; i++) {
      var el = body.querySelector("#" + ids[i]);
      map[ids[i]] = el ? Number(el.scrollTop || 0) : 0;
    }
    return map;
  }

  function restoreScrollPositions(body, map) {
    if (!map) return;
    for (var id in map) {
      if (!Object.prototype.hasOwnProperty.call(map, id)) continue;
      var el = body.querySelector("#" + id);
      if (el) el.scrollTop = Number(map[id] || 0);
    }
  }

  function buildDecisionHtml(state, decisionAccess, pendingDecisions) {
    if (!decisionAccess.hasAccess) {
      return '<div style="padding:8px 0;opacity:.75;line-height:1.7;">尚未持有足夠股權參與公司決策。當你對公司取得足夠影響力後，董事會議題會出現在這裡。</div>';
    }
    if (!pendingDecisions.length) {
      return '<div style="padding:8px 0;opacity:.75;line-height:1.7;">目前沒有可參與表決的公司決策。</div>';
    }
    var html = '';
    for (var i = 0; i < pendingDecisions.length; i++) {
      var dec = pendingDecisions[i] || {};
      var color = getDirectionColor(dec.outcomeDirection || dec.direction);
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < pendingDecisions.length - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center;">' +
            '<div style="font-weight:900;color:' + color + ';">' + safe(dec.assetName || '公司') + '｜' + safe(dec.title || '董事會提案') + '</div>' +
            '<div style="background:#7c3aed;color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">可投票</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.9;">' +
            safe(dec.decisionHint || '董事會正在評估這項方案。') + '<br>' +
            '剩餘：' + Number(dec.remainingDays || 0) + ' 天｜投票狀態：<b>' + getVoteLabel(dec.playerVote) + '</b>' +
          '</div>' +
          '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">' +
            '<button data-decision-vote="agree" data-decision-id="' + safe(dec.id) + '" style="background:#16a34a;color:#fff;border:0;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:900;">同意</button>' +
            '<button data-decision-vote="reject" data-decision-id="' + safe(dec.id) + '" style="background:#dc2626;color:#fff;border:0;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:900;">反對</button>' +
            '<button data-decision-vote="abstain" data-decision-id="' + safe(dec.id) + '" style="background:#475569;color:#fff;border:0;border-radius:10px;padding:8px 12px;cursor:pointer;font-weight:900;">棄權</button>' +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function buildActiveHtml(state, active) {
    if (!active.length) {
      return '<div style="padding:8px 0;opacity:.75;line-height:1.7;">目前沒有作用中的公司突發事件。</div>';
    }
    var html = '';
    var max = Math.min(8, active.length);
    for (var i = 0; i < max; i++) {
      var evt = active[i] || {};
      var asset = state.assets && state.assets[evt.target];
      var color = getDirectionColor(evt.direction);
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center;">' +
            '<div style="font-weight:900;color:' + color + ';">' + safe(evt.title || '公司事件') + '</div>' +
            '<div style="background:#1e293b;color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">' + getDynamicTypeLabel(evt.type) + '</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.9;">' +
            '公司：' + safe(asset ? asset.name : (evt.assetName || evt.target || '-')) + '<br>' +
            '事件狀態：' + getDirectionLabel(evt.direction) + '｜影響等級：' + safe(evt.levelLabel || '中') + '<br>' +
            (evt.description ? safe(evt.description) + '<br>' : '') +
            'AI持續觀察：剩餘約 ' + Number(evt.remainingDays || evt.remainingTicks || 0).toFixed(1) + ' 天' +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function buildHistoryHtml(state, history) {
    if (!history.length) {
      return '<div style="padding:8px 0;opacity:.75;line-height:1.7;">目前沒有公司動態歷史。</div>';
    }
    var html = '';
    var max = Math.min(16, history.length);
    for (var i = 0; i < max; i++) {
      var h = history[i] || {};
      var asset = state.assets && state.assets[h.target];
      var color = getDirectionColor(h.direction);
      html +=
        '<div style="padding:10px 0;border-bottom:' + (i < max - 1 ? '1px solid #1f2937' : '0') + ';">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center;">' +
            '<div style="font-weight:900;color:' + color + ';">' + safe(h.title || '公司事件') + '</div>' +
            '<div style="background:#1e293b;color:#fff;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:800;">' + getDynamicTypeLabel(h.type) + '</div>' +
          '</div>' +
          '<div style="font-size:13px;margin-top:5px;line-height:1.75;opacity:.88;">' +
            '公司：' + safe(asset ? asset.name : (h.assetName || h.target || '-')) + '<br>' +
            '事件狀態：' + getDirectionLabel(h.direction) + '｜建立日：第 ' + Number(h.createdDay || 0) + ' 日' +
          '</div>' +
        '</div>';
    }
    return html;
  }

  function collectViewModel(state) {
    var dynamicsState = state.companyDynamics || {};
    var active = getAICompanyEvents(state);
    var history = getAICompanyHistory(state);
    var pendingAll = w.StockMarketCompanyDynamics.getPendingDecisions ? (w.StockMarketCompanyDynamics.getPendingDecisions(state) || []) : [];
    var access = getDecisionAccessSummary(state);
    var pendingDecisions = access.hasAccess ? pendingAll.filter(function(d) { return !!(d && d.playerEligible); }) : [];
    dynamicsState.triggeredToday = active.length;
    dynamicsState.dailyQuota = "AI";
    return {
      dynamicsState: dynamicsState,
      active: active,
      history: history,
      decisionAccess: access,
      pendingDecisions: pendingDecisions
    };
  }

  function updateSections(body, state) {
    var vm = collectViewModel(state);
    var scrolls = rememberScrollPositions(body);

    var quota = body.querySelector('#dyn-summary-quota');
    if (quota) quota.textContent = Number(vm.dynamicsState.triggeredToday || 0) + ' / AI';
    var active = body.querySelector('#dyn-summary-active');
    if (active) active.textContent = vm.active.length + ' 則';
    var vote = body.querySelector('#dyn-summary-vote');
    if (vote) vote.textContent = vm.pendingDecisions.length + ' 件';
    var history = body.querySelector('#dyn-summary-history');
    if (history) history.textContent = vm.history.length + ' 筆';

    var voteSub = body.querySelector('#dyn-summary-vote-sub');
    if (voteSub) voteSub.textContent = vm.decisionAccess.hasAccess ? '可參與公司決策' : '尚未取得足夠公司影響力';

    var decisionContent = body.querySelector('#dyn-decision-content');
    if (decisionContent) decisionContent.innerHTML = buildDecisionHtml(state, vm.decisionAccess, vm.pendingDecisions);
    var activeContent = body.querySelector('#dyn-active-content');
    if (activeContent) activeContent.innerHTML = buildActiveHtml(state, vm.active);
    var historyContent = body.querySelector('#dyn-history-content');
    if (historyContent) historyContent.innerHTML = buildHistoryHtml(state, vm.history);

    bindActions(body);
    restoreScrollPositions(body, scrolls);
  }

  function render(body) {
    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();
    body.innerHTML =
      '<div style="display:flex;flex-direction:column;gap:12px;">' +
        '<div style="background:linear-gradient(135deg,#0b1220,#111827);border:1px solid #263247;border-radius:16px;padding:14px;">' +
          '<div style="font-size:22px;font-weight:1000;">🏢 公司情報</div>' +
          '<div style="font-size:12px;opacity:.72;margin-top:5px;line-height:1.6;">公司事件已由 AI Event Ecosystem 全面接管；董事會仍保留為玩家治理互動。</div>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">' +
          renderSummaryCard('dyn-summary-quota', '今日公司事件額度', '0 / 0', '公司內部事件觸發量') +
          renderSummaryCard('dyn-summary-active', '進行中事件', '0 則', '目前作用中的公司事件', '#facc15') +
          renderSummaryCard('dyn-summary-vote', '董事會議題', '0 件', '可參與公司決策', '#c4b5fd') +
          renderSummaryCard('dyn-summary-history', '公司紀錄', '0 筆', '最近公司內部事件') +
        '</div>' +
        renderSectionShell('🗳️ 董事會 / 公司決策', '只顯示你能參與或需要關注的公司治理議題。', 'dyn-decision-scroll', 'dyn-decision-content', 260) +
        renderSectionShell('⚡ 公司突發事件', '公司內部正在發生的事件，不顯示漲跌預估，只描述事件本身。', 'dyn-active-scroll', 'dyn-active-content', 300) +
        renderSectionShell('🗂️ 最近公司動態紀錄', '公司經營、危機、研發與決策相關紀錄。', 'dyn-history-scroll', 'dyn-history-content', 340) +
      '</div>';
    updateSections(body, state);
  }

  function bindActions(body) {
    if (!body) return;
    var btns = body.querySelectorAll('button[data-decision-vote][data-decision-id]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].onclick = (function(decisionId, vote) {
        return function() {
          var state = w.StockStateManager.getState();
          w.StockStateManager.settleAndSave();
          var res = w.StockMarketCompanyDynamics.voteOnDecision ? w.StockMarketCompanyDynamics.voteOnDecision(state, decisionId, vote) : { ok: false };
          if (!res.ok) {
            alert('目前無法參與此決策投票。');
            return;
          }
          w.StockStateManager.save();
          updateSections(body, state);
        };
      })(btns[i].getAttribute('data-decision-id'), btns[i].getAttribute('data-decision-vote'));
    }
  }

  function update(body) {
    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();
    updateSections(body, state);
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "公司情報",
    render: render,
    update: update
  });
})(window);
