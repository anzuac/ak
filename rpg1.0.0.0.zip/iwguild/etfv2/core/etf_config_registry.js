// ETFV2 Config Registry

window.ETF_CONFIGS = {

  guild_leader_fund: {
    id: "guild_leader_fund",
    title: "商會龍頭基金",
    trackingMode: "passive",
    rebalanceDays: 30,
    initialCapital: 100000000,
    initialPrice: 10,
    totalShares: 10000000,
    maxHoldings: 20,
    playerOwnershipLimit: 0.001
  },

  mad_dog_fund: {
    id: "mad_dog_fund",
    title: "王國戰略資本",
    subtitle: "瘋狗基金",
    trackingMode: "mad_dog",
    rebalanceDays: 1,
    initialCapital: 50000000,
    initialPrice: 10,
    totalShares: 5000000,
    maxHoldings: 30,
    unlockCompanyCount: 10,
    playerOwnershipLimit: 0.003
  }

};
