

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

// ======================================================
// stock_market_registry.js
// 自動上市 / 自動下市公司註冊中心（含上市預告 / 下市警告 / 核心股保護）
// 依賴：
// - StockMarketCompanyTemplates
// - StockMarketNameGenerator
// ======================================================
(function (w) {
  "use strict";

  if (!w.StockMarketCompanyTemplates || !w.StockMarketNameGenerator) {
    console.error("❌ stock_market_registry.js: 缺少依賴");
    return;
  }

  var TPL = w.StockMarketCompanyTemplates;
  var NAME = w.StockMarketNameGenerator;
  var SCALE = TPL.SCALE || 1000;

  var REGISTRY_DEFAULTS = {
    listedHistory: [],
    delistedHistory: [],
    pendingListings: [],
    symbolCounters: {},

    lastListingCheckDay: 0,
    lastDelistingCheckDay: 0,
    lastRefillCheckDay: 0,

    lastListedDay: 0,
    lastDelistedDay: 0,

    minActiveCompanies: 55,
    softMaxActiveCompanies: 60,
    maxActiveCompanies: 70,
    refillCheckIntervalDays: 2,

    dailyMaxListings: 1,
    dailyMaxDelistings: 1,

    listedToday: 0,
    delistedToday: 0,

    maxPendingListings: 4
  };

  function clone(v) {
    if (Array.isArray(v)) return v.slice();
    if (v && typeof v === "object") return JSON.parse(JSON.stringify(v));
    return v;
  }

  function ensureRegistryState(state) {
    if (!state.companyRegistry) state.companyRegistry = {};
    var reg = state.companyRegistry;

    for (var k in REGISTRY_DEFAULTS) {
      if (!Object.prototype.hasOwnProperty.call(REGISTRY_DEFAULTS, k)) continue;
      if (typeof reg[k] === "undefined") reg[k] = clone(REGISTRY_DEFAULTS[k]);
    }

    if (!Array.isArray(reg.listedHistory)) reg.listedHistory = [];
    if (!Array.isArray(reg.delistedHistory)) reg.delistedHistory = [];
    if (!Array.isArray(reg.pendingListings)) reg.pendingListings = [];

    return reg;
  }

  function ensureRegistry(state) {
    return ensureRegistryState(state);
  }

  function inferSectorCodeFromAsset(asset) {
    if (!asset) return "X";
    if (asset.sectorCode) return String(asset.sectorCode).toUpperCase();
    if (asset.stateOwned || (asset.companyInfo && /國營/.test(String(asset.companyInfo.ownerType || ""))) || /國營/.test(String(asset.companyInfo && asset.companyInfo.category || ""))) return "A";

    var industryId = String(asset.registryMeta && asset.registryMeta.industryId || asset.industryId || "").toLowerCase();
    var map = TPL.INDUSTRY_SECTOR_CODES || {};
    if (map[industryId]) return String(map[industryId]).toUpperCase();

    var tags = Array.isArray(asset.tags) ? asset.tags : [];
    if (tags.indexOf("arcane") >= 0) return "C";
    if (tags.indexOf("crystal_energy") >= 0) return "G";
    if (tags.indexOf("royal_military") >= 0) return "M";
    if (tags.indexOf("sky_route") >= 0) return "H";
    if (tags.indexOf("grain") >= 0) return "F";
    if (tags.indexOf("holy_care") >= 0) return "E";
    if (tags.indexOf("gold_contract") >= 0) return "B";
    if (tags.indexOf("royal_build") >= 0) return "D";
    if (tags.indexOf("alchemy") >= 0) return "L";
    if (tags.indexOf("adventurer") >= 0) return "V";
    if (tags.indexOf("black_market") >= 0) return "K";
    if (tags.indexOf("relic") >= 0) return "R";
    if (tags.indexOf("medical") >= 0) return "E";
    if (tags.indexOf("finance") >= 0) return "B";
    if (tags.indexOf("tech") >= 0) return "C";
    if (tags.indexOf("manufacturing") >= 0) return "D";
    if (tags.indexOf("energy") >= 0) return "G";
    if (tags.indexOf("shipping") >= 0) return "H";
    if (tags.indexOf("food") >= 0) return "F";
    if (tags.indexOf("resource") >= 0) return "R";
    return "X";
  }

  function syncSymbolCountersFromState(state) {
    var reg = ensureRegistryState(state);
    if (!reg.symbolCounters || typeof reg.symbolCounters !== "object") reg.symbolCounters = {};

    function scan(symbol) {
      symbol = String(symbol || "").toUpperCase();
      var m = /^([A-Z])(\d{4})$/.exec(symbol);
      if (!m) return;
      var prefix = m[1];
      var serial = Math.max(1, Math.floor(Number(m[2] || 0)));
      reg.symbolCounters[prefix] = Math.max(Math.floor(Number(reg.symbolCounters[prefix] || 0)), serial);
    }

    if (state && state.assets) {
      for (var id in state.assets) {
        if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
        scan(state.assets[id] && state.assets[id].symbol);
      }
    }

    var pending = reg.pendingListings || [];
    for (var i = 0; i < pending.length; i++) {
      scan(pending[i] && pending[i].asset && pending[i].asset.symbol);
    }

    return reg.symbolCounters;
  }

  function createNextStockSymbol(state, prefix) {
    var reg = ensureRegistryState(state);
    prefix = String(prefix || "X").toUpperCase().replace(/[^A-Z]/g, "") || "X";
    syncSymbolCountersFromState(state);
    reg.symbolCounters[prefix] = Math.max(0, Math.floor(Number(reg.symbolCounters[prefix] || 0))) + 1;
    return NAME.formatStockSymbol(prefix, reg.symbolCounters[prefix]);
  }

  function ensureAssetSymbol(state, asset) {
    if (!asset) return asset;
    if (/^[A-Z]\d{4}$/.test(String(asset.symbol || "").toUpperCase())) {
      asset.symbol = String(asset.symbol).toUpperCase();
      asset.sectorCode = String(asset.sectorCode || asset.symbol.charAt(0) || inferSectorCodeFromAsset(asset)).toUpperCase();
      syncSymbolCountersFromState(state);
      return asset;
    }

    var prefix = inferSectorCodeFromAsset(asset);
    asset.sectorCode = prefix;
    asset.symbol = createNextStockSymbol(state, prefix);
    return asset;
  }

  function randRange(min, max) {
    return TPL.randRange(min, max);
  }

  function randInt(min, max) {
    return TPL.randInt(min, max);
  }

  function clamp(v, min, max) {
    return TPL.clamp(v, min, max);
  }

  function getCurrentMarketDay(state) {
    if (typeof state.marketDay === "number") return state.marketDay;
    return 0;
  }

  function isActiveAsset(asset) {
    return !!(asset && asset.unlocked && !asset.isDelisted);
  }

  function getActiveAssetCount(state) {
    if (!state.assets) return 0;
    var n = 0;
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      if (isActiveAsset(state.assets[id])) n++;
    }
    return n;
  }

  function getActiveAssetIds(state) {
    var out = [];
    if (!state.assets) return out;
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      if (isActiveAsset(state.assets[id])) out.push(id);
    }
    return out;
  }

  function getPortfolioHolding(state, assetId) {
    if (!state || !state.portfolio) return { qty: 0, avgCostMilli: 0 };
    var h = state.portfolio[assetId];
    if (!h) return { qty: 0, avgCostMilli: 0 };
    return {
      qty: Math.max(0, Math.floor(Number(h.qty || 0))),
      avgCostMilli: Math.max(0, Math.floor(Number(h.avgCostMilli || 0)))
    };
  }

  function clearPortfolioHolding(state, assetId) {
    if (!state || !state.portfolio || !state.portfolio[assetId]) return;
    delete state.portfolio[assetId];
  }

  function addInvestmentCoinMilli(state, milli) {
    milli = Math.floor(Number(milli || 0));
    if (!milli) return;

    if (!state.currency) state.currency = {};
    state.currency.investCoinMilli = Math.max(0, Math.floor(Number(
      state.currency.investCoinMilli ??
      state.currency.milli ??
      state.currency.balanceMilli ??
      state.currency.coinMilli ??
      0
    ))) + milli;

    delete state.currency.milli;
    delete state.currency.balanceMilli;
    delete state.currency.coinMilli;
  }

  function pushListedHistory(state, rec) {
    var reg = ensureRegistryState(state);
    reg.listedHistory.unshift(rec);
    if (reg.listedHistory.length > 60) reg.listedHistory.length = 60;
  }

  function pushDelistedHistory(state, rec) {
    var reg = ensureRegistryState(state);
    reg.delistedHistory.unshift(rec);
    if (reg.delistedHistory.length > 60) reg.delistedHistory.length = 60;
  }

  function getClimateBias(state) {
    var climate = state.climate || {};
    var sentiment = Number(climate.sentiment || 0);
    var stability = Number(climate.stability || 0);

    var score = 0;
    if (sentiment >= 65) score += 1;
    if (sentiment <= 35) score -= 1;
    if (stability >= 65) score += 0.5;
    if (stability <= 30) score -= 0.5;

    return score;
  }

  function getWorldBias(state) {
    var ws = state.worldState || {};
    var label = String(ws.label || "");

    if (/多|熱|榮景|成長|強勢/.test(label)) return 1;
    if (/空|冷|衰退|弱勢|風險/.test(label)) return -1;
    return 0;
  }

  function getListingChance(state) {
    var reg = ensureRegistryState(state);
    var active = getActiveAssetCount(state);

    var chance = 0.14;
    chance += getClimateBias(state) * 0.04;
    chance += getWorldBias(state) * 0.05;

    if (active < reg.minActiveCompanies) chance += 0.08;
    if (active <= reg.minActiveCompanies - 3) chance += 0.06;

    if (active > reg.softMaxActiveCompanies) {
      var overSoft = active - reg.softMaxActiveCompanies;
      chance *= Math.max(0, 1 - overSoft * 0.16);
    }

    if (active >= reg.maxActiveCompanies) chance = 0;

    return clamp(chance, 0, 0.70);
  }

  function canListToday(state) {
    var reg = ensureRegistryState(state);
    var today = getCurrentMarketDay(state);

    if (reg.lastListingCheckDay !== today) {
      reg.lastListingCheckDay = today;
      reg.listedToday = 0;
    }

    if (reg.listedToday >= reg.dailyMaxListings) return false;
    if (getActiveAssetCount(state) >= reg.maxActiveCompanies) return false;

    return true;
  }

  function canDelistToday(state) {
    var reg = ensureRegistryState(state);
    var today = getCurrentMarketDay(state);

    if (reg.lastDelistingCheckDay !== today) {
      reg.lastDelistingCheckDay = today;
      reg.delistedToday = 0;
    }

    if (reg.delistedToday >= reg.dailyMaxDelistings) return false;
    return true;
  }

  function pickIndustryId() {
    return TPL.pickIndustryId();
  }

  function pickTierId() {
    return TPL.pickTierId();
  }

  function pickBoardId() {
    return TPL.pickBoardId();
  }

  function makeDescription(profile) {
    var desc = profile.industryDescription || "";
    return profile.industryLabel + "產業，" + desc;
  }

  function buildCompanyInfo(profile) {
    var foundedYear = randInt(1975, 2022);

    return {
      category: profile.industryLabel,
      foundedYear: foundedYear,
      descriptionLong: makeDescription(profile),
      notes: "董事會態度：" + profile.boardLabel,
      quality: profile.quality,
      stability: profile.stability,
      hype: profile.hype,
      payoutRatio: Number(profile.currentPayoutRatio),
      assetBaseMilli: Math.floor(Number(profile.assetsMilli || 0)),
      revenueBaseMilli: Math.floor(Number(profile.revenueMonthlyMilli || 0)),
      profitBaseMilli: Math.floor(Number(profile.profitMonthlyMilli || 0))
,
      guildCapitalMilli: Math.floor(Number(profile.guildCapitalMilli || profile.assetsMilli || 0)),
      guildCapitalBaseMilli: Math.floor(Number(profile.guildCapitalBaseMilli || profile.guildCapitalMilli || profile.assetsMilli || 0)),
      guildCapitalTierId: profile.guildCapitalTierId || "",
      guildCapitalTierLabel: profile.guildCapitalTierLabel || "",
      guildCapitalTierRank: Math.max(0, Math.floor(Number(profile.guildCapitalTierRank || 0))),
      guildCapitalLastUpdateDay: 0,
      aiParValueMilli: Math.floor(Number(profile.aiParValueMilli || 0)),
      aiPeRatio: Number(profile.aiPeRatio || 0),
      aiGeneratedEPSMilli: Math.floor(Number(profile.aiGeneratedEPSMilli || 0)),
      aiIssueMode: profile.aiIssueMode || "capital_liquidity_ai",
      liquidityShareMultiplier: Number(profile.liquidityShareMultiplier || 1),
      economicShares: Math.floor(Number(profile.economicShares || 0)),
      marketSharesMode: profile.marketSharesMode || "liquidity_unit"
    };
  }

  function buildCompanyMetrics(profile) {
    var estimatedDividendPerShareMilli = Math.max(
      0,
      Math.floor(
        (Number(profile.profitMonthlyMilli || 0) * Number(profile.currentPayoutRatio || 0)) /
        Math.max(1, Number(profile.totalShares || 1))
      )
    );

    return {
      assetsMilli: Math.floor(profile.assetsMilli),
      revenueMonthlyMilli: Math.floor(profile.revenueMonthlyMilli),
      profitMonthlyMilli: Math.floor(profile.profitMonthlyMilli),

      basePayoutRatio: Number(profile.basePayoutRatio),
      currentPayoutRatio: Number(profile.currentPayoutRatio),

      epsMilli: Math.max(1, Math.floor(Number(profile.aiGeneratedEPSMilli || estimatedDividendPerShareMilli || 1))),
      estimatedDividendPerShareMilli: Math.max(
        0,
        Math.floor(
          Math.max(1, Number(profile.aiGeneratedEPSMilli || estimatedDividendPerShareMilli || 1)) *
          Number(profile.currentPayoutRatio || 0)
        )
      ),
      lastDividendPerShareMilli: 0,

      latestDailyVolume: Math.floor(profile.availableShares * randRange(0.06, 0.18)),
      avgVolume5: Math.floor(profile.availableShares * randRange(0.05, 0.15)),
      avgVolume30: Math.floor(profile.availableShares * randRange(0.04, 0.12))
    };
  }


  function ensureGeneratedCompanyInfo(asset) {
    if (!asset) return;
    if (!asset.companyInfo || typeof asset.companyInfo !== "object") asset.companyInfo = {};
    if (!asset.companyMetrics || typeof asset.companyMetrics !== "object") asset.companyMetrics = {};

    var info = asset.companyInfo;
    var metrics = asset.companyMetrics;
    var fallbackPayout = clamp(Number(metrics.currentPayoutRatio || metrics.basePayoutRatio || info.payoutRatio || 0.2), 0.02, 0.75);

    if (typeof info.category === "undefined") info.category = asset.registryMeta && asset.registryMeta.industryLabel ? asset.registryMeta.industryLabel : "一般產業";
    if (typeof info.foundedYear !== "number") info.foundedYear = randInt(1975, 2022);
    if (typeof info.descriptionLong !== "string") info.descriptionLong = String(asset.desc || "新上市商會");
    if (typeof info.notes !== "string") info.notes = "董事會態度：" + String(asset.registryMeta && asset.registryMeta.boardLabel || "正常上市");
    if (typeof info.quality !== "number") info.quality = 0.55;
    if (typeof info.stability !== "number") info.stability = 0.55;
    if (typeof info.hype !== "number") info.hype = 0.30;
    if (!(Number(info.assetBaseMilli) > 0)) info.assetBaseMilli = Math.max(0, Math.floor(Number(metrics.assetsMilli || 0)));
    if (!(Number(info.revenueBaseMilli) > 0)) info.revenueBaseMilli = Math.max(0, Math.floor(Number(metrics.revenueMonthlyMilli || 0)));
    if (!(Number(info.profitBaseMilli) > 0)) info.profitBaseMilli = Math.max(0, Math.floor(Number(metrics.profitMonthlyMilli || 0)));

    if (!(Number(info.guildCapitalMilli) > 0)) info.guildCapitalMilli = Math.max(0, Math.floor(Number(asset.guildCapitalMilli || info.assetBaseMilli || metrics.assetsMilli || 0)));
    if (!(Number(info.guildCapitalBaseMilli) > 0)) info.guildCapitalBaseMilli = Math.max(0, Math.floor(Number(asset.guildCapitalBaseMilli || info.guildCapitalMilli || 0)));

    if (!info.guildCapitalTierLabel) {
      var capCoin = Number(info.guildCapitalMilli || 0) / ((w.StockMarketEngine && w.StockMarketEngine.SCALE) || 1000);
      var isRoyal = !!(asset.isRoyalEnterprise || asset.royalIndexEligible || asset.tier === "royal" || asset.stateOwned);
      if (isRoyal) {
        info.guildCapitalTierId = "sovereign";
        info.guildCapitalTierLabel = "王國最高級別";
        info.guildCapitalTierRank = 5;
      } else if (capCoin < 3000000) {
        info.guildCapitalTierId = "declining";
        info.guildCapitalTierLabel = "沒落商會";
        info.guildCapitalTierRank = 0;
      } else if (capCoin < 30000000) {
        info.guildCapitalTierId = "small_guild";
        info.guildCapitalTierLabel = "小型公會";
        info.guildCapitalTierRank = 1;
      } else if (capCoin < 100000000) {
        info.guildCapitalTierId = "medium_chamber";
        info.guildCapitalTierLabel = "中型商會";
        info.guildCapitalTierRank = 2;
      } else {
        info.guildCapitalTierId = "large_alliance";
        info.guildCapitalTierLabel = "大型商盟";
        info.guildCapitalTierRank = 3;
      }
    }

    asset.guildCapitalMilli = Math.floor(Number(info.guildCapitalMilli || 0));
    asset.guildCapitalBaseMilli = Math.floor(Number(info.guildCapitalBaseMilli || info.guildCapitalMilli || 0));
    asset.guildCapitalTierId = info.guildCapitalTierId;
    asset.guildCapitalTierLabel = info.guildCapitalTierLabel;
    asset.guildCapitalTierRank = info.guildCapitalTierRank;

    asset.aiIssueMode = asset.aiIssueMode || info.aiIssueMode || "capital_liquidity_ai";
    asset.aiParValueMilli = Math.floor(Number(asset.aiParValueMilli || info.aiParValueMilli || 0));
    asset.aiPeRatio = Number(asset.aiPeRatio || info.aiPeRatio || 0);
    asset.aiGeneratedEPSMilli = Math.floor(Number(asset.aiGeneratedEPSMilli || info.aiGeneratedEPSMilli || 0));
    asset.liquidityShareMultiplier = Number(asset.liquidityShareMultiplier || info.liquidityShareMultiplier || 1);
    asset.economicShares = Math.floor(Number(asset.economicShares || info.economicShares || 0));
    asset.marketSharesMode = asset.marketSharesMode || info.marketSharesMode || "liquidity_unit";
    if (!(Number(info.payoutRatio) > 0)) info.payoutRatio = fallbackPayout;

    if (!(Number(metrics.assetsMilli) > 0)) metrics.assetsMilli = Math.max(0, Math.floor(Number(info.assetBaseMilli || 0)));
    if (!(Number(metrics.revenueMonthlyMilli) > 0)) metrics.revenueMonthlyMilli = Math.max(0, Math.floor(Number(info.revenueBaseMilli || 0)));
    if (!(Number(metrics.profitMonthlyMilli) > 0)) metrics.profitMonthlyMilli = Math.max(0, Math.floor(Number(info.profitBaseMilli || 0)));
    if (!(Number(metrics.basePayoutRatio) > 0)) metrics.basePayoutRatio = clamp(Number(info.payoutRatio || fallbackPayout), 0.02, 0.75);
    if (!(Number(metrics.currentPayoutRatio) > 0)) metrics.currentPayoutRatio = clamp(Number(metrics.basePayoutRatio || info.payoutRatio || fallbackPayout), 0.02, 0.75);
    if (!(Number(metrics.epsMilli) > 0)) {
      metrics.epsMilli = Math.max(
        1,
        Math.floor(
          Number(asset.aiGeneratedEPSMilli || info.aiGeneratedEPSMilli || metrics.estimatedDividendPerShareMilli || 1)
        )
      );
    }
    if (typeof metrics.lastDividendPerShareMilli !== "number") metrics.lastDividendPerShareMilli = 0;
    if (typeof metrics.latestDailyVolume !== "number") metrics.latestDailyVolume = 0;
    if (typeof metrics.avgVolume5 !== "number") metrics.avgVolume5 = 0;
    if (typeof metrics.avgVolume30 !== "number") metrics.avgVolume30 = 0;
  }

  function completeGeneratedAsset(state, asset) {
    if (!asset) return asset;

    var anchor = Math.max(1, Math.floor(Number(
      asset.price || asset.basePrice || asset.meanPrice || asset.dayOpenPrice || asset.ipoPriceMilli || asset._lastFairValue || 1
    )));

    if (!(Number(asset.startPrice) > 0)) asset.startPrice = anchor;
    if (!(Number(asset.price) > 0)) asset.price = anchor;
    if (!(Number(asset.basePrice) > 0)) asset.basePrice = anchor;
    if (!(Number(asset.meanPrice) > 0)) asset.meanPrice = anchor;
    if (!(Number(asset.dayOpenPrice) > 0)) asset.dayOpenPrice = anchor;
    if (!(Number(asset.dayHighPrice) > 0)) asset.dayHighPrice = anchor;
    if (!(Number(asset.dayLowPrice) > 0)) asset.dayLowPrice = anchor;
    if (!(Number(asset.lastClosePrice) > 0)) asset.lastClosePrice = anchor;
    if (!(Number(asset.ipoPriceMilli) > 0)) asset.ipoPriceMilli = anchor;
    if (!(Number(asset._lastFairValue) > 0)) asset._lastFairValue = Math.max(anchor, Math.floor(Number(asset.basePrice || anchor)));

    if (typeof asset.baseTrend !== "number") asset.baseTrend = 0;
    if (!(Number(AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up) > 0)) AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up = 0.10;
    if (!(Number(AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down) > 0)) AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down = 0.10;
    if (typeof asset.lastChangeValue !== "number") asset.lastChangeValue = 0;
    if (typeof asset.lastChangePct !== "number") asset.lastChangePct = 0;
    if (typeof asset.limitLocked !== "boolean") asset.limitLocked = false;
    if (typeof asset.limitType === "undefined") asset.limitType = null;
    if (typeof asset.momentum !== "number") asset.momentum = 0;
    if (typeof asset._lastFlowRatio !== "number") asset._lastFlowRatio = 0;
    if (typeof asset._npcBuy !== "number") asset._npcBuy = 0;
    if (typeof asset._npcSell !== "number") asset._npcSell = 0;
    if (typeof asset.playerImpactBuy !== "number") asset.playerImpactBuy = 0;
    if (typeof asset.playerImpactSell !== "number") asset.playerImpactSell = 0;
    if (typeof asset.playerImpactDecay !== "number") asset.playerImpactDecay = 0.92;
    if (typeof asset.playerRecentNetFlow !== "number") asset.playerRecentNetFlow = 0;
    if (typeof asset._lastPlayerTradeImpact !== "number") asset._lastPlayerTradeImpact = 0;

    if (!asset.registryMeta || typeof asset.registryMeta !== "object") asset.registryMeta = {};
    ensureAssetSymbol(state, asset);
    if (typeof asset.registryMeta.createdDay !== "number") asset.registryMeta.createdDay = getCurrentMarketDay(state);
    if (!Array.isArray(asset.trendHistory)) asset.trendHistory = [];
    if (!Array.isArray(asset.volumeHistory)) asset.volumeHistory = [];

    ensureGeneratedCompanyInfo(asset);

    if (!(Number(asset.totalShares) > 0)) asset.totalShares = Math.max(1, Math.floor(Number(asset.floatShares || 1)));
    if (!(Number(asset.floatShares) > 0)) {
      asset.floatShares = Math.max(1, Math.floor(Number(asset.availableShares || 0) + Number(asset.insiderShares || 0) + Number(asset.strategicHoldingShares || 0) + Number(asset.marketMakerShares || 0)));
    }
    if (!(Number(asset.availableShares) >= 0)) asset.availableShares = 0;
    if (!(Number(asset.lockedShares) >= 0)) asset.lockedShares = Math.max(0, Math.floor(Number(asset.insiderShares || 0) + Number(asset.strategicHoldingShares || 0)));
    if (!(Number(asset.listingAgeDays) >= 0)) asset.listingAgeDays = 0;
    if (typeof asset.delistWarning !== "boolean") asset.delistWarning = false;
    if (typeof asset.delistRiskDays !== "number") asset.delistRiskDays = 0;
    if (typeof asset.delistReason !== "string") asset.delistReason = "";

    return normalizeListedAssetPrice(asset);
  }

  function buildAsset(state, opts) {
    var industryId = opts && opts.industryId ? opts.industryId : pickIndustryId();
    var tierId = opts && opts.tierId ? opts.tierId : pickTierId();
    var boardId = opts && opts.boardId ? opts.boardId : pickBoardId();

    var profile = TPL.buildBaseProfile(industryId, tierId, boardId);
    var nameInfo = NAME.createUniqueCompanyName(state, industryId);
    var assetId = NAME.createCompanyCode(state, industryId);

    var marketType = tierId === "starter" ? "starter" : "free";

    return {
      id: assetId,
      shortName: nameInfo.shortName,
      name: nameInfo.fullName,
      sectorCode: profile.sectorCode || "X",
      symbol: createNextStockSymbol(state, profile.sectorCode || "X"),
      unlocked: true,
      isDelisted: false,

      marketType: marketType,
      tier: tierId === "starter" ? "starter" : tierId,
      style: randInt(0, 1) === 0 ? "A" : "B",

      stateOwned: false,
      isCoreListed: false,
      delistProtected: false,
      allowAutoDelist: true,
      allowAutoReplace: true,

      desc: profile.industryLabel + "｜" + profile.boardLabel,
      risk: profile.risk,
      liquidity: Number(profile.liquidity.toFixed(3)),
      volatilityLevel: Number(profile.volatilityLevel.toFixed(3)),
      startPrice: Math.floor(profile.priceMilli),
      baseTrend: 0,
      limitUp: 0.10,
      limitDown: 0.10,

      price: Math.floor(profile.priceMilli),
      basePrice: Math.floor(profile.priceMilli),
      meanPrice: Math.floor(profile.priceMilli),
      _lastFairValue: Math.floor(profile.fairValueMilli),

      dayOpenPrice: Math.floor(profile.priceMilli),
      dayHighPrice: Math.floor(profile.priceMilli),
      dayLowPrice: Math.floor(profile.priceMilli),
      lastClosePrice: Math.floor(profile.priceMilli),
      lastChangeValue: 0,
      lastChangePct: 0,

      totalShares: Math.floor(profile.totalShares),
      floatShares: Math.floor(profile.floatShares),
      lockedShares: Math.floor(profile.lockedShares),
      insiderShares: Math.floor(profile.insiderShares),
      stateHoldingShares: Math.floor(profile.stateHoldingShares || 0),
      strategicHoldingShares: Math.floor(profile.strategicHoldingShares || 0),
      marketMakerShares: Math.floor(profile.marketMakerShares || 0),
      availableShares: Math.floor(profile.availableShares),

      _npcBuy: 0,
      _npcSell: 0,
      playerImpactBuy: 0,
      playerImpactSell: 0,
      playerImpactDecay: 0.92,
      playerRecentNetFlow: 0,
      _lastPlayerTradeImpact: 0,

      limitLocked: false,
      limitType: null,
      momentum: 0,
      _lastFlowRatio: 0,

      companyInfo: buildCompanyInfo(profile),
      companyMetrics: buildCompanyMetrics(profile),

      trendHistory: [],
      volumeHistory: [],

      listingAgeDays: 0,
      ipoPriceMilli: Math.floor(profile.priceMilli),
      aiIssueMode: profile.aiIssueMode || "capital_liquidity_ai",
      aiParValueMilli: Math.floor(Number(profile.aiParValueMilli || 0)),
      aiPeRatio: Number(profile.aiPeRatio || 0),
      aiGeneratedEPSMilli: Math.floor(Number(profile.aiGeneratedEPSMilli || 0)),
      liquidityShareMultiplier: Number(profile.liquidityShareMultiplier || 1),
      economicShares: Math.floor(Number(profile.economicShares || 0)),
      marketSharesMode: profile.marketSharesMode || "liquidity_unit",
      delistRiskDays: 0,
      delistWarning: false,
      delistReason: "",

      registryMeta: {
        industryId: profile.industryId,
        industryLabel: profile.industryLabel,
        tierId: profile.tierId,
        boardId: profile.boardId,
        boardLabel: profile.boardLabel,
        createdDay: getCurrentMarketDay(state)
      }
    };
  }

  function registerAsset(state, asset) {
    if (!state.assets) state.assets = {};
    state.assets[asset.id] = asset;
    return asset;
  }

  function normalizeListedAssetPrice(asset) {
    if (!asset) return asset;
    var anchor = Math.max(
      1,
      Math.floor(Number(
        asset.price || asset.basePrice || asset.meanPrice || asset.ipoPriceMilli || asset._lastFairValue || 0
      ))
    );

    asset.price = Math.max(1, Math.floor(Number(asset.price || anchor)));
    asset.basePrice = Math.max(1, Math.floor(Number(asset.basePrice || asset.price || anchor)));
    asset.meanPrice = Math.max(1, Math.floor(Number(asset.meanPrice || asset.price || asset.basePrice || anchor)));
    asset.dayOpenPrice = Math.max(1, Math.floor(Number(asset.dayOpenPrice || asset.price || anchor)));
    asset.dayHighPrice = Math.max(asset.dayOpenPrice, Math.floor(Number(asset.dayHighPrice || asset.price || anchor)));
    asset.dayLowPrice = Math.max(1, Math.min(asset.dayOpenPrice, Math.floor(Number(asset.dayLowPrice || asset.price || anchor))));
    asset.lastClosePrice = Math.max(1, Math.floor(Number(asset.lastClosePrice || asset.dayOpenPrice || anchor)));
    asset.ipoPriceMilli = Math.max(1, Math.floor(Number(asset.ipoPriceMilli || asset.dayOpenPrice || anchor)));
    asset._lastFairValue = Math.max(1, Math.floor(Number(asset._lastFairValue || asset.basePrice || asset.price || anchor)));
    return asset;
  }

  function listNewCompany(state, prepared) {

    ensureRegistryState(state);

    var asset = completeGeneratedAsset(state, prepared || buildAsset(state, null));
    registerAsset(state, asset);

    var day = getCurrentMarketDay(state);
    var reg = ensureRegistryState(state);

    reg.listedToday += 1;
    reg.lastListedDay = day;

    pushListedHistory(state, {
      id: asset.id,
      name: asset.name,
      shortName: asset.shortName,
      symbol: asset.symbol,
      marketDay: day,
      priceMilli: asset.price,
      tier: asset.tier,
      industryId: asset.registryMeta.industryId,
      industryLabel: asset.registryMeta.industryLabel,
      boardLabel: asset.registryMeta.boardLabel
    });

    return asset;
  }

  function getPendingListingCount(state) {
    var reg = ensureRegistryState(state);
    return Math.max(0, Number(reg.pendingListings.length || 0));
  }

  function buildIpoHeatProfile(asset, etaDays) {
    var meta = asset && asset.registryMeta ? asset.registryMeta : {};
    var info = asset && asset.companyInfo ? asset.companyInfo : {};
    var quality = clamp(Number(info.quality || 0.5), 0, 1);
    var stability = clamp(Number(info.stability || 0.5), 0, 1);
    var hype = clamp(Number(info.hype || 0.2), 0, 1);

    var tierBoost = asset.tier === "large" ? 0.22 : (asset.tier === "small" ? 0.12 : 0.16);
    var boardBoost = /成長|新創|科技|創新/.test(String(meta.boardLabel || "")) ? 0.08 : 0.03;
    var urgency = clamp((3 - Number(etaDays || 0)) / 3, 0, 1);

    var score = clamp(quality * 0.30 + stability * 0.10 + hype * 0.38 + tierBoost + boardBoost + urgency * 0.10 + Math.random() * 0.08, 0.10, 0.98);
    var label = score >= 0.82 ? "市場焦點" : (score >= 0.62 ? "熱門申請" : (score >= 0.42 ? "穩定關注" : "一般申請"));
    return { score: Number(score.toFixed(3)), label: label };
  }

  function createPendingListing(state, options) {
    var reg = ensureRegistryState(state);
    if (reg.pendingListings.length >= reg.maxPendingListings) return null;

    var asset = buildAsset(state, null);
    var today = getCurrentMarketDay(state);
    var opts = options || {};
    var etaDays = Math.max(1, Math.floor(Number(opts.etaDays || randInt(1, 3))));
    var heat = buildIpoHeatProfile(asset, etaDays);

    asset = completeGeneratedAsset(state, asset);

    var pending = {
      id: asset.id,
      asset: asset,
      symbol: asset.symbol,
      sectorCode: asset.sectorCode,
      createdDay: today,
      etaDays: etaDays,
      priceLowMilli: Math.floor(asset.price * 0.94),
      priceHighMilli: Math.floor(asset.price * 1.08),
      ipoHeatScore: heat.score,
      ipoHeatLabel: heat.label,
      refillGuaranteed: !!opts.refillGuaranteed
    };

    reg.pendingListings.push(pending);
    return pending;
  }

  function processPendingListings(state) {
    var reg = ensureRegistryState(state);
    if (!reg.pendingListings.length) return null;

    var listedAsset = null;
    var remain = [];

    for (var i = 0; i < reg.pendingListings.length; i++) {
      var p = reg.pendingListings[i];
      p.etaDays = Math.max(0, Number(p.etaDays || 0) - 1);

      if (!listedAsset && p.etaDays <= 0 && canListToday(state)) {
        listedAsset = listNewCompany(state, p.asset);
      } else {
        remain.push(p);
      }
    }

    reg.pendingListings = remain;
    return listedAsset;
  }


  function shouldCreateRefillListing(state) {
    var reg = ensureRegistryState(state);
    var today = getCurrentMarketDay(state);
    var active = getActiveAssetCount(state);

    if (active >= reg.minActiveCompanies) return false;
    if (getPendingListingCount(state) > 0) return false;
    if (active >= reg.maxActiveCompanies) return false;
    if (!reg.lastRefillCheckDay) return true;

    return (today - reg.lastRefillCheckDay) >= Math.max(1, Number(reg.refillCheckIntervalDays || 2));
  }

  function createRefillPendingListing(state) {
    var reg = ensureRegistryState(state);
    if (!shouldCreateRefillListing(state)) return null;

    reg.lastRefillCheckDay = getCurrentMarketDay(state);
    return createPendingListing(state, {
      etaDays: randInt(1, 2),
      refillGuaranteed: true
    });
  }

  function getUpcomingIpoEffectForAsset(state, assetId) {
    var reg = ensureRegistryState(state);
    var asset = state && state.assets ? state.assets[assetId] : null;
    var out = {
      bias: 0,
      volatilityBonus: 0,
      meta: {
        liquidityShift: 0,
        npcPanicSellBoost: 0,
        npcFomoBuyBoost: 0,
        strategicHoldingReleaseBoost: 0,
        npcAbsorbBoost: 0,
        shortPressureBoost: 0,
        confidenceImpact: 0,
        revenueAdjust: 0,
        profitAdjust: 0,
        payoutAdjust: 0
      }
    };

    if (!asset || !asset.unlocked || asset.isDelisted) return out;

    var assetIndustry = asset.registryMeta && asset.registryMeta.industryId;

    for (var i = 0; i < reg.pendingListings.length; i++) {
      var p = reg.pendingListings[i];
      if (!p || !p.asset) continue;

      var heat = clamp(Number(p.ipoHeatScore || 0.35), 0, 1);
      var eta = Math.max(0, Number(p.etaDays || 0));
      var urgency = clamp((3 - eta) / 3, 0, 1);
      var pulse = heat * (0.45 + urgency * 0.85);
      var sameIndustry = !!(assetIndustry && p.asset.registryMeta && p.asset.registryMeta.industryId === assetIndustry);

      if (sameIndustry) {
        out.bias += 0.003 + pulse * 0.012;
        out.volatilityBonus += 0.0006 + pulse * 0.0028;
        out.meta.npcFomoBuyBoost += 0.06 + pulse * 0.42;
        out.meta.npcAbsorbBoost += 0.04 + pulse * 0.20;
        out.meta.confidenceImpact += 0.05 + pulse * 0.24;
        out.meta.liquidityShift += 0.01 + pulse * 0.08;
      } else {
        out.bias += pulse * 0.0018;
        out.volatilityBonus += pulse * 0.0005;
        out.meta.confidenceImpact += pulse * 0.035;
        if (asset.tier === "small" && heat >= 0.72 && eta <= 1) {
          out.meta.liquidityShift -= pulse * 0.035;
        } else {
          out.meta.liquidityShift += pulse * 0.010;
        }
      }
    }

    out.bias = clamp(out.bias, -0.03, 0.03);
    out.volatilityBonus = clamp(out.volatilityBonus, 0, 0.010);
    out.meta.liquidityShift = clamp(out.meta.liquidityShift, -0.12, 0.16);
    out.meta.npcFomoBuyBoost = clamp(out.meta.npcFomoBuyBoost, 0, 0.85);
    out.meta.npcAbsorbBoost = clamp(out.meta.npcAbsorbBoost, 0, 0.50);
    out.meta.confidenceImpact = clamp(out.meta.confidenceImpact, -0.18, 0.35);
    return out;
  }

  function processAutoListing(state) {
    ensureRegistryState(state);

    var listedFromQueue = processPendingListings(state);
    if (listedFromQueue) return listedFromQueue;

    var reg = ensureRegistryState(state);
    if (getActiveAssetCount(state) >= reg.maxActiveCompanies) return null;

    var refillPending = createRefillPendingListing(state);
    if (refillPending) return null;

    if (reg.pendingListings.length >= reg.maxPendingListings) return null;

    var chance = getListingChance(state);
    if (Math.random() > chance) return null;

    createPendingListing(state);
    return null;
  }

  function isDelistProtected(state, asset) {
    var reg = ensureRegistryState(state);
    var active = getActiveAssetCount(state);

    if (asset && asset.delistProtected) return true;
    if (asset && asset.isCoreListed) return true;
    if (asset && asset.allowAutoDelist === false) return true;

    if (active <= reg.minActiveCompanies) return true;

    var age = Number(asset && asset.listingAgeDays || 0);
    if (age < 7) return true;

    return false;
  }

  function evaluateDelistRisk(asset) {
    var metrics = asset.companyMetrics || {};
    var reasons = [];
    var score = 0;

    var price = Number(asset.price || 0);
    var fair = Number(asset._lastFairValue || 0);
    var available = Number(asset.availableShares || 0);
    var liquidity = Number(asset.liquidity || 1);
    var profit = Number(metrics.profitMonthlyMilli || 0);
    var assets = Number(metrics.assetsMilli || 0);

    if (profit < 0) {
      score += 1.4;
      reasons.push("連續虧損");
    }
    if (price < 3000) {
      score += 1.8;
      reasons.push("股價過低");
    }
    if (fair > 0 && price < fair * 0.35) {
      score += 1.0;
      reasons.push("估值崩壞");
    }
    if (available < Math.max(2000, asset.totalShares * 0.01)) {
      score += 0.8;
      reasons.push("市場流通不足");
    }
    if (liquidity < 0.72) {
      score += 0.8;
      reasons.push("流動性過低");
    }
    if (assets > 0 && profit < -(assets * 0.01)) {
      score += 0.8;
      reasons.push("資產承壓");
    }

    return {
      score: score,
      reasons: reasons,
      isWarning: score >= 1.8
    };
  }

  function settleDelistedHolding(state, asset, severity) {
    var holding = getPortfolioHolding(state, asset.id);
    var qty = holding.qty;

    if (qty <= 0) {
      return {
        qty: 0,
        settlePriceMilli: 0,
        playerReceivedMilli: 0,
        severity: severity
      };
    }

    var basePrice = Number(asset.price || 0);
    var settleFactor = 0.55;

    if (severity === "bankrupt") settleFactor = randRange(0.12, 0.28);
    else if (severity === "private") settleFactor = randRange(0.90, 1.08);
    else settleFactor = randRange(0.40, 0.70);

    var settlePriceMilli = Math.max(1, Math.floor(basePrice * settleFactor));
    var playerReceivedMilli = Math.floor(settlePriceMilli * qty);

    addInvestmentCoinMilli(state, playerReceivedMilli);
    clearPortfolioHolding(state, asset.id);

    return {
      qty: qty,
      settlePriceMilli: settlePriceMilli,
      playerReceivedMilli: playerReceivedMilli,
      severity: severity
    };
  }

  function delistCompany(state, assetId, reasonText, severity) {
    ensureRegistryState(state);

    if (!state.assets || !state.assets[assetId]) return null;

    var asset = state.assets[assetId];
    if (!isActiveAsset(asset)) return null;
    if (isDelistProtected(state, asset)) return null;

    var day = getCurrentMarketDay(state);
    var reg = ensureRegistryState(state);

    var finalSeverity = severity || "weakness";
    var settlement = settleDelistedHolding(state, asset, finalSeverity);

    asset.isDelisted = true;
    asset.unlocked = false;
    asset.delistReason = reasonText || "下市";
    asset.delistWarning = false;

    reg.delistedToday += 1;
    reg.lastDelistedDay = day;

    var record = {
      id: asset.id,
      name: asset.name,
      shortName: asset.shortName,
      marketDay: day,
      reason: reasonText || "下市",
      severity: finalSeverity,
      settlePriceMilli: settlement.settlePriceMilli,
      playerQty: settlement.qty,
      playerReceivedMilli: settlement.playerReceivedMilli
    };

    pushDelistedHistory(state, record);
    return record;
  }

  function processAutoDelisting(state) {
    ensureRegistryState(state);

    if (!canDelistToday(state)) return null;

    var ids = getActiveAssetIds(state);
    if (!ids.length) return null;

    var candidates = [];
    for (var i = 0; i < ids.length; i++) {
      var asset = state.assets[ids[i]];
      if (!asset) continue;

      if (isDelistProtected(state, asset)) {
        asset.delistRiskDays = 0;
        asset.delistWarning = false;
        asset.delistReason = "";
        continue;
      }

      var risk = evaluateDelistRisk(asset);

      if (!risk.isWarning) {
        asset.delistRiskDays = 0;
        asset.delistWarning = false;
        continue;
      }

      asset.delistWarning = true;
      asset.delistRiskDays = Math.max(0, Number(asset.delistRiskDays || 0)) + 1;

      candidates.push({
        asset: asset,
        score: risk.score,
        reasons: risk.reasons,
        riskDays: asset.delistRiskDays
      });
    }

    if (!candidates.length) return null;

    candidates.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return b.riskDays - a.riskDays;
    });

    var top = candidates[0];

    if (top.score < 3.0 || top.riskDays < 4) return null;

    var severity = "weakness";
    if (top.score >= 4.5) severity = "bankrupt";

    return delistCompany(
      state,
      top.asset.id,
      top.reasons.join("、") || "經營惡化",
      severity
    );
  }

  function processDailyLifecycle(state) {
    ensureRegistryState(state);

    var ids = getActiveAssetIds(state);
    for (var i = 0; i < ids.length; i++) {
      var asset = state.assets[ids[i]];
      if (!asset) continue;
      asset.listingAgeDays = Math.max(0, Number(asset.listingAgeDays || 0)) + 1;
    }

    var listed = processAutoListing(state);
    var delisted = processAutoDelisting(state);

    return {
      listing: listed,
      delisting: delisted
    };
  }

  function maybeIpo(state) {
    ensureRegistryState(state);
    return processAutoListing(state);
  }

  function maybeDelist(state) {
    ensureRegistryState(state);
    return processAutoDelisting(state);
  }

  function getPendingListings(state) {
    var reg = ensureRegistryState(state);
    var out = [];

    for (var i = 0; i < reg.pendingListings.length; i++) {
      var p = reg.pendingListings[i];
      if (!p || !p.asset) continue;

      out.push({
        id: p.id,
        name: p.asset.name,
        shortName: p.asset.shortName,
        etaDays: Number(p.etaDays || 0),
        tier: p.asset.tier,
        marketType: p.asset.marketType,
        industryId: p.asset.registryMeta && p.asset.registryMeta.industryId,
        industryLabel: p.asset.registryMeta && p.asset.registryMeta.industryLabel,
        boardLabel: p.asset.registryMeta && p.asset.registryMeta.boardLabel,
        priceLowMilli: Number(p.priceLowMilli || 0),
        priceHighMilli: Number(p.priceHighMilli || 0),
        ipoHeatScore: Number(p.ipoHeatScore || 0),
        ipoHeatLabel: String(p.ipoHeatLabel || "一般申請"),
        refillGuaranteed: !!p.refillGuaranteed
      });
    }

    out.sort(function (a, b) {
      return a.etaDays - b.etaDays;
    });

    return out;
  }

  function getDelistWarnings(state) {
    var ids = getActiveAssetIds(state);
    var out = [];

    for (var i = 0; i < ids.length; i++) {
      var asset = state.assets[ids[i]];
      if (!asset || !asset.delistWarning) continue;
      if (asset.delistProtected || asset.isCoreListed || asset.allowAutoDelist === false) continue;

      var risk = evaluateDelistRisk(asset);
      var holding = getPortfolioHolding(state, asset.id);

      out.push({
        id: asset.id,
        name: asset.name,
        shortName: asset.shortName,
        reasonText: risk.reasons.join("、") || "經營風險升高",
        riskScore: Number(risk.score || 0),
        riskDays: Number(asset.delistRiskDays || 0),
        priceMilli: Number(asset.price || 0),
        fairValueMilli: Number(asset._lastFairValue || 0),
        playerQty: Number(holding.qty || 0),
        tier: asset.tier,
        industryId: asset.registryMeta && asset.registryMeta.industryId,
        industryLabel: asset.registryMeta && asset.registryMeta.industryLabel
      });
    }

    out.sort(function (a, b) {
      if (b.riskDays !== a.riskDays) return b.riskDays - a.riskDays;
      return b.riskScore - a.riskScore;
    });

    return out;
  }

  function getRegistrySummary(state) {
    var reg = ensureRegistryState(state);

    return {
      activeCompanyCount: getActiveAssetCount(state),
      maxActiveCompanies: reg.maxActiveCompanies,
      softMaxActiveCompanies: reg.softMaxActiveCompanies,
      minActiveCompanies: reg.minActiveCompanies,
      listedToday: reg.listedToday,
      delistedToday: reg.delistedToday,
      listedHistory: reg.listedHistory.slice(),
      delistedHistory: reg.delistedHistory.slice(),
      upcomingCount: reg.pendingListings.length
    };
  }

  w.StockMarketRegistry = {
    ensureRegistryState: ensureRegistryState,
    ensureRegistry: ensureRegistry,

    getActiveAssetCount: getActiveAssetCount,
    getActiveAssetIds: getActiveAssetIds,
    getRegistrySummary: getRegistrySummary,
    getPendingListings: getPendingListings,
    getPendingListingCount: getPendingListingCount,
    getDelistWarnings: getDelistWarnings,
    getUpcomingIpoEffectForAsset: getUpcomingIpoEffectForAsset,

    buildAsset: buildAsset,
    registerAsset: registerAsset,
    completeGeneratedAsset: completeGeneratedAsset,
    ensureAssetSymbol: ensureAssetSymbol,
    listNewCompany: listNewCompany,
    delistCompany: delistCompany,

    processAutoListing: processAutoListing,
    processAutoDelisting: processAutoDelisting,
    processDailyLifecycle: processDailyLifecycle,

    maybeIpo: maybeIpo,
    maybeDelist: maybeDelist
  };
})(window);