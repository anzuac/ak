
(function (w) {
  "use strict";

  if (
    !w.StockHub ||
    !w.StockStateManager ||
    !w.StockMarketEngine ||
    !w.StockMarketCurrency
  ) {
    console.error("❌ stock_finance_tab.js: 缺少依賴");
    return;
  }

  var SCALE = w.StockMarketEngine.SCALE || 1000;
  var TAB_ID = "finance";

  var CURRENCY_CONFIG = {
    gold: {
      key: "王國金幣",
      icon: "🟡",
      rate: 100
    },
    silver: {
      key: "王國銀幣",
      icon: "⚪",
      rate: 10
    },
    copper: {
      key: "王國銅幣",
      icon: "🟠",
      rate: 1
    }
  };

  var activeCurrency = "gold";

  function fmtCoinMilli(v) {
    return (Number(v || 0) / SCALE).toFixed(3);
  }

  function fmtNum(v) {
    return Math.floor(Number(v || 0)).toLocaleString();
  }

  function getBody() {
    var body = document.getElementById("stockHubBody");
    if (!body) return null;
    if (String(body.getAttribute("data-tab-owner") || "") !== TAB_ID) return null;
    return body;
  }

  function getInventoryAmount(name) {
    if (typeof w.getItemQuantity === "function") {
      return Math.floor(Number(w.getItemQuantity(name) || 0));
    }
    return 0;
  }

  function removeInventoryItem(name, amount) {
    if (typeof w.removeItem === "function") {
      w.removeItem(name, amount);
      return true;
    }
    return false;
  }

  function getCurrentConfig() {
    return CURRENCY_CONFIG[activeCurrency] || CURRENCY_CONFIG.gold;
  }

  function getExchangeInputCoins() {
    var el = document.querySelector('input[data-bind="finance-exchange-custom"]');
    var v = Number(el && el.value || 0);
    return Math.max(0, Math.floor(v));
  }

  function setExchangeInputCoins(amount) {
    var el = document.querySelector('input[data-bind="finance-exchange-custom"]');
    if (el) {
      el.value = String(Math.max(0, Math.floor(Number(amount || 0))));
    }
    updateFinancePreview();
  }

  function getQuickExchangeOptions() {
    return [1, 5, 10, 50, 100];
  }

  function addInvestCurrency(state, milli) {
    milli = Math.max(0, Math.floor(Number(milli || 0)));

    if (w.StockMarketCurrency && typeof w.StockMarketCurrency.addMilli === "function") {
      w.StockMarketCurrency.addMilli(state, milli);
    } else {
      if (!state.currency) state.currency = {};
      if (!state.currency.milli) state.currency.milli = 0;
      state.currency.milli += milli;
    }

    if (!state.currency) state.currency = {};
    if (!state.currency.stats) state.currency.stats = {};

    state.currency.stats.fromGoldMilli = (state.currency.stats.fromGoldMilli || 0) + milli;
    state.currency.stats.earnedMilli = (state.currency.stats.earnedMilli || 0) + milli;
  }

  function exchangeCurrency(coinAmount) {
    var state = w.StockStateManager.getState();
    coinAmount = Math.max(1, Math.floor(Number(coinAmount || 0)));

    var cfg = getCurrentConfig();
    var gainMilli = coinAmount * cfg.rate * SCALE;

    if (getInventoryAmount(cfg.key) < coinAmount) {
      alert(cfg.key + " 不足");
      return;
    }

    removeInventoryItem(cfg.key, coinAmount);
    addInvestCurrency(state, gainMilli);

    w.StockStateManager.save();
    render(getBody());
  }

  function updateFinancePreview() {
    var body = getBody();
    if (!body) return;

    var cfg = getCurrentConfig();
    var coinAmount = getExchangeInputCoins();
    var gainMilli = coinAmount * cfg.rate * SCALE;

    var needEl = body.querySelector("#stockFinanceExchangeNeed");
    if (needEl) {
      needEl.textContent = fmtCoinMilli(gainMilli) + " 投資幣";
    }

    var tabInfo = body.querySelector("#stockFinanceTabInfo");
    if (tabInfo) {
      tabInfo.textContent = "1 " + cfg.key + " = " + cfg.rate + " 投資幣";
    }
  }

  function switchCurrency(type) {
    activeCurrency = type;
    render(getBody());
  }

  function bindActions(body, state) {
    ["gold", "silver", "copper"].forEach(function (type) {
      var btn = body.querySelector('[data-currency-tab="' + type + '"]');
      if (!btn) return;

      btn.onclick = function () {
        switchCurrency(type);
      };
    });

    var quickRow = body.querySelector("#stockFinanceQuickRow");
    if (quickRow) {
      quickRow.innerHTML = "";

      getQuickExchangeOptions().forEach(function (coinAmount) {
        var btn = document.createElement("button");
        btn.textContent = "+" + coinAmount + " 枚";
        btn.style.cssText = "background:#111827;color:#fff;border:1px solid #334155;border-radius:10px;padding:8px 10px;cursor:pointer;font-weight:700;";
        btn.onclick = function () {
          setExchangeInputCoins(getExchangeInputCoins() + coinAmount);
        };
        quickRow.appendChild(btn);
      });

      var allBtn = document.createElement("button");
      allBtn.textContent = "全部可換";
      allBtn.style.cssText = "background:#2563eb;color:#fff;border:0;border-radius:10px;padding:8px 10px;font-weight:800;";
      allBtn.onclick = function () {
        var cfg = getCurrentConfig();
        setExchangeInputCoins(getInventoryAmount(cfg.key));
      };
      quickRow.appendChild(allBtn);

      var clearBtn = document.createElement("button");
      clearBtn.textContent = "清空";
      clearBtn.style.cssText = "background:#7f1d1d;color:#fff;border:0;border-radius:10px;padding:8px 10px;font-weight:800;";
      clearBtn.onclick = function () {
        setExchangeInputCoins(0);
      };
      quickRow.appendChild(clearBtn);
    }

    var input = body.querySelector('input[data-bind="finance-exchange-custom"]');
    if (input) {
      input.oninput = updateFinancePreview;
      input.onchange = updateFinancePreview;
    }

    var submit = body.querySelector("#stockFinanceExchangeSubmit");
    if (submit) {
      submit.onclick = function () {
        var coinAmount = getExchangeInputCoins();

        if (coinAmount <= 0) {
          alert("請輸入大於 0 的硬幣數量");
          return;
        }

        exchangeCurrency(coinAmount);
      };
    }

    updateFinancePreview();
  }

  function render(body) {
    if (!body) return;

    w.StockStateManager.settleAndSave();

    var state = w.StockStateManager.getState();
    var investMilli = w.StockMarketCurrency.getMilli(state);
    var cfg = getCurrentConfig();

    var goldCount = getInventoryAmount(CURRENCY_CONFIG.gold.key);
    var silverCount = getInventoryAmount(CURRENCY_CONFIG.silver.key);
    var copperCount = getInventoryAmount(CURRENCY_CONFIG.copper.key);

    body.innerHTML =
      '<div style="display:flex;flex-direction:column;gap:10px;width:100%;max-width:100%;overflow-x:hidden;padding-bottom:8px;">' +

        '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;">' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:clamp(10px,2vw,14px);min-width:0;">' +
            '<div style="font-size:14px;opacity:.8;">🪙 投資幣</div>' +
            '<div style="font-size:16px;font-weight:900;color:#facc15;">' + fmtCoinMilli(investMilli) + '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:clamp(10px,2vw,14px);min-width:0;">' +
            '<div style="font-size:14px;opacity:.8;">🟡 王國金幣</div>' +
            '<div style="font-size:16px;font-weight:900;">' + fmtNum(goldCount) + '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:clamp(10px,2vw,14px);min-width:0;">' +
            '<div style="font-size:14px;opacity:.8;">⚪ 王國銀幣</div>' +
            '<div style="font-size:16px;font-weight:900;">' + fmtNum(silverCount) + '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:clamp(10px,2vw,14px);min-width:0;">' +
            '<div style="font-size:14px;opacity:.8;">🟠 王國銅幣</div>' +
            '<div style="font-size:16px;font-weight:900;">' + fmtNum(copperCount) + '</div>' +
          '</div>' +

        '</div>' +

        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:8px;">' +

          '<div style="font-size:16px;font-weight:900;margin-bottom:12px;">👑 王國貨幣兌換</div>' +

          '<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:14px;">' +

            '<button data-currency-tab="gold" style="background:' + (activeCurrency === "gold" ? '#d4a017' : '#1f2937') + ';color:#fff;border:0;border-radius:10px;padding:9px;font-weight:900;">王國金幣</button>' +

            '<button data-currency-tab="silver" style="background:' + (activeCurrency === "silver" ? '#9ca3af' : '#1f2937') + ';color:#fff;border:0;border-radius:10px;padding:9px;font-weight:900;">王國銀幣</button>' +

            '<button data-currency-tab="copper" style="background:' + (activeCurrency === "copper" ? '#b45309' : '#1f2937') + ';color:#fff;border:0;border-radius:10px;padding:9px;font-weight:900;">王國銅幣</button>' +

          '</div>' +

          '<div id="stockFinanceTabInfo" style="font-size:13px;opacity:.82;margin-bottom:12px;">1 ' + cfg.key + ' = ' + cfg.rate + ' 投資幣</div>' +

          '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;align-items:end;">' +

            '<div>' +
              '<div style="font-size:12px;opacity:.8;margin-bottom:6px;">輸入兌換硬幣數量</div>' +
              '<input data-bind="finance-exchange-custom" type="number" min="0" step="1" value="1" style="width:100%;background:#111827;color:#fff;border:1px solid #334155;border-radius:10px;padding:8px;box-sizing:border-box;">' +
            '</div>' +

            '<div>' +
              '<div style="font-size:12px;opacity:.8;margin-bottom:6px;">可獲得投資幣</div>' +
              '<div id="stockFinanceExchangeNeed" style="background:#111827;border:1px solid #334155;border-radius:10px;padding:8px;">-</div>' +
            '</div>' +

            '<div>' +
              '<button id="stockFinanceExchangeSubmit" style="width:100%;background:#2563eb;color:#fff;border:0;border-radius:10px;padding:8px;font-weight:900;cursor:pointer;">確認兌換</button>' +
            '</div>' +

          '</div>' +

          '<div id="stockFinanceQuickRow" style="margin-top:10px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;"></div>' +

        '</div>' +

        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:8px;">' +

          '<div style="font-size:16px;font-weight:900;margin-bottom:10px;">📑 帳務資訊</div>' +

          '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;">' +

            '<div style="background:#111827;border-radius:12px;padding:8px;">' +
              '<div style="font-size:12px;opacity:.72;">累計獲得投資幣</div>' +
              '<div style="font-size:16px;font-weight:900;">' + fmtCoinMilli((state.currency && state.currency.stats && state.currency.stats.earnedMilli) || 0) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border-radius:12px;padding:8px;">' +
              '<div style="font-size:12px;opacity:.72;">累計支出投資幣</div>' +
              '<div style="font-size:16px;font-weight:900;">' + fmtCoinMilli((state.currency && state.currency.stats && state.currency.stats.spentMilli) || 0) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border-radius:12px;padding:8px;">' +
              '<div style="font-size:12px;opacity:.72;">股票交易手續費</div>' +
              '<div style="font-size:16px;font-weight:900;color:#f87171;">0.15%</div>' +
            '</div>' +

          '</div>' +

        '</div>' +

      '</div>';

    bindActions(body, state);
  }

  function update() {}

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "資金管理",
    render: render,
    update: update,
    noAutoRerender: true
  });

})(window);
