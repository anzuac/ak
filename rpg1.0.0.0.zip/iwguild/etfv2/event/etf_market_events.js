// etf_market_events.js
(function(w){
  "use strict";

  function ensureEventState(state){
    if(!state.etfEventState){
      state.etfEventState = {
        sentiment: 0,
        greed: 0,
        panic: 0,
        currentTheme: null,
        activeEvents: [],
        lastEventDay: 0
      };
    }
    return state.etfEventState;
  }

  var POSITIVE = [
    {
      id:"ai_boom",
      title:"AI ETF 熱潮升溫，科技型 ETF 出現大量資金流入。",
      theme:"AI",
      sentiment:15,
      popularity:8
    },
    {
      id:"dividend_hot",
      title:"高股利 ETF 熱賣，穩健型資金持續進場。",
      theme:"DIVIDEND",
      sentiment:10,
      popularity:6
    },
    {
      id:"foreign_buy",
      title:"外資開始加碼 ETF 市場，大型 ETF 交易熱度上升。",
      theme:"LARGE_CAP",
      sentiment:18,
      popularity:10
    }
  ];

  var NEGATIVE = [
    {
      id:"panic_redeem",
      title:"市場避險情緒升高，ETF 出現少量 NPC 贖回。",
      sentiment:-15,
      popularity:-5
    },
    {
      id:"liquidity_risk",
      title:"ETF 流動性下降，部分資金開始撤離。",
      sentiment:-20,
      popularity:-8
    },
    {
      id:"market_crash",
      title:"市場震盪加劇，ETF 市場出現恐慌賣壓。",
      sentiment:-30,
      popularity:-12
    }
  ];

  function pushEventAnnouncement(fund, text, marketDay){
    if(typeof w.pushAnnouncement === "function"){
      w.pushAnnouncement(
        fund,
        "market_event",
        text,
        marketDay || 1
      );
    }else{
      console.log("[ETF事件]", text);
    }
  }

  function getMarketSentiment(state){
    return Number(
      (((state||{}).climate||{}).sentiment) || 50
    );
  }

  function pickEvent(state){

    var sentiment = getMarketSentiment(state);

    var positiveBias = sentiment >= 50;

    var pool =
      positiveBias
      ? POSITIVE
      : NEGATIVE;

    return pool[
      Math.floor(Math.random() * pool.length)
    ];
  }

  function applyETFMarketEvent(state, fund, marketDay){

    if(!fund) return null;

    var eventState = ensureEventState(state);

    var event = pickEvent(state);

    if(!event) return null;

    fund.popularity =
      Number(fund.popularity || 0) +
      Number(event.popularity || 0);

    fund.marketHeat =
      Number(fund.marketHeat || 0) +
      Number(event.sentiment || 0);

    eventState.sentiment += Number(event.sentiment || 0);

    eventState.currentTheme =
      event.theme || null;

    eventState.lastEventDay = marketDay || 1;

    eventState.activeEvents.unshift({
      id:event.id,
      title:event.title,
      day:marketDay || 1
    });

    if(eventState.activeEvents.length > 20){
      eventState.activeEvents.length = 20;
    }

    pushEventAnnouncement(
      fund,
      event.title,
      marketDay
    );

    return event;
  }

  w.ETFMarketEvents = {
    ensureEventState: ensureEventState,
    applyETFMarketEvent: applyETFMarketEvent
  };

})(window);
