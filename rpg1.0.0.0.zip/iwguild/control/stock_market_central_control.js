// =====================================================
// AI5.4.3 Central Market Control System
// -----------------------------------------------------
// 單一市場控制核心：時間、費率、價格底線、漲跌停限制。
// 0 = Unlimited，不再由各子系統各自寫死限制。
// =====================================================
(function(w){
  "use strict";

  var C = w.AI5_MARKET_CONTROL_CONFIG || {};

  var config = {
    TICK_SEC: Number(C.TICK_SEC || 1),
    TICK_RATE: Number(C.TICK_RATE || 1),
    HEAVY_UPDATE_SEC: Number(C.HEAVY_UPDATE_SEC || 1),
    ASSET_BATCH_SIZE: Number(C.ASSET_BATCH_SIZE || 999999),
    MARKET_PREOPEN_SEC: Number(C.MARKET_PREOPEN_SEC || 1),
    MARKET_OPEN_SEC: Number(C.MARKET_OPEN_SEC || 1),
    MARKET_CLOSE_SEC: Number(C.MARKET_CLOSE_SEC || 1),
    MAX_OFFLINE_TICKS: Number(C.MAX_OFFLINE_TICKS || 7200),
    PRICE_FLOOR: Number(C.PRICE_FLOOR || 1),

    BUY_FEE_RATE: Number(C.BUY_FEE_RATE || 0.005),
    SELL_FEE_RATE: Number(C.SELL_FEE_RATE || 0.005),
    SELL_TAX_RATE: Number(C.SELL_TAX_RATE || 0.003),
    DIVIDEND_CYCLE_DAYS: Number(C.DIVIDEND_CYCLE_DAYS || 30),
    DIVIDEND_ANNOUNCE_DAY: Number(C.DIVIDEND_ANNOUNCE_DAY || 25),
    DIVIDEND_TIME_SCALE: Number(C.DIVIDEND_TIME_SCALE || (1 / 12)),

    limits: C.limits || {
      normal:  { up: 0.10, down: 0.10 },
      kingdom: { up: 0.10, down: 0.10 },
      etf:     { up: 0.10, down: 0.10 }
    }
  };

  function num(v, d){
    v = Number(v);
    return isFinite(v) ? v : d;
  }

  function getAssetMarketType(assetOrType){
    if(typeof assetOrType === "string") return assetOrType;

    var a = assetOrType || {};

    if(
      a.isETF ||
      a.etfId ||
      a.fundType ||
      String(a.type || "").toLowerCase().indexOf("etf") >= 0
    ){
      return "etf";
    }

    if(
      a.marketType === "kingdom" ||
      a.kingdom === true ||
      a.isKingdom === true ||
      a.type === "kingdom"
    ){
      return "kingdom";
    }

    return "normal";
  }


  function getPriceStepFromMilli(priceMilli, SCALE){
    SCALE = Number(SCALE || 1000);

    var coin =
      Math.max(
        0,
        Number(priceMilli || 0) / SCALE
      );

    // F4.4 Tick Size 規則
    // 0-50     => 0.01
    // 51-100   => 0.05
    // 101-200  => 0.1
    // 201-1000 => 0.5
    // 1000+    => 5

    if (coin <= 50) {
      return Math.floor(0.01 * SCALE);
    }

    if (coin <= 100) {
      return Math.floor(0.05 * SCALE);
    }

    if (coin <= 200) {
      return Math.floor(0.1 * SCALE);
    }
    if (coin <= 500) {
      return Math.floor(0.5 * SCALE);
    }
    if (coin <= 1000) {
      return Math.floor(1 * SCALE);
    }

    if (coin <= 5000) {
      return Math.floor(5 * SCALE);
    }

    return Math.floor(10 * SCALE);
  }

  function getLimit(type){
    type = getAssetMarketType(type);
    return config.limits[type] || config.limits.normal || { up:0, down:0 };
  }

  function getLimitRate(type, side, fallback){
    var l = getLimit(type);
    var v = side === "down" ? l.down : l.up;
    return Math.max(0, num(v, fallback || 0));
  }

  function isUnlimited(type){
    var l = getLimit(type);
    return !(num(l.up,0) > 0) && !(num(l.down,0) > 0);
  }

  function clampRate(rawRate, type){
    rawRate = num(rawRate, 0);
    var l = getLimit(type);
    var up = num(l.up, 0);
    var down = num(l.down, 0);
    if(up > 0) rawRate = Math.min(up, rawRate);
    if(down > 0) rawRate = Math.max(-down, rawRate);
    return rawRate;
  }

  function applyGrowthLimit(growth, type){
    growth = num(growth, 1);
    var rate = growth - 1;
    return 1 + clampRate(rate, type || "normal");
  }

  function getLimitPrices(openPrice, type){
    openPrice = Math.max(config.PRICE_FLOOR, num(openPrice, config.PRICE_FLOOR));

    var l = getLimit(type);
    var upRate = num(l.up, 0);
    var downRate = num(l.down, 0);

    var up =
      upRate > 0
        ? Math.floor(openPrice * (1 + upRate))
        : Number.POSITIVE_INFINITY;

    var down =
      downRate > 0
        ? Math.max(config.PRICE_FLOOR, Math.floor(openPrice * (1 - downRate)))
        : config.PRICE_FLOOR;

    return {
      up: up,
      down: down,
      upLocked: false,
      downLocked: false,
      upRemainingSellLiquidity: 0,
      downRemainingBuyLiquidity: 0
    };
  }

  

  function getAssetOpenPrice(asset){
    if(!asset || typeof asset !== "object"){
      return config.PRICE_FLOOR;
    }

    return Math.max(
      config.PRICE_FLOOR,
      num(
        asset.openPrice ||
        asset.dayOpenPrice ||
        asset.dayOpen ||
        asset.previousClosePrice ||
        asset.lastClosePrice ||
        asset.prevClose ||
        asset.basePrice ||
        asset.price,
        config.PRICE_FLOOR
      )
    );
  }

  function applyMarketLimitClamp(asset, nextPriceMilli){
    if(!asset || !isFinite(Number(nextPriceMilli))){
      return nextPriceMilli;
    }

    var openPrice =
      getAssetOpenPrice(asset);

    return clampPriceByMarketLimit(
      nextPriceMilli,
      openPrice,
      asset
    );
  }


  function clampPriceByMarketLimit(price, openPrice, type){
    price = Math.max(config.PRICE_FLOOR, num(price, config.PRICE_FLOOR));
    var p = getLimitPrices(openPrice, type);
    if(isFinite(p.up)) price = Math.min(p.up, price);
    price = Math.max(p.down, price);
    return Math.max(config.PRICE_FLOOR, Math.floor(price));
  }

  function updateLimitState(target, price, openPrice, type){
    if(!target) return target;
    var p = getLimitPrices(openPrice, type || target);
    target.limitLocked = false;
    target.limitType = target.limitType === null ? null : "";
    target.limitUpLocked = false;
    target.limitDownLocked = false;
    if(isFinite(p.up) && price >= p.up){
      target.limitLocked = true;
      target.limitType = "up";
      target.limitUpLocked = true;
    }else if(price <= p.down && getLimitRate(type || target, "down", 0) > 0){
      target.limitLocked = true;
      target.limitType = "down";
      target.limitDownLocked = true;
    }
    return target;
  }

  var api = {
    config: config,
    getAssetMarketType: getAssetMarketType,
    getLimit: getLimit,
    getLimitRate: getLimitRate,
    isUnlimited: isUnlimited,
    clampRate: clampRate,
    applyGrowthLimit: applyGrowthLimit,
    getLimitPrices: getLimitPrices,
    clampPriceByMarketLimit: clampPriceByMarketLimit,
    applyMarketLimitClamp: applyMarketLimitClamp,
    updateLimitState: updateLimitState,
    getPriceStepFromMilli: getPriceStepFromMilli
  };

  w.AI5MarketControl = api;
  w.MARKET_LIMITS = config.limits;
  w.MARKET_TICK_RATE = config.TICK_RATE;
})(window);
