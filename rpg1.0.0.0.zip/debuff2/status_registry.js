// status_registry.js

export const STATUS_REGISTRY = {

  poison: {
    id: "poison",

    type: "dot",

    icon: "☠️",

    name: "中毒",

    maxStacks: 5,

    defaultDuration: 5000,

    tickInterval: 1000,

    onTick(ctx) {

      const damage =
        ctx.effect.data?.damage || 1;

      ctx.damageEngine.applyDamage({
        source: ctx.source,
        target: ctx.target,

        amount: damage,

        type: "dot",

        tags: ["poison"]
      });
    }
  },

  burn: {
    id: "burn",

    type: "dot",

    icon: "🔥",

    name: "燃燒",

    maxStacks: 3,

    defaultDuration: 4000,

    tickInterval: 1000
  },

  freeze: {
    id: "freeze",

    type: "control",

    icon: "❄️",

    name: "凍結",

    defaultDuration: 2000,

    blockActions: true
  },

  stun: {
    id: "stun",

    type: "control",

    icon: "⚡",

    name: "暈眩",

    defaultDuration: 3000,

    blockActions: true
  },

  weaken: {
    id: "weaken",

    type: "modifier",

    icon: "🌀",

    name: "虛弱",

    defaultDuration: 5000,

    modifiers: {
      attackMultiplier: -0.3
    }
  }
};