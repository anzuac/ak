(function (w) {
  "use strict";

  if (
    !w.StockHub ||
    !w.StockStateManager ||
    !w.StockMarketEngine ||
    !w.StockMarketCurrency ||
    !w.StockMarketAssets
  ) {
    console.error("❌ stock_portfolio_tab.js: 缺少依賴");
    return;
  }

  var SCALE = w.StockMarketEngine.SCALE || 1000;
  var TAB_ID = "portfolio";
  var companyDetailAssetId = null;

  function fmtCoinMilli(v) {
    return (Number(v || 0) / SCALE).toFixed(2);
  }


  function getEtfPortfolioStats(state){
    var stats = {
      unrealizedMilli: 0,
      marketValueMilli: 0,
      count: 0
    };

    var root = state && state.etfV2;
    var holdings = root && root.playerHoldings ? root.playerHoldings : {};
    var funds = root && root.funds ? root.funds : {};

    for(var id in holdings){
      if(!Object.prototype.hasOwnProperty.call(holdings, id)) continue;
      var h = holdings[id] || {};
      var qty = Number(h.qty || h.amount || h.shares || 0);
      if(qty <= 0) continue;

      var fund = funds[id] || {};
      var price = Number(
        fund.marketPriceMilli ||
        fund.currentPriceMilli ||
        fund.navMilli ||
        h.priceMilli ||
        h.currentPriceMilli ||
        h.navMilli ||
        h.avgCostMilli ||
        0
      );
      var avg = Number(h.avgCostMilli || h.avgPriceMilli || h.avgCost || 0);

      stats.marketValueMilli += qty * price;
      stats.unrealizedMilli += (price - avg) * qty;
      stats.count += qty;
    }

    return stats;
  }

  function fmtSignedCoinMilli(v) {
    v = Number(v || 0);
    return (v >= 0 ? "+" : "-") + (Math.abs(v) / SCALE).toFixed(2);
  }

  function fmtPct(v) {
    v = Number(v || 0);
    return (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
  }

  function fmtNum(v) {
    return Math.floor(Number(v || 0)).toLocaleString();
  }

  function stripZero(text) {
    return String(text).replace(/\.0+$/, "").replace(/(\.\d*[1-9])0+$/, "$1");
  }

  function fmtCompactCoinMilli(v) {
    v = Number(v || 0);
    var coin = v / SCALE;
    var sign = coin < 0 ? "-" : "";
    var abs = Math.abs(coin);
    if (abs >= 1000000000000) return sign + stripZero((abs / 1000000000000).toFixed(2)) + "兆";
    if (abs >= 100000000) return sign + stripZero((abs / 100000000).toFixed(2)) + "億";
    if (abs >= 10000) return sign + stripZero((abs / 10000).toFixed(2)) + "萬";
    return sign + abs.toFixed(2);
  }

  function fmtLots(shares) {
    var toLots = w.StockMarketAssets.toLots || function (n) {
      return Math.floor(Number(n || 0) / 1000);
    };
    return fmtNum(toLots(shares));
  }

  function getSignedColor(v) {
    v = Number(v || 0);
    if (v > 0) return "#22c55e";
    if (v < 0) return "#ef4444";
    return "#e5e7eb";
  }

  function setText(body, id, text) {
    var el = body.querySelector("#" + id);
    if (el) el.textContent = text;
    return el;
  }

  function calcOpenChangePct(asset) {
    if (!asset || !asset.dayOpenPrice) return 0;
    return ((Number(asset.price || 0) - Number(asset.dayOpenPrice || 1)) / Number(asset.dayOpenPrice || 1)) * 100;
  }

  function getTierLabel(tier) {
    if (tier === "large") return "大型股";
    if (tier === "mid") return "中型股";
    if (tier === "small") return "小型股";
    return "新手盤";
  }

  function getDividendSummary(state, rows) {
    var divInfo = w.StockMarketEngine.getDividendInfo(state) || {};
    var totalDays = Number(divInfo.cycleTotalDays || 30);
    var cycleDay = Number(divInfo.cycleDay || 1);
    var daysLeft = Math.max(0, totalDays - cycleDay);

    var estTotal = 0;
    for (var i = 0; i < rows.length; i++) {
      estTotal += Number(rows[i].estimatedDividendMilli || 0);
    }

    return {
      cycleDay: cycleDay,
      totalDays: totalDays,
      daysLeft: daysLeft,
      totalReceivedMilli: Number(divInfo.totalReceivedMilli || 0),
      estimatedTotalMilli: estTotal
    };
  }

  function getPortfolioRows(state) {
    var out = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      var h = w.StockMarketEngine.getHolding(state, id);
      if (h.qty <= 0) continue;

      var marketValue = Number(asset.price || 0) * Number(h.qty || 0);
      var pnl = (Number(asset.price || 0) - Number(h.avgCostMilli || 0)) * Number(h.qty || 0);
      var estDiv = Number(asset.companyMetrics && asset.companyMetrics.estimatedDividendPerShareMilli || 0) * Number(h.qty || 0);

      out.push({
        assetId: id,
        name: asset.name,
        symbol: asset.symbol || "",
        tier: asset.marketType === "free" ? (asset.tier || "mid") : "starter",
        qty: h.qty,
        avgCostMilli: h.avgCostMilli,
        priceMilli: asset.price,
        marketValueMilli: marketValue,
        pnlMilli: pnl,
        fairValueMilli: asset._lastFairValue || asset.price,
        estimatedDividendMilli: estDiv
      });
    }

    out.sort(function (a, b) {
      return b.marketValueMilli - a.marketValueMilli;
    });

    return out;
  }

  function openCompanyDetail(assetId) {
    companyDetailAssetId = assetId;
    var body = document.getElementById("stockHubBody");
    if (!body) return;
    render(body);
  }

  function closeCompanyDetail() {
    companyDetailAssetId = null;
    var body = document.getElementById("stockHubBody");
    if (!body) return;
    render(body);
  }

  function renderRow(r) {
    return (
      '<tr id="pf-row-' + r.assetId + '">' +
        '<td style="padding:8px;border-bottom:1px solid #111827;">' +
          '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;"><span style="background:#1e293b;color:#93c5fd;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:800;">' + (r.symbol || '----') + '</span><div style="font-weight:700;">' + r.name + '</div></div>' +
          '<div style="font-size:12px;opacity:.7;">' + getTierLabel(r.tier) + '</div>' +
        '</td>' +
        '<td id="pf-qty-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtNum(r.qty) + '</td>' +
        '<td id="pf-avg-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtCoinMilli(r.avgCostMilli) + '</td>' +
        '<td id="pf-price-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtCoinMilli(r.priceMilli) + '</td>' +
        '<td id="pf-value-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtCoinMilli(r.marketValueMilli) + '</td>' +
        '<td id="pf-pnl-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;color:' + getSignedColor(r.pnlMilli) + ';font-weight:700;">' + fmtSignedCoinMilli(r.pnlMilli) + '</td>' +
        '<td id="pf-fair-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtCoinMilli(r.fairValueMilli) + '</td>' +
        '<td id="pf-div-' + r.assetId + '" style="padding:8px;border-bottom:1px solid #111827;text-align:right;">' + fmtCoinMilli(r.estimatedDividendMilli) + '</td>' +
        '<td style="padding:8px;border-bottom:1px solid #111827;text-align:center;">' +
          '<button data-port-detail="' + r.assetId + '" style="background:#334155;color:#fff;border:0;border-radius:8px;padding:6px 10px;cursor:pointer;font-weight:700;">查看</button>' +
        '</td>' +
      '</tr>'
    );
  }

  function buildMainView(state) {
    var rows = getPortfolioRows(state);
    var etfStats = getEtfPortfolioStats(state);
    var totalUnrealized = w.StockMarketEngine.totalUnrealized(state) + etfStats.unrealizedMilli;
    var totalMarketValue = w.StockMarketEngine.totalMarketValue(state) + etfStats.marketValueMilli;
    var dividendSummary = getDividendSummary(state, rows);
    var investCoin = w.StockMarketCurrency.getMilli(state);
    var dividendCoin = w.StockMarketCurrency.getDividendMilli ? w.StockMarketCurrency.getDividendMilli(state) : 0;
    var realizedMilli = (state.stats && state.stats.realizedProfitMilli) || 0;
    var feeMilli = (state.stats && state.stats.totalFeesMilli) || 0;

    var html =
      '<div style="display:flex;flex-direction:column;gap:12px;">' +

        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
          '<div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">' +
            '<div>' +
              '<div style="font-size:20px;font-weight:900;">👤 個人投資</div>' +
              '<div style="font-size:12px;opacity:.72;margin-top:4px;">查看你的持倉、市值、損益與配息進度</div>' +
            '</div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
              '<span id="pf-top-count" style="background:#1e293b;color:#dbeafe;border-radius:999px;padding:5px 10px;font-size:12px;font-weight:800;">持倉數 ' + (rows.length + etfStats.count) + '</span>' +
            '</div>' +
          '</div>' +

          '<div style="margin-top:10px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">' +
            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">投資幣</div>' +
              '<div id="pf-top-coin" style="font-size:18px;font-weight:900;color:#facc15;margin-top:4px;">' + fmtCompactCoinMilli(investCoin) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">股利幣</div>' +
              '<div id="pf-top-divcoin" style="font-size:18px;font-weight:900;color:#93c5fd;margin-top:4px;">' + fmtCompactCoinMilli(dividendCoin) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">持倉市值</div>' +
              '<div id="pf-top-value" style="font-size:18px;font-weight:900;margin-top:4px;">' + fmtCoinMilli(totalMarketValue) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">未實現損益</div>' +
              '<div id="pf-top-pnl" style="font-size:18px;font-weight:900;color:' + getSignedColor(totalUnrealized) + ';margin-top:4px;">' + fmtSignedCoinMilli(totalUnrealized) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">累積已實現損益</div>' +
              '<div id="pf-top-realized" style="font-size:18px;font-weight:900;color:' + getSignedColor(realizedMilli) + ';margin-top:4px;">' + fmtSignedCoinMilli(realizedMilli) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">累積交易手續費</div>' +
              '<div id="pf-top-fee" style="font-size:18px;font-weight:900;color:#f87171;margin-top:4px;">' + fmtCoinMilli(feeMilli) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">累計股利幣收入</div>' +
              '<div id="pf-top-dividend" style="font-size:18px;font-weight:900;margin-top:4px;">' + fmtCoinMilli(dividendSummary.totalReceivedMilli) + '</div>' +
            '</div>' +

            '<div style="background:#111827;border:1px solid #1f2937;border-radius:12px;padding:10px;">' +
              '<div style="font-size:12px;opacity:.72;">最近一次股利收入</div>' +
              '<div id="pf-top-realdiv" style="font-size:18px;font-weight:900;margin-top:4px;color:#86efac;">' + fmtCoinMilli((dividendSummary.history && dividendSummary.history[0] ? dividendSummary.history[0].totalReceivedMilli : 0)) + '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;">' +
          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">💰 已入帳股利來源</div>' +
            '<div style="line-height:1.9;">' +
              '只顯示「實際已發放」的股利收入。<br>' +
              '系統已移除預估股利資訊。<br>' +
              '累計已領股利幣：<b id="pf-div-total-2">' + fmtCoinMilli(dividendSummary.totalReceivedMilli) + '</b><br><br>' +

              
((dividendSummary.history || []).length
  ? (dividendSummary.history.slice(0, 10).map(function(h, idx) {
      var detail = Array.isArray(h.detail) ? h.detail : [];

      var rows = detail.map(function(d) {
        return '<div style="padding:6px 0;border-top:1px solid #1f2937;">' +
          '<div style="display:flex;justify-content:space-between;">' +
            '<span>' + d.assetName + '</span>' +
            '<span style="color:#86efac;">' + fmtCoinMilli(d.totalMilli) + '</span>' +
          '</div>' +
        '</div>';
      }).join('');

      return '<details style="margin-bottom:10px;background:#111827;border:1px solid #263247;border-radius:12px;padding:10px;">' +
        '<summary style="cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;">' +

          '<div>' +
            '<div style="font-size:12px;opacity:.65;">第 ' + h.marketDay + ' 天股利發放</div>' +
            '<div style="font-size:16px;font-weight:900;color:#86efac;margin-top:4px;">' +
              fmtCoinMilli(h.totalReceivedMilli) +
            '</div>' +
          '</div>' +

          '<div style="font-size:12px;opacity:.55;">點擊展開</div>' +

        '</summary>' +

        '<div style="margin-top:12px;font-size:13px;line-height:1.8;">' +
          rows +
        '</div>' +
      '</details>';
    }).join(''))
  : '<div style="opacity:.7;">目前尚無已入帳股利紀錄。</div>') +

            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📌 投資提醒</div>' +
            '<div style="line-height:1.85;opacity:.9;">' +
              '股利是否增加，會依公司本期利潤、配息率與營運狀況變動。<br>' +
              '若你持股越多，實際領到的股利收入通常也會越高。<br>' +
              '更詳細的公司體質、股本結構與配息資訊，可在下方點擊公司查看。' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
          '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📋 持倉明細</div>' +
          '<div id="stockPortfolioScroll" style="max-height:700px;overflow:auto;">';

    if (!rows.length) {
      html += '<div id="pf-empty" style="opacity:.75;">目前沒有持股。</div>';
    } else {
      html +=

  '<table style="width:100%;border-collapse:collapse;font-size:14px;">' +
    '<thead>' +
      '<tr>' +
        '<th style="text-align:left;padding:12px;border-bottom:1px solid #1f2937;">股票名稱</th>' +
        '<th style="text-align:right;padding:12px;border-bottom:1px solid #1f2937;">持有股數</th>' +
        '<th style="text-align:right;padding:12px;border-bottom:1px solid #1f2937;">平均價格</th>' +
      '</tr>' +
    '</thead>' +
    '<tbody>';

for (var i = 0; i < rows.length; i++) {
  var r = rows[i];

  html +=
    '<tr ' +
      'style="' +
        'cursor:pointer;' +
        'transition:.18s;' +
      '" ' +
      'onclick="window.StockPortfolioTab.openDetail(\'' + r.assetId + '\')"' +
    '>' +

      '<td style="padding:14px 12px;border-bottom:1px solid #18202f;font-weight:700;">' +
        r.name +
      '</td>' +

      '<td style="padding:14px 12px;border-bottom:1px solid #18202f;text-align:right;">' +
        fmtNum(r.qty) +
      '</td>' +

      '<td style="padding:14px 12px;border-bottom:1px solid #18202f;text-align:right;">' +
        fmtCoinMilli(r.avgCostMilli) +
      '</td>' +

    '</tr>';
}

html += '</tbody></table>';
    }

    html +=
          '</div>' +
        '</div>' +
      '</div>';

    return html;
  }

  function buildDetailView(state, assetId) {
    var detail = w.StockMarketEngine.getCompanyDetail(state, assetId);
    if (!detail) return null;

    var asset = state.assets[assetId];
    var ci = detail.companyInfo || {};
    var cm = detail.companyMetrics || {};
    var si = detail.shareInfo || {};
    var holding = detail.playerHolding || {};
    var control = detail.control || { ratio: 0, level: "正常", color: "#22c55e" };

    var tierText = detail.marketType === "free"
      ? (detail.tier === "large" ? "大型股" : (detail.tier === "small" ? "小型股" : "中型股"))
      : "新手盤";

    var styleText = detail.style === "A" ? "A 型" : "B 型";
    var openPctColor = getSignedColor(detail.openChangePct);
    var trend5Color = getSignedColor(detail.trend5);
    var trend30Color = getSignedColor(detail.trend30);
    var basePayoutPct = Number(cm.basePayoutRatio || 0) * 100;
    var currentPayoutPct = Number(cm.currentPayoutRatio || 0) * 100;
    var playerImpactNet = Number(asset && asset.playerImpactBuy || 0) - Number(asset && asset.playerImpactSell || 0);
    var playerRecentNetFlow = Number(asset && asset.playerRecentNetFlow || 0);
    var lastPlayerTradeImpact = Number(asset && asset._lastPlayerTradeImpact || 0);

    return (
      '<div style="display:flex;flex-direction:column;gap:12px;">' +

        '<div>' +
          '<button id="stockPortfolioBackBtn" style="background:#334155;color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:800;">← 返回個人投資</button>' +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;">' +
          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🏢 公司概況</div>' +
            '<div style="line-height:1.8;">' +
              '名稱：<b>' + detail.name + '</b><br>' +
              '代號：<b>' + (detail.symbol || '-') + '</b><br>' +
              '類型：<b>' + tierText + ' / ' + styleText + '</b><br>' +
              '股價：<b id="pfd-price" style="font-size:18px;">' + fmtCoinMilli(detail.priceMilli) + '</b>　' +
              '<b id="pfd-openpct" style="color:' + openPctColor + ';font-weight:700;">' + fmtPct(detail.openChangePct) + '</b><br>' +
              '平衡價：<b id="pfd-fair">' + fmtCoinMilli(detail.fairValueMilli) + '</b><br>' +
              '5日趨勢：<b id="pfd-trend5" style="color:' + trend5Color + ';font-weight:700;">' + fmtPct(detail.trend5) + '</b><br>' +
              '30日趨勢：<b id="pfd-trend30" style="color:' + trend30Color + ';font-weight:700;">' + fmtPct(detail.trend30) + '</b>' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🧾 你的持股</div>' +
            '<div style="line-height:1.8;">' +
              '你持有：<b id="pfd-hold-qty">' + fmtNum(holding.qty) + '</b> 股<br>' +
              '均價：<b id="pfd-hold-avg">' + fmtCoinMilli(holding.avgCostMilli) + '</b><br>' +
              '你占流通比：<b id="pfd-control-ratio" style="color:' + control.color + ';font-weight:700;">' + fmtPct(control.ratio * 100) + '</b><br>' +
              '集中度：<b id="pfd-control-level" style="color:' + control.color + ';font-weight:700;">' + control.level + '</b><br>' +
              '預估本次股利幣：<b id="pfd-hold-div">' + fmtCoinMilli(holding.estimatedDividendMilli) + '</b>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;">' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📘 公司介紹</div>' +
            '<div style="line-height:1.85;word-break:break-word;">' +
              '分類：<b>' + (ci.category || "-") + '</b><br>' +
              '創立年：<b>' + fmtNum(ci.foundedYear || 0) + '</b><br>' +
              '簡介：<div style="margin-top:6px;opacity:.9;">' + (ci.descriptionLong || detail.desc || "-") + '</div>' +
              (ci.notes ? ('<div style="margin-top:6px;color:#93c5fd;">備註：' + ci.notes + '</div>') : '') +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🏦 股本結構（張）</div>' +
            '<div style="line-height:1.85;">' +
              '總發行：<b id="pfd-total-lots">' + fmtLots(si.totalShares) + '</b> 張<br>' +
              '流通：<b id="pfd-float-lots">' + fmtLots(si.floatShares) + '</b> 張<br>' +
              '鎖倉：<b id="pfd-locked-lots">' + fmtLots(si.lockedShares) + '</b> 張<br>' +
              '董事持股：<b id="pfd-insider-lots">' + fmtLots(si.insiderShares) + '</b> 張<br>' +
              '策略持股：<b id="pfd-core-lots">' + fmtLots((si.strategicHoldingShares != null ? si.strategicHoldingShares : si.strategicHoldingShares)) + '</b> 張<br>' +
              '做市持股：<b id="pfd-trade-lots">' + fmtLots((si.marketMakerShares != null ? si.marketMakerShares : si.marketMakerShares)) + '</b> 張<br>' +
              '市場掛單：<b id="pfd-avail-lots">' + fmtLots(si.availableShares) + '</b> 張' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">📊 籌碼與量能</div>' +
            '<div style="line-height:1.85;">' +
              '玩家持股集中度：<b id="pfd-control-ratio-2" style="color:' + control.color + ';font-weight:700;">' + fmtPct(control.ratio * 100) + '</b><br>' +
              '集中狀態：<b id="pfd-control-level-2" style="color:' + control.color + ';font-weight:700;">' + control.level + '</b><br>' +
              '今日成交量：<b id="pfd-vol-now">' + fmtNum(cm.latestDailyVolume) + '</b> 股<br>' +
              '5日均量：<b id="pfd-vol-5">' + fmtNum(cm.avgVolume5) + '</b> 股<br>' +
              '30日均量：<b id="pfd-vol-30">' + fmtNum(cm.avgVolume30) + '</b> 股' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">🧠 玩家交易影響</div>' +
            '<div style="line-height:1.85;">' +
              '近期交易衝擊：<b id="pfd-impact-net" style="color:' + getSignedColor(playerImpactNet) + ';font-weight:700;">' + fmtPct(playerImpactNet * 100) + '</b><br>' +
              '最近淨流向：<b id="pfd-impact-flow" style="color:' + getSignedColor(playerRecentNetFlow) + ';font-weight:700;">' + fmtPct(playerRecentNetFlow * 100) + '</b><br>' +
              '最近單筆影響：<b id="pfd-impact-last" style="color:' + getSignedColor(lastPlayerTradeImpact) + ';font-weight:700;">' + fmtPct(lastPlayerTradeImpact * 100) + '</b><br>' +
              '說明：<span style="opacity:.82;">當你連續大量買入會偏多，連續大量賣出會偏空，之後會隨時間逐步衰退。</span>' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">💼 經營資訊</div>' +
            '<div style="line-height:1.85;">' +
              '資產額：<b id="pfd-assets">' + fmtCoinMilli(cm.assetsMilli) + '</b><br>' +
              '本期營業額：<b id="pfd-revenue">' + fmtCoinMilli(cm.revenueMonthlyMilli) + '</b><br>' +
              '本期利潤：<b id="pfd-profit" style="color:' + getSignedColor(cm.profitMonthlyMilli) + ';font-weight:700;">' + fmtSignedCoinMilli(cm.profitMonthlyMilli) + '</b><br>' +
              '公司體質：<b>' + Math.round(Number(ci.quality || 0) * 100) + '</b><br>' +
              '穩定度：<b>' + Math.round(Number(ci.stability || 0) * 100) + '</b><br>' +
              '熱度：<b>' + Math.round(Number(ci.hype || 0) * 100) + '</b>' +
            '</div>' +
          '</div>' +

          '<div style="background:#0b1220;border:1px solid #263247;border-radius:14px;padding:12px;">' +
            '<div style="font-size:16px;font-weight:900;margin-bottom:8px;">💰 股利資訊</div>' +
            '<div style="line-height:1.85;">' +
              '基礎配息率：<b id="pfd-base-payout">' + basePayoutPct.toFixed(2) + '%</b><br>' +
              '目前配息率：<b id="pfd-current-payout">' + currentPayoutPct.toFixed(2) + '%</b><br>' +
              '預估每股股利：<b id="pfd-est-div-share">' + fmtCoinMilli(cm.estimatedDividendPerShareMilli) + '</b><br>' +
              '上次每股股利：<b id="pfd-last-div-share">' + fmtCoinMilli(cm.lastDividendPerShareMilli) + '</b><br>' +
              '你本次預估可得股利幣：<b id="pfd-est-div-total">' + fmtCoinMilli(holding.estimatedDividendMilli) + '</b>' +
            '</div>' +
          '</div>' +

        '</div>' +
      '</div>'
    );
  }

  function bindPortfolioButtons(body) {
    var btns = body.querySelectorAll("button[data-port-detail]");
    for (var j = 0; j < btns.length; j++) {
      btns[j].onclick = (function (assetId) {
        return function () {
          openCompanyDetail(assetId);
        };
      })(btns[j].getAttribute("data-port-detail"));

      var backBtn = body.querySelector("#stockPortfolioBackBtn");
      if (backBtn) backBtn.onclick = closeCompanyDetail;
    }
  }

  function updateMainView(body, state) {
    var rows = getPortfolioRows(state);
    var etfStats = getEtfPortfolioStats(state);
    var totalUnrealized = w.StockMarketEngine.totalUnrealized(state) + etfStats.unrealizedMilli;
    var totalMarketValue = w.StockMarketEngine.totalMarketValue(state) + etfStats.marketValueMilli;
    var dividendSummary = getDividendSummary(state, rows);
    var investCoin = w.StockMarketCurrency.getMilli(state);
    var dividendCoin = w.StockMarketCurrency.getDividendMilli ? w.StockMarketCurrency.getDividendMilli(state) : 0;
    var realizedMilli = (state.stats && state.stats.realizedProfitMilli) || 0;
    var feeMilli = (state.stats && state.stats.totalFeesMilli) || 0;

    setText(body, "pf-top-count", "持倉數 " + rows.length);
    setText(body, "pf-top-coin", fmtCompactCoinMilli(w.StockMarketCurrency.getMilli(state)));
    setText(body, "pf-top-divcoin", fmtCompactCoinMilli(w.StockMarketCurrency.getDividendMilli ? w.StockMarketCurrency.getDividendMilli(state) : 0));
    setText(body, "pf-top-value", fmtCoinMilli(totalMarketValue));

    var pnlTopEl = setText(body, "pf-top-pnl", fmtSignedCoinMilli(totalUnrealized));
    if (pnlTopEl) pnlTopEl.style.color = getSignedColor(totalUnrealized);

    setText(body, "pf-top-dividend", fmtCoinMilli(dividendSummary.totalReceivedMilli));
    setText(body, "pf-top-estdiv", fmtCoinMilli(dividendSummary.estimatedTotalMilli));

    setText(body, "pf-div-cycle", dividendSummary.cycleDay + " / " + dividendSummary.totalDays);
    setText(body, "pf-div-days-left", dividendSummary.daysLeft);
    setText(body, "pf-div-est-total", fmtCoinMilli(dividendSummary.estimatedTotalMilli));
    setText(body, "pf-div-total-2", fmtCoinMilli(dividendSummary.totalReceivedMilli));

    var tableBody = body.querySelector("#pf-table-body");
    var emptyEl = body.querySelector("#pf-empty");

    if (!rows.length) {
      if (tableBody) {
        var wrap = body.querySelector("#stockPortfolioScroll");
        if (wrap) {
          wrap.innerHTML = '<div id="pf-empty" style="opacity:.75;">目前沒有持股。</div>';
        }
      } else if (emptyEl) {
        emptyEl.textContent = "目前沒有持股。";
      }
      return;
    }

    if (!tableBody) {
      render(body);
      return;
    }

    var existingIds = {};
    for (var i = 0; i < rows.length; i++) {
      existingIds[rows[i].assetId] = true;
    }

    var currentRows = tableBody.querySelectorAll("tr[id^='pf-row-']");
    for (var r = 0; r < currentRows.length; r++) {
      var rowId = currentRows[r].id.replace("pf-row-", "");
      if (!existingIds[rowId]) {
        currentRows[r].remove();
      }
    }

    for (var j = 0; j < rows.length; j++) {
      var item = rows[j];
      var rowEl = body.querySelector("#pf-row-" + item.assetId);

      if (!rowEl) {
        tableBody.insertAdjacentHTML("beforeend", renderRow(item));
        continue;
      }

      setText(body, "pf-qty-" + item.assetId, fmtNum(item.qty));
      setText(body, "pf-avg-" + item.assetId, fmtCoinMilli(item.avgCostMilli));
      setText(body, "pf-price-" + item.assetId, fmtCoinMilli(item.priceMilli));
      setText(body, "pf-value-" + item.assetId, fmtCoinMilli(item.marketValueMilli));

      var pnlEl = setText(body, "pf-pnl-" + item.assetId, fmtSignedCoinMilli(item.pnlMilli));
      if (pnlEl) pnlEl.style.color = getSignedColor(item.pnlMilli);

      setText(body, "pf-fair-" + item.assetId, fmtCoinMilli(item.fairValueMilli));
      setText(body, "pf-div-" + item.assetId, fmtCoinMilli(item.estimatedDividendMilli));
    }

    bindPortfolioButtons(body);
  }

  function updateDetailView(body, state, assetId) {
    var detail = w.StockMarketEngine.getCompanyDetail(state, assetId);
    if (!detail) {
      companyDetailAssetId = null;
      render(body);
      return;
    }

    var asset = state.assets[assetId];
    var cm = detail.companyMetrics || {};
    var si = detail.shareInfo || {};
    var holding = detail.playerHolding || {};
    var control = detail.control || { ratio: 0, level: "正常", color: "#22c55e" };
    var playerImpactNet = Number(asset && asset.playerImpactBuy || 0) - Number(asset && asset.playerImpactSell || 0);
    var playerRecentNetFlow = Number(asset && asset.playerRecentNetFlow || 0);
    var lastPlayerTradeImpact = Number(asset && asset._lastPlayerTradeImpact || 0);

    setText(body, "pfd-price", fmtCoinMilli(detail.priceMilli));
    var openPctEl = setText(body, "pfd-openpct", fmtPct(detail.openChangePct));
    if (openPctEl) openPctEl.style.color = getSignedColor(detail.openChangePct);

    setText(body, "pfd-fair", fmtCoinMilli(detail.fairValueMilli));

    var trend5El = setText(body, "pfd-trend5", fmtPct(detail.trend5));
    if (trend5El) trend5El.style.color = getSignedColor(detail.trend5);

    var trend30El = setText(body, "pfd-trend30", fmtPct(detail.trend30));
    if (trend30El) trend30El.style.color = getSignedColor(detail.trend30);

    setText(body, "pfd-hold-qty", fmtNum(holding.qty));
    setText(body, "pfd-hold-avg", fmtCoinMilli(holding.avgCostMilli));
    setText(body, "pfd-hold-div", fmtCoinMilli(holding.estimatedDividendMilli));

    var ctrlRatio1 = setText(body, "pfd-control-ratio", fmtPct(control.ratio * 100));
    var ctrlLevel1 = setText(body, "pfd-control-level", control.level);
    var ctrlRatio2 = setText(body, "pfd-control-ratio-2", fmtPct(control.ratio * 100));
    var ctrlLevel2 = setText(body, "pfd-control-level-2", control.level);

    [ctrlRatio1, ctrlLevel1, ctrlRatio2, ctrlLevel2].forEach(function (el) {
      if (el) el.style.color = control.color;
    });

    setText(body, "pfd-total-lots", fmtLots(si.totalShares));
    setText(body, "pfd-float-lots", fmtLots(si.floatShares));
    setText(body, "pfd-locked-lots", fmtLots(si.lockedShares));
    setText(body, "pfd-insider-lots", fmtLots(si.insiderShares));
    setText(body, "pfd-core-lots", fmtLots((si.strategicHoldingShares != null ? si.strategicHoldingShares : si.strategicHoldingShares)));
    setText(body, "pfd-trade-lots", fmtLots((si.marketMakerShares != null ? si.marketMakerShares : si.marketMakerShares)));
    setText(body, "pfd-avail-lots", fmtLots(si.availableShares));

    setText(body, "pfd-vol-now", fmtNum(cm.latestDailyVolume));
    setText(body, "pfd-vol-5", fmtNum(cm.avgVolume5));
    setText(body, "pfd-vol-30", fmtNum(cm.avgVolume30));

    var impactNetEl = setText(body, "pfd-impact-net", fmtPct(playerImpactNet * 100));
    var impactFlowEl = setText(body, "pfd-impact-flow", fmtPct(playerRecentNetFlow * 100));
    var impactLastEl = setText(body, "pfd-impact-last", fmtPct(lastPlayerTradeImpact * 100));

    if (impactNetEl) impactNetEl.style.color = getSignedColor(playerImpactNet);
    if (impactFlowEl) impactFlowEl.style.color = getSignedColor(playerRecentNetFlow);
    if (impactLastEl) impactLastEl.style.color = getSignedColor(lastPlayerTradeImpact);

    setText(body, "pfd-assets", fmtCoinMilli(cm.assetsMilli));
    setText(body, "pfd-revenue", fmtCoinMilli(cm.revenueMonthlyMilli));

    var profitEl = setText(body, "pfd-profit", fmtSignedCoinMilli(cm.profitMonthlyMilli));
    if (profitEl) profitEl.style.color = getSignedColor(cm.profitMonthlyMilli);

    setText(body, "pfd-base-payout", (Number(cm.basePayoutRatio || 0) * 100).toFixed(2) + "%");
    setText(body, "pfd-current-payout", (Number(cm.currentPayoutRatio || 0) * 100).toFixed(2) + "%");
    setText(body, "pfd-est-div-share", fmtCoinMilli(cm.estimatedDividendPerShareMilli));
    setText(body, "pfd-last-div-share", fmtCoinMilli(cm.lastDividendPerShareMilli));
    setText(body, "pfd-est-div-total", fmtCoinMilli(holding.estimatedDividendMilli));
  }

  function render(body) {
    w.StockStateManager.settleAndSave();
    var state = w.StockStateManager.getState();

    if (companyDetailAssetId) {
      var detailHtml = buildDetailView(state, companyDetailAssetId);
      if (!detailHtml) {
        companyDetailAssetId = null;
        body.innerHTML = buildMainView(state);
        bindPortfolioButtons(body);
        return;
      }
      body.innerHTML = detailHtml;
      bindPortfolioButtons(body);
      return;
    }

    body.innerHTML = buildMainView(state);
    bindPortfolioButtons(body);
  }

  function update(body) {
    var bodyScrollTop = body ? Number(body.scrollTop || 0) : 0;
    render(body);
    if (body) body.scrollTop = bodyScrollTop;
    setTimeout(function () {
      if (body) body.scrollTop = bodyScrollTop;
    }, 0);
  }

  function onClose() {
    companyDetailAssetId = null;
  }

  w.StockHub.registerTab({
    id: TAB_ID,
    title: "個人投資",
    render: render,
    update: update,
    onClose: onClose
  });
})(window);