
(function(w){
  "use strict";

  var MONTHS = [
    "霜火月","星雨月","赤陽月","灰霧月",
    "豐收月","永夜月","白銀月","炎龍月",
    "蒼風月","黑潮月","晨曦月","寒霜月"
  ];

  var SEASONS = [
    "春","夏","秋","冬"
  ];

  var WEATHER = {
    spring:["晴朗","細雨","暖風"],
    summer:["炎熱","烈陽","乾燥"],
    autumn:["強風","陰雨","豐收"],
    winter:["暴雪","寒流","冰霧"]
  };

  function ensure(state){

    if(!state.worldClimate){
      state.worldClimate = {};
    }

    var wc = state.worldClimate;

    if(!wc.day){
      wc.day = 1;
    }

    if(typeof wc.monthIndex !== "number"){
      wc.monthIndex = 0;
    }

    if(!wc.year){
      wc.year = 417;
    }

    if(!wc.lastMarketDay){
      wc.lastMarketDay = 0;
    }

    return wc;
  }

  function pick(arr){
    return arr[
      Math.floor(Math.random()*arr.length)
    ];
  }

  function update(state){

    var wc = ensure(state);

    var marketDay =
      Number(state.marketDay || 1);

    if(wc.lastMarketDay !== marketDay){

      wc.lastMarketDay = marketDay;
      wc.day++;

      if(wc.day > 30){

        wc.day = 1;
        wc.monthIndex++;

        if(wc.monthIndex > 11){
          wc.monthIndex = 0;
          wc.year++;
        }

      }

      var monthIndex = wc.monthIndex;

      wc.month =
        MONTHS[monthIndex];

      var seasonIndex =
        Math.floor(monthIndex / 3);

      wc.season =
        SEASONS[seasonIndex];

      var weatherPool =
        seasonIndex === 0 ? WEATHER.spring :
        seasonIndex === 1 ? WEATHER.summer :
        seasonIndex === 2 ? WEATHER.autumn :
        WEATHER.winter;

      wc.weather =
        pick(weatherPool);

      wc.worldMood =
        pick([
          "和平繁榮",
          "市場躁動",
          "資源緊張",
          "動盪時代",
          "貿易活絡"
        ]);

      wc.worldEventBoost = 1.0;
      wc.sectorEventBoost = 1.0;
      wc.tradeBoost = 1.0;

      if(wc.season === "冬"){
        wc.worldEventBoost += 0.25;
        wc.tradeBoost += 0.15;
      }

      if(wc.season === "夏"){
        wc.sectorEventBoost += 0.20;
      }

      if(wc.weather === "暴雪"){
        wc.worldEventBoost += 0.20;
      }

      if(wc.worldMood === "動盪時代"){
        wc.worldEventBoost += 0.35;
      }

      if(wc.worldMood === "市場躁動"){
        wc.tradeBoost += 0.25;
      }

      if(typeof w.pushWorldNews === "function"){

        w.pushWorldNews(
          "daily",
          "🌍 今日世界播報",
          "阿斯特拉曆 " +
          wc.year +
          " 年｜" +
          wc.month +
          wc.day +
          "號｜" +
          wc.season +
          "季｜天氣：" +
          wc.weather +
          "｜世界狀態：" +
          wc.worldMood,
          1
        );

      }

    }

    return wc;
  }

  function getModifiers(state){

    var wc = ensure(state);

    return {
      worldEventBoost:
        Number(wc.worldEventBoost || 1),

      sectorEventBoost:
        Number(wc.sectorEventBoost || 1),

      tradeBoost:
        Number(wc.tradeBoost || 1)
    };
  }

  function getDisplay(state){

    var wc = ensure(state);

    return {
      year: wc.year,
      month: wc.month,
      season: wc.season,
      weather: wc.weather,
      mood: wc.worldMood
    };
  }

  w.WorldClimateSystem = {
    update:update,
    getModifiers:getModifiers,
    getDisplay:getDisplay
  };

})(window);


// =====================================================
// AI5.3.0 World Calendar Config
// =====================================================

window.AI5_WORLD_ERAS = [
  "阿斯特拉帝國曆",
  "聖王聯邦紀元",
  "星環文明曆",
  "蒼穹聯盟紀元",
  "永夜王朝曆",
  "白銀皇室紀元"
];

window.AI5_WORLD_NEWS_NETWORKS = [
  "皇家經濟院",
  "世界觀測局",
  "地下情報網",
  "星環魔導院"
];

