

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

// ======================================================
// stock_market_name_generator.js
// 商會名稱隨機生成器
// ======================================================
(function(w) {
  "use strict";
  
  function randInt(min, max) {
    min = Math.floor(Number(min || 0));
    max = Math.floor(Number(max || 0));
    return Math.floor(min + Math.random() * (max - min + 1));
  }
  
  function pick(arr) {
    if (!arr || !arr.length) return "";
    return arr[randInt(0, arr.length - 1)];
  }
  
  function normalizeName(s) {
    return String(s || "").replace(/\s+/g, "").trim();
  }
  
  var PREFIX_POOL = [
    "王都", "蒼月", "赤焰", "白銀", "黑曜", "星穹", "霜狼", "秘法", "龍脊", "暮影",
    "日輪", "深淵", "翠森", "月冠", "天穹", "聖槍", "幽鐵", "琥珀", "銀翼", "夜霧",
    "晨星", "群島", "雷鳴", "秘銀", "獅鷲", "風語", "灰塔", "赤潮", "雲岬", "虹泉"
  ];
  
  var CORE_POOL = [
    "商會", "工坊", "學院", "結社", "旅團", "公社", "鍊金", "魔導", "聖堂", "工匠",
    "航路", "兵裝", "藥劑", "晶礦", "鍛冶", "獵團", "符印", "港務", "糧庫", "守望",
    "祕庫", "鋼爐", "織坊", "燈塔", "星港", "神殿", "典藏", "遠征", "盟約", "鑄造"
  ];
  
  var EXTRA_POOL = [
    "聯盟", "總會", "院", "團", "局", "坊", "社", "府", "會", "署",
    "隊", "塔", "站", "庭", "苑", "港", "營", "廳", "庫", "館"
  ];
  
  var SUFFIX_BY_INDUSTRY = {
    arcane: ["魔導院", "符印工坊", "晶核研究會", "秘術局", "星環工學院"],
    crystal_energy: ["晶礦局", "焰核會", "雷脈能源院", "日輪動力坊", "魔晶供給署"],
    royal_military: ["軍械局", "戰械署", "王國兵裝院", "城防工造", "鋼盾軍需會"],
    sky_route: ["天空航路局", "銀翼船團", "風帆商會", "群島運輸會", "星港旅團"],
    grain: ["糧庫", "豐穀司", "食坊商會", "農圃公社", "酒館供給會"],
    holy_care: ["聖療會", "藥劑院", "生靈醫館", "聖藥工坊", "白塔治療院"],
    gold_contract: ["金契會", "王都金庫", "銀券署", "星幣總庫", "資本結社"],
    royal_build: ["王城建設院", "城牆工務局", "皇家營造會", "石匠公社", "重建署"],
    alchemy: ["鍊金工坊", "藥瓶結社", "符液工坊", "秘藥院", "赤釜鍊成會"],
    adventurer: ["冒險公會", "遠征旅團", "獵團總會", "迷宮探索局", "守望傭兵團"],
    black_market: ["密貿會", "夜市結社", "黑牌商會", "影契聯盟", "灰巷交易所"],
    relic: ["遺跡研究會", "古物典藏院", "遠古探索團", "秘境考古局", "失落工坊"],

    // 舊代碼相容
    food: ["糧庫", "食坊", "豐穀司", "酒館商會", "農圃公社"],
    medical: ["藥劑院", "生靈醫館", "聖療會", "鍊藥工坊", "醫術結社"],
    shipping: ["航路局", "風帆商會", "銀翼船團", "群島運輸會", "遠航旅團"],
    tech: ["魔導院", "符印工坊", "晶核研究會", "秘術局", "星環工學院"],
    manufacturing: ["鍛冶坊", "兵裝署", "鋼爐工造", "匠作公社", "重機工坊"],
    energy: ["晶礦局", "焰核會", "雷脈能源院", "日輪動力坊", "魔晶供給署"],
    finance: ["金庫商會", "王都金契會", "銀券署", "資本結社", "星幣總庫"],
    resource: ["礦脈會", "祕銀商會", "黑曜採掘團", "晶石公社", "原材署"],
    default: ["商會", "工坊", "結社", "聯盟", "總會"]
  };
  
  function getSuffixPool(industryId) {
    return SUFFIX_BY_INDUSTRY[industryId] || SUFFIX_BY_INDUSTRY.default;
  }
  
  function buildShortName(industryId) {
    var mode = randInt(1, 100);
    
    var a = pick(PREFIX_POOL);
    var b = pick(CORE_POOL);
    var c = pick(EXTRA_POOL);
    var suffix = pick(getSuffixPool(industryId));
    
    // 三種名字型態，避免全部長一樣
    // 1. 雙字 + 產業尾詞：星岳科技
    // 2. 三字 + 產業尾詞：宏辰新航運
    // 3. 雙字 + 通用尾詞：青川實業（比例較低）
    if (mode <= 58) {
      return a + b + suffix;
    }
    
    if (mode <= 88) {
      return a + b + c + suffix;
    }
    
    return a + b + pick(SUFFIX_BY_INDUSTRY.default);
  }
  
  function toFormalCompanyName(shortName) {
    shortName = normalizeName(shortName);
    if (!shortName) return "未命名商會";
    if (/商會$/.test(shortName)) return shortName;
    return shortName + "商會";
  }
  
  function collectUsedNames(state) {
    var used = Object.create(null);
    
    if (state && state.assets) {
      for (var id in state.assets) {
        if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
        var asset = state.assets[id];
        if (!asset) continue;
        
        used[normalizeName(asset.name)] = true;
        used[normalizeName(asset.shortName)] = true;
      }
    }
    
    if (state && state.companyRegistry) {
      var reg = state.companyRegistry;
      
      var listed = reg.listedHistory || [];
      for (var i = 0; i < listed.length; i++) {
        used[normalizeName(listed[i] && listed[i].name)] = true;
        used[normalizeName(listed[i] && listed[i].shortName)] = true;
      }
      
      var delisted = reg.delistedHistory || [];
      for (var j = 0; j < delisted.length; j++) {
        used[normalizeName(delisted[j] && delisted[j].name)] = true;
        used[normalizeName(delisted[j] && delisted[j].shortName)] = true;
      }
    }
    
    return used;
  }
  
  function createUniqueCompanyName(state, industryId) {
    var used = collectUsedNames(state);
    
    for (var i = 0; i < 80; i++) {
      var shortName = buildShortName(industryId);
      var formalName = toFormalCompanyName(shortName);
      
      if (!used[normalizeName(shortName)] && !used[normalizeName(formalName)]) {
        return {
          shortName: shortName,
          fullName: formalName
        };
      }
    }
    
    // 極端情況：真的撞太多，最後加流水尾碼保證唯一
    var fallbackBase = buildShortName(industryId);
    var serial = randInt(10, 9999);
    var fallbackShort = fallbackBase + serial;
    return {
      shortName: fallbackShort,
      fullName: toFormalCompanyName(fallbackShort)
    };
  }
  
  function formatStockSymbol(prefix, serial) {
    prefix = String(prefix || "X").toUpperCase().replace(/[^A-Z]/g, "") || "X";
    serial = Math.max(1, Math.floor(Number(serial || 1)));
    return prefix + String(serial).padStart(4, "0");
  }

  function getUsedStockSymbols(state) {
    var used = Object.create(null);

    function mark(symbol) {
      symbol = String(symbol || "").toUpperCase();
      if (/^[A-Z][0-9]{4}$/.test(symbol)) used[symbol] = true;
    }

    if (state && state.assets) {
      for (var id in state.assets) {
        if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
        mark(state.assets[id] && state.assets[id].symbol);
      }
    }

    if (state && state.companyRegistry) {
      var pending = state.companyRegistry.pendingListings || [];
      for (var i = 0; i < pending.length; i++) {
        mark(pending[i] && pending[i].asset && pending[i].asset.symbol);
      }
    }

    return used;
  }

  function createCompanyCode(state, industryId) {
    industryId = String(industryId || "corp").toLowerCase();
    var prefix = industryId.slice(0, 3);
    
    var used = Object.create(null);
    if (state && state.assets) {
      for (var id in state.assets) {
        if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
        used[String(id)] = true;
      }
    }
    
    for (var i = 0; i < 80; i++) {
      var code = prefix + "_" + randInt(1000, 999999);
      if (!used[code]) return code;
    }
    
    return prefix + "_" + Date.now();
  }
  
  w.StockMarketNameGenerator = {
    PREFIX_POOL: PREFIX_POOL,
    CORE_POOL: CORE_POOL,
    EXTRA_POOL: EXTRA_POOL,
    SUFFIX_BY_INDUSTRY: SUFFIX_BY_INDUSTRY,
    
    buildShortName: buildShortName,
    toFormalCompanyName: toFormalCompanyName,
    collectUsedNames: collectUsedNames,
    createUniqueCompanyName: createUniqueCompanyName,
    getUsedStockSymbols: getUsedStockSymbols,
    formatStockSymbol: formatStockSymbol,
    createCompanyCode: createCompanyCode
  };
})(window);