// ETFV2 UI Adapter 7.2.0
(function(w){
  "use strict";
  w.ETFUIAdapter = {
    get: function(id){
      return w.UniversalETF && w.UniversalETF.getUIData
        ? w.UniversalETF.getUIData(id || "guild_leader_fund")
        : null;
    }
  };
})(window);
