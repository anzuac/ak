// ETFV2 Passive ETF Engine
(function(w){
  "use strict";

  var Engine = {

    update: function(fund){

      if(!fund) return;

      // 被動ETF維持原有邏輯標記
      fund.engineType = "passive";

      // 允許配息
      fund.dividendEnabled = true;

      // 保持滿倉模式
      fund.targetHoldingMode = "full";
    }

  };

  w.PassiveETFEngine = Engine;

})(window);
