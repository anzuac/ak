var STOCK_FEE_RATE = 0.0015;


// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================


// ===== REAL_WORLD_FREEZE_MODE =====
// 玩家離線時世界停止運作
function applyRealWorldFreeze(state) {

  if (!state) return;

  // 重新同步時間
  state.lastTs = Date.now();

  // 清空累積tick
  state.tickRemainderSec = 0;

  // 標記
  state.realWorldFreeze = true;
}
// ===== END =====



// ===== 官股國家隊穩定基金系統 =====
function processGovernmentStabilization(stock) {

  if (!stock) return;

  // 僅 A 開頭官股
  var code =
    String(stock.symbol || stock.code || "");

  if (!code.startsWith("A")) {
    return;
  }

  // 初始化國家基金
  if (!stock.stabilizationFund) {
    stock.stabilizationFund = 80000000000;
  }

  // 合理價格（初始價格）
  if (!stock.fairValue) {
    stock.fairValue =
      Number(stock.initialPrice || stock.price || 1);
  }

  // 國家持股（永久鎖定）
  if (!stock.governmentHoldings) {
    stock.governmentHoldings =
      Math.floor(
        Number(stock.sharesOutstanding || 1) * 0.45
      );
  }

  var price =
    Number(stock.price || 1);

  var fairValue =
    Number(stock.fairValue || 1);

  // 價格偏離
  var deviation =
    (price - fairValue) / fairValue;

  // 跌停與漲停紀錄
  stock.downLimitDays =
    Number(stock.downLimitDays || 0);

  stock.upLimitDays =
    Number(stock.upLimitDays || 0);

  // ===== 護盤 =====

  var shouldSupport = false;

  // 低於合理價60%
  if (price <= fairValue * 0.40) {
    shouldSupport = true;
  }

  // 連跌停 3~5 天
  if (stock.downLimitDays >= 3) {
    shouldSupport = true;
  }

  if (
    shouldSupport &&
    stock.stabilizationFund > 1000000
  ) {

    // 國家隊買盤
    var supportBudget =
      stock.stabilizationFund *
      (0.002 + Math.random() * 0.006);

    stock.stabilizationFund -=
      supportBudget;

    // 增加流動性與買盤
    stock.npcDailyVolume =
      Math.floor(
        Number(stock.npcDailyVolume || 1) *
        1.18
      );

    // 緩慢拉升
    stock.price *=
      (1 + 0.006 + Math.random() * 0.02);

    stock.lastGovernmentAction =
      "國家隊進場護盤";
  }

  // ===== 過熱降溫 =====

  var shouldCool = false;

  // 超過初始價100%
  if (price >= fairValue * 2) {
    shouldCool = true;
  }

  // 連漲停
  if (stock.upLimitDays >= 3) {
    shouldCool = true;
  }

  if (
    shouldCool &&
    Number(stock.governmentHoldings || 0) > 0
  ) {

    // 政府賣出部分持股
    var sellRatio =
      0.002 + Math.random() * 0.008;

    var sellAmount =
      Math.floor(
        stock.governmentHoldings *
        sellRatio
      );

    stock.governmentHoldings -= sellAmount;

    // 回收資金
    var recovered =
      sellAmount * price;

    stock.stabilizationFund += recovered;

    // 增加市場流通量
    stock.publicFloatShares =
      Math.floor(
        Number(stock.publicFloatShares || 0)
        + sellAmount
      );

    stock.availableShares =
      Math.floor(
        Number(stock.availableShares || 0)
        + sellAmount * 0.85
      );

    // 壓制過熱
    stock.price *=
      (1 - 0.004 - Math.random() * 0.015);

    stock.lastGovernmentAction =
      "國家隊賣出降溫";
  }

  // 防止基金過低
  stock.stabilizationFund =
    Math.max(
      500000000,
      stock.stabilizationFund
    );
}
// ===== END =====


// ===== 董事會防禦與釋股系統 =====
function processBoardDefense(company, playerShares) {

  if (!company) return;

  var totalShares =
    Number(company.sharesOutstanding || 1);

  var ownership =
    playerShares / totalShares;

  company.playerOwnershipRatio = ownership;

  // 10% 開始討論增發
  if (ownership >= 9999) {

    company.boardAlertLevel = "watch";

    // 小機率啟動增發
    if (Math.random() < 0.015) {

      var issueRatio =
        0.03 + Math.random() * 0.08;

      var addShares =
        Math.floor(totalShares * issueRatio);

      var maxShares =
        Number(
          company.maxSharesOutstanding ||
          totalShares * 4
        );

      company.sharesOutstanding =
        Math.min(
          totalShares + addShares,
          maxShares
        );

      company.publicFloatShares =
        Math.floor(
          company.sharesOutstanding * 0.72
        );

      company.lastBoardAction =
        "董事會討論增發股票";
    }
  }

  // 25% 啟動防禦釋股
  if (ownership >= 0.25) {

    company.boardAlertLevel = "defense";

    // 釋放鎖倉股
    var lockedShares =
      Number(company.lockedShares || 0);

    if (lockedShares > 0) {

      var releaseAmount =
        Math.floor(
          lockedShares *
          (0.08 + Math.random() * 0.18)
        );

      company.lockedShares =
        Math.max(
          0,
          lockedShares - releaseAmount
        );

      company.publicFloatShares =
        Number(company.publicFloatShares || 0)
        + releaseAmount;

      company.availableShares =
        Number(company.availableShares || 0)
        + Math.floor(releaseAmount * 0.8);

      company.liquidity =
        Math.floor(
          Number(company.liquidity || 1) * 1.12
        );

      company.lastBoardAction =
        "董事會釋出鎖倉股";
    }
  }
}
// ===== END =====


// ===== 公司自動增發系統 =====
function processAutoShareIssuance(company) {

  if (!company) return;

  // 初始最大增發上限（最多變成原始股數 4 倍）
  if (!company.initialSharesOutstanding) {
    company.initialSharesOutstanding =
      Number(company.sharesOutstanding || 0);
  }

  if (!company.maxSharesOutstanding) {
    company.maxSharesOutstanding =
      Math.floor(company.initialSharesOutstanding * 4);
  }

  // 已達上限
  if (
    Number(company.sharesOutstanding || 0) >=
    Number(company.maxSharesOutstanding || 0)
  ) {
    return;
  }

  // 僅高熱度或高股價公司較容易增發
  var hotLevel =
    Number(company.marketHeat || 0);

  var price =
    Number(company.price || company.sharePrice || 0);

  var growthChance = 0;

  if (price >= 180) growthChance += 0.015;
  if (price >= 300) growthChance += 0.025;
  if (hotLevel >= 70) growthChance += 0.02;

  // 每日小機率檢查
  if (Math.random() > growthChance) {
    return;
  }

  // 本次增發比例（3%~12%）
  var issueRatio =
    0.03 + Math.random() * 0.09;

  var currentShares =
    Number(company.sharesOutstanding || 0);

  var issueAmount =
    Math.floor(currentShares * issueRatio);

  var nextShares =
    Math.min(
      currentShares + issueAmount,
      company.maxSharesOutstanding
    );

  // 實際增發
  company.sharesOutstanding = nextShares;

  // 提高市場流動性
  company.publicFloatShares =
    Math.floor(nextShares * 0.58);

  company.availableShares =
    Math.floor(nextShares * 0.48);

  // 市場深度同步提升
  company.liquidity =
    Math.floor(
      Number(company.liquidity || 1) *
      (1 + issueRatio * 0.65)
    );

  // NPC 市場量增加
  company.npcDailyVolume =
    Math.floor(
      Number(company.npcDailyVolume || 1) *
      (1 + issueRatio * 0.8)
    );

  // 增發後股價微幅稀釋
  if (company.price) {
    company.price *=
      (1 - issueRatio * 0.35);
  }

  company.lastShareIssueRatio = issueRatio;
}
// ===== 公司自動增發系統 END =====


// V4.2.1 開盤前事件預留
(function (w) {
  "use strict";

  function applyCentralMarketLimitToAsset(asset, nextPrice){
    nextPrice = Math.max(1, Math.floor(Number(nextPrice || 1)));

    if(
      window.AI5MarketControl &&
      typeof window.AI5MarketControl.applyMarketLimitClamp === "function"
    ){
      return Math.max(
        1,
        Math.floor(
          window.AI5MarketControl.applyMarketLimitClamp(
            asset,
            nextPrice
          )
        )
      );
    }

    return nextPrice;
  }

  if (
    !w.StockMarketAssets ||
    !w.StockMarketClimate ||
    !w.StockMarketCurrency ||
    !w.StockMarketEvents ||
    !w.StockMarketCompanyDynamics ||
    !w.StockMarketRegistry
  ) {
    console.error("❌ stock_market_engine.js: 缺少依賴模組");
    return;
  }

  
// =====================================================
// AI5.0.0 Governance Layer
// Base: 4.0.0 Stable Runtime
//
// Fixes:
// - Frozen Auction no longer moves prices
// - AI converted into market sentiment layer
// - Reduced drift / volatility amplification
// - Reduced liquidity destruction
// - Original runtime preserved
// =====================================================


// =====================================================
// AI5 Dynamic Valuation Layer
//
// AI no longer uses aggressive fixed-price anchoring.
// Market corrections now depend more on:
//
// - growth momentum
// - emotional overheating
// - volatility spikes
// - rapid acceleration
//
// instead of absolute price level.
//
// Long-term market growth bias preserved.
// =====================================================


// =====================================================
// AI5.1.1 Tick Rate System
//
// Allows dynamic market speed control.
//
// Example:
// w.MARKET_TICK_RATE = 5;
//
// Result:
// 5 ticks per second.
//
// Safe runtime multiplier.
// No runtime restructuring performed.
// =====================================================

var MARKET_CONTROL = w.AI5MarketControl || null;
  var MARKET_CONFIG = MARKET_CONTROL ? MARKET_CONTROL.config : {};

  var TICK_SEC = Number(MARKET_CONFIG.TICK_SEC || 1);
  var TICK_RATE = Number(MARKET_CONFIG.TICK_RATE || 1); // 每秒 Tick 數（市場速度倍率）
  w.MARKET_TICK_RATE = TICK_RATE;
  var HEAVY_UPDATE_SEC = Number(MARKET_CONFIG.HEAVY_UPDATE_SEC || 1); // 每秒更新價格
  var ASSET_BATCH_SIZE = Number(MARKET_CONFIG.ASSET_BATCH_SIZE || 999999); // 保留相容用；runTick 會改成每秒全市場更新
  var MARKET_PREOPEN_SEC = Number(MARKET_CONFIG.MARKET_PREOPEN_SEC || 50);
  var MARKET_OPEN_SEC = Number(MARKET_CONFIG.MARKET_OPEN_SEC || 10);
  var MARKET_CLOSE_SEC = Number(MARKET_CONFIG.MARKET_CLOSE_SEC || 5);
  var MAX_OFFLINE_TICKS = Number(MARKET_CONFIG.MAX_OFFLINE_TICKS || 7200);
  var PRICE_FLOOR = Number(MARKET_CONFIG.PRICE_FLOOR || 1);
  var SCALE = w.StockMarketAssets.SCALE || 1000;

  var BUY_FEE_RATE = Number(MARKET_CONFIG.BUY_FEE_RATE || 0.005);
  var SELL_FEE_RATE = Number(MARKET_CONFIG.SELL_FEE_RATE || 0.005);
  var SELL_TAX_RATE = Number(MARKET_CONFIG.SELL_TAX_RATE || 0.003);
  var DIVIDEND_CYCLE_DAYS = Number(MARKET_CONFIG.DIVIDEND_CYCLE_DAYS || 30);
  var DIVIDEND_ANNOUNCE_DAY = Number(MARKET_CONFIG.DIVIDEND_ANNOUNCE_DAY || 25);
  var DIVIDEND_TIME_SCALE = Number(MARKET_CONFIG.DIVIDEND_TIME_SCALE || (1 / 12));


// =====================================================
// AI5.4.2 Global Market Limit Config
// 0 = Unlimited
// =====================================================

var MARKET_LIMITS = MARKET_CONFIG.limits || {

  normal: {
    up: 0.10,
    down: 0.10
  },

  kingdom: {
    up: 0.20,
    down: 0.20
  },

  etf: {
    up: 0.30,
    down: 0.30
  }

};

window.MARKET_LIMITS = MARKET_LIMITS;



  
  // [OPTIMIZED]
  // Lazy 市值計算
  function getLazyMarketCap(asset) {
    return getEconomicMarketCapMilli(asset);
  }

  // =====================================================
  // 異世界公司背景市值
  // -----------------------------------------------------
  // 市值不再由「股價 × 股數」即時推導。
  // 它代表公司在異世界經濟中的規模與權重，主要供：
  // - 加權指數
  // - 股利能力
  // - 世界經濟展示
  // 使用。股價仍由市場情緒、事件與玩家交易即時推動。
  // =====================================================
  function getEconomicMarketCapMilli(asset) {
    if (!asset) return 0;

    var cm = asset.companyMetrics || {};
    var saved =
      Number(cm.economicMarketCapMilli || cm.marketCapMilli || asset.economicMarketCapMilli || asset.marketCapMilli || 0);

    if (saved > 0) return Math.floor(saved);

    return computeEconomicMarketCapMilli(asset, null, cm);
  }


  // =====================================================
  // [ANCHOR PRICE MODEL]
  // 股價長期均值 / 短期情緒偏移模型
  // -----------------------------------------------------
  // anchorPriceMilli：公司長期市場認知均值，低頻/月更。
  // marketOffset：短期情緒、事件、玩家交易造成的偏離，高頻/tick。
  // 股價 = anchorPriceMilli * marketOffset。
  // 沒事件時 offset 會逐步回到 1；事件會短期推動 offset，
  // 少部分事件殘留會在公司月更時寫入 anchor。
  // =====================================================
  function getOffsetBoundsForAsset(asset) {
    var ci = asset && asset.companyInfo ? asset.companyInfo : {};
    var hype = clamp(Number(ci.hype || 0.25), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var risk = Number(asset && asset.risk || ci.risk || 1);
    var tier = String(asset && asset.tier || "middle");

    var min = 0.62;
    var max = 1.72;

    if (tier === "large") {
      min = 0.72;
      max = 1.45;
    } else if (tier === "small") {
      min = 0.42;
      max = 2.65;
    }

    max += hype * 0.55 + Math.max(0, risk - 1) * 0.10;
    min -= hype * 0.10 + Math.max(0, risk - 1) * 0.035;

    // 穩定公司較不容易成為妖股，也較不容易腰斬。
    max -= stability * 0.20;
    min += stability * 0.08;

    return {
      min: clamp(min, 0.30, 0.90),
      max: clamp(max, 1.20, 3.40)
    };
  }

  function getAnchorPriceMilli(asset) {
    if (!asset) return PRICE_FLOOR;
    var anchor = Math.floor(Number(asset.anchorPriceMilli || asset.longTermAnchorPriceMilli || asset.basePrice || asset.startPrice || asset.meanPrice || asset.price || PRICE_FLOOR));
    return Math.max(PRICE_FLOOR, anchor);
  }

  function ensureAnchorPriceState(asset) {
    if (!asset) return PRICE_FLOOR;
    var anchor = getAnchorPriceMilli(asset);
    if (!(Number(asset.anchorPriceMilli) > 0)) asset.anchorPriceMilli = anchor;
    if (!(Number(asset.longTermAnchorPriceMilli) > 0)) asset.longTermAnchorPriceMilli = anchor;

    var price = Math.max(PRICE_FLOOR, Number(asset.price || anchor));
    var bounds = getOffsetBoundsForAsset(asset);
    var offset = Number(asset.marketOffset || 0);
    if (!(offset > 0)) offset = price / Math.max(1, anchor);
    asset.marketOffset = clamp(offset, bounds.min, bounds.max);
    asset._lastFairValue = anchor;
    return anchor;
  }

  function applyAnchorBoundToPrice(asset, candidatePrice) {
    var anchor = ensureAnchorPriceState(asset);
    var bounds = getOffsetBoundsForAsset(asset);
    var minPrice = Math.max(PRICE_FLOOR, Math.floor(anchor * bounds.min));
    var maxPrice = Math.max(minPrice + 1, Math.floor(anchor * bounds.max));
    var next = Math.floor(Number(candidatePrice || anchor));
    next = clamp(next, minPrice, maxPrice);
    asset.marketOffset = clamp(next / Math.max(1, anchor), bounds.min, bounds.max);
    return Math.max(PRICE_FLOOR, Math.floor(next));
  }

  function updateAssetAnchorFromBusiness(state, asset) {
    if (!asset) return;
    var anchor = ensureAnchorPriceState(asset);
    var ci = asset.companyInfo || {};
    var cm = asset.companyMetrics || {};
    var meta = state ? getCombinedNarrativeMetaForAsset(state, asset.id) : null;

    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.25), 0, 1);
    var profit = Number(cm.profitMonthlyMilli || ci.profitBaseMilli || 0);
    var revenue = Math.max(1, Number(cm.revenueMonthlyMilli || ci.revenueBaseMilli || 1));
    var profitRate = clamp(profit / revenue, -0.40, 0.50);

    var confidenceImpact = meta ? Number(meta.confidenceImpact || 0) : 0;
    var eventBias = state ? Number((getCombinedNarrativeEffectForAsset(state, asset.id) || {}).bias || 0) : 0;
    var shortPressure = meta ? Number(meta.shortPressureBoost || 0) : 0;
    var panic = meta ? Number(meta.npcPanicSellBoost || 0) : 0;

    // 平時只有極小幅長期漂移；事件是 anchor 上修/下修的導火索。
    var organicGrowth =
      0.0012 +
      (quality - 0.5) * 0.006 +
      (stability - 0.5) * 0.002 +
      (hype - 0.35) * 0.003 +
      clamp((profitRate - 0.08) * 0.030, -0.006, 0.010);

    var eventResidual =
      clamp(eventBias * 0.050, -0.090, 0.120) +
      clamp(confidenceImpact * 0.018, -0.080, 0.080) -
      clamp(shortPressure * 0.012, 0, 0.080) -
      clamp(panic * 0.010, 0, 0.070);

    var noise = rand(-0.0020, 0.0035);
    var growth = clamp(organicGrowth + eventResidual + noise, -0.16, 0.22);

    // 高穩定公司不容易因單次事件劇烈改變長期均值。
    growth *= (1 - stability * 0.28);

    var nextAnchor = Math.max(PRICE_FLOOR, Math.floor(anchor * (1 + growth)));
    asset.anchorPriceMilli = nextAnchor;
    asset.longTermAnchorPriceMilli = nextAnchor;
    asset.basePrice = Math.max(PRICE_FLOOR, Math.floor(lerp(Number(asset.basePrice || anchor), nextAnchor, 0.35)));
    asset.meanPrice = Math.max(PRICE_FLOOR, Math.floor(lerp(Number(asset.meanPrice || anchor), nextAnchor, 0.20)));
    asset._lastAnchorGrowth = growth;
    asset._lastAnchorUpdateDay = state ? Math.max(1, Math.floor(Number(state.marketDay || 1))) : Number(asset._lastAnchorUpdateDay || 0);

    // anchor 被下修/上修後，短期 offset 保留，但不允許超出該公司合理偏離範圍。
    applyAnchorBoundToPrice(asset, Number(asset.price || nextAnchor));
  }

  function computeEconomicMarketCapMilli(asset, state, metrics) {
    if (!asset) return 0;

    var ci = asset.companyInfo || {};
    var cm = metrics || asset.companyMetrics || {};
    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);

    var baseAssets = Math.max(0, Number(ci.assetBaseMilli || cm.assetsMilli || 0));
    var revenue = Math.max(0, Number(cm.revenueMonthlyMilli || ci.revenueBaseMilli || 0));
    var profit = Math.max(0, Number(cm.profitMonthlyMilli || ci.profitBaseMilli || 0));

    var tierScale =
      asset.tier === "large" ? 1.45 :
      asset.tier === "small" ? 0.72 :
      1.00;

    var styleScale =
      asset.style === "B" ? 1.06 : 1.00;

    var reputationScale =
      0.82 +
      quality * 0.28 +
      stability * 0.20 +
      hype * 0.10;

    // 背景市值採公司規模 + 營運能力估算，不讀取即時股價。
    var cap =
      baseAssets * 1.00 +
      revenue * 6.00 +
      profit * 18.00;

    if (!(cap > 0)) {
      var fallbackPrice = Math.max(PRICE_FLOOR, Number(asset.startPrice || asset.basePrice || asset.price || 1));
      var fallbackShares = Math.max(1, Number(asset.totalShares || asset.floatShares || asset.sharesOutstanding || 1));
      cap = fallbackPrice * fallbackShares;
    }

    return Math.max(1, Math.floor(cap * tierScale * styleScale * reputationScale));
  }

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function rand(min, max) { return min + Math.random() * (max - min); }
  function lerp(a, b, t) { return a + (b - a) * t; }


  // =====================================================
  // F4.2.1 流通份額影響股價
  // =====================================================
  
  // =====================================================
  // F4.4 排隊委託系統
  // =====================================================

  function shouldEnterQueueOrder(asset, side){
    if(!asset) return false;

    var floatShares =
      Math.max(
        1,
        Number(asset.floatShares || asset.totalShares || 1)
      );

    var available =
      Math.max(
        0,
        Number(asset.availableShares || 0)
      );

    var liquidityRatio =
      available / floatShares;

    var limitUp =
      !!AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).upLocked;

    var limitDown =
      !!AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).downLocked;

    // 漲停買進排隊
    if(side === "buy" && limitUp){
      return true;
    }

    // 跌停賣出排隊
    if(side === "sell" && limitDown){
      return true;
    }

    // 流動性不足
    if(liquidityRatio < 0.015){
      return Math.random() < 0.72;
    }

    if(liquidityRatio < 0.03){
      return Math.random() < 0.45;
    }

    return false;
  }

function getLiquidityPriceDamping(asset){
    if(!asset) return 1;

    var shares =
      Math.max(
        1,
        Number(asset.floatShares || asset.totalShares || asset.availableShares || 1)
      );

    var lots = shares / 1000;

    // 流通越大，價格越不容易被單次資金流推動。
    if(lots >= 100000000) return 0.18;
    if(lots >= 50000000) return 0.25;
    if(lots >= 10000000) return 0.38;
    if(lots >= 3000000) return 0.55;
    if(lots >= 1000000) return 0.75;

    return 1.00;
  }


  function getPriceStepFromMilli(priceMilli) {
    if (w.AI5MarketControl && typeof w.AI5MarketControl.getPriceStepFromMilli === "function") {
      return w.AI5MarketControl.getPriceStepFromMilli(priceMilli, SCALE);
    }

    return Math.floor(0.01 * SCALE);
  }


  function forceQuantizedPriceMilli(priceMilli){
    return quantizePriceMilli(
      Math.max(
        PRICE_FLOOR,
        Math.floor(Number(priceMilli || PRICE_FLOOR))
      )
    );
  }


  function quantizePriceMilli(priceMilli) {
    var step = Math.max(1, getPriceStepFromMilli(priceMilli));
    return Math.max(PRICE_FLOOR, Math.round(Number(priceMilli || 0) / step) * step);
  }

  // 依照股價級距強制跳動：只要本次計算方向有變，就至少跳一個合法 tick。
  // 這避免「內部變動 0.3，但還沒累積到 0.5 / 1.0 所以畫面不動」的感覺。
  function applyPriceTickRule(oldPrice, rawPrice) {
    oldPrice = Math.max(PRICE_FLOOR, Math.floor(Number(oldPrice || PRICE_FLOOR)));
    rawPrice = Math.max(PRICE_FLOOR, Number(rawPrice || oldPrice));

    var step = Math.max(1, getPriceStepFromMilli(oldPrice));
    var dir = rawPrice > oldPrice ? 1 : (rawPrice < oldPrice ? -1 : 0);
    if (!dir) return oldPrice;

    var q = dir > 0
      ? Math.ceil(rawPrice / step) * step
      : Math.floor(rawPrice / step) * step;

    // 如果 rawPrice 的變化小到還落在同一個價位，仍然依方向跳一格。
    if (q === oldPrice) q = oldPrice + dir * step;

    return Math.max(PRICE_FLOOR, Math.floor(q));
  }

  function getTierProfile(asset) {
    var tier = String(asset.tier || "mid");
    var style = String(asset.style || "A");

    if (tier === "large") {
      return {
        baseMarketFlowRate: style === "A" ? 0.00070 : 0.00078,
        randomFlowRate: style === "A" ? 0.00105 : 0.00118,
        insiderReleaseRate: 0,
        coreReleaseRate: style === "A" ? 0.00002 : 0.00003,
        tradeReleaseRate: style === "A" ? 0.00022 : 0.00028,
        tradeAbsorbRate: style === "A" ? 0.00020 : 0.00024,
        depthFactor: style === "A" ? 0.70 : 0.76,
        pressureWeight: style === "A" ? 0.54 : 0.62,
        noiseFactor: style === "A" ? 0.72 : 0.82,
        meanRevert: style === "A" ? 0.055 : 0.048,
        anchorPull: style === "A" ? 0.030 : 0.035,
        momentumCarry: style === "A" ? 0.11 : 0.14,
        eventBoost: style === "A" ? 1.9 : 2.2,
        playerControlSuppress: style === "A" ? 0.72 : 0.82,
        minInsiderHoldRatio: style === "A" ? 0.24 : 0.18,
        minCoreHoldRatio: style === "A" ? 0.16 : 0.12,
        dividendYieldRange: style === "A" ? [0.0010, 0.0040] : [0.0008, 0.0035],
        playerImpactStrength: style === "A" ? 0.22 : 0.26,
        playerFairShift: style === "A" ? 0.010 : 0.012
      };
    }

    if (tier === "small") {
      return {
        baseMarketFlowRate: style === "A" ? 0.00018 : 0.00014,
        randomFlowRate: style === "A" ? 0.00280 : 0.00320,
        insiderReleaseRate: 0,
        coreReleaseRate: style === "A" ? 0.00003 : 0.00002,
        tradeReleaseRate: style === "A" ? 0.00038 : 0.00044,
        tradeAbsorbRate: style === "A" ? 0.00034 : 0.00028,
        depthFactor: style === "A" ? 1.24 : 1.34,
        pressureWeight: style === "A" ? 0.90 : 1.00,
        noiseFactor: style === "A" ? 1.40 : 1.55,
        meanRevert: style === "A" ? 0.030 : 0.024,
        anchorPull: style === "A" ? 0.045 : 0.038,
        momentumCarry: style === "A" ? 0.22 : 0.26,
        eventBoost: style === "A" ? 3.0 : 3.4,
        playerControlSuppress: style === "A" ? 0.58 : 0.42,
        minInsiderHoldRatio: style === "A" ? 0.08 : 0.05,
        minCoreHoldRatio: style === "A" ? 0.08 : 0.04,
        dividendYieldRange: style === "A" ? [0.0000, 0.0120] : [0.0000, 0.0080],
        playerImpactStrength: style === "A" ? 0.62 : 0.72,
        playerFairShift: style === "A" ? 0.024 : 0.028
      };
    }

    return {
      baseMarketFlowRate: style === "A" ? 0.00042 : 0.00048,
      randomFlowRate: style === "A" ? 0.00170 : 0.00195,
      insiderReleaseRate: 0,
      coreReleaseRate: style === "A" ? 0.00003 : 0.00003,
      tradeReleaseRate: style === "A" ? 0.00028 : 0.00034,
      tradeAbsorbRate: style === "A" ? 0.00024 : 0.00022,
      depthFactor: style === "A" ? 0.96 : 1.02,
      pressureWeight: style === "A" ? 0.70 : 0.78,
      noiseFactor: style === "A" ? 1.00 : 1.12,
      meanRevert: style === "A" ? 0.040 : 0.034,
      anchorPull: style === "A" ? 0.040 : 0.036,
      momentumCarry: style === "A" ? 0.17 : 0.20,
      eventBoost: style === "A" ? 2.4 : 2.8,
      playerControlSuppress: style === "A" ? 0.64 : 0.52,
      minInsiderHoldRatio: style === "A" ? 0.14 : 0.10,
      minCoreHoldRatio: style === "A" ? 0.12 : 0.08,
      dividendYieldRange: style === "A" ? [0.0000, 0.0070] : [0.0000, 0.0055],
      playerImpactStrength: style === "A" ? 0.38 : 0.44,
      playerFairShift: style === "A" ? 0.016 : 0.020
    };
  }

  function ensureDividendState(state) {
    if (!state.dividend) {
      state.dividend = {
        cycleDay: 1,
        totalPaidMilli: 0,
        totalReceivedMilli: 0,
        history: [],
        pendingToday: false,
        lockedDividendPerShareByAsset: {},
        lockedAnnouncementMarketDay: 0
      };
    }
    if (!Array.isArray(state.dividend.history)) state.dividend.history = [];
    if (typeof state.dividend.cycleDay !== "number") state.dividend.cycleDay = 1;
    if (typeof state.dividend.totalPaidMilli !== "number") state.dividend.totalPaidMilli = 0;
    if (typeof state.dividend.totalReceivedMilli !== "number") state.dividend.totalReceivedMilli = 0;
    if (typeof state.dividend.pendingToday !== "boolean") state.dividend.pendingToday = false;
    if (!state.dividend.lockedDividendPerShareByAsset || typeof state.dividend.lockedDividendPerShareByAsset !== "object") {
      state.dividend.lockedDividendPerShareByAsset = {};
    }
    if (typeof state.dividend.lockedAnnouncementMarketDay !== "number") state.dividend.lockedAnnouncementMarketDay = 0;
    return state.dividend;
  }

  function isDividendAnnouncementPeriod(state) {
    ensureDividendState(state);
    return Number(state.dividend.cycleDay || 1) >= DIVIDEND_ANNOUNCE_DAY;
  }

  function resetDividendLocks(state) {
    ensureDividendState(state);
    state.dividend.lockedDividendPerShareByAsset = {};
    state.dividend.lockedAnnouncementMarketDay = 0;
  }

  function applyDividendLockToAsset(state, asset) {
    if (!state || !asset || !asset.companyMetrics) return;
    var div = ensureDividendState(state);

    // 公告日前仍可隨公司營運與股價變動預估；避免上一季鎖定值污染新季度。
    if (!isDividendAnnouncementPeriod(state)) {
      if (!div.pendingToday && div.lockedAnnouncementMarketDay) resetDividendLocks(state);
      return;
    }

    var id = asset.id;
    if (!id) return;
    var locked = div.lockedDividendPerShareByAsset;
    if (!Object.prototype.hasOwnProperty.call(locked, id)) {
      locked[id] = Math.max(0, Math.floor(Number(asset.companyMetrics.estimatedDividendPerShareMilli || 0)));
      div.lockedAnnouncementMarketDay = Math.max(1, Math.floor(Number(state.marketDay || 1)));
    }

    // 第 25 天公布後，到第 30 天結算前，畫面與實際發放都一律讀取鎖定值。
    asset.companyMetrics.estimatedDividendPerShareMilli = Math.max(0, Math.floor(Number(locked[id] || 0)));
  }

  function resolveAnchorPrice(asset) {
    if (!asset) return 1;
    var candidates = [
      asset.price,
      asset.basePrice,
      asset.meanPrice,
      asset.dayOpenPrice,
      asset.dayHighPrice,
      asset.dayLowPrice,
      asset.lastClosePrice,
      asset.ipoPriceMilli,
      asset._lastFairValue,
      asset.companyMetrics && asset.companyMetrics.estimatedDividendPerShareMilli ? Number(asset.companyMetrics.estimatedDividendPerShareMilli) * 40 : 0
    ];
    for (var i = 0; i < candidates.length; i++) {
      var v = Math.floor(Number(candidates[i] || 0));
      if (v > 0) return v;
    }
    return 1;
  }

  function repairAssetPriceFields(asset) {
    if (!asset) return;
    var anchor = resolveAnchorPrice(asset);
    if (!(Number(asset.price) > 0)) asset.price = anchor;
    if (!(Number(asset.basePrice) > 0)) asset.basePrice = anchor;
    if (!(Number(asset.meanPrice) > 0)) asset.meanPrice = anchor;
    if (!(Number(asset.dayOpenPrice) > 0)) asset.dayOpenPrice = anchor;
    if (!(Number(asset.dayHighPrice) > 0)) asset.dayHighPrice = Math.max(anchor, Number(asset.price || anchor));
    if (!(Number(asset.dayLowPrice) > 0)) asset.dayLowPrice = Math.min(anchor, Number(asset.price || anchor));
    if (!(Number(asset.lastClosePrice) > 0)) asset.lastClosePrice = anchor;
    if (!(Number(asset.ipoPriceMilli) > 0)) asset.ipoPriceMilli = anchor;
    if (!(Number(asset._lastFairValue) > 0)) asset._lastFairValue = Math.max(anchor, Number(asset.basePrice || anchor));
    if (!(Number(asset.anchorPriceMilli) > 0)) asset.anchorPriceMilli = Math.max(anchor, Number(asset.basePrice || anchor));
    if (!(Number(asset.longTermAnchorPriceMilli) > 0)) asset.longTermAnchorPriceMilli = asset.anchorPriceMilli;
    ensureAnchorPriceState(asset);
    if (Number(asset.dayHighPrice || 0) < Number(asset.price || 0)) asset.dayHighPrice = Number(asset.price || 0);
    if (Number(asset.dayLowPrice || 0) > Number(asset.price || 0)) asset.dayLowPrice = Number(asset.price || 0);
  }

  function ensureState(state) {
    if (!state.assets) state.assets = w.StockMarketAssets.createRuntimeAssets();
    if (!state.portfolio) state.portfolio = {};
    if (!state.news) state.news = [];
    if (!state.pendingTradeOrders || typeof state.pendingTradeOrders !== "object") state.pendingTradeOrders = {};
    if (!state.stats) {
      state.stats = {
        totalTicks: 0,
        totalBuysMilli: 0,
        totalSellsMilli: 0,
        realizedProfitMilli: 0,
        totalFeesMilli: 0,
        totalTaxesMilli: 0
      };
    }
    if (!state.lastTs) state.lastTs = Date.now();
    if (!state.tickRemainderSec) state.tickRemainderSec = 0;
    if (typeof state.marketDay !== "number") state.marketDay = Math.max(1, Math.floor(Number((state.marketDay != null ? state.marketDay : (state.day != null ? state.day : (state.clock && state.clock.marketDay != null ? state.clock.marketDay : 1))))));
    if (typeof state.marketDayTick !== "number") state.marketDayTick = 0;
    if (!state.marketPhase) state.marketPhase = "preopen";
    if (typeof state.phaseElapsedSec !== "number") state.phaseElapsedSec = 0;
    if (!state.worldState) state.worldState = null;
    if (!state.shockState) state.shockState = null;
    if (!state.events) state.events = { active: [], history: [], nextId: 1 };
    if (!state.runtime) state.runtime = {};
    if (typeof state.runtime.assetBatchCursor !== "number") state.runtime.assetBatchCursor = 0;
    if (typeof state.runtime.heavyTickCursor !== "number") state.runtime.heavyTickCursor = 0;
    if (!Array.isArray(state.events.active) && Array.isArray(state.events.activeEvents)) state.events.active = state.events.activeEvents.slice();
    if (!Array.isArray(state.events.active)) state.events.active = [];
    delete state.events.activeEvents;
    delete state.day;
    if (state.clock && typeof state.clock === "object") delete state.clock.marketDay;

    w.StockMarketClimate.ensureClimate(state);
    w.StockMarketCurrency.ensureCurrency(state);
    w.StockMarketEvents.ensureEvents(state);
    w.StockMarketCompanyDynamics.ensureDynamics(state);
    w.StockMarketRegistry.ensureRegistry(state);
    if (w.StockMarketDisplay && w.StockMarketDisplay.ensureDisplayState) w.StockMarketDisplay.ensureDisplayState(state);
    ensureDividendState(state);

    if (state.companyRegistry && Array.isArray(state.companyRegistry.pendingListings) && w.StockMarketRegistry.completeGeneratedAsset) {
      for (var pi = 0; pi < state.companyRegistry.pendingListings.length; pi++) {
        if (!state.companyRegistry.pendingListings[pi] || !state.companyRegistry.pendingListings[pi].asset) continue;
        w.StockMarketRegistry.completeGeneratedAsset(state, state.companyRegistry.pendingListings[pi].asset);
      }
    }

    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (w.StockMarketRegistry.completeGeneratedAsset) w.StockMarketRegistry.completeGeneratedAsset(state, asset);
      ensureStarterTradableStructure(asset);
      ensureLiquidityModel(asset);
      repairAssetPriceFields(asset);

      if (!(Number(asset.startPrice) > 0)) asset.startPrice = asset.price || asset.basePrice || 1;
      if (asset.meanPrice == null) asset.meanPrice = asset.price || asset.basePrice || 1;
      if (MARKET_CONTROL) {
        var assetLimitType = MARKET_CONTROL.getAssetMarketType(asset);
        AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up = MARKET_CONTROL.getLimitRate(assetLimitType, "up", 0.10);
        AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down = MARKET_CONTROL.getLimitRate(assetLimitType, "down", 0.10);
      } else {
        if (!(Number(AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up) >= 0)) AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up = 0.10;
        if (!(Number(AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down) >= 0)) AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down = 0.10;
      }
      if (typeof asset.momentum !== "number") asset.momentum = 0;
      if (typeof asset.limitLocked !== "boolean") asset.limitLocked = false;
      // limit liquidity is reset only at new market day, not every state ensure.
      if (asset.limitType == null) asset.limitType = null;
      if (typeof asset._lastFlowRatio !== "number") asset._lastFlowRatio = 0;
      if (typeof asset._lastFairValue !== "number") asset._lastFairValue = asset.price || asset.basePrice || 1;
      ensureAnchorPriceState(asset);
      if (typeof asset.insiderShares !== "number") asset.insiderShares = 0;
      if (typeof asset.lockedShares !== "number") asset.lockedShares = 0;

      if (!asset.companyMetrics) {
        asset.companyMetrics = {
          assetsMilli: Math.max(0, Number(asset.companyInfo && asset.companyInfo.assetBaseMilli || 0)),
          revenueMonthlyMilli: Math.max(0, Number(asset.companyInfo && asset.companyInfo.revenueBaseMilli || 0)),
          profitMonthlyMilli: Math.max(0, Number(asset.companyInfo && asset.companyInfo.profitBaseMilli || 0)),
          estimatedDividendPerShareMilli: 0,
          lastDividendPerShareMilli: 0,
          avgVolume5: 0,
          avgVolume30: 0,
          latestDailyVolume: 0,
          basePayoutRatio: Math.max(0, Math.min(1, Number(asset.companyInfo && asset.companyInfo.payoutRatio || 0.2))),
          currentPayoutRatio: Math.max(0, Math.min(1, Number(asset.companyInfo && asset.companyInfo.payoutRatio || 0.2)))
        };
      } else {
        if (typeof asset.companyMetrics.basePayoutRatio !== "number") {
          asset.companyMetrics.basePayoutRatio = Math.max(0, Math.min(1, Number(asset.companyInfo && asset.companyInfo.payoutRatio || 0.2)));
        }
        if (typeof asset.companyMetrics.currentPayoutRatio !== "number") {
          asset.companyMetrics.currentPayoutRatio = Math.max(0, Math.min(1, Number(asset.companyMetrics.basePayoutRatio || 0.2)));
        }
      }

      if (!asset.companyInfo) asset.companyInfo = {};
      if (!(Number(asset.companyInfo.assetBaseMilli) > 0)) asset.companyInfo.assetBaseMilli = Math.max(0, Number(asset.companyMetrics.assetsMilli || 0));
      if (!(Number(asset.companyInfo.revenueBaseMilli) > 0)) asset.companyInfo.revenueBaseMilli = Math.max(0, Number(asset.companyMetrics.revenueMonthlyMilli || 0));
      if (!(Number(asset.companyInfo.profitBaseMilli) > 0)) asset.companyInfo.profitBaseMilli = Math.max(0, Number(asset.companyMetrics.profitMonthlyMilli || 0));
      if (!(Number(asset.companyInfo.payoutRatio) > 0)) asset.companyInfo.payoutRatio = Math.max(0.02, Math.min(0.75, Number(asset.companyMetrics.currentPayoutRatio || asset.companyMetrics.basePayoutRatio || 0.2)));

      if (!Array.isArray(asset.trendHistory)) asset.trendHistory = [];
      if (!Array.isArray(asset.volumeHistory)) asset.volumeHistory = [];

      if (typeof asset.playerImpactBuy !== "number") asset.playerImpactBuy = 0;
      if (typeof asset.playerImpactSell !== "number") asset.playerImpactSell = 0;
      if (typeof asset.playerImpactDecay !== "number") asset.playerImpactDecay = 0.92;
      if (typeof asset.playerRecentNetFlow !== "number") asset.playerRecentNetFlow = 0;
      if (typeof asset._lastPlayerTradeImpact !== "number") asset._lastPlayerTradeImpact = 0;
    }

    return state;
  }

  function createDefaultState() {
    var state = {
      _ver: 18,
      lastTs: Date.now(),
      tickRemainderSec: 0,
      marketDay: 1,
      marketDayTick: 0,
      marketPhase: "preopen",
      phaseElapsedSec: 0,
      worldState: null,
      shockState: null,
      assets: w.StockMarketAssets.createRuntimeAssets(),
      portfolio: {},
      news: [{
        ts: Date.now(),
        title: "市場進入開盤前撮合",
        detail: "市場已進入撮合階段，價格會先行波動，但正式開市前暫時無法交易。",
        tone: "neutral"
      }],
      stats: {
        totalTicks: 0,
        totalBuysMilli: 0,
        totalSellsMilli: 0,
        realizedProfitMilli: 0,
        totalFeesMilli: 0,
        totalTaxesMilli: 0
      }
    };
    ensureState(state);
    rollWorldState(state, true);
    refreshAllEstimatedDividends(state);
    return state;
  }

  function pushNews(state, title, detail, tone) {
    state.news.unshift({
      ts: Date.now(),
      title: String(title || ""),
      detail: String(detail || ""),
      tone: tone || "neutral"
    });
    if (state.news.length > 120) state.news.length = 120;
  }

  function getHolding(state, assetId) {
    var h = state.portfolio[assetId];
    if (!h) return { qty: 0, avgCostMilli: 0 };
    return {
      qty: Math.max(0, Math.floor(Number(h.qty || 0))),
      avgCostMilli: Math.max(0, Math.floor(Number(h.avgCostMilli || 0)))
    };
  }

  function setHolding(state, assetId, qty, avgCostMilli) {
    qty = Math.max(0, Math.floor(Number(qty || 0)));
    avgCostMilli = Math.max(0, Math.floor(Number(avgCostMilli || 0)));
    if (qty <= 0) {
      delete state.portfolio[assetId];
      return;
    }
    state.portfolio[assetId] = { qty: qty, avgCostMilli: avgCostMilli };
  }

  function getSecondsToNextTick(state) {
    ensureState(state);
    var rem = Math.max(0, Number(state.tickRemainderSec || 0));
    var left = TICK_SEC - rem;
    return left <= 0 ? TICK_SEC : Math.ceil(left);
  }

  function getSecondsToPhaseEnd(state) {
    ensureState(state);
    var total = MARKET_CLOSE_SEC;
    if (state.marketPhase === "preopen") total = MARKET_PREOPEN_SEC;
    else if (state.marketPhase === "open") total = MARKET_OPEN_SEC;
    return Math.max(0, total - Number(state.phaseElapsedSec || 0));
  }

  function getSecondsToDayEnd(state) {
    ensureState(state);
    return state.marketPhase === "closed" ? 0 : getSecondsToPhaseEnd(state);
  }

  function isDividendSettlementDay(state) {
    ensureState(state);
    return !!state.dividend.pendingToday;
  }

  function calcOpenChangePct(asset) {
    if (!asset || !asset.dayOpenPrice) return 0;
    return ((Number(asset.price || 0) - Number(asset.dayOpenPrice || 0)) / Number(asset.dayOpenPrice || 1)) * 100;
  }

  function getPlayerControlRatio(state, assetId) {
    var asset = state.assets[assetId];
    if (!asset || asset.marketType !== "free") return 0;
    var h = getHolding(state, assetId);
    return clamp(h.qty / Math.max(1, Number(asset.floatShares || 1)), 0, 1);
  }

  function getPlayerControlLevel(state, assetId) {
    var ratio = getPlayerControlRatio(state, assetId);
    var concentrationLevel = "正常";
    var color = "#22c55e";
    if (ratio >= 0.80) {
      concentrationLevel = "控盤風險極高";
      color = "#ef4444";
    } else if (ratio >= 0.55) {
      concentrationLevel = "高度集中";
      color = "#f59e0b";
    } else if (ratio >= 0.35) {
      concentrationLevel = "偏集中";
      color = "#facc15";
    }

    var shareholderLevel = "普通投資人";
    if (ratio >= 0.50) shareholderLevel = "控股股東";
    else if (ratio >= 0.20) shareholderLevel = "關鍵股東";
    else if (ratio >= 0.10) shareholderLevel = "重要股東";
    else if (ratio >= 0.05) shareholderLevel = "主要股東";

    return {
      ratio: ratio,
      level: concentrationLevel,
      concentrationLevel: concentrationLevel,
      shareholderLevel: shareholderLevel,
      color: color
    };
  }

  function pushDailyTrend(asset, marketDay) {
    if (!asset) return;
    var record = {
      marketDay: Math.max(1, Math.floor(Number(marketDay || 1))),
      closePrice: Math.floor(Number(asset.price || 0)),
      volume: Math.floor(Number(asset.companyMetrics && asset.companyMetrics.latestDailyVolume || 0))
    };
    asset.trendHistory.push(record);
    if (asset.trendHistory.length > 30) asset.trendHistory.shift();

    asset.volumeHistory.push(record.volume);
    if (asset.volumeHistory.length > 30) asset.volumeHistory.shift();

    var sum5 = 0, sum30 = 0, i;
    for (i = Math.max(0, asset.volumeHistory.length - 5); i < asset.volumeHistory.length; i++) sum5 += Number(asset.volumeHistory[i] || 0);
    for (i = 0; i < asset.volumeHistory.length; i++) sum30 += Number(asset.volumeHistory[i] || 0);

    asset.companyMetrics.avgVolume5 = asset.volumeHistory.length ? Math.floor(sum5 / Math.max(1, Math.min(5, asset.volumeHistory.length))) : 0;
    asset.companyMetrics.avgVolume30 = asset.volumeHistory.length ? Math.floor(sum30 / asset.volumeHistory.length) : 0;
  }

  function getTrendPercent(asset, days) {
    if (!asset || !Array.isArray(asset.trendHistory) || !asset.trendHistory.length) return 0;
    var hist = asset.trendHistory;
    var idx = hist.length - Math.min(days, hist.length);
    var oldPrice = Math.max(1, Number(hist[idx].closePrice || asset.price || 1));
    var nowPrice = Math.max(1, Number(asset.price || oldPrice));
    return ((nowPrice - oldPrice) / oldPrice) * 100;
  }

  function getCombinedNarrativeEffectForAsset(state, assetId) {
    var evtEffect = w.StockMarketEvents.getCombinedEffectForAsset
      ? w.StockMarketEvents.getCombinedEffectForAsset(state, assetId)
      : { bias: 0, volatilityBonus: 0 };

    var dynEffect = w.StockMarketCompanyDynamics.getCombinedEffectForAsset
      ? w.StockMarketCompanyDynamics.getCombinedEffectForAsset(state, assetId)
      : { bias: 0, volatilityBonus: 0 };

    var ipoEffect = w.StockMarketRegistry.getUpcomingIpoEffectForAsset
      ? w.StockMarketRegistry.getUpcomingIpoEffectForAsset(state, assetId)
      : { bias: 0, volatilityBonus: 0 };

    return {
      bias: clamp(Number(evtEffect.bias || 0) + Number(dynEffect.bias || 0) + Number(ipoEffect.bias || 0), -0.16, 0.16),
      volatilityBonus: clamp(Number(evtEffect.volatilityBonus || 0) + Number(dynEffect.volatilityBonus || 0) + Number(ipoEffect.volatilityBonus || 0), 0, 0.04)
    };
  }

  function getCombinedNarrativeMetaForAsset(state, assetId) {
    var evtMeta = w.StockMarketEvents.getCombinedMetaForAsset
      ? w.StockMarketEvents.getCombinedMetaForAsset(state, assetId)
      : null;

    var dynMeta = w.StockMarketCompanyDynamics.getCombinedMetaForAsset
      ? w.StockMarketCompanyDynamics.getCombinedMetaForAsset(state, assetId)
      : null;

    var ipoMetaBundle = w.StockMarketRegistry.getUpcomingIpoEffectForAsset
      ? w.StockMarketRegistry.getUpcomingIpoEffectForAsset(state, assetId)
      : null;
    var ipoMeta = ipoMetaBundle ? ipoMetaBundle.meta : null;

    var out = {
      liquidityShift: 0,
      npcPanicSellBoost: 0,
      npcFomoBuyBoost: 0,
      strategicHoldingReleaseBoost: 0,
      npcAbsorbBoost: 0,
      shortPressureBoost: 0,
      confidenceImpact: 0,
      revenueAdjust: 0,
      profitAdjust: 0,
      payoutAdjust: 0
    };

    function apply(meta) {
      if (!meta) return;
      out.liquidityShift += Number(meta.liquidityShift || 0);
      out.npcPanicSellBoost += Number(meta.npcPanicSellBoost || 0);
      out.npcFomoBuyBoost += Number(meta.npcFomoBuyBoost || 0);
      out.strategicHoldingReleaseBoost += Number(meta.strategicHoldingReleaseBoost || 0);
      out.npcAbsorbBoost += Number(meta.npcAbsorbBoost || 0);
      out.shortPressureBoost += Number(meta.shortPressureBoost || 0);
      out.confidenceImpact += Number(meta.confidenceImpact || 0);
      out.revenueAdjust += Number(meta.revenueAdjust || 0);
      out.profitAdjust += Number(meta.profitAdjust || 0);
      out.payoutAdjust += Number(meta.payoutAdjust || 0);
    }

    apply(evtMeta);
    apply(dynMeta);
    apply(ipoMeta);

    out.liquidityShift = clamp(out.liquidityShift, -0.45, 0.45);
    out.npcPanicSellBoost = clamp(out.npcPanicSellBoost, 0, 2.5);
    out.npcFomoBuyBoost = clamp(out.npcFomoBuyBoost, 0, 2.5);
    out.strategicHoldingReleaseBoost = clamp(out.strategicHoldingReleaseBoost, 0, 1.6);
    out.npcAbsorbBoost = clamp(out.npcAbsorbBoost, 0, 1.6);
    out.shortPressureBoost = clamp(out.shortPressureBoost, -1.5, 2.2);
    out.confidenceImpact = clamp(out.confidenceImpact, -1.2, 1.2);
    out.revenueAdjust = clamp(out.revenueAdjust, -0.50, 0.50);
    out.profitAdjust = clamp(out.profitAdjust, -0.60, 0.60);
    out.payoutAdjust = clamp(out.payoutAdjust, -0.35, 0.35);

    return out;
  }

  function normalizeEquityShares(asset) {
    if (!asset) return asset;

    var strategic = Math.max(0, Math.floor(Number(asset.strategicHoldingShares || 0)));
    var marketMaker = Math.max(0, Math.floor(Number(asset.marketMakerShares || 0)));

    asset.strategicHoldingShares = strategic;
    asset.marketMakerShares = marketMaker;
    return asset;
  }

  function getStrategicHoldingShares(asset) {
    normalizeEquityShares(asset);
    return Math.max(0, Math.floor(Number(asset && asset.strategicHoldingShares || 0)));
  }

  function getMarketMakerShares(asset) {
    normalizeEquityShares(asset);
    return Math.max(0, Math.floor(Number(asset && asset.marketMakerShares || 0)));
  }


  // =========================================
  // F2.5.2 商會流通性核心
  // 40% 固定持股 / 60% 流通股 / 每日掛單池
  // =========================================
  function ensureLiquidityModel(asset) {
    if (!asset) return asset;

    var total = Math.max(1, Math.floor(Number(asset.totalShares || asset.floatShares || asset.availableShares || 1)));
    asset.totalShares = total;

    if (typeof asset.lockedRatio !== "number") asset.lockedRatio = 0.40;
    if (typeof asset.floatRatio !== "number") asset.floatRatio = 0.60;

    asset.lockedRatio = clamp(Number(asset.lockedRatio || 0.40), 0, 0.95);
    asset.floatRatio = clamp(Number(asset.floatRatio || 0.60), 0.05, 1);

    // 預設固定持股 40%，市場流通 60%。
    var locked = Math.floor(total * asset.lockedRatio);
    var floatShares = Math.max(1, total - locked);

    asset.lockedShares = locked;
    asset.floatShares = floatShares;

    // 不再讓 insider / strategic / marketMaker 加總回推 floatShares，避免總流通被玩家交易改寫。
    asset.insiderShares = Math.max(0, Math.floor(Number(asset.insiderShares || locked)));
    asset.strategicHoldingShares = Math.max(0, Math.floor(Number(asset.strategicHoldingShares || 0)));
    asset.marketMakerShares = Math.max(0, Math.floor(Number(asset.marketMakerShares || 0)));

    if (typeof asset.availableShares !== "number") asset.availableShares = 0;
    if (typeof asset.dailyBuyLiquidityShares !== "number") asset.dailyBuyLiquidityShares = 0;
    if (typeof asset.dayOpenSellLiquidityShares !== "number") asset.dayOpenSellLiquidityShares = Math.max(1, Math.floor(asset.availableShares || 1));
    if (typeof asset.dayOpenBuyLiquidityShares !== "number") asset.dayOpenBuyLiquidityShares = Math.max(1, Math.floor(asset.dailyBuyLiquidityShares || 1));

    return asset;
  }

  function resetDailyLiquidityPool(asset) {
    if (!asset || asset.marketType !== "free") return asset;

    ensureLiquidityModel(asset);

    var floatShares = Math.max(1, Math.floor(Number(asset.floatShares || 1)));

    // 每天只釋出流通股的一小部分作為市場掛單，模擬真實交易不會一次全放出來賣。
    var baseRatio = rand(0.0005, 0.0030);
    if (asset.tier === "large") baseRatio *= 1.45;
    else if (asset.tier === "small") baseRatio *= 0.72;

    var sellPool = Math.max(10, Math.floor(floatShares * baseRatio));
    var buyPool = Math.max(10, Math.floor(floatShares * baseRatio * rand(0.85, 1.25)));

    asset.availableShares = sellPool;
    asset.dailyBuyLiquidityShares = buyPool;
    asset.dayOpenSellLiquidityShares = sellPool;
    asset.dayOpenBuyLiquidityShares = buyPool;

      // limit liquidity is reset only at new market day, not every state ensure.

    return asset;
  }


  // =========================================
  // F2.6.1：盤中流動性補給
  // 背景 NPC 市場會持續提供少量買盤/賣盤，讓集中盤委託不會卡死。
  // 注意：漲停/跌停仍維持封板枯竭，不做大量補給。
  // =========================================
  function refreshIntradayLiquidityForAsset(state, asset) {
    if (!state || !asset || asset.marketType !== "free" || !asset.unlocked) return asset;
    if (state.marketPhase !== "open" || isDividendSettlementDay(state)) return asset;

    ensureLiquidityModel(asset);

    var floatShares = Math.max(1, Math.floor(Number(asset.floatShares || 1)));
    var profile = asset.tradingProfile || {};
    var liq = Math.max(0.25, Number(profile.liquidity || asset.liquidity || 1));

    var sellCap = Math.max(
      Math.floor(Number(asset.dayOpenSellLiquidityShares || 0)),
      Math.floor(floatShares * 0.0035 * liq)
    );

    var buyCap = Math.max(
      Math.floor(Number(asset.dayOpenBuyLiquidityShares || 0)),
      Math.floor(floatShares * 0.0035 * liq)
    );

    // 封板時只保留極少量，避免漲停仍能被大量買、跌停仍能大量賣。
    if (asset.limitLocked && asset.limitType === "up") {
      asset.availableShares = Math.min(
        Math.max(0, Math.floor(Number(asset.availableShares || 0))),
        Math.max(0, Math.floor(Number(asset.upRemainingSellLiquidity || 0)))
      );
      return asset;
    }

    if (asset.limitLocked && asset.limitType === "down") {
      asset.dailyBuyLiquidityShares = Math.min(
        Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0))),
        Math.max(0, Math.floor(Number(asset.downRemainingBuyLiquidity || 0)))
      );
      return asset;
    }

    // 每 tick 補充一點 NPC 背景掛單。股本越大、流動性越高，成交速度越快。
    var sellAdd = Math.max(
      1,
      Math.floor(floatShares * rand(0.000004, 0.000018) * liq)
    );

    var buyAdd = Math.max(
      1,
      Math.floor(floatShares * rand(0.000004, 0.000018) * liq)
    );

    asset.availableShares = Math.min(
      sellCap,
      Math.max(0, Math.floor(Number(asset.availableShares || 0))) + sellAdd
    );

    asset.dailyBuyLiquidityShares = Math.min(
      buyCap,
      Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0))) + buyAdd
    );

    if (typeof asset.dayOpenSellLiquidityShares !== "number" || asset.dayOpenSellLiquidityShares <= 0) {
      asset.dayOpenSellLiquidityShares = sellCap;
    }

    if (typeof asset.dayOpenBuyLiquidityShares !== "number" || asset.dayOpenBuyLiquidityShares <= 0) {
      asset.dayOpenBuyLiquidityShares = buyCap;
    }

    return asset;
  }

  function refreshIntradayLiquidity(state) {
    if (!state || !state.assets || state.marketPhase !== "open" || isDividendSettlementDay(state)) return;
    Object.keys(state.assets).forEach(function(id) {
      refreshIntradayLiquidityForAsset(state, state.assets[id]);
    });
  }

  function getLiquidityState(asset) {
    ensureLiquidityModel(asset);

    var remain = Math.max(0, Math.floor(Number(asset && asset.availableShares || 0)));
    var base = Math.max(1, Math.floor(Number(asset && asset.dayOpenSellLiquidityShares || remain || 1)));
    var ratio = remain / base;

    var openPrice =
      Math.max(
        1,
        Number(
          asset &&
          (
            asset.openPrice ||
            asset.dayOpenPrice ||
            asset.dayOpen ||
            asset.previousClosePrice ||
            asset.basePrice ||
            asset.price
          ) || 1
        )
      );

    var currentPrice =
      Math.max(
        1,
        Number(
          asset &&
          (asset.price || asset.currentPriceMilli || openPrice)
        )
      );

    var move =
      Math.abs(
        (currentPrice - openPrice) / openPrice
      );

    if (remain <= 0) {
      return {
        level: "locked",
        icon: "⚫",
        label: "完全鎖單",
        color: "#111827"
      };
    }

    // 接近漲跌停改為市場壓力燈號
    if (move >= 0.098) {
      return {
        level: "locked",
        icon: "⚫",
        label: "極限排隊",
        color: "#111827"
      };
    }

    if (move >= 0.09) {
      return {
        level: "danger",
        icon: "🔴",
        label: "流動性枯竭",
        color: "#ef4444"
      };
    }

    if (move >= 0.07) {
      return {
        level: "warning",
        icon: "🟡",
        label: "高波動",
        color: "#facc15"
      };
    }

    if (ratio <= 0.05) {
      return {
        level: "danger",
        icon: "🔴",
        label: "幾乎無流通",
        color: "#ef4444"
      };
    }

    if (ratio <= 0.25) {
      return {
        level: "warning",
        icon: "🟡",
        label: "流通吃緊",
        color: "#facc15"
      };
    }

    return {
      level: "normal",
      icon: "🟢",
      label: "正常流通",
      color: "#22c55e"
    };
  }

  function pushMerchantLiquidityAlert(state, asset, liquidity) {
    if (!state || !asset || !liquidity) return;

    // 只公告紅燈 / 黑燈 / 漲跌停，避免正常與吃緊狀態洗版。
    var isImportant =
      liquidity.level === "danger" ||
      liquidity.level === "locked" ||
      (asset.limitLocked && (asset.limitType === "up" || asset.limitType === "down"));

    if (!isImportant) return;

    if (!state.merchantLiquidityAlerts || typeof state.merchantLiquidityAlerts !== "object") {
      state.merchantLiquidityAlerts = {};
    }

    var key = String(state.marketDay || 1) + ":" + String(asset.id) + ":" + String(liquidity.level) + ":" + String(asset.limitType || "");
    if (state.merchantLiquidityAlerts[key]) return;
    state.merchantLiquidityAlerts[key] = true;

    var title = "🏛 商會公告";
    var text;

    if (asset.limitLocked && asset.limitType === "up") {
      text = asset.name + " 已進入漲停狀態，市場流通性接近枯竭。";
    } else if (asset.limitLocked && asset.limitType === "down") {
      text = asset.name + " 已進入跌停狀態，目前市場買盤極度不足。";
    } else if (liquidity.level === "locked") {
      text = asset.name + " 所有市場掛單已耗盡，目前完全鎖單。";
    } else {
      text = asset.name + " 市場流通性急速下降，目前幾乎無流通。";
    }

    pushNews(state, title, text, liquidity.level === "locked" ? "bearish" : "warning");

    if (typeof w.pushWorldNews === "function") {
      w.pushWorldNews("merchant", title, text, 1);
    }
  }

  function ensureStarterTradableStructure(asset) {
    if (!asset || asset.marketType === "free") return asset;
    var sectorCode = String(asset.sectorCode || "X").toUpperCase();
    if (sectorCode !== "A") return asset;

    var total = Math.max(600000, Math.floor(Number(asset.totalShares || 800000)));
    var boardControl = Math.max(0, Math.floor(Number(asset.boardControlShares || total * 0.12)));
    var stateHolding = Math.max(0, Math.floor(Number(asset.stateHoldingShares || total * 0.42)));
    var strategic = Math.max(0, Math.floor(Number(asset.strategicHoldingShares || total * 0.10)));
    var maker = Math.max(0, Math.floor(Number(asset.marketMakerShares || total * 0.06)));
    var reserved = boardControl + stateHolding + strategic + maker;
    if (reserved >= total) {
      var scale = (total * 0.82) / Math.max(1, reserved);
      boardControl = Math.floor(boardControl * scale);
      stateHolding = Math.floor(stateHolding * scale);
      strategic = Math.floor(strategic * scale);
      maker = Math.floor(maker * scale);
      reserved = boardControl + stateHolding + strategic + maker;
    }
    var floatShares = Math.max(120000, total - reserved);
    var available = Math.max(50000, Math.floor(Number(asset.availableShares || floatShares * 0.45)));
    available = Math.min(floatShares, available);

    asset.totalShares = total;
    asset.boardControlShares = boardControl;
    asset.stateHoldingShares = stateHolding;
    asset.strategicHoldingShares = strategic;
    asset.marketMakerShares = maker;
    asset.floatShares = floatShares;
    asset.availableShares = available;
    asset.lockedShares = Math.max(0, total - floatShares);
    asset.insiderShares = Math.max(0, boardControl + stateHolding);
    return asset;
  }

  function computeStructuralAnchor(asset, state) {
    var base = Math.max(PRICE_FLOOR, Number(asset.basePrice || asset.startPrice || asset.price || 1));
    if (asset.marketType !== "free") {
      var ci0 = asset.companyInfo || {};
      var q0 = clamp(Number(ci0.quality || 0.5), 0, 1);
      var meta0 = state ? getCombinedNarrativeMetaForAsset(state, asset.id) : null;
      var conf0 = meta0 ? Number(meta0.confidenceImpact || 0) : 0;
      return Math.floor(base * (1 + (q0 - 0.5) * 0.08 + conf0 * 0.04));
    }

    var floatShares = Math.max(1, Number(asset.floatShares || 1));
    var listed = Math.max(1, Number(asset.availableShares || 1));
    var insider = Math.max(0, Number(asset.insiderShares || 0));
    normalizeEquityShares(asset);
    var core = Math.max(0, Number(asset.strategicHoldingShares || 0));
    var trade = Math.max(0, Number(asset.marketMakerShares || 0));
    var locked = Math.max(0, Number(asset.lockedShares || 0));
    var ci = asset.companyInfo || {};
    var meta = state ? getCombinedNarrativeMetaForAsset(state, asset.id) : null;
    var confidenceImpact = meta ? Number(meta.confidenceImpact || 0) : 0;

    var listedRatio = listed / floatShares;
    var insiderRatio = insider / floatShares;
    var coreRatio = core / floatShares;
    var tradeRatio = trade / floatShares;
    var lockedVsTotal = locked / Math.max(1, Number(asset.totalShares || floatShares));
    var playerFlowBias = clamp(Number(asset.playerRecentNetFlow || 0), -0.06, 0.06);

    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);

    var scarcityBoost = (0.30 - listedRatio) * 0.50;
    var insiderBoost = (insiderRatio - 0.20) * 0.16;
    var concentrationBoost = (coreRatio - 0.22) * 0.12;
    var tradeSupport = tradeRatio * 0.04;
    var lockedSupport = lockedVsTotal * 0.05;
    var qualityBoost = (quality - 0.5) * 0.16;
    var stabilityBoost = (stability - 0.5) * 0.08;
    var hypeBoost = (hype - 0.3) * 0.10;
    var confidenceBoost = confidenceImpact * 0.10;
    var playerBoost = playerFlowBias * 0.28;
    var tierBias = asset.tier === "large" ? -0.02 : (asset.tier === "small" ? 0.02 : 0);

    var totalBoost = clamp(
      scarcityBoost + insiderBoost + concentrationBoost + tradeSupport + lockedSupport + qualityBoost + stabilityBoost + hypeBoost + confidenceBoost + playerBoost + tierBias,
      -0.28,
      0.30
    );

    return Math.max(PRICE_FLOOR, Math.floor(base * (1 + totalBoost)));
  }

  function getEffectiveLiquidity(asset, state) {
    var base = Math.max(0.25, Number(asset.liquidity || 1));
    if (asset.marketType !== "free") {
      var metaStarter = getCombinedNarrativeMetaForAsset(state, asset.id);
      var starterShift = metaStarter ? Number(metaStarter.liquidityShift || 0) : 0;
      return clamp(base * (1 + starterShift * 0.35), 0.25, 1.80);
    }

    var floatShares = Math.max(1, Number(asset.floatShares || 1));
    var listedRatio = Number(asset.availableShares || 0) / floatShares;
    var insiderRatio = Number(asset.insiderShares || 0) / floatShares;
    var worldVol = state.worldState ? Number(state.worldState.volatilityBonus || 0) : 0;
    var climateVol = w.StockMarketClimate.getVolatilityMultiplier(state);
    var heat = state.climate ? Number(state.climate.heat || 0) : 0;
    var panic = state.climate ? Number(state.climate.panic || 0) : 0;
    var meta = getCombinedNarrativeMetaForAsset(state, asset.id);
    var eventLiqShift = meta ? Number(meta.liquidityShift || 0) : 0;

    var listedAdjust = clamp((listedRatio - 0.12) * 1.2, -0.25, 0.30);
    var insiderAdjust = clamp(-(insiderRatio - 0.18) * 0.45, -0.18, 0.08);
    var eventAdjust = clamp(worldVol * 100, 0, 0.18);
    var metaAdjust = clamp(eventLiqShift, -0.50, 0.50);
    var heatAdjust = clamp(heat / 50000, -0.05, 0.12);
    var panicAdjust = clamp(-panic / 60000, -0.14, 0.03);
    var climateAdjust = clamp((climateVol - 1) * 0.22, -0.10, 0.12);

    return clamp(base * (1 + listedAdjust + insiderAdjust + eventAdjust + metaAdjust + heatAdjust + panicAdjust + climateAdjust), 0.15, 2.40);
  }

  function getEffectivePayoutRatio(asset, state, basePayoutRatio) {
    basePayoutRatio = clamp(Number(basePayoutRatio || 0), 0, 1);

    var ci = asset.companyInfo || {};
    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);
    var meta = getCombinedNarrativeMetaForAsset(state, asset.id);
    var confidenceImpact = meta ? Number(meta.confidenceImpact || 0) : 0;
    var payoutAdjust = meta ? Number(meta.payoutAdjust || 0) : 0;

    var price = Math.max(PRICE_FLOOR, Number(asset.price || asset.basePrice || 1));
    var meanPrice = Math.max(PRICE_FLOOR, Number(asset.meanPrice || price));
    var trend = (price - meanPrice) / meanPrice;

    var payout =
      basePayoutRatio *
      (0.92 + stability * 0.18) *
      (0.94 + quality * 0.14) *
      (1 + confidenceImpact * 0.12) *
      (1 - hype * 0.08);

    payout *= (1 + clamp(trend * 0.18, -0.08, 0.08));
    payout *= (1 + clamp(payoutAdjust, -0.25, 0.25));

    if (asset.marketType === "starter") {
      payout = clamp(payout, 0.05, 0.35);
    } else if (asset.tier === "large") {
      payout = clamp(payout, 0.10, 0.70);
    } else if (asset.tier === "mid") {
      payout = clamp(payout, 0.04, 0.55);
    } else {
      payout = clamp(payout, 0.00, 0.25);
    }

    return payout;
  }

  function rollWorldState(state, silent) {
    var r = Math.random();
    var ws = null;

    if (r < 0.62) ws = null;
    else if (r < 0.74) ws = { type: "bullish", label: "偏多盤", drift: 0.00025, volatilityBonus: 0.00010, tone: "bullish" };
    else if (r < 0.86) ws = { type: "bearish", label: "偏空盤", drift: -0.00025, volatilityBonus: 0.00010, tone: "bearish" };
    else if (r < 0.93) ws = { type: "volatile_up", label: "高波動偏多", drift: 0.00018, volatilityBonus: 0.00045, tone: "bullish" };
    else if (r < 0.98) ws = { type: "volatile_down", label: "高波動偏空", drift: -0.00018, volatilityBonus: 0.00045, tone: "bearish" };
    else ws = { type: "chaotic", label: "混亂震盪", drift: 0, volatilityBonus: 0.00075, tone: "neutral" };

    state.worldState = ws;

    if (!silent) {
      if (ws) pushNews(state, "今日世界盤勢：" + ws.label, "今日整體市場將逐步受到此背景影響。", ws.tone);
      else pushNews(state, "今日世界盤勢：無特別事件", "今天沒有明顯世界級事件，市場主要靠籌碼、情緒與交易行為運作。", "neutral");
    }
  }

  function maybeRollShockState(state) {
    if (state.marketPhase === "closed") return;
    if (isDividendSettlementDay(state)) return;
    if (state.shockState && state.shockState.remainingSec > 0) return;
    if (Math.random() > 0.0025) return;

    var ids = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      if (state.assets[id].marketType === "free" && state.assets[id].unlocked) ids.push(id);
    }
    if (!ids.length) return;

    var assetId = pick(ids);
    var kind = Math.random() < 0.5 ? "buy" : "sell";
    state.shockState = {
      assetId: assetId,
      type: kind,
      label: kind === "buy" ? "突發買壓" : "突發賣壓",
      multiplier: 1.6 + Math.random() * 1.6,
      remainingSec: 10 + Math.floor(Math.random() * 16)
    };

    pushNews(
      state,
      state.assets[assetId].name + " 出現" + state.shockState.label,
      "短線資金明顯集中，市場掛單將在短時間內快速被消耗或補充。",
      kind === "buy" ? "bullish" : "bearish"
    );
  }

  function tickShockState(state) {
    if (!state.shockState) return;
    state.shockState.remainingSec = Math.max(0, Number(state.shockState.remainingSec || 0) - 1);
    if (state.shockState.remainingSec <= 0) state.shockState = null;
  }

  function updateCompanyMetricsForAsset(state, asset) {

  // [BACKGROUND BUSINESS]
  // 公司營運改為低頻背景資料，不再跟隨股價每 tick 重算。
  // 財報 / 股利 / 背景市值只在排程更新、股利公告或結算時刷新。

    if (!asset || !asset.companyMetrics) return;

    var ci = asset.companyInfo || {};
    var cm = asset.companyMetrics || {};
    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);
    var basePayoutRatio = clamp(Number(ci.payoutRatio || 0.2), 0, 1);
    var worldDrift = state && state.worldState ? Number(state.worldState.drift || 0) : 0;
    var climateBias = state && w.StockMarketClimate ? w.StockMarketClimate.getTrendBias(state) : 0;
    var meta = state ? getCombinedNarrativeMetaForAsset(state, asset.id) : null;
    var confidenceImpact = meta ? Number(meta.confidenceImpact || 0) : 0;
    var revenueAdjustExtra = meta ? Number(meta.revenueAdjust || 0) : 0;
    var profitAdjustExtra = meta ? Number(meta.profitAdjust || 0) : 0;
    var payoutAdjustExtra = meta ? Number(meta.payoutAdjust || 0) : 0;

    var baseAssets = Math.max(0, Number(ci.assetBaseMilli || cm.assetsMilli || 0));
    var baseRevenue = Math.max(0, Number(ci.revenueBaseMilli || cm.revenueMonthlyMilli || 0));
    var baseProfit = Math.max(0, Number(ci.profitBaseMilli || cm.profitMonthlyMilli || 0));

    var revenueAdjust =
      1 +
      (quality - 0.5) * 0.25 +
      (stability - 0.5) * 0.12 +
      (hype - 0.3) * 0.10 +
      clamp(worldDrift * 80, -0.10, 0.10) +
      clamp(climateBias * 100, -0.10, 0.10) +
      clamp(confidenceImpact * 0.18, -0.14, 0.14) +
      clamp(revenueAdjustExtra, -0.30, 0.30);

    revenueAdjust *= rand(0.98, 1.02);

    var margin =
      0.05 +
      quality * 0.16 +
      stability * 0.06 +
      clamp(confidenceImpact * 0.04, -0.04, 0.04) +
      (asset.tier === "large" ? 0.03 : (asset.tier === "small" ? -0.01 : 0.01));

    margin = clamp(margin + clamp(profitAdjustExtra * 0.35, -0.12, 0.12), 0.02, 0.40);

    var revenue = Math.max(0, Math.floor(baseRevenue * revenueAdjust));
    var profit = Math.max(0, Math.floor(revenue * margin));

    var assetAdjust =
      1 +
      (quality - 0.5) * 0.10 +
      (stability - 0.5) * 0.08 +
      clamp(confidenceImpact * 0.08, -0.08, 0.08);

    var assetsMilli = Math.max(0, Math.floor(baseAssets * assetAdjust));
    var adjustedBasePayoutRatio = clamp(basePayoutRatio * (1 + clamp(payoutAdjustExtra, -0.20, 0.20)), 0, 1);
    var currentPayoutRatio = getEffectivePayoutRatio(asset, state, adjustedBasePayoutRatio);

    cm.assetsMilli = assetsMilli;
    cm.revenueMonthlyMilli = revenue;
    cm.profitMonthlyMilli = profit;
    cm.basePayoutRatio = adjustedBasePayoutRatio;
    cm.currentPayoutRatio = currentPayoutRatio;
    cm.economicMarketCapMilli = computeEconomicMarketCapMilli(asset, state, cm);
    cm.marketCapMilli = cm.economicMarketCapMilli;
    asset.economicMarketCapMilli = cm.economicMarketCapMilli;
    cm.lastBusinessUpdateDay = state ? Math.max(1, Math.floor(Number(state.marketDay || 1))) : Number(cm.lastBusinessUpdateDay || 0);
    cm.estimatedDividendPerShareMilli = estimateDividendPerShareMilli(asset, state, currentPayoutRatio);
    applyDividendLockToAsset(state, asset);
    updateAssetAnchorFromBusiness(state, asset);
  }

  function estimateDividendPerShareMilli(asset, state, effectivePayoutRatioOverride) {
    if (!asset) return 0;

    var ci = asset.companyInfo || {};
    var cm = asset.companyMetrics || {};
    var basePayoutRatio = clamp(Number(ci.payoutRatio || cm.basePayoutRatio || 0.2), 0, 1);
    var effectivePayoutRatio = typeof effectivePayoutRatioOverride === "number"
      ? clamp(Number(effectivePayoutRatioOverride || 0), 0, 1)
      : getEffectivePayoutRatio(asset, state, basePayoutRatio);

    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);
    var meta = state ? getCombinedNarrativeMetaForAsset(state, asset.id) : null;
    var confidenceImpact = meta ? Number(meta.confidenceImpact || 0) : 0;

    var profit = Math.max(0, Number(cm.profitMonthlyMilli || ci.profitBaseMilli || 0));
    var totalShares = Math.max(1, Number(asset.totalShares || asset.floatShares || asset.sharesOutstanding || 1));
    var economicShares = Math.max(
      1,
      Number(asset.economicShares || ci.economicShares || totalShares)
    );

    // F4.2.1：
    // 股利同時掛勾資本收益與市場份額。
    // 但市場份額是「流通容器」，不能完全把每份股利壓到無感。
    var liquidityDividendDamping =
      Math.sqrt(totalShares / Math.max(1, economicShares));

    // 股利改由公司低頻營運能力決定，不讀取即時股價。
    var dividendPoolMilli = profit * effectivePayoutRatio * DIVIDEND_TIME_SCALE;

    var stabilityBonus = 0.88 + stability * 0.20 + quality * 0.10;
    var hypePenalty = 1 - clamp((hype - 0.55) * 0.16, 0, 0.08);
    var confidenceBonus = 1 + clamp(confidenceImpact * 0.04, -0.08, 0.08);

    return Math.max(
      0,
      Math.floor(
        (dividendPoolMilli / economicShares) *
        stabilityBonus *
        hypePenalty *
        confidenceBonus /
        Math.max(1, liquidityDividendDamping * 0.35)
      )
    );
  }

  function refreshAllEstimatedDividends(state) {
    ensureState(state);
    // 股利公告讀取公司背景營運資料；若舊存檔缺資料才初始化。
    processScheduledCompanyBusinessUpdates(state, false);

    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.companyMetrics) continue;
      if (!(Number(asset.companyMetrics.economicMarketCapMilli || asset.companyMetrics.marketCapMilli || 0) > 0)) {
        updateCompanyMetricsForAsset(state, asset);

      // 漲停流動性消耗
      if (
        asset.limitLocked &&
        asset.limitType === "up"
      ) {

        asset.upRemainingSellLiquidity =
          Math.max(
            0,
            Math.floor(
              Number(asset.upRemainingSellLiquidity || 0) - qty
            )
          );

      }
      }
      asset.companyMetrics.estimatedDividendPerShareMilli = estimateDividendPerShareMilli(asset, state, asset.companyMetrics.currentPayoutRatio);
      applyDividendLockToAsset(state, asset);
    }
  }

  function calculateDividendPerShareMilli(asset, state) {
    if (!asset || !asset.companyMetrics) return 0;
    if (!(Number(asset.companyMetrics.estimatedDividendPerShareMilli || 0) >= 0)) {
      asset.companyMetrics.estimatedDividendPerShareMilli = estimateDividendPerShareMilli(asset, state, asset.companyMetrics.currentPayoutRatio);
    }
    return Math.max(0, Math.floor(Number(asset.companyMetrics && asset.companyMetrics.estimatedDividendPerShareMilli || 0)));
  }

  function processDividendSettlement(state) {
    ensureState(state);

    var receivedTotal = 0;
    var paidTotal = 0;
    var detail = [];
    var perAssetNews = [];

    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;

      var asset = state.assets[id];
      var h = getHolding(state, id);
      var perShareMilli = calculateDividendPerShareMilli(asset, state);
      var totalMilli = perShareMilli * h.qty;

      if (totalMilli > 0) {
        w.StockMarketCurrency.addDividendMilli(state, totalMilli);
        receivedTotal += totalMilli;
      }

      if (asset.companyMetrics) {
        asset.companyMetrics.lastDividendPerShareMilli = perShareMilli;
      }

      paidTotal += perShareMilli * Math.max(0, Number(asset.totalShares || 0));

      detail.push({
        assetId: id,
        name: asset.name,
        qty: h.qty,
        dividendPerShareMilli: perShareMilli,
        totalMilli: totalMilli
      });

      if (perShareMilli > 0) {
        perAssetNews.push(asset.name + " 每股 " + (perShareMilli / SCALE).toFixed(2));
      }
    }

    state.dividend.totalPaidMilli += paidTotal;
    state.dividend.totalReceivedMilli += receivedTotal;
    state.dividend.history.unshift({
      ts: Date.now(),
      marketDay: state.marketDay,
      cycleDay: state.dividend.cycleDay,
      totalReceivedMilli: receivedTotal,
      totalPaidMilli: paidTotal,
      detail: detail
    });
    if (state.dividend.history.length > 24) state.dividend.history.length = 24;

    pushNews(
      state,
      "股利結算完成",
      perAssetNews.length
        ? perAssetNews.join("｜") + "｜你本次共收到股利幣 " + (receivedTotal / SCALE).toFixed(2)
        : "本次沒有可領取股利。",
      "neutral"
    );

    state.dividend.pendingToday = false;
    state.dividend.cycleDay = 1;
    resetDividendLocks(state);
    refreshAllEstimatedDividends(state);
  }

  function recordDailySnapshots(state) {
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      pushDailyTrend(state.assets[id], state.marketDay);
      state.assets[id].companyMetrics.latestDailyVolume = 0;
    }
  }

  function applyDailyRegistryFlow(state) {
    var pendingBefore = w.StockMarketRegistry.getPendingListings
      ? w.StockMarketRegistry.getPendingListings(state)
      : [];

    var ipo = w.StockMarketRegistry.maybeIpo(state);

    var pendingAfter = w.StockMarketRegistry.getPendingListings
      ? w.StockMarketRegistry.getPendingListings(state)
      : [];

    if (pendingAfter.length > pendingBefore.length) {
      var pendingMap = {};
      for (var pb = 0; pb < pendingBefore.length; pb++) pendingMap[pendingBefore[pb].id] = true;
      for (var pa = 0; pa < pendingAfter.length; pa++) {
        var pending = pendingAfter[pa];
        if (!pendingMap[pending.id]) {
          pushNews(
            state,
            "IPO 預告：" + pending.name,
            "熱度：" + String(pending.ipoHeatLabel || "一般申請") +
              "｜預計 " + Number(pending.etaDays || 0) + " 天後掛牌" +
              "｜產業：" + String(pending.industryLabel || "-") +
              "｜價格區間：" + (Number(pending.priceLowMilli || 0) / SCALE).toFixed(2) + " ~ " + (Number(pending.priceHighMilli || 0) / SCALE).toFixed(2),
            Number(pending.ipoHeatScore || 0) >= 0.62 ? "bullish" : "neutral"
          );
          break;
        }
      }
    }

    if (ipo) {
      updateCompanyMetricsForAsset(state, ipo);
      ipo._lastFairValue = computeStructuralAnchor(ipo, state);
      pushNews(
        state,
        "新股上市：" + ipo.name,
        "掛牌價：" + (Number(ipo.price || 0) / SCALE).toFixed(2) +
          "｜類型：" + (ipo.tier === "large" ? "大型股" : (ipo.tier === "small" ? "小型股" : "中型股")) +
          "｜流通股：" + Math.floor(Number(ipo.floatShares || 0)).toLocaleString(),
        "bullish"
      );
    }

    var delistRecord = w.StockMarketRegistry.maybeDelist(state);
    if (delistRecord) {
      pushNews(
        state,
        "股票下市：" + delistRecord.name,
        "原因：" + delistRecord.reason +
          "｜清算價：" + (Number(delistRecord.settlePriceMilli || 0) / SCALE).toFixed(2) +
          (delistRecord.playerQty > 0
            ? "｜你持有 " + delistRecord.playerQty + " 股，已結算 " + (Number(delistRecord.playerReceivedMilli || 0) / SCALE).toFixed(2)
            : "｜你未持有該股"),
        delistRecord.severity === "bankrupt" ? "bearish" : "neutral"
      );
    }
  }

  function getUpdatableAssetIds(state) {
    var ids = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      ids.push(id);
    }
    ids.sort();
    return ids;
  }

  function updateAssetBatch(state, batchSize) {
    var ids = getUpdatableAssetIds(state);
    if (!ids.length) return 0;
    batchSize = Math.max(1, Math.floor(Number(batchSize || ASSET_BATCH_SIZE)));
    var cursor = Math.max(0, Math.floor(Number(state.runtime.assetBatchCursor || 0))) % ids.length;
    var updated = 0;
    while (updated < batchSize && ids.length) {
      var assetId = ids[cursor % ids.length];
      updateOneAsset(state, state.assets[assetId]);
      updated += 1;
      cursor += 1;
    }
    state.runtime.assetBatchCursor = cursor % ids.length;
    return updated;
  }

  

  // =====================================================
  // [BACKGROUND BUSINESS]
  // 公司營運分批月更：
  // - 每家公司 30 天內只更新一次
  // - 每天更新一批，避免第 25 / 30 天全公司同步爆量
  // - 背景市值與股利能力在此更新
  // =====================================================
  function processScheduledCompanyBusinessUpdates(state, forceAll) {
    ensureState(state);

    var currentDay = Math.max(1, Math.floor(Number(state.marketDay || 1)));
    if (!forceAll && state.runtime.lastCompanyBusinessProcessDay === currentDay) return;

    state.runtime.lastCompanyBusinessProcessDay = currentDay;

    var ids = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (asset && asset.unlocked) ids.push(id);
    }

    ids.sort();

    for (var i = 0; i < ids.length; i++) {
      var assetId = ids[i];
      var a = state.assets[assetId];
      if (!a || !a.companyMetrics) continue;

      var cm = a.companyMetrics || {};
      var needsInit = !(Number(cm.economicMarketCapMilli || cm.marketCapMilli || 0) > 0);
      var slot = (i % DIVIDEND_CYCLE_DAYS) + 1;
      var shouldUpdateToday = ((currentDay - 1) % DIVIDEND_CYCLE_DAYS) + 1 === slot;

      if (forceAll || needsInit || shouldUpdateToday) {
        updateCompanyMetricsForAsset(state, a);
      }
    }
  }

  // =====================================================
  // [OPTIMIZED]
  // 公司增發低頻更新（避免每家公司更新時全表掃描）
  // =====================================================
  function processDailyShareIssuance(state) {
    if (!Array.isArray(state?.companies)) return;

    var currentDay = Number(state && state.marketDay || 0);

    if (state.runtime.lastIssuanceProcessDay === currentDay) {
      return;
    }

    state.runtime.lastIssuanceProcessDay = currentDay;

    state.companies.forEach(function(company) {
      try {
        processAutoShareIssuance(company);
      } catch(e) {}
    });
  }

function applyOpeningGapAdjustments(state) {
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      var evtEffect = getCombinedNarrativeEffectForAsset(state, asset.id);
      var evtMeta = getCombinedNarrativeMetaForAsset(state, asset.id);
      var worldDrift = state.worldState ? Number(state.worldState.drift || 0) : 0;
      var climateBias = w.StockMarketClimate.getTrendBias(state);
      var gapRate = Number(evtEffect.bias || 0) * 0.22 + worldDrift * 0.65 + climateBias * 0.35 + Number(evtMeta.confidenceImpact || 0) * 0.004 + Number(evtMeta.liquidityShift || 0) * 0.002;
      gapRate = clamp(gapRate, -0.035, 0.035);
      if (Math.abs(gapRate) < 0.001) continue;
      var oldPrice = Math.max(PRICE_FLOOR, Math.floor(Number(asset.price || asset.basePrice || 1)));
      var newPrice = applyPriceTickRule(oldPrice, oldPrice * (1 + gapRate));
      newPrice = applyAnchorBoundToPrice(asset, newPrice);
      if(newPrice === oldPrice){
      asset.noMoveTicks =
        Math.floor(Number(asset.noMoveTicks || 0) + 1);
    }else{
      asset.noMoveTicks = 0;
    }

    if(asset.noMoveTicks >= 3){
      var emergencyStep =
        getPriceStepFromMilli(oldPrice);

      newPrice =
        oldPrice +
        (Math.random() < 0.5 ? -1 : 1) *
        emergencyStep;

      newPrice =
        quantizePriceMilli(newPrice);

      asset.noMoveTicks = 0;
    }

    asset.price = applyCentralMarketLimitToAsset(asset, newPrice);
      asset.lastChangeValue = newPrice - oldPrice;
      asset.lastChangePct = oldPrice > 0 ? ((newPrice - oldPrice) / oldPrice) * 100 : 0;
    }
  }

  function announcePendingEventsAtOpen(state) {
    if (!w.StockMarketEvents || !w.StockMarketEvents.consumePendingAnnouncements) return;
    var items = w.StockMarketEvents.consumePendingAnnouncements(state) || [];
    for (var i = 0; i < items.length; i++) {
      var evt = items[i];
      w.StockMarketClimate.applyEventImpactToClimate(state, evt);
      var targetText = "全市場";
      if (evt.kind === "sector") targetText = String(evt.sectorLabel || evt.sectorCode || "產業");
      else if (evt.kind === "world") targetText = "世界市場";
      else if (evt.target) targetText = state.assets[evt.target] ? state.assets[evt.target].name : evt.target;
      var openingText = String(evt.detail || evt.title || "市場在開盤前出現異常訊號。");
      pushNews(state, "開盤前撮合", openingText, "neutral");

      // 同步到世界新聞 Tab
      if (typeof w.pushWorldNews === "function") {
        if (evt.kind === "world") {
          w.pushWorldNews(
            "world",
            evt.title || "世界局勢變化",
            evt.detail || openingText,
            evt.remainingDays || evt.durationDays || 7
          );
        } else if (evt.kind === "sector") {
          w.pushWorldNews(
            "sector",
            evt.title || "產業動向",
            evt.detail || openingText,
            evt.remainingDays || evt.durationDays || 3
          );
        }
      }
    }
  }


  // =====================================================
  // F4.1 商會資本額月更新
  // =====================================================
  function getGuildCapitalTierFromMilliEngine(asset, capitalMilli){
    var scale = SCALE || 1000;
    var capitalCoin = Number(capitalMilli || 0) / scale;

    if(asset && (asset.isRoyalEnterprise || asset.royalIndexEligible || asset.tier === "royal" || asset.stateOwned)){
      return {
        id: "sovereign",
        label: "王國最高級別",
        rank: 5
      };
    }

    if(capitalCoin < 3000000){
      return {
        id: "declining",
        label: "沒落商會",
        rank: 0
      };
    }

    if(capitalCoin < 30000000){
      return {
        id: "small_guild",
        label: "小型公會",
        rank: 1
      };
    }

    if(capitalCoin < 100000000){
      return {
        id: "medium_chamber",
        label: "中型商會",
        rank: 2
      };
    }

    return {
      id: "large_alliance",
      label: "大型商盟",
      rank: 3
    };
  }

  function ensureGuildCapitalState(asset){
    if(!asset) return asset;

    if(!asset.companyInfo || typeof asset.companyInfo !== "object"){
      asset.companyInfo = {};
    }

    var ci = asset.companyInfo;
    var cm = asset.companyMetrics || {};

    var base =
      Math.max(
        0,
        Math.floor(
          Number(
            asset.guildCapitalMilli ||
            ci.guildCapitalMilli ||
            ci.assetBaseMilli ||
            cm.assetsMilli ||
            0
          )
        )
      );

    if(!(base > 0)){
      base = Math.max(0, Math.floor(Number(asset.price || 1) * Number(asset.totalShares || 1) * 0.08));
    }

    asset.guildCapitalMilli = base;
    ci.guildCapitalMilli = base;

    if(!(Number(asset.guildCapitalBaseMilli) > 0)){
      asset.guildCapitalBaseMilli = base;
    }

    if(!(Number(ci.guildCapitalBaseMilli) > 0)){
      ci.guildCapitalBaseMilli = asset.guildCapitalBaseMilli;
    }

    var tier = getGuildCapitalTierFromMilliEngine(asset, base);

    asset.guildCapitalTierId = tier.id;
    asset.guildCapitalTierLabel = tier.label;
    asset.guildCapitalTierRank = tier.rank;

    ci.guildCapitalTierId = tier.id;
    ci.guildCapitalTierLabel = tier.label;
    ci.guildCapitalTierRank = tier.rank;

    return asset;
  }

  function updateGuildCapitalMonthly(state, force){
    if(!state || !state.assets) return;

    if(!state.guildCapitalBatchCursor){
      state.guildCapitalBatchCursor = 0;
    }

    if(!state.guildCapitalMonthlyReport){
      state.guildCapitalMonthlyReport = {
        changed:[]
      };
    }

    var day = Math.max(1, Math.floor(Number(state.marketDay || 1)));
    var ids = Object.keys(state.assets || {});
    if(!ids.length) return;

    // =====================================================
    // F4.1.1 分批背景更新
    // =====================================================

    var batchSize =
      Math.max(
        1,
        Math.ceil(ids.length / 30)
      );

    if(force){
      batchSize = ids.length;
    }

    var start = state.guildCapitalBatchCursor || 0;
    var end = Math.min(ids.length, start + batchSize);

    var changed = [];

    for(var i = start; i < end; i++){

      var id = ids[i];
      if(!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;

      var asset = state.assets[id];
      if(!asset || !asset.unlocked) continue;

      ensureGuildCapitalState(asset);

      if(!force && Number(asset.guildCapitalLastUpdateDay || 0) === day) continue;

      var ci = asset.companyInfo || {};
      var cm = asset.companyMetrics || {};
      var oldCapital = Math.max(0, Math.floor(Number(asset.guildCapitalMilli || ci.guildCapitalMilli || 0)));
      var oldTier = String(asset.guildCapitalTierLabel || ci.guildCapitalTierLabel || "");

      var profit = Number(cm.profitMonthlyMilli || ci.profitBaseMilli || 0);
      var revenue = Number(cm.revenueMonthlyMilli || ci.revenueBaseMilli || 0);
      var quality = clamp(Number(ci.quality || 0.5), 0, 1);
      var stability = clamp(Number(ci.stability || 0.5), 0, 1);
      var hype = clamp(Number(ci.hype || 0.2), 0, 1);

      var retainRatio =
        asset.isRoyalEnterprise || asset.royalIndexEligible
          ? 1.00
          : clamp(0.45 + quality * 0.22 + stability * 0.18 - hype * 0.08, 0.25, 0.92);

      var retainedProfit = profit * retainRatio;
      var operatingDrift = revenue * (quality - 0.45) * 0.012;
      var randomDrift = oldCapital * rand(-0.012, 0.018);

      if(asset.isRoyalEnterprise || asset.royalIndexEligible || asset.tier === "royal" || asset.stateOwned){
        randomDrift = Math.abs(randomDrift) * 0.35;
      }

      var newCapital =
        Math.max(
          0,
          Math.floor(
            oldCapital +
            retainedProfit +
            operatingDrift +
            randomDrift
          )
        );

      asset.guildCapitalMilli = newCapital;
      asset.guildCapitalLastUpdateDay = day;

      ci.guildCapitalMilli = newCapital;
      ci.guildCapitalLastUpdateDay = day;

      var tier = getGuildCapitalTierFromMilliEngine(asset, newCapital);
      asset.guildCapitalTierId = tier.id;
      asset.guildCapitalTierLabel = tier.label;
      asset.guildCapitalTierRank = tier.rank;

      ci.guildCapitalTierId = tier.id;
      ci.guildCapitalTierLabel = tier.label;
      ci.guildCapitalTierRank = tier.rank;

      if(oldTier && oldTier !== tier.label){
        changed.push((asset.name || id) + "：" + oldTier + " → " + tier.label);
      }
    }

    state.guildCapitalBatchCursor = end;

    // 累積月報資料
    if(changed.length){
      state.guildCapitalMonthlyReport.changed =
        state.guildCapitalMonthlyReport.changed.concat(changed);
    }

    // =====================================================
    // 每30天才正式公布
    // =====================================================

    var monthReportDay =
      (day > 1 && ((day - 1) % 30) === 0);

    if(
      force ||
      (
        monthReportDay &&
        end >= ids.length
      )
    ){

      var finalChanges =
        state.guildCapitalMonthlyReport.changed || [];

      if(finalChanges.length){
        pushNews(
          state,
          "商會資本階級月報",
          finalChanges.slice(0, 8).join("｜"),
          "neutral"
        );
      }else{
        pushNews(
          state,
          "商會資本額月報",
          "本月各商會資本結構更新完成，未出現明顯階級變動。",
          "neutral"
        );
      }

      state.guildCapitalMonthlyReport = {
        changed:[]
      };
    }

    // 全部輪完重新開始
    if(end >= ids.length){
      state.guildCapitalBatchCursor = 0;
    }
  }


  function startNewMarketDay(state) {
    recordDailySnapshots(state);

    state.marketDay += 1;
    state.marketDayTick = 0;

    // F4.1.1：商會資本額背景分批更新
    updateGuildCapitalMonthly(state, false);


    // 世界新聞每日扣天
    if (typeof w.tickWorldNewsDay === "function") {
      w.tickWorldNewsDay();
    }

    // 世界氣候 / 曆法每日更新，並推送每日世界播報
    if (w.WorldClimateSystem && typeof w.WorldClimateSystem.update === "function") {
      w.WorldClimateSystem.update(state);
    }

    applyDailyRegistryFlow(state);

    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      asset.lastClosePrice = asset.price;
      asset.limitLocked = false;
      // limit liquidity is reset only at new market day, not every state ensure.
      asset.limitType = null;
      asset.momentum = Number(asset.momentum || 0) * 0.35;
      asset._lastFlowRatio = 0;
      asset.playerImpactBuy = Number(asset.playerImpactBuy || 0) * 0.45;
      asset.playerImpactSell = Number(asset.playerImpactSell || 0) * 0.45;
      asset.playerRecentNetFlow = Number(asset.playerRecentNetFlow || 0) * 0.45;
      asset._lastPlayerTradeImpact = 0;
    }

    processScheduledCompanyBusinessUpdates(state, false);

    if (state.dividend.cycleDay >= DIVIDEND_CYCLE_DAYS) {
      state.dividend.pendingToday = true;
      pushNews(state, "今日為股利結算日", "市場今日停止交易與價格更新，將依持股進行股利分紅。", "neutral");
      return;
    }

    state.dividend.cycleDay += 1;
    w.StockMarketCompanyDynamics.prepareDailyQuota(state);
    rollWorldState(state, false);
    applyOpeningGapAdjustments(state);

    for (var id2 in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id2)) continue;
      var asset2 = state.assets[id2];
      asset2.dayOpenPrice = asset2.price;
      asset2.dayHighPrice = asset2.price;
      asset2.dayLowPrice = asset2.price;
      asset2.lastChangePct = 0;
      asset2.lastChangeValue = 0;
      asset2._lastFairValue = computeStructuralAnchor(asset2, state);
    }

    announcePendingEventsAtOpen(state);

    var createdDynamics = w.StockMarketCompanyDynamics.maybeGenerateDailyDynamics(state);
    var createdDecisions = w.StockMarketCompanyDynamics.maybeGenerateDailyDecisions ? w.StockMarketCompanyDynamics.maybeGenerateDailyDecisions(state) : [];
    var hadCompanyItems = false;
    if (createdDynamics && createdDynamics.length) {
      hadCompanyItems = true;
      for (var i = 0; i < createdDynamics.length; i++) {
        var dyn = createdDynamics[i];
        pushNews(
          state,
          "公司動態：" + dyn.assetName + "｜" + dyn.title,
          "影響方向：" + (dyn.bias >= 0 ? "偏多" : "偏空") +
            "｜等級：" + String(dyn.levelLabel || "中") +
            "｜方向：" + (dyn.direction === "positive" ? "利多" : (dyn.direction === "negative" ? "利空" : "混合")) +
            "｜持續：" + Number(dyn.durationDays || 0) + " 天",
          dyn.bias > 0 ? "bullish" : "bearish"
        );
      }
    }
    if (createdDecisions && createdDecisions.length) {
      hadCompanyItems = true;
      for (var j = 0; j < createdDecisions.length; j++) {
        var dec = createdDecisions[j];
        pushNews(
          state,
          "公司決策：" + dec.assetName + "｜" + dec.title,
          (dec.playerEligible ? "你持股已達 30%，可參與投票。" : "此次由董事會自行表決。") +
            "｜剩餘：" + Number(dec.remainingDays || 0) + " 天" +
            "｜提案：" + String(dec.proposalType || "一般決策"),
          dec.playerEligible ? "bullish" : "neutral"
        );
      }
    }
    if (!hadCompanyItems) {
      pushNews(state, "公司動態：今日無重大公告", "今天沒有公司發布足以改變股價結構的重要消息。", "neutral");
    }

    refreshAllEstimatedDividends(state);

    var quota = state.events ? Number(state.events.dailyQuota || 0) : 0;
    pushNews(state, "今日突發事件額度：" + quota + " 次", "今天盤中最多觸發 " + quota + " 次突發事件。", "neutral");
    pushNews(state, "市場進入第 " + state.marketDay + " 個交易日", "新交易日開始。", "neutral");
  }

  function transitionPhase(state) {
    if (state.marketPhase === "preopen") {
      state.marketPhase = "open";
      state.phaseElapsedSec = 0;
      pushNews(state, "正式開市", "撮合階段結束，市場正式開市。", "positive");
    } else if (state.marketPhase === "open") {
      state.marketPhase = "closed";
      state.phaseElapsedSec = 0;
      state.shockState = null;
      pushNews(state, "市場休市", "本輪交易日已結束，進入休市整理期。", "neutral");
    } else {
      state.marketPhase = "preopen";
      state.phaseElapsedSec = 0;
      startNewMarketDay(state);
      if (w.StockMarketEvents && w.StockMarketEvents.prepareOvernightEvents) {
        w.StockMarketEvents.prepareOvernightEvents(state);
      }
      pushNews(state, "開盤前撮合", "市場進入撮合階段，價格將持續波動，但暫時無法交易。", "warning");
    }
  }

  function maybeReleaseLockedShares(state, asset, evtMeta, effectiveLiquidity) {
    if (!asset || asset.marketType !== "free") return 0;

    var locked = Math.max(0, Math.floor(Number(asset.lockedShares || 0)));
    if (locked <= 0) return 0;

    var floatShares = Math.max(1, Math.floor(Number(asset.floatShares || 1)));
    var available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
    var listedRatio = available / floatShares;
    var priceToFair = asset._lastFairValue > 0 ? Number(asset.price || 0) / Math.max(1, Number(asset._lastFairValue || 1)) : 1;

    var shortPressureBoost = Number(evtMeta.shortPressureBoost || 0);
    var panicBoost = Number(evtMeta.npcPanicSellBoost || 0);
    var fomoBoost = Number(evtMeta.npcFomoBuyBoost || 0);

    var severeSell = shortPressureBoost > 2.2 || panicBoost > 2.6 || priceToFair < 0.78;
    var severeBuy = fomoBoost > 1.9 && listedRatio < 0.025;
    var severeDry = listedRatio < 0.015 && effectiveLiquidity < 0.35;

    if (!(severeSell || severeBuy || severeDry)) return 0;

    var releaseRatio = 0;

    if (severeSell) releaseRatio += rand(0.0005, 0.0022);
    if (severeBuy) releaseRatio += rand(0.0003, 0.0012);
    if (severeDry) releaseRatio += rand(0.0002, 0.0008);

    if (asset.tier === "large") releaseRatio *= 1.25;
    if (asset.tier === "small") releaseRatio *= 0.85;

    releaseRatio = clamp(releaseRatio, 0, 0.0030);

    var releaseQty = Math.max(0, Math.floor(locked * releaseRatio));
    if (releaseQty <= 0) return 0;

    asset.lockedShares = Math.max(0, locked - releaseQty);
    asset.floatShares = Math.max(1, Math.floor(Number(asset.floatShares || 0) + releaseQty));
    asset.availableShares = Math.max(0, Math.floor(Number(asset.availableShares || 0) + releaseQty));

    pushNews(
      state,
      asset.name + " 釋出鎖倉股份",
      "因市場處於極端狀態，釋出 " + releaseQty.toLocaleString() + " 股補充流動性。",
      severeSell ? "bearish" : "neutral"
    );

    return releaseQty;
  }

  function applyPlayerTradeImpact(state, asset, side, qty) {
    if (!asset || asset.marketType !== "free") return;
    qty = Math.max(1, Math.floor(Number(qty || 0)));

    var profile = getTierProfile(asset);
    var floatShares = Math.max(1, Math.floor(Number(asset.floatShares || 1)));
    var availableShares = Math.max(1, Math.floor(Number(asset.availableShares || 1)));
    var liquidity = getEffectiveLiquidity(asset, state);

    // 玩家交易只影響該個股，而且必須用極大的量才可能完全操控股價。
    // 原本使用 sqrt(qty / floatShares) 會讓中小量交易過度放大；
    // 改為「市場深度」線性吸收，權重股需要數億到十億股以上才有顯著衝擊。
    var depthFloor = asset.tier === "large"
      ? 1000000000
      : (asset.tier === "small" ? 120000000 : 500000000);

    var depthByFloat = floatShares * (asset.tier === "large" ? 10 : (asset.tier === "small" ? 3 : 6));
    var marketDepthShares = Math.max(depthFloor, depthByFloat, availableShares * 6);

    var rawImpact = qty / Math.max(1, marketDepthShares);
    var liquidityFactor = 1 / Math.max(0.55, liquidity);
    var impactStrength = rawImpact * profile.playerImpactStrength * liquidityFactor;

    impactStrength = clamp(impactStrength, 0, asset.tier === "large" ? 0.020 : (asset.tier === "small" ? 0.090 : 0.050));

    var fairShift = clamp(impactStrength * profile.playerFairShift * 8, 0, asset.tier === "large" ? 0.012 : (asset.tier === "small" ? 0.040 : 0.022));
    var npcReaction = clamp(impactStrength * 2.2, 0, 0.25);

    if (side === "buy") {
      asset.playerImpactBuy = clamp(Number(asset.playerImpactBuy || 0) + impactStrength, 0, 0.20);
      asset.playerRecentNetFlow = clamp(Number(asset.playerRecentNetFlow || 0) + fairShift, -0.10, 0.10);
      asset._npcSell = Math.floor(Number(asset._npcSell || 0) + qty * npcReaction);
      asset._npcBuy = Math.max(0, Math.floor(Number(asset._npcBuy || 0) - qty * npcReaction * 0.35));
      asset._lastFairValue = Math.max(PRICE_FLOOR, Math.floor((Number(asset._lastFairValue || asset.price) * (1 + fairShift))));
      asset._lastPlayerTradeImpact = impactStrength;
    } else {
      asset.playerImpactSell = clamp(Number(asset.playerImpactSell || 0) + impactStrength, 0, 0.20);
      asset.playerRecentNetFlow = clamp(Number(asset.playerRecentNetFlow || 0) - fairShift, -0.10, 0.10);
      asset._npcBuy = Math.floor(Number(asset._npcBuy || 0) + qty * npcReaction);
      asset._npcSell = Math.max(0, Math.floor(Number(asset._npcSell || 0) - qty * npcReaction * 0.35));
      asset._lastFairValue = Math.max(PRICE_FLOOR, Math.floor((Number(asset._lastFairValue || asset.price) * (1 - fairShift))));
      asset._lastPlayerTradeImpact = -impactStrength;
    }
  }


  // =====================================================
  // F4.3 AI 雙核心市場
  // AI Market Brain：判斷公平價值 / 高低估 / 市場情緒
  // AI Trading Brain：用成本、損益、均線與風格決定買賣
  // =====================================================

  function getTrendClose(asset, offset){
    var h = asset && asset.trendHistory;
    if(!Array.isArray(h) || !h.length) return Number(asset && asset.price || 0);

    var index = Math.max(0, h.length - 1 - Math.floor(Number(offset || 0)));
    var row = h[index] || h[h.length - 1];

    return Number(
      row.closePrice ||
      row.price ||
      row.close ||
      asset.price ||
      0
    );
  }

  function calcMovingAverageMilli(asset, days){
    days = Math.max(1, Math.floor(Number(days || 1)));
    var h = asset && asset.trendHistory;

    if(!Array.isArray(h) || !h.length){
      return Math.max(1, Number(asset && asset.price || 1));
    }

    var start = Math.max(0, h.length - days);
    var sum = 0;
    var count = 0;

    for(var i = start; i < h.length; i++){
      var row = h[i] || {};
      var v = Number(row.closePrice || row.price || row.close || 0);
      if(v > 0){
        sum += v;
        count++;
      }
    }

    if(!count){
      return Math.max(1, Number(asset && asset.price || 1));
    }

    return Math.max(1, Math.floor(sum / count));
  }

  function getAiTradingStyle(asset){
    if(!asset) return "balanced";

    if(!asset.aiTradingStyle){
      var styles = ["value","momentum","contrarian","panic","fund","balanced"];
      var seed =
        String(asset.id || asset.name || "")
          .split("")
          .reduce(function(a,c){ return a + c.charCodeAt(0); }, 0);

      asset.aiTradingStyle =
        styles[Math.abs(seed) % styles.length];
    }

    return asset.aiTradingStyle;
  }

  function estimateAIFairValueMilli(state, asset){
    if(!asset) return 1;

    var ci = asset.companyInfo || {};
    var cm = asset.companyMetrics || {};

    var price =
      Math.max(
        PRICE_FLOOR,
        Number(asset.price || asset.basePrice || 1)
      );

    var capital =
      Math.max(
        0,
        Number(asset.guildCapitalMilli || ci.guildCapitalMilli || ci.assetBaseMilli || cm.assetsMilli || 0)
      );

    var eps =
      Math.max(
        1,
        Number(cm.epsMilli || asset.aiGeneratedEPSMilli || ci.aiGeneratedEPSMilli || cm.estimatedDividendPerShareMilli || 1)
      );

    var pe =
      Math.max(
        4,
        Number(asset.aiPeRatio || ci.aiPeRatio || 12)
      );

    var quality = clamp(Number(ci.quality || 0.5), 0, 1);
    var stability = clamp(Number(ci.stability || 0.5), 0, 1);
    var hype = clamp(Number(ci.hype || 0.2), 0, 1);

    var capitalTierBoost =
      asset.guildCapitalTierRank >= 5 ? 1.45 :
      asset.guildCapitalTierRank >= 3 ? 1.18 :
      asset.guildCapitalTierRank >= 2 ? 1.06 :
      asset.guildCapitalTierRank <= 0 ? 0.72 :
      1.00;

    var growthScore =
      0.82 +
      quality * 0.32 +
      stability * 0.18 +
      hype * 0.20;

    var macro =
      1 +
      clamp(Number(state && state.worldState && state.worldState.drift || 0) * 8, -0.18, 0.22) +
      clamp((w.StockMarketClimate ? w.StockMarketClimate.getTrendBias(state) : 0) * 0.18, -0.18, 0.18);

    var epsValue =
      eps *
      pe *
      growthScore *
      capitalTierBoost *
      macro;

    // 資本額只當長期地板，不直接用股數硬除，避免巨大流通份額壓扁價格。
    var capitalAnchor =
      capital > 0
        ? Math.sqrt(capital / SCALE) * SCALE * 0.018
        : price;

    var historicalAnchor =
      Math.max(
        PRICE_FLOOR,
        Number(asset.basePrice || asset.startPrice || asset.meanPrice || price)
      );

    var fair =
      epsValue * 0.62 +
      capitalAnchor * 0.18 +
      historicalAnchor * 0.20;

    var oldFair =
      Math.max(
        PRICE_FLOOR,
        Number(asset.aiFairValueMilli || asset._lastFairValue || fair)
      );

    // AI公平價值慢速移動，避免每天跳太大。
    return Math.max(
      PRICE_FLOOR,
      Math.floor(oldFair * 0.90 + fair * 0.10)
    );
  }

  function updateAIMarketBrain(state, asset, evtEffect, evtMeta, capitalEffect){
    if(!asset) return null;

    var price =
      Math.max(
        PRICE_FLOOR,
        Number(asset.price || asset.basePrice || 1)
      );

    var fair =
      estimateAIFairValueMilli(state, asset);

    var valuationGap =
      (fair - price) / Math.max(1, fair);

    var ma5 = calcMovingAverageMilli(asset, 5);
    var ma20 = calcMovingAverageMilli(asset, 20);
    var ma60 = calcMovingAverageMilli(asset, 60);

    var trendBias =
      (price > ma5 ? 0.20 : -0.20) +
      (ma5 > ma20 ? 0.35 : -0.35) +
      (ma20 > ma60 ? 0.45 : -0.45);

    trendBias = clamp(trendBias, -1, 1);

    var eventBias =
      clamp(
        Number(evtEffect && evtEffect.bias || 0) * 18 +
        Number(evtMeta && evtMeta.confidenceImpact || 0) * 0.20 +
        Number(capitalEffect && capitalEffect.drift || 0) * 18,
        -1,
        1
      );

    var worldBias =
      clamp(
        Number(state && state.worldState && state.worldState.drift || 0) * 15 +
        (w.StockMarketClimate ? w.StockMarketClimate.getTrendBias(state) : 0) * 0.35,
        -1,
        1
      );

    var overheat =
      clamp(
        (-valuationGap - 0.12) * 2.8 +
        Math.max(0, trendBias) * 0.25 +
        Math.max(0, eventBias) * 0.18,
        0,
        1
      );

    var undervalued =
      clamp(
        (valuationGap - 0.08) * 3.0 +
        Math.max(0, -trendBias) * 0.18,
        0,
        1
      );

    var panic =
      clamp(
        Number(evtMeta && evtMeta.npcPanicSellBoost || 0) * 0.20 +
        Math.max(0, -eventBias) * 0.42 +
        Math.max(0, -worldBias) * 0.28 +
        Math.max(0, -trendBias) * 0.18,
        0,
        1
      );

    var bubble =
      clamp(
        overheat * 0.65 +
        Math.max(0, trendBias) * 0.20 +
        Math.max(0, eventBias) * 0.15,
        0,
        1
      );

    var moodScore =
      clamp(
        valuationGap * 1.25 +
        trendBias * 0.45 +
        eventBias * 0.65 +
        worldBias * 0.35 -
        panic * 0.75 -
        bubble * 0.25,
        -1.5,
        1.5
      );

    var mood =
      moodScore > 0.45 ? "bullish" :
      moodScore < -0.45 ? "bearish" :
      panic > 0.55 ? "panic" :
      bubble > 0.65 ? "bubble" :
      undervalued > 0.45 ? "undervalued" :
      overheat > 0.55 ? "overheated" :
      "neutral";

    asset.aiFairValueMilli = fair;
    asset.aiValuationGap = valuationGap;
    asset.aiMarketMood = mood;
    asset.aiMoodScore = moodScore;
    asset.aiOverheatLevel = overheat;
    asset.aiPanicLevel = panic;
    asset.aiBubbleLevel = bubble;
    asset.aiTrendBias = trendBias;
    asset.aiMA5Milli = ma5;
    asset.aiMA20Milli = ma20;
    asset.aiMA60Milli = ma60;

    return {
      fairValueMilli: fair,
      valuationGap: valuationGap,
      mood: mood,
      moodScore: moodScore,
      overheat: overheat,
      panic: panic,
      bubble: bubble,
      undervalued: undervalued,
      trendBias: trendBias,
      eventBias: eventBias,
      worldBias: worldBias,
      ma5: ma5,
      ma20: ma20,
      ma60: ma60
    };
  }

  function ensureAIPositionState(asset){
    if(!asset) return;

    if(typeof asset.aiPositionQty !== "number"){
      asset.aiPositionQty =
        Math.max(
          0,
          Math.floor(Number(asset.floatShares || asset.totalShares || 0) * rand(0.015, 0.055))
        );
    }

    if(typeof asset.aiAvgCostMilli !== "number" || !(asset.aiAvgCostMilli > 0)){
      asset.aiAvgCostMilli =
        Math.max(
          PRICE_FLOOR,
          Math.floor(Number(asset.price || asset.basePrice || 1) * rand(0.92, 1.08))
        );
    }

    if(typeof asset.aiConfidence !== "number"){
      asset.aiConfidence = rand(0.35, 0.72);
    }

    getAiTradingStyle(asset);
  }

  function updateAITradingBrain(state, asset, marketBrain, profile){
    ensureAIPositionState(asset);

    var price =
      Math.max(
        PRICE_FLOOR,
        Number(asset.price || asset.basePrice || 1)
      );

    var floatShares =
      Math.max(
        1,
        Number(asset.floatShares || asset.totalShares || 1)
      );

    var style = getAiTradingStyle(asset);
    var avgCost =
      Math.max(
        PRICE_FLOOR,
        Number(asset.aiAvgCostMilli || price)
      );

    var pnl =
      (price - avgCost) / avgCost;

    var confidence =
      clamp(
        Number(asset.aiConfidence || 0.5) * 0.94 +
        (Math.random() * 0.12 - 0.06) +
        Math.abs(marketBrain.moodScore || 0) * 0.025,
        0.05,
        0.98
      );

    var buyScore = 0;
    var sellScore = 0;

    // 價值判斷
    buyScore += Math.max(0, marketBrain.valuationGap) * 0.18;
    sellScore += Math.max(0, -marketBrain.valuationGap) * 0.18;

    // 技術判斷
    if(style === "momentum"){
      buyScore += Math.max(0, marketBrain.trendBias) * 0.95;
      sellScore += Math.max(0, -marketBrain.trendBias) * 0.55;
    }else if(style === "value"){
      buyScore += marketBrain.undervalued * 0.35;
      sellScore += marketBrain.overheat * 0.28;
    }else if(style === "contrarian"){
      buyScore += marketBrain.panic * 0.85 + marketBrain.undervalued * 0.22;
      sellScore += marketBrain.bubble * 0.90;
    }else if(style === "panic"){
      sellScore += marketBrain.panic * 1.15 + Math.max(0, -marketBrain.trendBias) * 0.80;
      buyScore += Math.max(0, marketBrain.trendBias) * 0.30;
    }else if(style === "fund"){
      buyScore += marketBrain.worldBias * 0.42 + Math.max(0, marketBrain.valuationGap) * 0.15;
      sellScore += Math.max(0, -marketBrain.worldBias) * 0.55 + marketBrain.overheat * 0.16;
    }else{
      buyScore += Math.max(0, marketBrain.moodScore) * 0.50;
      sellScore += Math.max(0, -marketBrain.moodScore) * 0.50;
    }

    // 損益判斷
    if(pnl > 0.22){
      sellScore += (pnl - 0.22) * 1.55;
    }

    if(pnl < -0.18){
      if(style === "value" || style === "contrarian" || style === "fund"){
        buyScore += Math.abs(pnl) * 0.75;
      }else{
        sellScore += Math.abs(pnl) * 0.55;
      }
    }

    // 過熱與恐慌
    sellScore += marketBrain.overheat * 0.55 + marketBrain.bubble * 0.75;
    buyScore += marketBrain.undervalued * 0.60;
    sellScore += marketBrain.panic * (style === "contrarian" ? 0.15 : 0.75);
    buyScore += marketBrain.panic * (style === "contrarian" ? 0.70 : 0.08);

    buyScore =
      clamp(buyScore * confidence, 0, 3.5);

    sellScore =
      clamp(sellScore * (1.08 - confidence * 0.18), 0, 3.5);

    var baseFlow =
      Math.max(
        1,
        Math.floor(
          floatShares *
          (
            style === "fund" ? 0.00018 :
            style === "momentum" ? 0.00030 :
            style === "panic" ? 0.00036 :
            0.00024
          )
        )
      );

    var buyShares =
      Math.floor(
        baseFlow *
        buyScore *
        rand(0.75, 1.45)
      );

    var sellShares =
      Math.floor(
        Math.min(
          Number(asset.aiPositionQty || 0),
          baseFlow *
          sellScore *
          rand(0.75, 1.55)
        )
      );

    var net = buyShares - sellShares;

    if(buyShares > 0){
      var oldQty = Math.max(0, Number(asset.aiPositionQty || 0));
      var newQty = oldQty + buyShares;
      asset.aiAvgCostMilli =
        Math.max(
          PRICE_FLOOR,
          Math.floor(
            (
              avgCost * oldQty +
              price * buyShares
            ) /
            Math.max(1, newQty)
          )
        );
      asset.aiPositionQty = newQty;
    }

    if(sellShares > 0){
      asset.aiPositionQty =
        Math.max(
          0,
          Math.floor(Number(asset.aiPositionQty || 0) - sellShares)
        );

      // 大量出清後，剩餘AI成本略向市價靠攏。
      asset.aiAvgCostMilli =
        Math.max(
          PRICE_FLOOR,
          Math.floor(avgCost * 0.985 + price * 0.015)
        );
    }

    asset.aiConfidence = confidence;
    asset.aiUnrealizedPnl = pnl;
    asset.aiLastBuyShares = buyShares;
    asset.aiLastSellShares = sellShares;
    asset.aiLastNetFlow = net;
    asset.aiBuyScore = buyScore;
    asset.aiSellScore = sellScore;

    return {
      style: style,
      pnl: pnl,
      confidence: confidence,
      buyScore: buyScore,
      sellScore: sellScore,
      buyShares: buyShares,
      sellShares: sellShares,
      netFlow: net,
      valueDrift: clamp(marketBrain.valuationGap * 0.003, -0.002, 0.002),
      trendDrift: clamp(marketBrain.trendBias * 0.004, -0.004, 0.004),
      panicDrift: -clamp(marketBrain.panic * 0.006, 0, 0.006),
      bubbleRisk: marketBrain.bubble
    };
  }


  
  // =====================================================
  // F4.4 開盤集合競價核心
  // 撮合不再直接鎖定開盤價
  // 而是生成開盤情緒與壓力
  // =====================================================

  function buildOpeningAuctionState(state, asset){
    if(!asset) return null;

    var fair =
      Math.max(
        PRICE_FLOOR,
        Number(asset.aiFairValueMilli || asset._lastFairValue || asset.price || 1)
      );

    var lastClose =
      Math.max(
        PRICE_FLOOR,
        Number(asset.price || asset.lastClosePrice || 1)
      );

    var valuationGap =
      Number(asset.aiValuationGap || 0);

    var panic =
      clamp(Number(asset.aiPanicLevel || 0), 0, 1);

    var bubble =
      clamp(Number(asset.aiBubbleLevel || 0), 0, 1);

    var mood =
      clamp(Number(asset.aiMoodScore || 0), -2, 2);

    var buyPressure =
      Math.max(
        0,
        0.5 +
        valuationGap * 2.2 +
        mood * 0.8 -
        panic * 0.4
      );

    var sellPressure =
      Math.max(
        0,
        0.5 +
        (-valuationGap) * 2.0 +
        panic * 0.9 +
        bubble * 0.45
      );

    var pressureGap =
      clamp(
        (buyPressure - sellPressure),
        -2,
        2
      );

    // 撮合只形成跳空方向，不直接鎖死。
    var openGapRate =
      clamp(
        pressureGap * 0.028,
        -0.085,
        0.085
      );

    // AI公平價值拉回。
    openGapRate +=
      clamp(
        (fair - lastClose) / Math.max(1, fair) * 0.35,
        -0.045,
        0.045
      );

    var openPrice =
      Math.max(
        PRICE_FLOOR,
        Math.floor(
          lastClose *
          (1 + openGapRate)
        )
      );

    asset.openAuctionPressure = pressureGap;
    asset.openAuctionGapRate = openGapRate;
    asset.pendingOpenPrice = openPrice;

    return {
      openPrice: forceQuantizedPriceMilli(openPrice),
      openGapRate: openGapRate,
      buyPressure: buyPressure,
      sellPressure: sellPressure,
      pressureGap: pressureGap
    };
  }


  // =====================================================
  // F4.4 防停滯流動性修正
  // AI大量持有後避免市場完全停滯
  // =====================================================

  function applyAntiStallLiquidity(asset, marketBuy, marketSell){
    if(!asset){
      return {
        buy: marketBuy,
        sell: marketSell
      };
    }

    var floatShares =
      Math.max(
        1,
        Number(asset.floatShares || asset.totalShares || 1)
      );

    var aiHoldings =
      Math.max(
        0,
        Number(asset.aiPositionQty || 0)
      );

    var holdRatio =
      aiHoldings / floatShares;

    var liquidityFloor =
      Math.max(
        1,
        Math.floor(floatShares * 0.00008)
      );

    // AI持股太高時，市場開始強制釋放流動性。
    if(holdRatio >= 0.35){
      marketSell += Math.floor(liquidityFloor * rand(1.2, 2.5));
    }

    if(holdRatio >= 0.50){
      marketSell += Math.floor(liquidityFloor * rand(2.0, 4.0));
    }

    // 避免完全沒有成交
    marketBuy = Math.max(
      marketBuy,
      liquidityFloor
    );

    marketSell = Math.max(
      marketSell,
      liquidityFloor
    );

    return {
      buy: marketBuy,
      sell: marketSell
    };
  }


  // =====================================================
  // F4.5 多空情緒陣營系統
  // =====================================================

  

  // =====================================================
  // Market Core V2.2
  // 四層 NPC 市場系統
  // =====================================================

  

function getStateAssetList(state){
  if(!state || !state.assets) return [];

  if(Array.isArray(state.assets)){
    return state.assets.filter(Boolean);
  }

  if(typeof state.assets === "object"){
    return Object.keys(state.assets)
      .map(function(k){ return state.assets[k]; })
      .filter(Boolean);
  }

  return [];
}

function getStateKingdomList(state){
  if(!state || !state.kingdoms) return [];

  if(Array.isArray(state.kingdoms)){
    return state.kingdoms.filter(Boolean);
  }

  if(typeof state.kingdoms === "object"){
    return Object.keys(state.kingdoms)
      .map(function(k){ return state.kingdoms[k]; })
      .filter(Boolean);
  }

  return [];
}

// =====================================================
// Market Core V3 - AI Event Ecosystem
// =====================================================

var WORLD_STABILIZER = {
  name: "世界維穩聯盟",
  hiddenCapital: 30000000000000000,
  enabled: true
};

function ensureAIWorldState(state){

  if(!state.aiWorldState){

    state.aiWorldState = {
      activeWorldEvents: [],
      activeIndustryEvents: [],
      activeCompanyEvents: [],
      history: [],

      stabilizer: {
        active: false,
        targetKingdom: null,
        remainingDays: 0
      }
    };
  }

  return state.aiWorldState;
}

function buildAIEvent(type, payload){

  return {
    id: "evt_" + Date.now() + "_" + Math.floor(Math.random()*999999),
    type: type,
    title: payload.title || "未知事件",
    description: payload.description || "",
    kingdomId: payload.kingdomId || null,
    assetId: payload.assetId || null,
    positive: !!payload.positive,
    intensity: Number(payload.intensity || rand(0.2, 1.0)),
    remainingDays: Number(payload.remainingDays || rand(3, 20)),
    aiControlled: true
  };
}

function updateAIEventEcosystem(state){

  if(!state) return;

  var ws = ensureAIWorldState(state);
  var day = Number(state.marketDay || state.day || 1);

  if(!ws.history) ws.history = [];

  var assets = getStateAssetList(state);

  // 世界事件：極低頻
  if(Math.random() < 0.00006){
    var we = buildAIEvent("world", {
      title: Math.random() < 0.5 ? "邊境局勢升溫" : "世界貿易秩序調整",
      description: "AI 判定世界局勢出現新的連鎖變化。",
      intensity: rand(0.25, 0.85),
      remainingDays: rand(5, 35)
    });
    ws.activeWorldEvents.unshift(we);
    ws.history.unshift({
      type: "world",
      title: we.title,
      description: we.description,
      createdDay: day
    });
  }

  // 產業事件：低頻
  if(Math.random() < 0.00012){
    var sectors = ["軍工","科技","資源","商貿","建設","外交"];
    var sec = sectors[Math.floor(Math.random()*sectors.length)];
    var ie = buildAIEvent("industry", {
      title: "AI 需求加速擴散",
      description: sec + " 產業需求開始出現連鎖變化。",
      industryId: sec,
      intensity: rand(0.20, 0.75),
      remainingDays: rand(3, 18)
    });
    ws.activeIndustryEvents.unshift(ie);
    ws.history.unshift({
      type: "industry",
      title: ie.title,
      description: ie.description,
      createdDay: day
    });
  }

  // 公司事件：AI主導，但只進新事件池
  if(assets.length){
    for(var a=0;a<assets.length;a++){
      var asset = assets[a];
      if(!asset || !asset.id) continue;

      if(Math.random() < 0.00015){
        var positive = Math.random() < 0.5;
        var evt = buildAIEvent("company", {
          title: positive ? asset.name + " 技術突破" : asset.name + " 資金壓力",
          description: positive ? "商會內部 AI 判定經營前景改善。" : "商會內部 AI 判定短期壓力升高。",
          assetId: asset.id,
          positive: positive,
          intensity: rand(0.2, 0.8),
          remainingDays: rand(2, 16)
        });
        ws.activeCompanyEvents.unshift(evt);
        ws.history.unshift({
          type: "company",
          title: evt.title,
          description: evt.description,
          assetId: asset.id,
          createdDay: day
        });
      }
    }
  }

  function closeEvent(arr, i, reason){
    var evt = arr[i];
    ws.history.unshift({
      type: evt.type,
      title: evt.title + " 結束",
      description: reason || "AI 判定事件影響已逐漸消退。",
      assetId: evt.assetId || null,
      industryId: evt.industryId || null,
      createdDay: day
    });
    arr.splice(i,1);
  }

  function processEvents(arr){
    for(var i = arr.length - 1; i >= 0; i--){
      var evt = arr[i];
      evt.remainingDays = Number(evt.remainingDays || 0) - 0.05;

      // AI 提前結束
      var earlyEndChance = evt.type === "world" ? 0.00025 : (evt.type === "industry" ? 0.00045 : 0.0008);
      if(Math.random() < earlyEndChance){
        closeEvent(arr, i, "AI 判定事件已被市場吸收。");
        continue;
      }

      if(evt.remainingDays <= 0){
        closeEvent(arr, i, "事件自然冷卻。");
      }
    }
  }

  processEvents(ws.activeWorldEvents);
  processEvents(ws.activeIndustryEvents);
  processEvents(ws.activeCompanyEvents);

  ws.activeWorldEvents = ws.activeWorldEvents.slice(0, 8);
  ws.activeIndustryEvents = ws.activeIndustryEvents.slice(0, 8);
  ws.activeCompanyEvents = ws.activeCompanyEvents.slice(0, 20);
  ws.history = ws.history.slice(0, 60);

  if(WORLD_STABILIZER.enabled){
    var kingdoms = getStateKingdomList(state);

    if(!ws.stabilizer.active){
      kingdoms.forEach(function(kingdom){
        var collapseRisk =
          (100 - Number(kingdom.stability || 100)) +
          (100 - Number(kingdom.economy || 100)) +
          Number(kingdom.warPressure || 0);

        if(collapseRisk >= 240 && Math.random() < 0.00005){
          ws.stabilizer.active = true;
          ws.stabilizer.targetKingdom = kingdom.id;
          ws.stabilizer.remainingDays = rand(8, 40);
          ws.history.unshift({
            type: "stabilizer",
            title: WORLD_STABILIZER.name + " 介入 " + (kingdom.name || "未知王國"),
            description: "世界維穩力量啟動最後防線。",
            createdDay: day,
            danger: !!kingdom.isPlayerKingdom
          });
        }
      });
    }

    if(ws.stabilizer.active){
      ws.stabilizer.remainingDays -= 0.05;
      var target = kingdoms.find(function(k){ return k.id === ws.stabilizer.targetKingdom; });
      if(target){
        target.stability = Math.min(55, Number(target.stability || 0) + 0.08);
        target.economy = Math.min(50, Number(target.economy || 0) + 0.06);

        if(Number(target.stability || 0) >= 45 && Number(target.economy || 0) >= 40){
          ws.history.unshift({
            type: "stabilizer",
            title: WORLD_STABILIZER.name + " 撤離 " + (target.name || "未知王國"),
            description: "該國家已恢復最低生存標準。",
            createdDay: day
          });
          ws.stabilizer.active = false;
          ws.stabilizer.targetKingdom = null;
        }
      }

      if(ws.stabilizer.remainingDays <= 0){
        ws.stabilizer.active = false;
        ws.stabilizer.targetKingdom = null;
      }
    }
  }
}

function buildNpcLayerState(asset){
    if(!asset.npcLayers){
      asset.npcLayers = {
        retail: {
          mood: rand(-0.12, 0.12),
          fear: rand(0, 0.25),
          greed: rand(0, 0.25),
          capital: rand(0.8, 1.2),
          activity: rand(0.9, 1.4)
        },

        institution: {
          mood: rand(-0.08, 0.08),
          fear: rand(0, 0.15),
          greed: rand(0, 0.15),
          capital: rand(1.6, 2.8),
          activity: rand(0.45, 0.8)
        },

        whale: {
          mood: rand(-0.05, 0.05),
          fear: rand(0, 0.08),
          greed: rand(0, 0.08),
          capital: rand(3.5, 6.5),
          activity: rand(0.15, 0.35)
        },

        kingdom: {
          mood: rand(-0.03, 0.03),
          fear: rand(0, 0.03),
          greed: rand(0, 0.03),
          capital: rand(8, 14),
          activity: rand(0.03, 0.12)
        }
      };
    }

    return asset.npcLayers;
  }

  function updateNpcLayers(state, asset, aiMarketBrain){
    var layers =
      buildNpcLayerState(asset);

    var worldMood =
      Number(aiMarketBrain && aiMarketBrain.moodScore || 0);

    Object.keys(layers).forEach(function(key){

      var layer = layers[key];

      // 情緒漂移
      layer.mood += rand(-0.03, 0.03);

      // 散戶最容易受情緒影響
      if(key === "retail"){
        layer.mood += worldMood * 0.18;
      }

      // 機構較穩
      if(key === "institution"){
        layer.mood += worldMood * 0.08;
      }

      // 主力常反向
      if(key === "whale"){
        layer.mood -= worldMood * 0.05;
      }

      // 王國偏維穩
      if(key === "kingdom"){
        layer.mood -= worldMood * 0.02;
      }

      // 漲太多
      if(Number(asset.lastChangePct || 0) > 2){
        if(key === "retail"){
          layer.greed += 0.03;
        }

        if(key === "whale"){
          layer.greed -= 0.02;
        }
      }

      // 跌太多
      if(Number(asset.lastChangePct || 0) < -2){
        if(key === "retail"){
          layer.fear += 0.04;
        }

        if(key === "whale"){
          layer.fear -= 0.01;
        }
      }

      layer.mood =
        clamp(layer.mood, -1, 1);

      layer.fear =
        clamp(layer.fear, 0, 1);

      layer.greed =
        clamp(layer.greed, 0, 1);

    });

    return layers;
  }

function updateEmotionSides(asset){
    if(!asset) return null;

    var bull =
      Math.max(
        1,
        Number(asset.bullEmotionPower || rand(40, 60))
      );

    var bear =
      Math.max(
        1,
        Number(asset.bearEmotionPower || rand(40, 60))
      );

    var mood =
      Number(asset.aiMoodScore || 0);

    var overheat =
      clamp(Number(asset.aiOverheatLevel || 0), 0, 1);

    var panic =
      clamp(Number(asset.aiPanicLevel || 0), 0, 1);

    var bubble =
      clamp(Number(asset.aiBubbleLevel || 0), 0, 1);

    var pnl =
      Number(asset.aiUnrealizedPnl || 0);

    // 多頭情緒
    bull +=
      mood * rand(2.0, 5.0);

    // 空頭情緒
    bear +=
      panic * rand(3.0, 6.0);

    // 漲太多 → 獲利了結
    if(pnl > 0.08){
      var convert =
        pnl * rand(8, 20);

      bull -= convert;
      bear += convert;
    }

    // 過熱轉空
    if(overheat > 0.45 || bubble > 0.55){
      var hotShift =
        (overheat + bubble) *
        rand(5, 15);

      bull -= hotShift;
      bear += hotShift;
    }

    // 超跌空方回補
    if(panic > 0.45 && mood > -0.4){
      var coverShift =
        panic *
        rand(3, 10);

      bear -= coverShift;
      bull += coverShift;
    }

    // 市場會自己循環
    bull += rand(-2.5, 2.5);
    bear += rand(-2.5, 2.5);

    bull = clamp(bull, 1, 500);
    bear = clamp(bear, 1, 500);

    asset.bullEmotionPower = bull;
    asset.bearEmotionPower = bear;

    return {
      bull: bull,
      bear: bear,
      force: bull - bear,
      ratio: bull / Math.max(1, bear)
    };
  }


  // =====================================================
  // Market Core V3.4
  // 現實股市化：趨勢慣性系統
  // =====================================================

  function updateMarketTrendPower(asset, oldPrice, newPrice, aiMarketBrain){
    if(!asset) return 0;

    var oldTrend =
      Number(asset.trendPower || 0);

    var dir =
      newPrice > oldPrice ? 1 :
      newPrice < oldPrice ? -1 :
      0;

    var mood =
      Number(aiMarketBrain && aiMarketBrain.moodScore || 0);

    var eventMemory =
      Number(asset.eventMomentum || 0);

    var trend =
      oldTrend * 0.94;

    if(dir > 0){
      trend += 0.85;
    }else if(dir < 0){
      trend -= 0.85;
    }else{
      trend *= 0.96;
    }

    trend += clamp(mood * 0.22, -0.35, 0.35);
    trend += clamp(eventMemory * 0.10, -0.25, 0.25);

    trend =
      clamp(
        trend,
        -18,
        18
      );

    asset.trendPower = trend;

    return trend;
  }

  function getTrendDirectionBias(asset){
    var trend =
      Number(asset && asset.trendPower || 0);

    if(Math.abs(trend) < 1.5){
      return 0;
    }

    return trend > 0 ? 1 : -1;
  }

function updateOneStarterAsset(state, asset) {
    var evtEffect = getCombinedNarrativeEffectForAsset(state, asset.id);
    var evtMeta = getCombinedNarrativeMetaForAsset(state, asset.id);
    var climateBias = w.StockMarketClimate.getTrendBias(state);
    var climateVol = w.StockMarketClimate.getVolatilityMultiplier(state);
    var worldDrift = state.worldState ? Number(state.worldState.drift || 0) : 0;
    var worldVol = state.worldState ? Number(state.worldState.volatilityBonus || 0) : 0;

    var fairBase = ensureAnchorPriceState(asset);
    var fairGap = fairBase > 0 ? (fairBase - asset.price) / fairBase : 0;
    var meanGap = asset.meanPrice > 0 ? (asset.meanPrice - asset.price) / asset.meanPrice : 0;
    var eventBias = evtEffect.bias;
    var eventVol = evtEffect.volatilityBonus;
    var liqShift = evtMeta ? Number(evtMeta.liquidityShift || 0) : 0;
    var confShift = evtMeta ? Number(evtMeta.confidenceImpact || 0) : 0;

    var randomSwing = (Math.random() * 2 - 1) *
      (0.00035 + worldVol * 0.45 + eventVol * 0.12 + Math.abs(liqShift) * 0.0012) *
      climateVol;

    var rate =
      Number(asset.baseTrend || 0) * 0.08 +
      worldDrift * 0.40 +
      climateBias * 0.30 +
      fairGap * 0.04 +
      meanGap * 0.05 +
      eventBias * 0.08 +
      confShift * 0.005 +
      randomSwing;

    rate = clamp(rate, -0.010, 0.010);

    var oldPrice = Math.max(PRICE_FLOOR, Math.floor(asset.price || asset.basePrice || 1));
    var newPrice = applyPriceTickRule(oldPrice, oldPrice * (1 + rate));
    newPrice = applyAnchorBoundToPrice(asset, newPrice);

    asset.price = applyCentralMarketLimitToAsset(asset, newPrice);

    updateMarketTrendPower(
      asset,
      oldPrice,
      newPrice,
      aiMarketBrain
    );

    asset.lastChangeValue = newPrice - oldPrice;
    asset.lastChangePct = oldPrice > 0 ? ((newPrice - oldPrice) / oldPrice) * 100 : 0;
    if (newPrice > asset.dayHighPrice) asset.dayHighPrice = newPrice;
    if (newPrice < asset.dayLowPrice) asset.dayLowPrice = newPrice;
    asset.meanPrice = Number(asset.meanPrice || fairBase) * 0.997 + fairBase * 0.003;
    asset._lastFairValue = fairBase;

    var starterVolBase = 50 + Math.abs(rate) * 20000 + Math.max(0, eventVol * 5000);
    asset.companyMetrics.latestDailyVolume += Math.max(0, Math.floor(starterVolBase));
  }

function updateOneFreeAsset(state, asset) {

    // =====================================================
    // Market Core V2
    // 純 Tick 撮合核心：
    // - AI 不直接改價格
    // - 舊 drift / percent / momentum 改價全部移除
    // - 價格只能透過 Tick Matching Engine 改變
    // =====================================================

    if (asset.limitLocked) {
      asset._npcBuy = 0;
      asset._npcSell = 0;
      asset._lastPressure = 0;
      asset._lastFlowRatio = 0;
      asset.playerImpactBuy = Number(asset.playerImpactBuy || 0) * Number(asset.playerImpactDecay || 0.92);
      asset.playerImpactSell = Number(asset.playerImpactSell || 0) * Number(asset.playerImpactDecay || 0.92);
      asset.playerRecentNetFlow = Number(asset.playerRecentNetFlow || 0) * 0.94;
      asset._lastPlayerTradeImpact = 0;
      return;
    }

    var profile = getTierProfile(asset);

    normalizeEquityShares(asset);
    ensureLiquidityModel(asset);
    repairAssetPriceFields(asset);

    var floatShares = Math.max(1, Math.floor(Number(asset.floatShares || asset.totalShares || 1)));
    var available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
    var insider = Math.max(0, Math.floor(Number(asset.insiderShares || 0)));
    var core = Math.max(0, Math.floor(Number(asset.strategicHoldingShares || 0)));
    var trade = Math.max(0, Math.floor(Number(asset.marketMakerShares || 0)));

    var evtEffect = getCombinedNarrativeEffectForAsset(state, asset.id);
    var evtMeta = getCombinedNarrativeMetaForAsset(state, asset.id);

    var capitalEffect =
      (w.ForeignCapitalAI && typeof w.ForeignCapitalAI.getEffectForAsset === "function")
        ? w.ForeignCapitalAI.getEffectForAsset(state, asset)
        : null;

    capitalEffect = capitalEffect || {
      buyBoost: 0,
      sellBoost: 0,
      liquidityDrain: 0,
      volatilityBoost: 0,
      drift: 0,
      anchorLift: 0
    };

    var fairValue = ensureAnchorPriceState(asset);
    var effectiveLiquidity = getEffectiveLiquidity(asset, state);

    var aiMarketBrain =
      updateAIMarketBrain(state, asset, evtEffect, evtMeta, capitalEffect);

    if (aiMarketBrain && aiMarketBrain.fairValueMilli) {
      fairValue = aiMarketBrain.fairValueMilli;
    }

    var aiTradingBrain =
      updateAITradingBrain(state, asset, aiMarketBrain, profile);

    var emotionSides =
      updateEmotionSides(asset);

    // Market Core V2.2
    // 四層 NPC AI
    var npcLayers =
      updateNpcLayers(
        state,
        asset,
        aiMarketBrain
      );

    asset._lastFairValue = fairValue;

    var releasedLocked = maybeReleaseLockedShares(state, asset, evtMeta, effectiveLiquidity);
    if (releasedLocked > 0) {
      floatShares = Math.max(1, Math.floor(Number(asset.floatShares || asset.totalShares || 1)));
      available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
      insider = Math.max(0, Math.floor(Number(asset.insiderShares || 0)));
      core = Math.max(0, Math.floor(Number(asset.strategicHoldingShares || 0)));
      trade = Math.max(0, Math.floor(Number(asset.marketMakerShares || 0)));
    }

    var decay = Number(asset.playerImpactDecay || 0.92);
    asset.playerImpactBuy = Number(asset.playerImpactBuy || 0) * decay;
    asset.playerImpactSell = Number(asset.playerImpactSell || 0) * decay;
    asset.playerRecentNetFlow = Number(asset.playerRecentNetFlow || 0) * 0.96;

    var playerImpactNet =
      clamp(Number(asset.playerImpactBuy || 0) - Number(asset.playerImpactSell || 0), -0.20, 0.20);

    // -----------------------------------------------------
    // Order Layer：所有力量都轉成買賣單，不直接改價格
    // -----------------------------------------------------

    var baseMarketFlow =
      Math.max(
        1,
        Math.floor(floatShares * profile.baseMarketFlowRate)
      );

    var marketBuy = 0;
    var marketSell = 0;

    // =====================================================
    // Retail AI
    // 高頻微波動
    // =====================================================

    var retail =
      npcLayers.retail;

    marketBuy += Math.floor(
      baseMarketFlow *
      retail.activity *
      (1 + Math.max(0, retail.mood)) *
      rand(0.8, 1.3)
    );

    marketSell += Math.floor(
      baseMarketFlow *
      retail.activity *
      (1 + Math.max(0, -retail.mood + retail.fear)) *
      rand(0.8, 1.3)
    );

    // =====================================================
    // Institution AI
    // 中長線穩定
    // =====================================================

    var institution =
      npcLayers.institution;

    marketBuy += Math.floor(
      baseMarketFlow *
      institution.capital *
      institution.activity *
      (1 + Math.max(0, institution.mood)) *
      0.35
    );

    marketSell += Math.floor(
      baseMarketFlow *
      institution.capital *
      institution.activity *
      (1 + Math.max(0, -institution.mood)) *
      0.30
    );

    // =====================================================
    // Whale AI
    // 主力 / 財團
    // =====================================================

    var whale =
      npcLayers.whale;

    marketBuy += Math.floor(
      baseMarketFlow *
      whale.capital *
      whale.activity *
      (1 + Math.max(0, whale.mood - whale.fear)) *
      0.22
    );

    marketSell += Math.floor(
      baseMarketFlow *
      whale.capital *
      whale.activity *
      (1 + Math.max(0, -whale.mood + whale.greed)) *
      0.22
    );

    // =====================================================
    // Kingdom AI
    // 王國維穩
    // =====================================================

    var kingdom =
      npcLayers.kingdom;

    // 暴跌時王國承接
    if(Number(asset.lastChangePct || 0) < -3){
      marketBuy += Math.floor(
        baseMarketFlow *
        kingdom.capital *
        kingdom.activity *
        0.35
      );
    }

    // 暴漲時王國降溫
    if(Number(asset.lastChangePct || 0) > 4){
      marketSell += Math.floor(
        baseMarketFlow *
        kingdom.capital *
        kingdom.activity *
        0.28
      );
    }

    if (aiTradingBrain) {
      marketBuy += Math.max(0, Math.floor(Number(aiTradingBrain.buyShares || 0)));
      marketSell += Math.max(0, Math.floor(Number(aiTradingBrain.sellShares || 0)));
    }

    var antiStallFlow =
      applyAntiStallLiquidity(
        asset,
        marketBuy,
        marketSell
      );

    marketBuy = Math.floor(antiStallFlow.buy);
    marketSell = Math.floor(antiStallFlow.sell);

    var tradeRelease = trade * profile.tradeReleaseRate;
    var coreRelease = core * profile.coreReleaseRate;
    var insiderRelease = insider * profile.insiderReleaseRate;
    var tradeAbsorb = available * profile.tradeAbsorbRate;

    // AI Market Brain：只改掛單強度
    if (aiMarketBrain) {
      if (Number(aiMarketBrain.moodScore || 0) > 0) {
        tradeAbsorb *= 1 + Math.min(1.8, Number(aiMarketBrain.moodScore || 0) * 0.45);
        tradeRelease *= Math.max(0.45, 1 - Number(aiMarketBrain.moodScore || 0) * 0.10);
      } else if (Number(aiMarketBrain.moodScore || 0) < 0) {
        tradeRelease *= 1 + Math.min(1.8, Math.abs(Number(aiMarketBrain.moodScore || 0)) * 0.45);
        tradeAbsorb *= Math.max(0.45, 1 - Math.abs(Number(aiMarketBrain.moodScore || 0)) * 0.10);
      }

      if (Number(aiMarketBrain.panic || 0) > 0.55) {
        tradeRelease *= 1 + Number(aiMarketBrain.panic || 0) * 0.65;
      }

      if (Number(aiMarketBrain.undervalued || 0) > 0.45) {
        tradeAbsorb *= 1 + Number(aiMarketBrain.undervalued || 0) * 0.55;
      }

      if (Number(aiMarketBrain.bubble || 0) > 0.55) {
        tradeRelease *= 1 + Number(aiMarketBrain.bubble || 0) * 0.40;
      }
    }

    // 事件與外資仍然存在，但只能影響掛單
    if (evtEffect.bias > 0) {
      tradeAbsorb *= 1 + Math.abs(evtEffect.bias) * profile.eventBoost * 5.0;
      tradeRelease *= 0.90;
      coreRelease *= 0.96;
    } else if (evtEffect.bias < 0) {
      tradeRelease *= 1 + Math.abs(evtEffect.bias) * profile.eventBoost * 5.0;
      coreRelease *= 1 + Math.abs(evtEffect.bias) * profile.eventBoost * 1.2;
      insiderRelease *= 1 + Math.abs(evtEffect.bias) * 0.15;
      tradeAbsorb *= 0.90;
    }

    tradeRelease *= (1 + Number(evtMeta.npcPanicSellBoost || 0) * 0.35);
    coreRelease *= (1 + Number(evtMeta.strategicHoldingReleaseBoost || 0) * 0.30);
    tradeAbsorb *= (1 + Number(evtMeta.npcFomoBuyBoost || 0) * 0.35);
    tradeAbsorb *= (1 + Number(evtMeta.npcAbsorbBoost || 0) * 0.30);

    if (capitalEffect) {
      var capBuy = Math.max(0, Number(capitalEffect.buyBoost || 0));
      var capSell = Math.max(0, Number(capitalEffect.sellBoost || 0));
      var capDrain = Math.max(0, Number(capitalEffect.liquidityDrain || 0));

      if (capBuy > 0) {
        tradeAbsorb *= (1 + capBuy * 0.75);
        tradeRelease *= Math.max(0.40, 1 - capBuy * 0.18);
      }

      if (capSell > 0) {
        tradeRelease *= (1 + capSell * 0.75);
        tradeAbsorb *= Math.max(0.40, 1 - capSell * 0.18);
      }

      if (capDrain > 0) {
        asset.availableShares = Math.max(
          0,
          Math.floor(Number(asset.availableShares || 0) * Math.max(0.35, 1 - capDrain * 0.05))
        );
        available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
      }
    }

    // 玩家影響轉成掛單
    if (playerImpactNet > 0) {
      tradeAbsorb *= 1 + playerImpactNet * 2.0;
      tradeRelease *= 1 + playerImpactNet * 0.25;
    } else if (playerImpactNet < 0) {
      var absNet = Math.abs(playerImpactNet);
      tradeRelease *= 1 + absNet * 2.0;
      tradeAbsorb *= 1 + absNet * 0.25;
    }

    // -----------------------------------------------------
    // Counter Emotion：漲多賣壓 / 跌多回補
    // -----------------------------------------------------

    var oldPrice =
      forceQuantizedPriceMilli(
        asset.price || asset.basePrice || PRICE_FLOOR
      );

    asset.price = applyCentralMarketLimitToAsset(asset, oldPrice);

    var tickSize =
      Math.max(
        1,
        getPriceStepFromMilli(oldPrice)
      );

    var openBase =
      Math.max(
        PRICE_FLOOR,
        forceQuantizedPriceMilli(asset.dayOpenPrice || oldPrice)
      );

    var intradayMove =
      (oldPrice - openBase) / Math.max(1, openBase);

    if (intradayMove >= 0.035) {
      var profitTaking = intradayMove * floatShares * 0.000055;
      tradeRelease += profitTaking;
      marketSell += Math.floor(profitTaking * rand(0.15, 0.42));
    }

    if (intradayMove >= 0.085) {
      var heavyProfitTaking = intradayMove * floatShares * 0.000075;
      tradeRelease += heavyProfitTaking;
      coreRelease += heavyProfitTaking * 0.05;
    }

    if (intradayMove <= -0.035) {
      var dipBuy = Math.abs(intradayMove) * floatShares * 0.000050;
      tradeAbsorb += dipBuy;
      marketBuy += Math.floor(dipBuy * rand(0.14, 0.40));
    }

    if (intradayMove <= -0.085) {
      var shortCover = Math.abs(intradayMove) * floatShares * 0.000070;
      tradeAbsorb += shortCover;
    }

    if (Number(asset.aiUnrealizedPnl || 0) > 0.08) {
      tradeRelease += floatShares * Math.min(0.00035, Number(asset.aiUnrealizedPnl || 0) * 0.00022);
    }

    if (Number(asset.aiUnrealizedPnl || 0) < -0.10) {
      tradeAbsorb += floatShares * Math.min(0.00030, Math.abs(Number(asset.aiUnrealizedPnl || 0)) * 0.00020);
    }

    if (state.shockState && state.shockState.assetId === asset.id) {
      if (state.shockState.type === "buy") tradeAbsorb *= state.shockState.multiplier;
      else tradeRelease *= state.shockState.multiplier;
    }

    var npcBuy = Math.max(0, marketBuy + tradeAbsorb);
    var npcSell = Math.max(0, marketSell + tradeRelease + coreRelease + insiderRelease);

    npcBuy = Math.max(0, Math.min(available, npcBuy));

    var insiderFloor = Math.floor(floatShares * profile.minInsiderHoldRatio);
    var coreFloor = Math.floor(floatShares * profile.minCoreHoldRatio);

    var maxInsiderSell = Math.max(0, insider - insiderFloor);
    var maxCoreSell = Math.max(0, core - coreFloor);
    var maxSellable = trade + maxCoreSell + maxInsiderSell;

    npcSell = Math.max(0, Math.min(maxSellable, npcSell));

    
    
    // -----------------------------------------------------
    // Market Core V2.3
    // 即時 1 Tick 撮合市場
    // -----------------------------------------------------

    var totalFlow = npcBuy + npcSell;

    var pressure =
      (npcBuy - npcSell) /
      Math.max(1, floatShares);

    var buyOrders =
      Math.floor(
        npcBuy /
        Math.max(1, floatShares * 0.00002)
      );

    var sellOrders =
      Math.floor(
        npcSell /
        Math.max(1, floatShares * 0.00002)
      );

    var bullPower =
      Math.max(
        1,
        Number(asset.bullEmotionPower || 50)
      );

    var bearPower =
      Math.max(
        1,
        Number(asset.bearEmotionPower || 50)
      );

    if (emotionSides) {
      bullPower =
        Number(emotionSides.bull || bullPower);

      bearPower =
        Number(emotionSides.bear || bearPower);
    }

    // 散戶提供持續微波動
    buyOrders +=
      Math.floor(
        bullPower *
        rand(0.25, 0.55)
      );

    sellOrders +=
      Math.floor(
        bearPower *
        rand(0.25, 0.55)
      );

    // 多空差
    var imbalance =
      buyOrders - sellOrders;

    // =====================================================
    // V2.3 核心
    // 每次更新都直接決定 1 Tick
    // =====================================================

    var direction = 0;

    // 多方略強
    if (imbalance > 0) {
      direction = 1;
    }

    // 空方略強
    else if (imbalance < 0) {
      direction = -1;
    }

    // 完全平衡時仍然微震盪
    else {
      direction =
        Math.random() < 0.5
          ? -1
          : 1;
    }

    // Market Core V3.4：
    // 趨勢慣性有機率主導短線方向，讓市場不會每秒被估值拉回。
    var trendBiasDir =
      getTrendDirectionBias(asset);

    if(trendBiasDir !== 0){
      var trendAbs =
        Math.min(
          18,
          Math.abs(Number(asset.trendPower || 0))
        );

      var trendFollowChance =
        clamp(
          0.18 + trendAbs * 0.025,
          0.18,
          0.62
        );

      if(Math.random() < trendFollowChance){
        direction = trendBiasDir;
      }
    }

    // -----------------------------------------------------
    // 反情緒系統
    // -----------------------------------------------------

    var centralLimitType = MARKET_CONTROL ? MARKET_CONTROL.getAssetMarketType(asset) : "normal";
    var upLimit =
      MARKET_CONTROL && MARKET_CONTROL.getLimitRate(centralLimitType, "up", 0) <= 0
        ? Number.POSITIVE_INFINITY
        : forceQuantizedPriceMilli(
            openBase * (1 + AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).up)
          );

    var downLimit =
      MARKET_CONTROL && MARKET_CONTROL.getLimitRate(centralLimitType, "down", 0) <= 0
        ? PRICE_FLOOR
        : forceQuantizedPriceMilli(
            openBase * (1 - AI5MarketControl.getLimitPrices((asset.openPrice||asset.dayOpen||asset.price), asset).down)
          );

    var bandRange =
      Math.max(
        1,
        upLimit - downLimit
      );

    var bandPos =
      (oldPrice - downLimit) / bandRange;

    // 漲太高容易被壓
    if (direction > 0 && bandPos > 0.85) {

      if (Math.random() < 0.34) {
        direction = -1;
      }

    }

    // 跌太深容易承接
    if (direction < 0 && bandPos < 0.15) {

      if (Math.random() < 0.34) {
        direction = 1;
      }

    }

    // 極端情緒才有機率不動
    var freezeChance = 0.04;

    if (Math.abs(imbalance) > 35) {
      freezeChance = 0.01;
    }

    if (Math.random() < freezeChance) {
      direction = 0;
    }

    // =====================================================
    // 永遠只移動 1 Tick
    // =====================================================

    var tickMove =
      direction === 0
        ? 0
        : 1;

    var rawPrice =
      oldPrice +
      direction *
      tickSize *
      tickMove;

    var newPrice =
      forceQuantizedPriceMilli(rawPrice);

    if (newPrice > upLimit) newPrice = forceQuantizedPriceMilli(upLimit);
    if (newPrice < downLimit) newPrice = forceQuantizedPriceMilli(downLimit);

    asset.limitUpLocked = false;
    asset.limitDownLocked = false;

    if (newPrice >= upLimit) {
      newPrice = forceQuantizedPriceMilli(upLimit);
      asset.limitLocked = true;
      asset.limitType = "up";
      asset.limitUpLocked = true;
      asset.upRemainingSellLiquidity = Math.max(0, Math.min(Math.floor(Number(asset.availableShares || 0)), Math.floor(rand(0, 8))));
      asset.availableShares = asset.upRemainingSellLiquidity;
      pushNews(state, asset.name + " 觸及漲停", "該股已鎖定至下一個交易日開盤前。", "bullish");
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));
    } else if (newPrice <= downLimit) {
      newPrice = forceQuantizedPriceMilli(downLimit);
      asset.limitLocked = true;
      asset.limitType = "down";
      asset.limitDownLocked = true;
      asset.downRemainingBuyLiquidity = Math.max(0, Math.min(Math.floor(Number(asset.dailyBuyLiquidityShares || 0)), Math.floor(rand(0, 8))));
      asset.dailyBuyLiquidityShares = asset.downRemainingBuyLiquidity;
      pushNews(state, asset.name + " 觸及跌停", "該股已鎖定至下一個交易日開盤前。", "bearish");
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));
    }

    asset.price = applyCentralMarketLimitToAsset(asset, newPrice);
    asset.lastChangeValue = newPrice - oldPrice;
    asset.lastChangePct = oldPrice > 0 ? ((newPrice - oldPrice) / oldPrice) * 100 : 0;

    if (newPrice > asset.dayHighPrice) asset.dayHighPrice = newPrice;
    if (newPrice < asset.dayLowPrice) asset.dayLowPrice = newPrice;

    var actualBuy = Math.floor(npcBuy);
    var actualSell = Math.floor(npcSell);

    var sellFromTrade = Math.min(trade, actualSell);
    var remainingAfterTrade = Math.max(0, actualSell - sellFromTrade);

    var sellFromCore = Math.min(maxCoreSell, remainingAfterTrade);
    var remainingAfterCore = Math.max(0, remainingAfterTrade - sellFromCore);

    var sellFromInsider = Math.min(maxInsiderSell, remainingAfterCore);

    asset.availableShares = clamp(
      available - actualBuy + actualSell,
      0,
      Math.max(0, Math.floor(Number(asset.dayOpenSellLiquidityShares || floatShares)))
    );

    asset.marketMakerShares = clamp(trade + actualBuy - sellFromTrade, 0, floatShares);
    asset.strategicHoldingShares = clamp(core - sellFromCore, 0, floatShares);
    asset.insiderShares = clamp(insider - sellFromInsider, 0, floatShares);

    normalizeEquityShares(asset);
    ensureLiquidityModel(asset);

    asset._npcBuy = actualBuy;
    asset._npcSell = actualSell;
    asset._lastPressure = pressure;
    asset._lastFlowRatio = totalFlow / Math.max(1, floatShares * 0.003);
    asset._lastPlayerTradeImpact = playerImpactNet;
    asset.lastTickMove = tickMove * direction;
    asset.lastBuyOrders = buyOrders;
    asset.lastSellOrders = sellOrders;

    asset.lastRetailMood =
      Number(npcLayers.retail.mood || 0);

    asset.lastInstitutionMood =
      Number(npcLayers.institution.mood || 0);

    asset.lastWhaleMood =
      Number(npcLayers.whale.mood || 0);

    asset.lastKingdomMood =
      Number(npcLayers.kingdom.mood || 0);
    asset.meanPrice = Number(asset.meanPrice || fairValue) * 0.998 + fairValue * 0.002;

    asset.companyMetrics.latestDailyVolume += Math.max(0, actualBuy + actualSell);
  }

  function updateOneAsset(state, asset) {
    if (!asset || !asset.unlocked) return;
    if (asset.marketType === "free") updateOneFreeAsset(state, asset);
    else updateOneStarterAsset(state, asset);
  }

  function runTick(state) {
    ensureState(state);

    // Market Core V3.2：
    // AI Event Ecosystem 每個市場 tick 只執行一次。
    if (typeof updateAIEventEcosystem === "function") {
      var aiEventTickKey = String(state.marketDay || 0) + ":" + String(state.marketDayTick || 0) + ":" + String(state.marketPhase || "");
      if (state._aiEventLastTick !== aiEventTickKey) {
        state._aiEventLastTick = aiEventTickKey;
        updateAIEventEcosystem(state);
      }
    }

    state.phaseElapsedSec += 1;
    state.stats.totalTicks += 1;

    if (state.marketPhase === "closed") {
      tickShockState(state);
      if (state.phaseElapsedSec >= MARKET_CLOSE_SEC) transitionPhase(state);
      return;
    }

    if (isDividendSettlementDay(state)) {
      if (state.marketDayTick === 0) {
        processDividendSettlement(state);
      }
      state.marketDayTick += 1;
      var dividendPhaseTotal = state.marketPhase === "preopen" ? MARKET_PREOPEN_SEC : MARKET_OPEN_SEC;
      if (state.phaseElapsedSec >= dividendPhaseTotal) transitionPhase(state);
      return;
    }

    state.marketDayTick += 1;
    w.StockMarketClimate.tickClimate(state);
    w.StockMarketEvents.tickActiveEvents(state);
    w.StockMarketCompanyDynamics.tickActiveDynamics(state);
    var resolvedDecisions = w.StockMarketCompanyDynamics.tickDecisions ? w.StockMarketCompanyDynamics.tickDecisions(state) : [];
    if (resolvedDecisions && resolvedDecisions.length) {
      for (var rd = 0; rd < resolvedDecisions.length; rd++) {
        var result = resolvedDecisions[rd];
        if (!result || !result.decision) continue;
        var dec = result.decision;
        var tone = dec.status === "passed" ? "bullish" : "neutral";
        pushNews(
          state,
          "董事會表決：" + dec.assetName + "｜" + (dec.status === "passed" ? "提案通過" : "提案否決"),
          "提案：" + dec.title +
            "｜玩家投票：" + (dec.playerVote === "agree" ? "同意" : (dec.playerVote === "reject" ? "反對" : (dec.playerVote === "abstain" ? "棄權" : (dec.playerEligible ? "未投票" : "無資格")))) +
            "｜董事會支持度：" + (Number(dec.finalSupport || 0) * 100).toFixed(1) + "%",
          tone
        );
      }
    }
    maybeRollShockState(state);
    tickShockState(state);

    // F2.8：外部資本 AI（獨立系統）
    // 只影響流動性 / NPC 買賣壓 / 短期市場壓力，不直接改 ETF。
    if (w.ForeignCapitalAI && typeof w.ForeignCapitalAI.tick === "function") {
      try {
        w.ForeignCapitalAI.tick(state);
      } catch (e) {
        console.error("ForeignCapitalAI tick error", e);
      }
    }

    // 每秒更新全市場的內部價格資料。
    // UI 只需要目前開啟頁面重繪；其他頁面切換進去時會從 state 讀到最新價格。
    if (state.marketPhase === "open") {

      state.runtime.heavyTickCursor = 0;

      updateAssetBatch(
        state,
        getUpdatableAssetIds(state).length
      );

    }

    // F2.6.1：NPC 背景市場持續補充買賣流動性。
    refreshIntradayLiquidity(state);

    // F2.6：處理玩家集中盤委託。
    processPendingOrders(state);

    // F2.7：ETF 商會背景更新（獨立系統，不反向影響個股）。
    if (w.StockETFSystem && typeof w.StockETFSystem.tick === "function") {
      try {
        w.StockETFSystem.tick(state);
      } catch (e) {
        console.error("StockETFSystem tick error", e);
      }
    }

    // F2.9.1：第二基金「王國戰略資本」背景更新（主動型，會透過真實持倉影響個股）。
    if (w.StockActiveETFSystem && typeof w.StockActiveETFSystem.tick === "function") {
      try {
        w.StockActiveETFSystem.tick(state);
      } catch (e) {
        console.error("StockActiveETFSystem tick error", e);
      }
    }

    w.StockMarketEvents.cleanupExpiredEvents(state);
    w.StockMarketCompanyDynamics.cleanupExpiredDynamics(state);

    var phaseTotal = state.marketPhase === "preopen" ? MARKET_PREOPEN_SEC : MARKET_OPEN_SEC;
    if (state.phaseElapsedSec >= phaseTotal) transitionPhase(state);
  }

  function settleToNow(state) {
    ensureState(state);

    var now = Date.now();
    var last = Number(state.lastTs || now);
    
var rawDiffSec =
  Math.max(
    0,
    (now - last) / 1000
  );

// ===== 世界凍結 =====
// 如果超過 3 秒沒更新
// 視為玩家離線
if (rawDiffSec > 3) {

  try {

    applyRealWorldFreeze(state);

  } catch(e) {}

  // 不補離線時間
  var diffSec = 0;

} else {

  // 正常在線時間
  var diffSec = rawDiffSec;
}


    // 重要：不能用 Math.floor(diffSec)，也不能在每次 RAF 時把小於 1 秒的差值丟掉。
    // 否則每次畫面更新都會重設 lastTs，造成「現實時間有過，但遊戲時間不動」。
    var totalSec = Math.max(0, Number(state.tickRemainderSec || 0)) + diffSec;
    var ticks = Math.floor(totalSec / TICK_SEC);

    state.tickRemainderSec = totalSec - ticks * TICK_SEC;
    state.lastTs = now;

    // 避免離線很久一次跑太多 tick 卡死；超過上限的部分先保留在 remainder，之後分批補。
    if (ticks > MAX_OFFLINE_TICKS) {
      state.tickRemainderSec += (ticks - MAX_OFFLINE_TICKS) * TICK_SEC;
      ticks = MAX_OFFLINE_TICKS;
    }

    while (ticks > 0) {
      runTick(state);
      ticks--;
    }
  }

  function getLimitDryTradableQty(asset, side, requestedQty, holdingQty) {
    if (!asset || !asset.limitLocked) {
      return Math.max(1, Math.floor(Number(requestedQty || 0)));
    }

    var q = Math.max(1, Math.floor(Number(requestedQty || 0)));
    ensureLiquidityModel(asset);
    var available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
    var holding = Math.max(0, Math.floor(Number(holdingQty || 0)));

    // ============================
    // 漲停：市場幾乎沒人賣
    // 只保留極少量流動性
    // 而且會被實際消耗
    // ============================
    if (asset.limitType === "up" && side === "buy") {

      if (!(Number(asset.upRemainingSellLiquidity) >= 0)) {

        asset.upRemainingSellLiquidity =
          Math.max(
            0,
            Math.min(
              available,
              Math.floor(rand(0, 8))
            )
          );

      }

      return Math.max(
        0,
        Math.floor(asset.upRemainingSellLiquidity)
      );

    }

    // ============================
    // 跌停：市場幾乎沒人接
    // 但仍保留少量接盤
    // 並會被逐步吃光
    // ============================
    if (asset.limitType === "down" && side === "sell") {

      if (!(Number(asset.downRemainingBuyLiquidity) >= 0)) {

        asset.downRemainingBuyLiquidity =
          Math.max(
            0,
            Math.min(
              Math.floor(Number(asset.dailyBuyLiquidityShares || 0)),
              Math.floor(rand(0, 8))
            )
          );

      }

      return Math.max(
        0,
        Math.floor(asset.downRemainingBuyLiquidity)
      );

    }

    // 漲停賣出 / 跌停買入正常
    return q;
  }

  function calcBuyCost(priceMilli, qty) {
    var gross = priceMilli * qty;
    var fee = Math.floor(gross * BUY_FEE_RATE);
    return { grossMilli: gross, feeMilli: fee, totalMilli: gross + fee };
  }

  function calcSellIncome(priceMilli, qty) {
    var gross = priceMilli * qty;
    var fee = Math.floor(gross * SELL_FEE_RATE);
    var tax = Math.floor(gross * SELL_TAX_RATE);
    return { grossMilli: gross, feeMilli: fee, taxMilli: tax, netMilli: gross - fee - tax };
  }

  function buyAsset(state, assetId, qty) {
    ensureState(state);
    if (state.marketPhase !== "open" || isDividendSettlementDay(state)) return { ok: false, reason: "market_closed" };

    qty = Math.max(1, Math.floor(Number(qty || 0)));
    var asset = state.assets[assetId];
    if (!asset || !asset.unlocked) return { ok: false, reason: "asset_locked" };
    ensureLiquidityModel(asset);

    if (asset.marketType === "free") {
      var available = Math.max(0, Math.floor(asset.availableShares || 0));
      if (available <= 0) return { ok: false, reason: "market_not_enough_shares" };
      qty = Math.min(qty, available);

      var limitMaxBuy = getLimitDryTradableQty(asset, "buy", qty, 0);
      if (asset.limitLocked && asset.limitType === "up") {

        if (limitMaxBuy <= 0) {
          return { ok: false, reason: "market_not_enough_shares" };
        }

        qty = Math.min(qty, limitMaxBuy);

      }
    }

    var cost = calcBuyCost(asset.price, qty);
    var spend = w.StockMarketCurrency.spendMilli(state, cost.totalMilli);
    if (!spend.ok) return { ok: false, reason: spend.reason };

    var h = getHolding(state, assetId);
    var newQty = h.qty + qty;
    var newAvg = Math.floor(((h.qty * h.avgCostMilli) + (qty * asset.price)) / newQty);
    setHolding(state, assetId, newQty, newAvg);

    if (asset.marketType === "free") {
      normalizeEquityShares(asset);
      asset.availableShares = Math.max(0, Math.floor(asset.availableShares - qty));
      applyPlayerTradeImpact(state, asset, "buy", qty);
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));
      asset._lastFairValue = computeStructuralAnchor(asset, state);
      asset.companyMetrics.latestDailyVolume += qty;
      updateCompanyMetricsForAsset(state, asset);
    } else {
      ensureStarterTradableStructure(asset);
      if (Number(asset.availableShares || 0) > 0) {
        asset.availableShares = Math.max(0, Math.floor(Number(asset.availableShares || 0) - qty));
      }
      asset.companyMetrics.latestDailyVolume += qty;
    }

    state.stats.totalBuysMilli += cost.grossMilli;
    state.stats.totalFeesMilli += cost.feeMilli;
    // 玩家交易只影響該個股，不再推動全市場氣候或產業連動。

    pushNews(
      state,
      "買入成交：" + asset.name,
      "數量：" + qty +
        "｜成交總額：" + (cost.grossMilli / SCALE).toFixed(2) +
        "｜手續費：" + (cost.feeMilli / SCALE).toFixed(2) +
        (asset.marketType === "free" ? "｜已對該股產生買盤衝擊" : ""),
      "neutral"
    );

    return { ok: true, qty: qty, grossMilli: cost.grossMilli, feeMilli: cost.feeMilli, totalMilli: cost.totalMilli };
  }

  function sellAsset(state, assetId, qty) {
    ensureState(state);
    if (state.marketPhase !== "open" || isDividendSettlementDay(state)) return { ok: false, reason: "market_closed" };

    qty = Math.max(1, Math.floor(Number(qty || 0)));
    var asset = state.assets[assetId];
    if (!asset || !asset.unlocked) return { ok: false, reason: "asset_locked" };
    ensureLiquidityModel(asset);

    var h = getHolding(state, assetId);
    if (h.qty < qty) return { ok: false, reason: "holding_not_enough" };

    if (asset.marketType === "free") {
      var buyPool = Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0)));
      if (buyPool <= 0) {
        return { ok: false, reason: "market_no_buyers" };
      }
      qty = Math.min(qty, buyPool);

      var limitMaxSell = getLimitDryTradableQty(asset, "sell", qty, h.qty);
      if (asset.limitLocked && asset.limitType === "down") {

        if (limitMaxSell <= 0) {
          return {
            ok: false,
            reason: "market_no_buyers"
          };
        }

        qty = Math.min(qty, limitMaxSell);

      }
    }

    var income = calcSellIncome(asset.price, qty);
    var realized = (asset.price - h.avgCostMilli) * qty - income.feeMilli - income.taxMilli;

    setHolding(state, assetId, h.qty - qty, h.avgCostMilli);
    w.StockMarketCurrency.addMilli(state, income.netMilli);

    if (asset.marketType === "free") {
      normalizeEquityShares(asset);
      asset.dailyBuyLiquidityShares = Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0) - qty));
      asset.availableShares = Math.min(
        Math.floor(asset.dayOpenSellLiquidityShares || asset.floatShares || 0),
        Math.floor((asset.availableShares || 0) + Math.floor(qty * 0.05))
      );
      applyPlayerTradeImpact(state, asset, "sell", qty);
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));

      // 跌停接盤流動性消耗
      if (
        asset.limitLocked &&
        asset.limitType === "down"
      ) {

        asset.downRemainingBuyLiquidity =
          Math.max(
            0,
            Math.floor(
              Number(asset.downRemainingBuyLiquidity || 0) - qty
            )
          );

      }
      asset._lastFairValue = computeStructuralAnchor(asset, state);
      asset.companyMetrics.latestDailyVolume += qty;
      updateCompanyMetricsForAsset(state, asset);
    } else {
      ensureStarterTradableStructure(asset);
      if (Number(asset.availableShares || 0) > 0) {
        asset.availableShares = Math.min(Math.floor(Number(asset.floatShares || asset.availableShares || 0)), Math.floor(Number(asset.availableShares || 0) + qty));
      }
      asset.companyMetrics.latestDailyVolume += qty;
    }

    state.stats.totalSellsMilli += income.grossMilli;
    state.stats.totalFeesMilli += income.feeMilli;
    state.stats.totalTaxesMilli += income.taxMilli;
    state.stats.realizedProfitMilli += realized;
    // 玩家交易只影響該個股，不再推動全市場氣候或產業連動。

    pushNews(
      state,
      "賣出成交：" + asset.name,
      "數量：" + qty +
        "｜成交總額：" + (income.grossMilli / SCALE).toFixed(2) +
        "｜手續費：" + (income.feeMilli / SCALE).toFixed(2) +
        "｜交易稅：" + (income.taxMilli / SCALE).toFixed(2) +
        (asset.marketType === "free" ? "｜已對市場產生賣盤衝擊" : ""),
      "neutral"
    );

    return {
      ok: true,
      qty: qty,
      grossMilli: income.grossMilli,
      feeMilli: income.feeMilli,
      taxMilli: income.taxMilli,
      netMilli: income.netMilli,
      realizedMilli: realized
    };
  }



  // =========================================
  // F2.6 測試版：集中盤 / 委託交易
  // - 每檔股票只保留一筆買入、一筆賣出等候
  // - 下單鎖定當下價格
  // - 買單鎖資金，賣單鎖股票
  // - 每個開盤 tick 依市場流動性逐步成交
  // =========================================
  function ensurePendingTradeOrders(state) {
    if (!state) return {};
    if (!state.pendingTradeOrders || typeof state.pendingTradeOrders !== "object") state.pendingTradeOrders = {};
    return state.pendingTradeOrders;
  }

  function getAssetOrderBook(state, assetId) {
    var all = ensurePendingTradeOrders(state);
    assetId = String(assetId || "");
    if (!all[assetId] || typeof all[assetId] !== "object") all[assetId] = {};
    return all[assetId];
  }

  function getPendingOrder(state, assetId, side) {
    var book = getAssetOrderBook(state, assetId);
    var order = book[String(side || "")];
    if (!order || Math.floor(Number(order.remainingQty || 0)) <= 0) return null;
    return order;
  }

  function getPendingOrdersForAsset(state, assetId) {
    return {
      buy: getPendingOrder(state, assetId, "buy"),
      sell: getPendingOrder(state, assetId, "sell")
    };
  }

  function removePendingOrder(state, assetId, side) {
    var all = ensurePendingTradeOrders(state);
    assetId = String(assetId || "");
    if (all[assetId]) delete all[assetId][String(side || "")];
  }

  function completePendingOrderIfDone(state, assetId, order) {
    if (!order) return;
    if (Math.floor(Number(order.remainingQty || 0)) > 0) return;

    if (order.side === "buy" && Number(order.lockedMilli || 0) > 0) {
      w.StockMarketCurrency.addMilli(state, Math.floor(Number(order.lockedMilli || 0)));
      order.lockedMilli = 0;
    }

    removePendingOrder(state, assetId, order.side);
  }

  function fillPendingOrder(state, asset, order, fillQty) {
    if (!state || !asset || !order) return 0;
    fillQty = Math.max(0, Math.floor(Number(fillQty || 0)));
    if (fillQty <= 0) return 0;

    var assetId = asset.id;
    var priceMilli = Math.max(1, Math.floor(Number(order.priceMilli || asset.price || 1)));

    if (order.side === "buy") {
      var buyCost = calcBuyCost(priceMilli, fillQty);
      if (Number(order.lockedMilli || 0) < buyCost.totalMilli) {
        fillQty = Math.floor(fillQty * (Number(order.lockedMilli || 0) / Math.max(1, buyCost.totalMilli)));
        if (fillQty <= 0) return 0;
        buyCost = calcBuyCost(priceMilli, fillQty);
      }

      var h = getHolding(state, assetId);
      var newQty = h.qty + fillQty;
      var newAvg = Math.floor(((h.qty * h.avgCostMilli) + (fillQty * priceMilli)) / Math.max(1, newQty));
      setHolding(state, assetId, newQty, newAvg);

      order.lockedMilli = Math.max(0, Math.floor(Number(order.lockedMilli || 0) - buyCost.totalMilli));
      order.remainingQty = Math.max(0, Math.floor(Number(order.remainingQty || 0) - fillQty));
      order.filledQty = Math.floor(Number(order.filledQty || 0) + fillQty);

      normalizeEquityShares(asset);
      asset.availableShares = Math.max(0, Math.floor(Number(asset.availableShares || 0) - fillQty));
      if (asset.limitLocked && asset.limitType === "up") {
        asset.upRemainingSellLiquidity = Math.max(0, Math.floor(Number(asset.upRemainingSellLiquidity || 0) - fillQty));
      }

      applyPlayerTradeImpact(state, asset, "buy", fillQty);
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));
      asset._lastFairValue = computeStructuralAnchor(asset, state);
      asset.companyMetrics.latestDailyVolume += fillQty;
      updateCompanyMetricsForAsset(state, asset);

      state.stats.totalBuysMilli += buyCost.grossMilli;
      state.stats.totalFeesMilli += buyCost.feeMilli;
    }
    else if (order.side === "sell") {
      var sellIncome = calcSellIncome(priceMilli, fillQty);
      var realized = (priceMilli - Math.floor(Number(order.avgCostMilli || 0))) * fillQty - sellIncome.feeMilli - sellIncome.taxMilli;

      w.StockMarketCurrency.addMilli(state, sellIncome.netMilli);

      order.remainingQty = Math.max(0, Math.floor(Number(order.remainingQty || 0) - fillQty));
      order.filledQty = Math.floor(Number(order.filledQty || 0) + fillQty);
      order.lockedShares = Math.max(0, Math.floor(Number(order.lockedShares || 0) - fillQty));

      normalizeEquityShares(asset);
      asset.dailyBuyLiquidityShares = Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0) - fillQty));
      asset.availableShares = Math.min(
        Math.floor(asset.dayOpenSellLiquidityShares || asset.floatShares || 0),
        Math.floor((asset.availableShares || 0) + Math.floor(fillQty * 0.05))
      );

      if (asset.limitLocked && asset.limitType === "down") {
        asset.downRemainingBuyLiquidity = Math.max(0, Math.floor(Number(asset.downRemainingBuyLiquidity || 0) - fillQty));
      }

      applyPlayerTradeImpact(state, asset, "sell", fillQty);
      pushMerchantLiquidityAlert(state, asset, getLiquidityState(asset));
      asset._lastFairValue = computeStructuralAnchor(asset, state);
      asset.companyMetrics.latestDailyVolume += fillQty;
      updateCompanyMetricsForAsset(state, asset);

      state.stats.totalSellsMilli += sellIncome.grossMilli;
      state.stats.totalFeesMilli += sellIncome.feeMilli;
      state.stats.totalTaxesMilli += sellIncome.taxMilli;
      state.stats.realizedProfitMilli += realized;
    }

    completePendingOrderIfDone(state, assetId, order);
    return fillQty;
  }

  function processPendingOrdersForAsset(state, asset) {
    if (!state || !asset || !asset.id || state.marketPhase !== "open" || isDividendSettlementDay(state)) return;
    ensureLiquidityModel(asset);
    var orders = getPendingOrdersForAsset(state, asset.id);

    if (orders.buy) {
      var available = Math.max(0, Math.floor(Number(asset.availableShares || 0)));
      var buyCap = available;
      if (asset.limitLocked && asset.limitType === "up") {
        buyCap = getLimitDryTradableQty(asset, "buy", Number(orders.buy.remainingQty || 0), 0);
      } else {
        buyCap = Math.max(1, Math.floor(available * 0.18));
      }
      var buyFill = Math.min(Math.floor(Number(orders.buy.remainingQty || 0)), buyCap);
      fillPendingOrder(state, asset, orders.buy, buyFill);
    }

    if (orders.sell) {
      var buyPool = Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0)));
      var sellCap = buyPool;
      if (asset.limitLocked && asset.limitType === "down") {
        sellCap = getLimitDryTradableQty(asset, "sell", Number(orders.sell.remainingQty || 0), Number(orders.sell.remainingQty || 0));
      } else {
        // 正常流通時，即使買盤池暫時很低，也讓 NPC 基礎接盤逐步出現。
        if (buyPool <= 0) {
          refreshIntradayLiquidityForAsset(state, asset);
          buyPool = Math.max(0, Math.floor(Number(asset.dailyBuyLiquidityShares || 0)));
        }
        sellCap = Math.max(1, Math.floor(buyPool * 0.18));
      }
      var sellFill = Math.min(Math.floor(Number(orders.sell.remainingQty || 0)), sellCap);
      fillPendingOrder(state, asset, orders.sell, sellFill);
    }
  }

  function processPendingOrders(state) {
    ensureState(state);
    if (state.marketPhase !== "open" || isDividendSettlementDay(state)) return;
    var all = ensurePendingTradeOrders(state);
    Object.keys(all).forEach(function(assetId) {
      var asset = state.assets && state.assets[assetId];
      if (asset && asset.unlocked) processPendingOrdersForAsset(state, asset);
    });
  }

  function placePendingOrder(state, assetId, side, qty) {
    ensureState(state);
    if (state.marketPhase !== "open" || isDividendSettlementDay(state)) return { ok: false, reason: "market_closed" };

    assetId = String(assetId || "");
    side = String(side || "");
    qty = Math.max(1, Math.floor(Number(qty || 0)));

    var asset = state.assets[assetId];
    if (!asset || !asset.unlocked) return { ok: false, reason: "asset_locked" };
    if (side !== "buy" && side !== "sell") return { ok: false, reason: "bad_order_side" };

    var book = getAssetOrderBook(state, assetId);
    if (book[side] && Math.floor(Number(book[side].remainingQty || 0)) > 0) {
      return { ok: false, reason: "pending_order_exists" };
    }

    ensureLiquidityModel(asset);
    var priceMilli = Math.max(1, Math.floor(Number(asset.price || asset.startPrice || asset.basePrice || 1)));

    var order = {
      id: Date.now() + "_" + Math.random().toString(36).slice(2),
      assetId: assetId,
      assetName: asset.name || assetId,
      side: side,
      priceMilli: priceMilli,
      qty: qty,
      remainingQty: qty,
      filledQty: 0,
      createdMarketDay: Math.floor(Number(state.marketDay || 1)),
      createdTick: Math.floor(Number(state.marketDayTick || 0)),
      ts: Date.now()
    };

    if (side === "buy") {
      var cost = calcBuyCost(priceMilli, qty);
      var spend = w.StockMarketCurrency.spendMilli(state, cost.totalMilli);
      if (!spend.ok) return { ok: false, reason: spend.reason };
      order.lockedMilli = cost.totalMilli;
    }
    else {
      var h = getHolding(state, assetId);
      if (h.qty < qty) return { ok: false, reason: "holding_not_enough" };
      order.avgCostMilli = h.avgCostMilli;
      order.lockedShares = qty;
      setHolding(state, assetId, h.qty - qty, h.avgCostMilli);
    }

    book[side] = order;

    // 下單後先補一次背景流動性，讓正常流通股票能立即開始撮合。
    refreshIntradayLiquidityForAsset(state, asset);
    processPendingOrdersForAsset(state, asset);

    pushNews(
      state,
      (side === "buy" ? "買入委託：" : "賣出委託：") + (asset.name || assetId),
      "委託價格：" + (priceMilli / SCALE).toFixed(2) + "｜委託數量：" + qty + "｜將依市場流動性逐步成交。",
      "neutral"
    );

    return { ok: true, order: book[side] || order, filledQty: order.filledQty || 0, remainingQty: order.remainingQty || 0 };
  }

  function cancelPendingOrder(state, assetId, side) {
    ensureState(state);
    var order = getPendingOrder(state, assetId, side);
    if (!order) return { ok: false, reason: "pending_order_missing" };

    if (order.side === "buy") {
      var refund = Math.max(0, Math.floor(Number(order.lockedMilli || 0)));
      if (refund > 0) w.StockMarketCurrency.addMilli(state, refund);
    }
    else if (order.side === "sell") {
      var remain = Math.max(0, Math.floor(Number(order.remainingQty || 0)));
      if (remain > 0) {
        var h = getHolding(state, assetId);
        var newQty = h.qty + remain;
        var avg = Math.floor(((h.qty * h.avgCostMilli) + (remain * Math.floor(Number(order.avgCostMilli || h.avgCostMilli || 0)))) / Math.max(1, newQty));
        setHolding(state, assetId, newQty, avg);
      }
    }

    removePendingOrder(state, assetId, side);
    return { ok: true };
  }

  function totalMarketValue(state) {
    ensureState(state);
    var total = 0;
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var h = getHolding(state, id);
      total += state.assets[id].price * h.qty;
    }
    return total;
  }

  function totalUnrealized(state) {
    ensureState(state);
    var total = 0;
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      var h = getHolding(state, id);
      total += (asset.price - h.avgCostMilli) * h.qty;
    }
    return total;
  }

  function getDividendInfo(state) {
    ensureState(state);

    var upcoming = [];
    var currentDay = Number(state.dividend.cycleDay || 1);
    var isAnnouncementPeriod = currentDay >= DIVIDEND_ANNOUNCE_DAY;

    if (isAnnouncementPeriod) {
      for (var id in state.assets) {
        if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;

        var asset = state.assets[id];
        var estimated = calculateDividendPerShareMilli(asset, state);
        applyDividendLockToAsset(state, asset);

        upcoming.push({
          assetId: id,
          name: asset.name,
          estimatedDividendPerShareMilli: estimated
        });
      }

      upcoming.sort(function(a, b) {
        return Number(b.estimatedDividendPerShareMilli || 0) - Number(a.estimatedDividendPerShareMilli || 0);
      });
    }

    return {
      cycleDay: state.dividend.cycleDay,
      cycleTotalDays: DIVIDEND_CYCLE_DAYS,
      announcementDay: DIVIDEND_ANNOUNCE_DAY,
      isAnnouncementPeriod: isAnnouncementPeriod,
      pendingToday: !!state.dividend.pendingToday,
      totalReceivedMilli: state.dividend.totalReceivedMilli,
      totalPaidMilli: state.dividend.totalPaidMilli,
      history: state.dividend.history,
      upcomingDividends: upcoming
    };
  }

  function getCompanyDetail(state, assetId) {
    ensureState(state);
    var asset = state.assets[assetId];
    if (!asset) return null;
    normalizeEquityShares(asset);

    var h = getHolding(state, assetId);
    var ci = asset.companyInfo || {};
    var cm = asset.companyMetrics || {};
    var toLots = w.StockMarketAssets.toLots || function (shares) { return Math.floor(Number(shares || 0) / 1000); };
    var control = getPlayerControlLevel(state, assetId);

    return {
      id: asset.id,
      symbol: asset.symbol || "",
      sectorCode: asset.sectorCode || "",
      name: asset.name,
      desc: asset.desc,
      marketType: asset.marketType,
      tier: asset.tier,
      style: asset.style,
      priceMilli: asset.price,
      fairValueMilli: asset.anchorPriceMilli || asset._lastFairValue || asset.price,
      openChangePct: calcOpenChangePct(asset),
      trend5: getTrendPercent(asset, 5),
      trend30: getTrendPercent(asset, 30),
      companyInfo: ci,
      companyMetrics: cm,
      guildCapitalMilli: asset.guildCapitalMilli || ci.guildCapitalMilli || 0,
      guildCapitalBaseMilli: asset.guildCapitalBaseMilli || ci.guildCapitalBaseMilli || 0,
      guildCapitalTierId: asset.guildCapitalTierId || ci.guildCapitalTierId || "",
      guildCapitalTierLabel: asset.guildCapitalTierLabel || ci.guildCapitalTierLabel || "",
      guildCapitalTierRank: asset.guildCapitalTierRank || ci.guildCapitalTierRank || 0,
      guildCapitalLastUpdateDay: asset.guildCapitalLastUpdateDay || ci.guildCapitalLastUpdateDay || 0,
      aiIssueMode: asset.aiIssueMode || ci.aiIssueMode || "",
      aiParValueMilli: asset.aiParValueMilli || ci.aiParValueMilli || 0,
      aiPeRatio: asset.aiPeRatio || ci.aiPeRatio || 0,
      aiGeneratedEPSMilli: asset.aiGeneratedEPSMilli || ci.aiGeneratedEPSMilli || cm.epsMilli || 0,
      liquidityShareMultiplier: asset.liquidityShareMultiplier || ci.liquidityShareMultiplier || 1,
      economicShares: asset.economicShares || ci.economicShares || 0,
      marketSharesMode: asset.marketSharesMode || ci.marketSharesMode || "",
      aiFairValueMilli: asset.aiFairValueMilli || asset._lastFairValue || asset.price || 0,
      aiMarketMood: asset.aiMarketMood || "neutral",
      aiMoodScore: asset.aiMoodScore || 0,
      aiValuationGap: asset.aiValuationGap || 0,
      aiOverheatLevel: asset.aiOverheatLevel || 0,
      aiPanicLevel: asset.aiPanicLevel || 0,
      aiBubbleLevel: asset.aiBubbleLevel || 0,
      aiTradingStyle: asset.aiTradingStyle || "",
      aiAvgCostMilli: asset.aiAvgCostMilli || 0,
      aiUnrealizedPnl: asset.aiUnrealizedPnl || 0,
      aiConfidence: asset.aiConfidence || 0,
      aiLastNetFlow: asset.aiLastNetFlow || 0,
      aiMA5Milli: asset.aiMA5Milli || 0,
      aiMA20Milli: asset.aiMA20Milli || 0,
      aiMA60Milli: asset.aiMA60Milli || 0,
      control: control,
      shareInfo: {
        totalShares: asset.totalShares,
        floatShares: asset.floatShares,
        lockedShares: asset.lockedShares,
        insiderShares: asset.insiderShares,
        stateHoldingShares: asset.stateHoldingShares || 0,
        strategicHoldingShares: getStrategicHoldingShares(asset),
        marketMakerShares: getMarketMakerShares(asset),
        availableShares: asset.availableShares,

        totalLots: toLots(asset.totalShares),
        floatLots: toLots(asset.floatShares),
        lockedLots: toLots(asset.lockedShares),
        insiderLots: toLots(asset.insiderShares),
        stateHoldingLots: toLots(asset.stateHoldingShares || 0),
        strategicHoldingLots: toLots(getStrategicHoldingShares(asset)),
        marketMakerLots: toLots(getMarketMakerShares(asset)),
        availableLots: toLots(asset.availableShares),
        dailyBuyLiquidityShares: asset.dailyBuyLiquidityShares || 0,
        dayOpenSellLiquidityShares: asset.dayOpenSellLiquidityShares || 0,
        dayOpenBuyLiquidityShares: asset.dayOpenBuyLiquidityShares || 0,
        liquidityState: getLiquidityState(asset)
      },
      playerHolding: {
        qty: h.qty,
        avgCostMilli: h.avgCostMilli,
        estimatedDividendMilli: Math.max(0, Number(cm.estimatedDividendPerShareMilli || 0)) * h.qty
      }
    };
  }


  function getAIEventState(state){
    ensureState(state);
    return ensureAIWorldState(state);
  }

  function getAIWorldEvents(state){
    return (getAIEventState(state).activeWorldEvents || []).slice();
  }

  function getAIIndustryEvents(state){
    return (getAIEventState(state).activeIndustryEvents || []).slice();
  }

  function getAICompanyEvents(state){
    return (getAIEventState(state).activeCompanyEvents || []).slice();
  }

  function getAIEventHistory(state){
    var ws = getAIEventState(state);
    if(!ws.history) ws.history = [];
    return ws.history.slice();
  }

  function getWorldStabilizerInfo(state){
    var ws = getAIEventState(state);
    var targetName = "";
    if(ws.stabilizer && ws.stabilizer.targetKingdom){
      var ks = getStateKingdomList(state);
      for(var i=0;i<ks.length;i++){
        if(ks[i] && ks[i].id === ws.stabilizer.targetKingdom){
          targetName = ks[i].name || "";
          break;
        }
      }
    }
    return {
      name: WORLD_STABILIZER.name,
      active: !!(ws.stabilizer && ws.stabilizer.active),
      targetKingdom: ws.stabilizer ? ws.stabilizer.targetKingdom : null,
      targetName: targetName,
      remainingDays: ws.stabilizer ? ws.stabilizer.remainingDays : 0
    };
  }

  w.StockMarketEngine = {
    TICK_SEC: TICK_SEC,
    HEAVY_UPDATE_SEC: HEAVY_UPDATE_SEC,
    ASSET_BATCH_SIZE: ASSET_BATCH_SIZE,
    SCALE: SCALE,
    BUY_FEE_RATE: BUY_FEE_RATE,
    SELL_FEE_RATE: SELL_FEE_RATE,
    SELL_TAX_RATE: SELL_TAX_RATE,
    MARKET_OPEN_SEC: MARKET_OPEN_SEC,
    MARKET_CLOSE_SEC: MARKET_CLOSE_SEC,
    MARKET_PREOPEN_SEC: MARKET_PREOPEN_SEC,
    DIVIDEND_CYCLE_DAYS: DIVIDEND_CYCLE_DAYS,
    DIVIDEND_TIME_SCALE: DIVIDEND_TIME_SCALE,
    DIVIDEND_ANNOUNCE_DAY: DIVIDEND_ANNOUNCE_DAY,

    createDefaultState: createDefaultState,
    ensureState: ensureState,
    settleToNow: settleToNow,
    runTick: runTick,

    buyAsset: buyAsset,
    sellAsset: sellAsset,

    placePendingOrder: placePendingOrder,
    cancelPendingOrder: cancelPendingOrder,
    getPendingOrdersForAsset: getPendingOrdersForAsset,
    processPendingOrders: processPendingOrders,

    getHolding: getHolding,
    setHolding: setHolding,

    totalMarketValue: totalMarketValue,
    totalUnrealized: totalUnrealized,

    getSecondsToNextTick: getSecondsToNextTick,
    getSecondsToPhaseEnd: getSecondsToPhaseEnd,
    getSecondsToDayEnd: getSecondsToDayEnd,
    getMarketDay: function(state) { ensureState(state); return Math.max(1, Math.floor(Number(state.marketDay || 1))); },

    getDividendInfo: getDividendInfo,
    isDividendSettlementDay: isDividendSettlementDay,
    getCompanyDetail: getCompanyDetail,
    getLiquidityState: getLiquidityState,
    getPlayerControlRatio: getPlayerControlRatio,
    getPlayerControlLevel: getPlayerControlLevel,
MARKET_PREOPEN_SEC:
  MARKET_PREOPEN_SEC,
  
  MARKET_OPEN_SEC:
  MARKET_OPEN_SEC,
  
  MARKET_CLOSE_SEC:
  MARKET_CLOSE_SEC,
    refreshAllEstimatedDividends: refreshAllEstimatedDividends,
    processScheduledCompanyBusinessUpdates: processScheduledCompanyBusinessUpdates,
    getEconomicMarketCapMilli: getEconomicMarketCapMilli,
    updateGuildCapitalMonthly: updateGuildCapitalMonthly,
    getAnchorPriceMilli: getAnchorPriceMilli,
    calcOpenChangePct: calcOpenChangePct,
    getCombinedNarrativeEffectForAsset: getCombinedNarrativeEffectForAsset,
    getCombinedNarrativeMetaForAsset: getCombinedNarrativeMetaForAsset,
    getAIEventState: getAIEventState,
    getAIWorldEvents: getAIWorldEvents,
    getAIIndustryEvents: getAIIndustryEvents,
    getAICompanyEvents: getAICompanyEvents,
    getAIEventHistory: getAIEventHistory,
    getWorldStabilizerInfo: getWorldStabilizerInfo
  };
})(window);

try {
  if (typeof window !== 'undefined') {
    window.processBoardDefense =
      processBoardDefense;
  }
} catch(e) {}


// =====================================================
// F3.0 現代化增股系統
// =====================================================
(function(w){

  function rand(min,max){
    return min + Math.random() * (max - min);
  }

  function getShareGrowthCap(company){

    var tier =
      String(company && company.tier || "");

    if(tier === "large") return 20;
    if(tier === "mid") return 15;

    return 10;
  }

  function issueShares(company, ratio, reason){

    if(!company) return false;

    var currentShares =
      Math.max(
        1,
        Math.floor(
          Number(
            company.sharesOutstanding ||
            company.totalShares ||
            1
          )
        )
      );

    if(!company.baseShares){
      company.baseShares = currentShares;
    }

    var maxShares =
      Math.floor(
        Number(company.baseShares) *
        getShareGrowthCap(company)
      );

    if(currentShares >= maxShares){
      return false;
    }

    var addShares =
      Math.floor(currentShares * ratio);

    var newShares =
      Math.min(
        maxShares,
        currentShares + addShares
      );

    var oldPrice =
      Math.max(
        1,
        Number(company.price || 1)
      );

    // 維持市值
    var marketCap =
      oldPrice * currentShares;

    var newPrice =
      marketCap / newShares;

    company.sharesOutstanding = newShares;
    company.totalShares = newShares;

    if(company.equityConfig){

      company.equityConfig.totalShares =
        newShares;

      company.equityConfig.publicFloatShares =
        Math.floor(newShares * 0.60);

    }

    company.price =
      Math.max(
        1,
        Math.floor(newPrice)
      );

    if(
      w.WorldNewsSystem &&
      typeof w.WorldNewsSystem.pushNews === "function"
    ){

      w.WorldNewsSystem.pushNews({

        category:"finance",

        title:
          "🏦 " +
          (company.name || "未知商會") +
          " 宣布增發新股",

        content:
          reason +
          "｜增發比例 " +
          (ratio * 100).toFixed(1) +
          "%",

        color:"#60a5fa"

      });

    }

    return true;
  }

  w.processModernShareIssuance = function(company){

    if(!company) return;

    // 成長型增股
    if(Math.random() < 0.003){

      issueShares(
        company,
        rand(0.03,0.08),
        "因應商會擴張與資本需求"
      );

    }

    // 軍工國策增股
    var sector =
      String(company.sector || "");

    if(
      sector.indexOf("military") >= 0 &&
      Math.random() < 0.002
    ){

      issueShares(
        company,
        rand(0.05,0.12),
        "王國軍備擴張計畫"
      );

    }

  };

})(window);


// =====================================================
// AI5.3.0 World Calendar Config
// =====================================================

window.AI5_WORLD_ERAS = [
  "阿斯特拉帝國曆",
  "聖王聯邦紀元",
  "星環文明曆",
  "蒼穹聯盟紀元",
  "永夜王朝曆",
  "白銀皇室紀元"
];

window.AI5_WORLD_NEWS_NETWORKS = [
  "皇家經濟院",
  "世界觀測局",
  "地下情報網",
  "星環魔導院"
];

