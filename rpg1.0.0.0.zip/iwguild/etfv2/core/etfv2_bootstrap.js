// ETFV2 Bootstrap

(function(){

  if(!window.UniversalETF) return;

  var ETF = window.UniversalETF;

  // =====================================================
  // Passive ETF
  // =====================================================

  var passiveCfg =
    window.ETF_CONFIGS.guild_leader_fund;

  ETF.registerETF(passiveCfg);

  ETF.activateETF(passiveCfg.id);

  // =====================================================
  // Mad Dog ETF
  // =====================================================

  var madDogCfg =
    window.ETF_CONFIGS.mad_dog_fund;

  if(madDogCfg){

    ETF.registerETF(madDogCfg);

    ETF.activateETF(madDogCfg.id);
  }

  ETF.startRuntime();

  console.log("[ETFV2] Bootstrap Complete");

})();
