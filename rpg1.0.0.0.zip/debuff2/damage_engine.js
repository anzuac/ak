// damage_engine.js

export function applyDamage({
  
  source = null,
  
  target,
  
  amount = 0,
  
  type = "normal",
  
  tags = []
  
}) {
  
  if (!target) return 0;
  
  const finalDamage =
    Math.max(1, Math.floor(amount));
  
  target.currentHP =
    Math.max(
      0,
      target.currentHP - finalDamage
    );
  
  return finalDamage;
}