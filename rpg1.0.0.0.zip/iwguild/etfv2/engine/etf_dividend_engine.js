// ETFV2 7.0.0 Dividend Engine
window.ETFDividendEngine = {
  announce(etf, amount){
    if(!etf) return;

    etf.pendingDividend = amount;
  }
};


window.payPlayerEtfDividend = function(amountMilli){
  window.state = window.state || {};
  state.stats = state.stats || {};

  state.stats.totalDividendMilli =
    Number(state.stats.totalDividendMilli || 0) + Number(amountMilli || 0);

  return true;
};
