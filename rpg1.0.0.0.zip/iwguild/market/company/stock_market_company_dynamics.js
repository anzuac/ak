

// ===== EXD Daily Weighted Index Rebuild =====
var EXD_BASE_INDEX = 10000;

function EXD_REBUILD_WORLD_INDEX(companies){
  companies = companies || [];

  var totalCap = 0;
  for(var i=0;i<companies.length;i++){
    totalCap += (companies[i].worldMarketCap || companies[i].marketCap || 1);
  }

  if(totalCap <= 0){
    return EXD_BASE_INDEX;
  }

  var growth = 0;

  for(var j=0;j<companies.length;j++){
    var c = companies[j];

    var cap = (c.worldMarketCap || c.marketCap || 1);
    var weight = cap / totalCap;

    var baseAnchor = c.baseAnchorPriceMilli || c.anchorPriceMilli || 100000;
    var anchor = c.anchorPriceMilli || baseAnchor;
    var price = c.priceMilli || anchor;

    var anchorRatio = anchor / Math.max(1, baseAnchor);
    var shortRatio = price / Math.max(1, anchor);

    // 95% 長期經濟 / 5% 市場情緒
    var companyGrowth =
      (anchorRatio * 0.95) +
      (shortRatio * 0.05);

    growth += weight * companyGrowth;
  }

  // 防止單日超過10%
  growth = (window.AI5MarketControl ? window.AI5MarketControl.applyGrowthLimit(growth, "normal") : Math.max(0.90, Math.min(1.10, growth)));

  return Math.round(EXD_BASE_INDEX * growth);
}
// ============================================


// ===== Anchor Weighted Index Model =====
function EXD_computeWeightedIndexValue(company, totalCap){
  if(!company || !totalCap) return 0;

  var weight = (company.worldMarketCap || company.marketCap || 1) / totalCap;

  var baseAnchor = company.baseAnchorPriceMilli || company.anchorPriceMilli || 100000;
  var anchor = company.anchorPriceMilli || baseAnchor;
  var price = company.priceMilli || anchor;

  var anchorRatio = anchor / Math.max(1, baseAnchor);
  var marketRatio = price / Math.max(1, anchor);

  return weight * (
    (anchorRatio * 0.8) +
    (marketRatio * 0.2)
  );
}
// =======================================

(function (w) {
  "use strict";

  var DEFAULT_TICKS_PER_DAY = 600;
  var SAME_COMPANY_COOLDOWN_DAYS = 5;
  var MAX_ACTIVE_PER_COMPANY = 1;

  var LEVEL_DEFS = {
    micro:   { label: "微",  weight: 30, impact: 0.45, days: [1, 2] },
    small:   { label: "小",  weight: 30, impact: 0.75, days: [2, 3] },
    medium:  { label: "中",  weight: 25, impact: 1.00, days: [3, 5] },
    large:   { label: "大",  weight: 10, impact: 1.45, days: [4, 7] },
    extreme: { label: "特大", weight:  5, impact: 2.10, days: [6, 10] }
  };

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function rand(min, max) {
    return min + Math.random() * (max - min);
  }

  function randInt(min, max) {
    min = Math.floor(Number(min || 0));
    max = Math.floor(Number(max || 0));
    if (max < min) max = min;
    return Math.floor(rand(min, max + 1));
  }

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function shuffle(arr) {
    var out = arr.slice();
    for (var i = out.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = out[i];
      out[i] = out[j];
      out[j] = tmp;
    }
    return out;
  }

  function getTicksPerDay() {
    return Math.max(1, Math.floor(Number((w.StockMarketEngine && w.StockMarketEngine.MARKET_OPEN_SEC) || DEFAULT_TICKS_PER_DAY)));
  }

  function toTickDuration(days) {
    return Math.max(1, Math.floor(Number(days || 1) * getTicksPerDay()));
  }

  function hasOwn(obj, key) {
    return !!obj && Object.prototype.hasOwnProperty.call(obj, key);
  }

  function numberOr(value, fallback) {
    var n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function isLiveDynamic(evt) {
    return !!evt && !evt.finished && Number.isFinite(Number(evt.remainingTicks)) && Number(evt.remainingTicks) > 0;
  }

  function ensureDynamics(state) {
    if (!state.companyDynamics) {
      state.companyDynamics = {
        nextId: 1,
        active: [],
        history: [],
        triggeredToday: 0,
        dailyQuota: 0,
        lastPreparedDay: 0,
        cooldownByAsset: {},
        decisionNextId: 1,
        decisions: [],
        decisionHistory: [],
        decisionTriggeredToday: 0,
        decisionDailyQuota: 0,
        decisionLastPreparedDay: 0,
        decisionCooldownByAsset: {}
      };
    }

    if (typeof state.companyDynamics.nextId !== "number") state.companyDynamics.nextId = 1;
    if (!Array.isArray(state.companyDynamics.active)) state.companyDynamics.active = [];
    if (!Array.isArray(state.companyDynamics.history)) state.companyDynamics.history = [];
    if (typeof state.companyDynamics.triggeredToday !== "number") state.companyDynamics.triggeredToday = 0;
    if (typeof state.companyDynamics.dailyQuota !== "number") state.companyDynamics.dailyQuota = 0;
    if (typeof state.companyDynamics.lastPreparedDay !== "number") state.companyDynamics.lastPreparedDay = 0;
    if (!state.companyDynamics.cooldownByAsset || typeof state.companyDynamics.cooldownByAsset !== "object") {
      state.companyDynamics.cooldownByAsset = {};
    }
    if (typeof state.companyDynamics.decisionNextId !== "number") state.companyDynamics.decisionNextId = 1;
    if (!Array.isArray(state.companyDynamics.decisions)) state.companyDynamics.decisions = [];
    if (!Array.isArray(state.companyDynamics.decisionHistory)) state.companyDynamics.decisionHistory = [];
    if (typeof state.companyDynamics.decisionTriggeredToday !== "number") state.companyDynamics.decisionTriggeredToday = 0;
    if (typeof state.companyDynamics.decisionDailyQuota !== "number") state.companyDynamics.decisionDailyQuota = 0;
    if (typeof state.companyDynamics.decisionLastPreparedDay !== "number") state.companyDynamics.decisionLastPreparedDay = 0;
    if (!state.companyDynamics.decisionCooldownByAsset || typeof state.companyDynamics.decisionCooldownByAsset !== "object") {
      state.companyDynamics.decisionCooldownByAsset = {};
    }

    normalizeDynamics(state);
    return state.companyDynamics;
  }

  function normalizeDynamics(state) {
    var dynamics = state.companyDynamics;
    var ticksPerDay = getTicksPerDay();
    var byAsset = {};
    for (var i = 0; i < dynamics.active.length; i++) {
      var evt = dynamics.active[i];
      if (!evt) continue;
      if (!evt.level || !LEVEL_DEFS[evt.level]) evt.level = inferLevelFromBias(evt.bias);
      evt.levelLabel = getLevelLabel(evt.level);
      if (!evt.direction) evt.direction = inferDirection(evt.bias);
      if (!evt.durationDays) {
        if (evt.totalTicks) evt.durationDays = Math.max(1, Math.ceil(numberOr(evt.totalTicks, 0) / ticksPerDay));
        else if (evt.duration) evt.durationDays = Math.max(1, Math.ceil(numberOr(evt.duration, 0) / ticksPerDay));
        else evt.durationDays = LEVEL_DEFS[evt.level].days[0];
      }
      evt.totalTicks = Math.max(1, Math.floor(numberOr(evt.totalTicks != null ? evt.totalTicks : (evt.durationTicks != null ? evt.durationTicks : evt.duration), toTickDuration(evt.durationDays))));

      // 關鍵修復：0 是合法結束狀態，不可被 || 轉回 totalTicks。
      var rawRemaining = hasOwn(evt, "remainingTicks") && evt.remainingTicks != null ? evt.remainingTicks : evt.totalTicks;
      evt.remainingTicks = clamp(Math.floor(numberOr(rawRemaining, 0)), 0, evt.totalTicks);
      evt.remainingDays = Math.max(0, Math.ceil(evt.remainingTicks / ticksPerDay));
      if (!evt.assetName && evt.target && state.assets && state.assets[evt.target]) evt.assetName = state.assets[evt.target].name;
      if (!evt.sectorCode && evt.target && state.assets && state.assets[evt.target]) evt.sectorCode = state.assets[evt.target].sectorCode || "X";
      evt.instanceId = evt.instanceId || ["company", evt.id || evt.key || "event", evt.target || "asset", evt.createdDay || 0, evt.createdTick || 0].join(":");
      if (evt.remainingTicks <= 0) evt.finished = true;
      if (!isLiveDynamic(evt)) continue;
      var target = String(evt.target || evt.assetName || evt.instanceId);
      if (!byAsset[target] || numberOr(evt.remainingTicks, 0) > numberOr(byAsset[target].remainingTicks, 0)) byAsset[target] = evt;
    }
    dynamics.active = [];
    for (var targetKey in byAsset) {
      if (Object.prototype.hasOwnProperty.call(byAsset, targetKey)) dynamics.active.push(byAsset[targetKey]);
    }

    var cleanedDecisions = [];
    var seenDecisions = {};
    for (var j = 0; j < dynamics.decisions.length; j++) {
      var d = dynamics.decisions[j];
      if (!d) continue;
      if (!d.status) d.status = "pending";
      d.totalTicks = Math.max(1, Math.floor(numberOr(d.totalTicks != null ? d.totalTicks : (d.durationTicks != null ? d.durationTicks : d.duration), toTickDuration(d.durationDays || 2))));
      var rawDecisionRemaining = hasOwn(d, "remainingTicks") && d.remainingTicks != null ? d.remainingTicks : d.totalTicks;
      d.remainingTicks = clamp(Math.floor(numberOr(rawDecisionRemaining, 0)), 0, d.totalTicks);
      d.remainingDays = Math.max(0, Math.ceil(d.remainingTicks / ticksPerDay));
      if (!d.assetName && d.target && state.assets && state.assets[d.target]) d.assetName = state.assets[d.target].name;
      if (!d.symbol && d.target && state.assets && state.assets[d.target]) d.symbol = state.assets[d.target].symbol || "----";
      if (!d.sectorCode && d.target && state.assets && state.assets[d.target]) d.sectorCode = state.assets[d.target].sectorCode || "X";
      if (typeof d.playerEligible !== "boolean") d.playerEligible = false;
      if (typeof d.playerVote !== "string") d.playerVote = "pending";
      if (typeof d.notified !== "boolean") d.notified = false;
      d.instanceId = d.instanceId || ["decision", d.id || d.key || "vote", d.target || "asset", d.createdDay || 0, d.createdTick || 0].join(":");
      if (d.status === "pending" && d.remainingTicks <= 0) d.finished = true;
      if (d.status === "pending" && !isLiveDynamic(d)) continue;
      if (seenDecisions[d.instanceId]) continue;
      seenDecisions[d.instanceId] = true;
      cleanedDecisions.push(d);
    }
    dynamics.decisions = cleanedDecisions;
    if (dynamics.history.length > 100) dynamics.history.length = 100;
  }

  function inferDirection(bias) {
    bias = Number(bias || 0);
    if (bias > 0.002) return "positive";
    if (bias < -0.002) return "negative";
    return "mixed";
  }

  function inferLevelFromBias(bias) {
    var abs = Math.abs(Number(bias || 0));
    if (abs >= 0.045) return "extreme";
    if (abs >= 0.025) return "large";
    if (abs >= 0.012) return "medium";
    if (abs >= 0.006) return "small";
    return "micro";
  }

  function getLevelLabel(level) {
    return LEVEL_DEFS[level] ? LEVEL_DEFS[level].label : "中";
  }

  function getAllCandidateAssets(state) {
    var out = [];
    for (var id in state.assets) {
      if (!Object.prototype.hasOwnProperty.call(state.assets, id)) continue;
      var asset = state.assets[id];
      if (!asset || !asset.unlocked) continue;
      out.push(asset);
    }
    return out;
  }

  function getTierDailyChance(asset) {
    if (!asset) return 0;
    if (asset.marketType !== "free") return 0.040;
    if (asset.tier === "large") return 0.050;
    if (asset.tier === "mid") return 0.065;
    if (asset.tier === "small") return 0.085;
    return 0.05;
  }

  function buildMeta(metaTpl, level) {
    var levelDef = LEVEL_DEFS[level] || LEVEL_DEFS.medium;
    var scale = Number(levelDef.impact || 1);
    var out = {
      liquidityShift: 0,
      npcPanicSellBoost: 0,
      npcFomoBuyBoost: 0,
      strategicHoldingReleaseBoost: 0,
      npcAbsorbBoost: 0,
      shortPressureBoost: 0,
      confidenceImpact: 0,
      revenueAdjust: 0,
      profitAdjust: 0,
      payoutAdjust: 0
    };

    if (!metaTpl) return out;

    for (var k in out) {
      if (!Object.prototype.hasOwnProperty.call(out, k)) continue;
      if (Object.prototype.hasOwnProperty.call(metaTpl, k)) {
        out[k] = Number(metaTpl[k] || 0) * scale;
      }
    }

    return out;
  }

  function weightedPickLevel() {
    var total = 0;
    var keys = Object.keys(LEVEL_DEFS);
    for (var i = 0; i < keys.length; i++) total += Number(LEVEL_DEFS[keys[i]].weight || 0);
    var roll = Math.random() * total;
    var acc = 0;
    for (var j = 0; j < keys.length; j++) {
      var key = keys[j];
      acc += Number(LEVEL_DEFS[key].weight || 0);
      if (roll <= acc) return key;
    }
    return "medium";
  }

  function resolveDurationDays(template, level) {
    if (template && Array.isArray(template.durationDays)) return randInt(template.durationDays[0], template.durationDays[1]);
    var def = LEVEL_DEFS[level] || LEVEL_DEFS.medium;
    return randInt(def.days[0], def.days[1]);
  }

  function buildTierTemplatePools() {
    return {
      large: [
        { key: "large_big_contract", title: "公司宣布取得重大長約", direction: "positive", meta: { liquidityShift: 0.03, npcFomoBuyBoost: 0.14, npcAbsorbBoost: 0.10, confidenceImpact: 0.16, revenueAdjust: 0.05, profitAdjust: 0.04, payoutAdjust: 0.02 } },
        { key: "large_dividend_raise", title: "董事會決議提高配息", direction: "positive", meta: { npcFomoBuyBoost: 0.10, confidenceImpact: 0.14, payoutAdjust: 0.04 } },
        { key: "large_capex_pressure", title: "公司啟動大型擴產計畫", direction: "mixed", meta: { liquidityShift: -0.01, confidenceImpact: 0.05, revenueAdjust: 0.03, profitAdjust: -0.03, payoutAdjust: -0.02 } },
        { key: "large_guidance_miss", title: "公司財報不如預期", direction: "negative", meta: { liquidityShift: -0.04, npcPanicSellBoost: 0.18, strategicHoldingReleaseBoost: 0.06, confidenceImpact: -0.18, revenueAdjust: -0.06, profitAdjust: -0.08, payoutAdjust: -0.04 } }
      ],
      mid: [
        { key: "mid_breakthrough", title: "公司宣布技術突破", direction: "positive", meta: { liquidityShift: 0.05, npcFomoBuyBoost: 0.22, npcAbsorbBoost: 0.12, confidenceImpact: 0.20, revenueAdjust: 0.08, profitAdjust: 0.07 } },
        { key: "mid_new_order", title: "公司取得新一波大單", direction: "positive", meta: { liquidityShift: 0.03, npcFomoBuyBoost: 0.16, confidenceImpact: 0.16, revenueAdjust: 0.06, profitAdjust: 0.05 } },
        { key: "mid_strategy_shift", title: "公司宣布策略轉型", direction: "mixed", meta: { liquidityShift: -0.01, confidenceImpact: 0.02, revenueAdjust: 0.02, profitAdjust: -0.02, payoutAdjust: -0.01 } },
        { key: "mid_earnings_bomb", title: "公司爆出營運失速", direction: "negative", meta: { liquidityShift: -0.06, npcPanicSellBoost: 0.24, strategicHoldingReleaseBoost: 0.08, confidenceImpact: -0.24, revenueAdjust: -0.09, profitAdjust: -0.12, payoutAdjust: -0.05 } }
      ],
      small: [
        { key: "small_super_breakthrough", title: "公司宣布重大突破", direction: "positive", meta: { liquidityShift: 0.08, npcFomoBuyBoost: 0.40, npcAbsorbBoost: 0.14, confidenceImpact: 0.30, revenueAdjust: 0.12, profitAdjust: 0.10 } },
        { key: "small_hot_collab", title: "公司宣布熱門合作案", direction: "positive", meta: { liquidityShift: 0.05, npcFomoBuyBoost: 0.26, confidenceImpact: 0.20, revenueAdjust: 0.07, profitAdjust: 0.05 } },
        { key: "small_buyback", title: "公司宣布庫藏股計畫", direction: "positive", meta: { liquidityShift: -0.03, npcFomoBuyBoost: 0.18, confidenceImpact: 0.18 } },
        { key: "small_dilution", title: "公司宣布增資計畫", direction: "negative", meta: { liquidityShift: 0.06, npcPanicSellBoost: 0.20, strategicHoldingReleaseBoost: 0.08, confidenceImpact: -0.22, payoutAdjust: -0.05 } },
        { key: "small_scandal", title: "公司爆出重大醜聞", direction: "negative", meta: { liquidityShift: -0.10, npcPanicSellBoost: 0.42, strategicHoldingReleaseBoost: 0.18, shortPressureBoost: 0.20, confidenceImpact: -0.38, revenueAdjust: -0.12, profitAdjust: -0.18, payoutAdjust: -0.07 } },
        { key: "small_operational_crash", title: "公司爆雷停工", direction: "negative", meta: { liquidityShift: -0.10, npcPanicSellBoost: 0.38, strategicHoldingReleaseBoost: 0.14, confidenceImpact: -0.34, revenueAdjust: -0.13, profitAdjust: -0.20, payoutAdjust: -0.08 } }
      ],
      starter: [
        { key: "starter_local_growth", title: "公司業績穩步成長", direction: "positive", meta: { confidenceImpact: 0.08, revenueAdjust: 0.03, profitAdjust: 0.03 } },
        { key: "starter_minor_issue", title: "公司營運出現小幅失誤", direction: "negative", meta: { confidenceImpact: -0.08, revenueAdjust: -0.03, profitAdjust: -0.04 } }
      ]
    };
  }

  function buildSectorTemplatePools() {
    return {
      A: [
        { key: "sector_a_infra_budget", title: "公共建設預算增加", direction: "positive", meta: { liquidityShift: 0.03, confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.03 } },
        { key: "sector_a_regulation_drag", title: "國營體系面臨政策拖延", direction: "negative", meta: { confidenceImpact: -0.10, revenueAdjust: -0.03, profitAdjust: -0.04 } }
      ],
      B: [
        { key: "sector_b_margin_expand", title: "金融利差改善", direction: "positive", meta: { confidenceImpact: 0.10, revenueAdjust: 0.04, profitAdjust: 0.06, payoutAdjust: 0.03 } },
        { key: "sector_b_bad_loan", title: "呆帳風險升高", direction: "negative", meta: { confidenceImpact: -0.16, profitAdjust: -0.08, payoutAdjust: -0.04 } }
      ],
      C: [
        { key: "sector_c_ai_heat", title: "AI 題材熱度升溫", direction: "positive", meta: { liquidityShift: 0.05, npcFomoBuyBoost: 0.20, confidenceImpact: 0.18, revenueAdjust: 0.06 } },
        { key: "sector_c_security_issue", title: "資安疑慮擴大", direction: "negative", meta: { liquidityShift: -0.03, npcPanicSellBoost: 0.16, confidenceImpact: -0.16, profitAdjust: -0.05 } }
      ],
      D: [
        { key: "sector_d_order_rebuild", title: "製造鏈補庫存", direction: "positive", meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.04 } },
        { key: "sector_d_cost_spike", title: "製造成本急升", direction: "negative", meta: { confidenceImpact: -0.12, revenueAdjust: -0.03, profitAdjust: -0.07 } }
      ],
      E: [
        { key: "sector_e_trial_success", title: "臨床試驗傳出佳音", direction: "positive", meta: { liquidityShift: 0.05, npcFomoBuyBoost: 0.18, confidenceImpact: 0.20, revenueAdjust: 0.04, profitAdjust: 0.06 } },
        { key: "sector_e_review_delay", title: "法規審查延後", direction: "negative", meta: { liquidityShift: -0.04, npcPanicSellBoost: 0.16, confidenceImpact: -0.18, revenueAdjust: -0.04, profitAdjust: -0.06 } }
      ],
      F: [
        { key: "sector_f_demand_pickup", title: "民生消費需求升溫", direction: "positive", meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.03 } },
        { key: "sector_f_margin_squeeze", title: "原料成本侵蝕毛利", direction: "negative", meta: { confidenceImpact: -0.10, profitAdjust: -0.06 } }
      ],
      G: [
        { key: "sector_g_price_surge", title: "能源價格走高", direction: "positive", meta: { confidenceImpact: 0.12, revenueAdjust: 0.05, profitAdjust: 0.06 } },
        { key: "sector_g_supply_shock", title: "能源供應受阻", direction: "mixed", meta: { liquidityShift: -0.02, confidenceImpact: -0.04, volatilityAdjust: 0 } }
      ],
      H: [
        { key: "sector_h_freight_rebound", title: "運價回升", direction: "positive", meta: { confidenceImpact: 0.14, revenueAdjust: 0.07, profitAdjust: 0.06 } },
        { key: "sector_h_route_disruption", title: "航線調度受阻", direction: "negative", meta: { confidenceImpact: -0.14, revenueAdjust: -0.05, profitAdjust: -0.06 } }
      ],
      R: [
        { key: "sector_r_resource_tight", title: "原物料報價上揚", direction: "positive", meta: { confidenceImpact: 0.12, revenueAdjust: 0.06, profitAdjust: 0.05 } },
        { key: "sector_r_inventory_pressure", title: "原料庫存壓力上升", direction: "negative", meta: { confidenceImpact: -0.12, revenueAdjust: -0.04, profitAdjust: -0.05 } }
      ]
    };
  }


  function buildDecisionTemplatePools() {
    return {
      large: [
        { key: "decision_large_dividend", title: "董事會提案提高配息", proposalType: "raise_dividend", decisionHint: "若通過，配息傾向上升，但成長與擴張彈性略降。", outcomeTitle: "董事會通過提高配息", outcomeDirection: "positive", outcomeMeta: { confidenceImpact: 0.12, payoutAdjust: 0.08, revenueAdjust: -0.01, profitAdjust: -0.01 }, durationDays: [3, 5], voteDays: [2, 3], baseSupport: 0.56 },
        { key: "decision_large_conservative", title: "董事會討論保守經營", proposalType: "conservative", decisionHint: "若通過，波動會降低，穩定度上升，但成長性也會下降。", outcomeTitle: "董事會通過保守經營", outcomeDirection: "mixed", outcomeMeta: { liquidityShift: -0.01, confidenceImpact: 0.05, revenueAdjust: -0.02, profitAdjust: 0.01, payoutAdjust: 0.02 }, durationDays: [3, 5], voteDays: [2, 3], baseSupport: 0.60 }
      ],
      mid: [
        { key: "decision_mid_expand", title: "董事會提案擴張投資", proposalType: "expand", decisionHint: "若通過，營收成長可望升高，但短期利潤與穩定性可能下降。", outcomeTitle: "董事會通過擴張投資", outcomeDirection: "positive", outcomeMeta: { liquidityShift: 0.02, confidenceImpact: 0.08, revenueAdjust: 0.08, profitAdjust: -0.03, payoutAdjust: -0.03 }, durationDays: [4, 6], voteDays: [2, 3], baseSupport: 0.52 },
        { key: "decision_mid_dividend", title: "董事會討論調高股利", proposalType: "raise_dividend", decisionHint: "若通過，股利幣收益會提升，但公司可用資金減少。", outcomeTitle: "董事會通過調高股利", outcomeDirection: "positive", outcomeMeta: { confidenceImpact: 0.10, payoutAdjust: 0.07, revenueAdjust: -0.01, profitAdjust: -0.02 }, durationDays: [3, 4], voteDays: [2, 3], baseSupport: 0.51 }
      ],
      small: [
        { key: "decision_small_buyback", title: "董事會提案庫藏股", proposalType: "buyback", decisionHint: "若通過，籌碼會更集中，價格承接轉強，但流動性下降。", outcomeTitle: "董事會通過庫藏股", outcomeDirection: "positive", outcomeMeta: { liquidityShift: -0.04, npcFomoBuyBoost: 0.10, confidenceImpact: 0.10, payoutAdjust: -0.02 }, durationDays: [3, 5], voteDays: [2, 3], baseSupport: 0.48 },
        { key: "decision_small_expand", title: "董事會提案高速擴張", proposalType: "expand", decisionHint: "若通過，營收成長可能加速，但波動與失敗風險也會提高。", outcomeTitle: "董事會通過高速擴張", outcomeDirection: "mixed", outcomeMeta: { liquidityShift: 0.03, confidenceImpact: 0.06, revenueAdjust: 0.10, profitAdjust: -0.05, payoutAdjust: -0.04 }, durationDays: [4, 6], voteDays: [2, 3], baseSupport: 0.45 }
      ],
      starter: [
        { key: "decision_starter_stability", title: "董事會討論穩定配息方案", proposalType: "raise_dividend", decisionHint: "若通過，配息略升、經營更穩，但成長速度偏慢。", outcomeTitle: "董事會通過穩定配息方案", outcomeDirection: "positive", outcomeMeta: { confidenceImpact: 0.08, payoutAdjust: 0.05, revenueAdjust: -0.01 }, durationDays: [3, 4], voteDays: [2, 3], baseSupport: 0.62 }
      ]
    };
  }

  function getDecisionPoolByAsset(asset) {
    var pools = buildDecisionTemplatePools();
    if (!asset) return [];
    if (asset.marketType !== "free") return (pools.starter || []).slice();
    return (pools[asset.tier] || []).slice();
  }

  function isDecisionCoolingDown(state, assetId) {
    var dynamics = ensureDynamics(state);
    var day = Number(state.marketDay || 1);
    var until = Number(dynamics.decisionCooldownByAsset[assetId] || 0);
    return until > day;
  }

  function hasPendingDecisionForAsset(state, assetId) {
    var arr = ensureDynamics(state).decisions || [];
    for (var i = 0; i < arr.length; i++) {
      var d = arr[i];
      if (d && d.target === assetId && d.status === "pending" && numberOr(d.remainingTicks, 0) > 0) return true;
    }
    return false;
  }

  function createDecision(state, asset, template) {
    var voteDays = Array.isArray(template.voteDays) ? randInt(template.voteDays[0], template.voteDays[1]) : 2;
    var totalTicks = toTickDuration(voteDays);
    var ratio = w.StockMarketEngine && w.StockMarketEngine.getPlayerControlRatio ? Number(w.StockMarketEngine.getPlayerControlRatio(state, asset.id) || 0) : 0;
    var playerEligible = ratio >= 0.30 && String(asset.sectorCode || "").toUpperCase() !== "A";
    return {
      id: state.companyDynamics.decisionNextId++,
      key: template.key,
      target: asset.id,
      assetName: asset.name,
      symbol: asset.symbol || "----",
      sectorCode: String(asset.sectorCode || "X").toUpperCase(),
      title: template.title,
      proposalType: template.proposalType || "general",
      decisionHint: template.decisionHint || "董事會正在評估這項方案。",
      playerEligible: playerEligible,
      playerVote: playerEligible ? "pending" : "ineligible",
      playerRatio: ratio,
      voteDays: voteDays,
      durationDays: voteDays,
      totalTicks: totalTicks,
      remainingTicks: totalTicks,
      remainingDays: voteDays,
      status: "pending",
      baseSupport: clamp(Number(template.baseSupport || 0.5), 0.15, 0.85),
      outcomeTitle: template.outcomeTitle || ("董事會通過：" + template.title),
      outcomeDirection: template.outcomeDirection || "mixed",
      outcomeMeta: template.outcomeMeta || {},
      outcomeDurationDays: template.durationDays || [3, 5],
      createdDay: Number(state.marketDay || 1),
      createdTick: Number(state.marketDayTick || 0),
      notified: false
    };
  }

  function prepareDailyDecisionQuota(state) {
    ensureDynamics(state);
    if (state.companyDynamics.decisionLastPreparedDay === state.marketDay) return;
    state.companyDynamics.decisionLastPreparedDay = state.marketDay;
    state.companyDynamics.decisionTriggeredToday = 0;
    var r = Math.random();
    if (r < 0.68) state.companyDynamics.decisionDailyQuota = 0;
    else if (r < 0.95) state.companyDynamics.decisionDailyQuota = 1;
    else state.companyDynamics.decisionDailyQuota = 2;
  }

  function maybeGenerateDailyDecisions(state) {
    ensureDynamics(state);
    prepareDailyDecisionQuota(state);
    var quota = Number(state.companyDynamics.decisionDailyQuota || 0);
    if (quota <= 0) return [];
    var created = [];
    var assets = shuffle(getAllCandidateAssets(state));
    for (var i = 0; i < assets.length; i++) {
      if (state.companyDynamics.decisionTriggeredToday >= quota) break;
      var asset = assets[i];
      if (hasPendingDecisionForAsset(state, asset.id)) continue;
      if (isDecisionCoolingDown(state, asset.id)) continue;
      if (Math.random() > getTierDailyChance(asset) * 0.70) continue;
      var pool = getDecisionPoolByAsset(asset);
      if (!pool.length) continue;
      var d = createDecision(state, asset, pick(pool));
      state.companyDynamics.decisions.push(d);
      state.companyDynamics.decisionHistory.unshift(d);
      state.companyDynamics.decisionTriggeredToday += 1;
      state.companyDynamics.decisionCooldownByAsset[asset.id] = Number(state.marketDay || 1) + SAME_COMPANY_COOLDOWN_DAYS + 2;
      created.push(d);
    }
    if (state.companyDynamics.decisionHistory.length > 100) state.companyDynamics.decisionHistory.length = 100;
    return created;
  }

  function getBoardSupport(asset, decision) {
    var base = clamp(Number(decision.baseSupport || 0.5), 0.15, 0.85);
    var boardLabel = String(asset && asset.registryMeta && asset.registryMeta.boardLabel || "");
    if (/保守|穩健|審慎/.test(boardLabel)) {
      if (decision.proposalType === "conservative" || decision.proposalType === "raise_dividend") base += 0.08;
      if (decision.proposalType === "expand") base -= 0.08;
    }
    if (/成長|新創|科技|創新/.test(boardLabel)) {
      if (decision.proposalType === "expand") base += 0.08;
      if (decision.proposalType === "conservative") base -= 0.06;
    }
    if (String(asset && asset.sectorCode || "").toUpperCase() === "A") {
      if (decision.proposalType === "conservative" || decision.proposalType === "raise_dividend") base += 0.10;
      if (decision.proposalType === "expand" || decision.proposalType === "buyback") base -= 0.10;
    }
    return clamp(base, 0.10, 0.90);
  }

  function createOutcomeEvent(state, asset, decision, passed) {
    if (!passed) return null;
    var outcomeTemplate = {
      key: String(decision.key || "decision") + "_passed",
      title: decision.outcomeTitle || ("董事會通過：" + decision.title),
      direction: decision.outcomeDirection || "mixed",
      meta: decision.outcomeMeta || {},
      durationDays: decision.outcomeDurationDays || [3, 5]
    };
    var evt = createDynamicEvent(state, asset, outcomeTemplate);
    evt.type = "decision";
    return evt;
  }

  function resolveDecision(state, decision) {
    if (!decision || decision.status !== "pending") return null;
    var asset = state.assets && state.assets[decision.target];
    if (!asset) {
      decision.status = "void";
      return null;
    }
    var playerRatio = w.StockMarketEngine && w.StockMarketEngine.getPlayerControlRatio ? Number(w.StockMarketEngine.getPlayerControlRatio(state, asset.id) || 0) : Number(decision.playerRatio || 0);
    decision.playerRatio = playerRatio;
    var playerEligible = playerRatio >= 0.30 && String(asset.sectorCode || "").toUpperCase() !== "A";
    decision.playerEligible = playerEligible;
    var playerWeight = playerEligible ? clamp(0.12 + playerRatio * 0.65, 0.18, 0.42) : 0;
    var boardSupport = getBoardSupport(asset, decision);
    var support = boardSupport * (1 - playerWeight);
    var vote = String(decision.playerVote || "pending");
    if (playerEligible) {
      if (vote === "agree") support += playerWeight;
      else if (vote === "abstain" || vote === "pending") support += playerWeight * 0.45;
    }
    support = clamp(support, 0, 1);
    decision.finalSupport = support;
    decision.resolvedDay = Number(state.marketDay || 1);
    decision.status = support >= 0.5 ? "passed" : "rejected";
    var outcome = createOutcomeEvent(state, asset, decision, decision.status === "passed");
    if (outcome) {
      state.companyDynamics.active.push(outcome);
      state.companyDynamics.history.unshift(outcome);
    }
    return { decision: decision, outcome: outcome };
  }

  function tickDecisions(state) {
    ensureDynamics(state);
    if (!state.companyDynamics.decisions.length) return [];
    var ticksPerDay = getTicksPerDay();
    var resolved = [];
    for (var i = 0; i < state.companyDynamics.decisions.length; i++) {
      var d = state.companyDynamics.decisions[i];
      if (!d || d.status !== "pending") continue;
      d.remainingTicks = Math.max(0, numberOr(d.remainingTicks, 0) - 1);
      d.remainingDays = Math.max(0, Math.ceil(numberOr(d.remainingTicks, 0) / ticksPerDay));
      if (numberOr(d.remainingTicks, 0) <= 0) {
        var result = resolveDecision(state, d);
        if (result) resolved.push(result);
      }
    }
    return resolved;
  }

  function getPendingDecisions(state) {
    ensureDynamics(state);
    return (state.companyDynamics.decisions || []).filter(function (d) {
      return d && d.status === "pending" && numberOr(d.remainingTicks, 0) > 0;
    });
  }

  function voteOnDecision(state, decisionId, vote) {
    ensureDynamics(state);
    vote = String(vote || "");
    if (vote !== "agree" && vote !== "reject" && vote !== "abstain") return { ok: false, reason: "invalid_vote" };
    var list = state.companyDynamics.decisions || [];
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (!d || String(d.id) !== String(decisionId)) continue;
      if (d.status !== "pending") return { ok: false, reason: "decision_closed" };
      if (!d.playerEligible) return { ok: false, reason: "player_not_eligible" };
      d.playerVote = vote;
      return { ok: true, decision: d };
    }
    return { ok: false, reason: "not_found" };
  }

  function getPoolByAsset(asset) {
    var tierPools = buildTierTemplatePools();
    var sectorPools = buildSectorTemplatePools();
    var out = [];

    if (!asset) return out;
    if (asset.marketType !== "free") out = out.concat(tierPools.starter || []);
    else out = out.concat(tierPools[asset.tier] || []);

    var sectorCode = String(asset.sectorCode || "X").toUpperCase();
    if (sectorPools[sectorCode]) out = out.concat(sectorPools[sectorCode]);
    return out;
  }

  function createDynamicEvent(state, asset, template) {
    var level = weightedPickLevel();
    var levelDef = LEVEL_DEFS[level] || LEVEL_DEFS.medium;
    var direction = template.direction || "mixed";
    var durationDays = resolveDurationDays(template, level);
    var totalTicks = toTickDuration(durationDays);
    var impact = Number(levelDef.impact || 1);

    var baseBias = 0;
    if (direction === "positive") baseBias = rand(0.006, 0.016);
    else if (direction === "negative") baseBias = -rand(0.006, 0.016);
    else baseBias = rand(-0.008, 0.008);

    var bias = baseBias * impact;
    var volatilityBonus = rand(0.0006, 0.0022) * (0.75 + impact * 0.5);
    if (level === "extreme") volatilityBonus *= 1.25;
    if (direction === "mixed") volatilityBonus *= 1.15;

    return {
      id: state.companyDynamics.nextId++,
      key: template.key,
      type: template.type || (direction === "mixed" ? "mixed" : direction),
      title: template.title,
      target: asset.id,
      assetName: asset.name,
      sectorCode: String(asset.sectorCode || "X").toUpperCase(),
      level: level,
      levelLabel: getLevelLabel(level),
      direction: direction,
      durationDays: durationDays,
      totalTicks: totalTicks,
      remainingTicks: totalTicks,
      remainingDays: durationDays,
      bias: bias,
      volatilityBonus: volatilityBonus,
      meta: buildMeta(template.meta, level),
      createdDay: Number(state.marketDay || 1),
      createdTick: Number(state.marketDayTick || 0)
    };
  }

  function prepareDailyQuota(state) {
    ensureDynamics(state);
    if (state.companyDynamics.lastPreparedDay === state.marketDay) return;

    state.companyDynamics.lastPreparedDay = state.marketDay;
    state.companyDynamics.triggeredToday = 0;

    var r = Math.random();
    if (r < 0.44) state.companyDynamics.dailyQuota = 0;
    else if (r < 0.82) state.companyDynamics.dailyQuota = 1;
    else if (r < 0.95) state.companyDynamics.dailyQuota = 2;
    else state.companyDynamics.dailyQuota = 3;
  }

  function isAssetCoolingDown(state, assetId) {
    var dynamics = ensureDynamics(state);
    var day = Number(state.marketDay || 1);
    var until = Number(dynamics.cooldownByAsset[assetId] || 0);
    return until > day;
  }

  function hasActiveEventForAsset(state, assetId) {
    var active = ensureDynamics(state).active;
    var count = 0;
    for (var i = 0; i < active.length; i++) {
      if (active[i] && active[i].target === assetId && numberOr(active[i].remainingTicks, 0) > 0) count += 1;
    }
    return count >= MAX_ACTIVE_PER_COMPANY;
  }

  function maybeGenerateDailyDynamics(state) {
    ensureDynamics(state);
    prepareDailyQuota(state);

    var quota = Number(state.companyDynamics.dailyQuota || 0);
    if (quota <= 0) return [];

    var created = [];
    var assets = shuffle(getAllCandidateAssets(state));

    for (var i = 0; i < assets.length; i++) {
      if (state.companyDynamics.triggeredToday >= quota) break;

      var asset = assets[i];
      if (hasActiveEventForAsset(state, asset.id)) continue;
      if (isAssetCoolingDown(state, asset.id)) continue;
      if (Math.random() > getTierDailyChance(asset)) continue;

      var pool = getPoolByAsset(asset);
      if (!pool.length) continue;

      var evt = createDynamicEvent(state, asset, pick(pool));
      state.companyDynamics.active.push(evt);
      state.companyDynamics.history.unshift(evt);
      state.companyDynamics.triggeredToday += 1;
      state.companyDynamics.cooldownByAsset[asset.id] = Number(state.marketDay || 1) + SAME_COMPANY_COOLDOWN_DAYS;
      created.push(evt);
    }

    if (state.companyDynamics.history.length > 100) {
      state.companyDynamics.history.length = 100;
    }

    return created;
  }

  function tickActiveDynamics(state) {
    ensureDynamics(state);
    if (!state.companyDynamics.active.length) return;

    var ticksPerDay = getTicksPerDay();
    for (var i = 0; i < state.companyDynamics.active.length; i++) {
      var evt = state.companyDynamics.active[i];
      evt.remainingTicks = Math.max(0, numberOr(evt.remainingTicks, 0) - 1);
      evt.remainingDays = Math.max(0, Math.ceil(numberOr(evt.remainingTicks, 0) / ticksPerDay));
      if (evt.remainingTicks <= 0) evt.finished = true;
    }
  }

  function cleanupExpiredDynamics(state) {
    ensureDynamics(state);
    if (!state.companyDynamics.active.length) return;

    state.companyDynamics.active = state.companyDynamics.active.filter(isLiveDynamic);
  }

  function getEventDecay(evt) {
    var total = Math.max(1, Number(evt && evt.totalTicks || 1));
    var remaining = clamp(numberOr(evt && evt.remainingTicks, 0), 0, total);
    var progress = remaining / total;
    return clamp(0.35 + progress * 0.65, 0.20, 1.0);
  }

  function getCombinedEffectForAsset(state, assetId) {
    ensureDynamics(state);

    var bias = 0;
    var volatilityBonus = 0;

    for (var i = 0; i < state.companyDynamics.active.length; i++) {
      var evt = state.companyDynamics.active[i];
      if (evt.target !== assetId) continue;
      var decay = getEventDecay(evt);
      bias += Number(evt.bias || 0) * decay;
      volatilityBonus += Number(evt.volatilityBonus || 0) * decay;
    }

    return {
      bias: clamp(bias, -0.12, 0.12),
      volatilityBonus: clamp(volatilityBonus, 0, 0.03)
    };
  }

  function getCombinedMetaForAsset(state, assetId) {
    ensureDynamics(state);

    var out = {
      liquidityShift: 0,
      npcPanicSellBoost: 0,
      npcFomoBuyBoost: 0,
      strategicHoldingReleaseBoost: 0,
      npcAbsorbBoost: 0,
      shortPressureBoost: 0,
      confidenceImpact: 0,
      revenueAdjust: 0,
      profitAdjust: 0,
      payoutAdjust: 0
    };

    for (var i = 0; i < state.companyDynamics.active.length; i++) {
      var evt = state.companyDynamics.active[i];
      if (evt.target !== assetId) continue;

      var meta = evt.meta || {};
      var decay = getEventDecay(evt);
      out.liquidityShift += Number(meta.liquidityShift || 0) * decay;
      out.npcPanicSellBoost += Number(meta.npcPanicSellBoost || 0) * decay;
      out.npcFomoBuyBoost += Number(meta.npcFomoBuyBoost || 0) * decay;
      out.strategicHoldingReleaseBoost += Number(meta.strategicHoldingReleaseBoost || 0) * decay;
      out.npcAbsorbBoost += Number(meta.npcAbsorbBoost || 0) * decay;
      out.shortPressureBoost += Number(meta.shortPressureBoost || 0) * decay;
      out.confidenceImpact += Number(meta.confidenceImpact || 0) * decay;
      out.revenueAdjust += Number(meta.revenueAdjust || 0) * decay;
      out.profitAdjust += Number(meta.profitAdjust || 0) * decay;
      out.payoutAdjust += Number(meta.payoutAdjust || 0) * decay;
    }

    out.liquidityShift = clamp(out.liquidityShift, -0.40, 0.40);
    out.npcPanicSellBoost = clamp(out.npcPanicSellBoost, 0, 2.0);
    out.npcFomoBuyBoost = clamp(out.npcFomoBuyBoost, 0, 2.0);
    out.strategicHoldingReleaseBoost = clamp(out.strategicHoldingReleaseBoost, 0, 1.5);
    out.npcAbsorbBoost = clamp(out.npcAbsorbBoost, 0, 1.5);
    out.shortPressureBoost = clamp(out.shortPressureBoost, -1.5, 2.0);
    out.confidenceImpact = clamp(out.confidenceImpact, -1.0, 1.0);
    out.revenueAdjust = clamp(out.revenueAdjust, -0.40, 0.40);
    out.profitAdjust = clamp(out.profitAdjust, -0.50, 0.50);
    out.payoutAdjust = clamp(out.payoutAdjust, -0.30, 0.30);

    return out;
  }

  function getActiveDynamics(state) {
    ensureDynamics(state);
    return state.companyDynamics.active || [];
  }

  function getHistory(state) {
    ensureDynamics(state);
    return state.companyDynamics.history || [];
  }

  w.StockMarketCompanyDynamics = {
    ensureDynamics: ensureDynamics,
    prepareDailyQuota: prepareDailyQuota,
    maybeGenerateDailyDynamics: maybeGenerateDailyDynamics,
    maybeGenerateDailyDecisions: maybeGenerateDailyDecisions,
    tickActiveDynamics: tickActiveDynamics,
    tickDecisions: tickDecisions,
    cleanupExpiredDynamics: cleanupExpiredDynamics,
    getCombinedEffectForAsset: getCombinedEffectForAsset,
    getCombinedMetaForAsset: getCombinedMetaForAsset,
    getActiveDynamics: getActiveDynamics,
    getPendingDecisions: getPendingDecisions,
    voteOnDecision: voteOnDecision,
    getHistory: getHistory,
    LEVEL_DEFS: LEVEL_DEFS,
    getLevelLabel: getLevelLabel,
    getTicksPerDay: getTicksPerDay
  };
})(window);
