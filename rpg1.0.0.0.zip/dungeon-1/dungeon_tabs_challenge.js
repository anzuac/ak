// dungeon_tabs_challenge_scoped.js — 挑戰分頁（每分頁自管票券：資源票；改用 SaveHub 中控存檔）
(function () {
  if (!window.DungeonHub) return;

  var LV   = window.LevelConfig;
  var DUNS = window.WaveDungeonDefs || [];
  var U    = window.WaveDungeonUtils;
  var GATE = window.DungeonGate || null; // ← 比照 v13：取得副本門控制
  var SH   = window.SaveHub || null;
  if (!SH){
    console.error("[dungeon_tabs_challenge] 缺少 SaveHub");
    return;
  }

  // ===== 票券（本分頁自管：資源票；改用 SaveHub）=====
  (function () {
    var CFG = {
      NAME: "資源票（免費）",
      ITEM_NAME: "資源票",
      PERIOD_MS: 300 * 60 * 1000,
      DEFAULT_CAP: 10,
      EXPAND_COST_GEM: 500,
      EXPAND_DELTA: 5,
      GIFT_ON_EXPAND: 1
    };

    var NS_TICKET   = "dungeon.challenge.ticket";
    var NS_PROGRESS = "dungeon.challenge.progress";

    SH.registerNamespaces({
      "dungeon.challenge.ticket": {
        version: 1,
        migrate: function (o) {
          o = o || {};
          if (typeof o.cap !== "number")    o.cap    = CFG.DEFAULT_CAP;
          if (typeof o.count !== "number")  o.count  = 0;
          if (typeof o.lastTs !== "number") o.lastTs = 0;
          o.cap    = Math.max(1, o.cap|0);
          o.count  = Math.max(0, Math.min(o.count|0, o.cap));
          o.lastTs = Math.max(0, o.lastTs|0);
          return o;
        }
      },
      "dungeon.challenge.progress": {
        version: 1,
        migrate: function (o) {
          return o || {};
        }
      }
    });

    var st = { count: 0, cap: CFG.DEFAULT_CAP, lastTs: 0 };

    function now(){ return Date.now(); }

    function save(){
      try{
        SH.set(NS_TICKET, {
          count:  st.count|0,
          cap:    st.cap|0,
          lastTs: Math.max(0, st.lastTs|0)
        }, { replace: true });
      }catch(_){}
    }

    (function load(){
      try{
        var o = SH.get(NS_TICKET);
        if (o && typeof o === "object") {
          st.cap    = Math.max(1, Number(o.cap) || CFG.DEFAULT_CAP);
          st.count  = Math.max(0, Math.min(Number(o.count) || 0, st.cap));
          st.lastTs = Math.max(0, Number(o.lastTs) || 0);
          if (st.lastTs > now()) st.lastTs = now();
          return;
        }
      }catch(_){}
      // 第一次半滿
      var half = Math.floor(st.cap / 2);
      st.count  = half;
      st.lastTs = now() - (CFG.PERIOD_MS * half);
      save();
    })();

    // 直接走你的背包 API（如果專案有）。若沒提供，安全返回不報錯。
    function bagCount(){
      try { return Math.max(0, Number(window.getItemQuantity?.(CFG.ITEM_NAME)) || 0); }
      catch(_) { return 0; }
    }
    function bagAdd(n){
      try { window.addItem?.(CFG.ITEM_NAME, Math.max(1, Number(n)||1)); }
      catch(_){}
    }
    function bagRemove(n){
      n = Math.max(1, Number(n)||1);
      if (bagCount() < n) return false;
      try { window.removeItem?.(CFG.ITEM_NAME, n); return true; }
      catch(_){ return false; }
    }

    function refill(){
      var changed = false;
      if (st.count >= st.cap){
        var t = now();
        if (st.lastTs !== t){ st.lastTs = t; changed = true; }
        if (changed) save();
        return;
      }
      var el = Math.max(0, now() - st.lastTs);
      if (el < CFG.PERIOD_MS) return;
      var add = Math.floor(el / CFG.PERIOD_MS);
      if (add > 0){
        var room = st.cap - st.count;
        var gain = Math.min(add, room);
        if (gain > 0){ st.count += gain; changed = true; }
        var aligned = now() - (el % CFG.PERIOD_MS);
        if (aligned !== st.lastTs){ st.lastTs = aligned; changed = true; }
      }
      if (changed) save();
    }

    window.ChallengeTicket = {
      getConfig: function () { return CFG; },
      get: function () {
        refill();
        return {
          free: { count: st.count, cap: st.cap, lastTs: st.lastTs },
          bag:  { count: bagCount() },
          total: st.count + bagCount()
        };
      },
      refill: refill,
      timeToNext: function () {
        refill();
        if (st.count >= st.cap) return 0;
        var el = Math.max(0, now() - st.lastTs);
        return CFG.PERIOD_MS - (el % CFG.PERIOD_MS);
      },
      canSpend: function (n) {
        n = Math.max(1, Number(n)||1);
        refill();
        return (st.count + bagCount()) >= n;
      },
      spend: function (n) {
        n = Math.max(1, Number(n)||1);
        refill();
        if ((st.count + bagCount()) < n) return false;
        var useFree = Math.min(n, st.count);
        st.count -= useFree;
        n -= useFree;
        if (n > 0 && !bagRemove(n)) { st.count += useFree; return false; }
        st.lastTs = now();
        save();
        return true;
      },
      addFree: function (n) {
        n = Math.max(0, Number(n)||0);
        if (!n) return;
        st.count = Math.min(st.cap, st.count + n);
        st.lastTs = now();
        save();
      },
      addToBag: function (n) { bagAdd(n || 1); },
      setCap: function (cap) {
        cap = Math.max(1, Number(cap)||1);
        st.cap = cap;
        if (st.count > st.cap) st.count = st.cap;
        save();
      },
      expand: function (times) {
        var t = Math.max(1, Number(times)||1);
        st.cap += (CFG.EXPAND_DELTA || 1) * t;
        if (st.count > st.cap) st.count = st.cap;
        var gift = (CFG.GIFT_ON_EXPAND || 0) * t;
        if (gift > 0) bagAdd(gift); // 贈票入你的背包
        save();
      },
      exportState: function () {
        return {
          ns: "challenge",
          config: CFG,
          state: {
            count: st.count|0,
            cap:   st.cap|0,
            lastTs: Math.max(0, st.lastTs|0)
          }
        };
      },
      applyState: function (s) {
        try{
          var o   = (s && s.state) || s || {};
          var cap = Math.max(1, Number(o.cap) || st.cap);
          var cnt = Math.max(0, Number(o.count) || 0);
          var ts  = Math.max(0, Number(o.lastTs) || 0);
          st.cap    = cap;
          st.count  = Math.min(cnt, cap);
          st.lastTs = (ts > now() ? now() : ts);
          save();
        }catch(e){ console.warn("[challenge tickets] applyState error:", e); }
      }
    };

    // ========= 進度存檔（各副本最高通關 Lv；改用 SaveHub）=========
    var PROG_NS = NS_PROGRESS;
    function loadProg(){
      try{
        var p = SH.get(PROG_NS);
        return p && typeof p === "object" ? p : {};
      }catch(_){
        return {};
      }
    }
    function saveProg(p){
      try{
        SH.set(PROG_NS, p || {}, { replace: true });
      }catch(_){}
    }
    function getMaxCleared(dId){
      var p   = loadProg();
      var rec = p[dId] || {};
      return Math.max(0, Number(rec.maxCleared || 0));
    }
    function setMaxCleared(dId, lv){
      var p   = loadProg();
      var rec = p[dId] || { maxCleared: 0 };
      if (lv > (rec.maxCleared || 0)){
        rec.maxCleared = lv;
        p[dId] = rec;
        saveProg(p);
      }
    }

    function fmtClock(ms){ var s=Math.floor(ms/1000), m=Math.floor(s/60), ss=s%60; return m+":"+String(ss).padStart(2,"0"); }

    function tryExpandCap(){
      var cfg = window.ChallengeTicket.getConfig(), need = cfg.EXPAND_COST_GEM;
      var have = Number(window.player?.gem || 0);
      if (have < need) { alert("需要 "+need+" 鑽石"); return; }
      var label = (cfg.ITEM_NAME || cfg.NAME);
      if (!confirm("花費 "+need+" 鑽石將上限 +"+cfg.EXPAND_DELTA+"，並贈送 "+cfg.GIFT_ON_EXPAND+" 張「"+label+"」\n是否確認？")) return;
      window.player.gem = Math.max(0, have - need);
      window.ChallengeTicket.expand(1);
      window.updateResourceUI?.();
      var nowT = window.ChallengeTicket.get();
      window.logPrepend?.("🧾 已擴充"+cfg.NAME+"上限至 "+nowT.free.cap+"，並獲得 "+cfg.GIFT_ON_EXPAND+" 張");
      window.DungeonHub.requestRerender();
    }

    function renderGotRewards(got){
      var rw = document.getElementById("dun-rewards");
      if (!rw) return;
      var lines = [];
      Object.keys(got || {}).forEach(function(k){
        var n = Number(got[k] || 0);
        if (n > 0) lines.push("<li>"+k+" × "+n.toLocaleString()+"</li>");
      });
      if (lines.length){
        rw.style.display = "block";
        rw.innerHTML = "獎勵：<ul>"+lines.join("")+"</ul>";
      }
    }

    function sweepGrant(dDef, level){
      var scaledView = U.scaledFinalRewardsForLevel(dDef.finalRewards, level);
      var got = {};
      Object.keys(scaledView || {}).forEach(function(k){
        var r = scaledView[k]; if (!r) return;
        var a = r[0], b = r[1];
        var roll = Math.floor(Math.random() * (b - a + 1)) + a;
        var qty  = Math.max(0, Math.floor(roll * 0.75));
        if (qty <= 0) return;
        got[k] = qty;

        if (k === "金幣" || k === "gold") {
          window.player.gold = (window.player.gold || 0) + qty;
        } else if (k === "強化石" || k === "stone") {
          window.player.stone = (window.player.stone || 0) + qty;
        } else {
          window.addItem?.(k, qty);
        }
      });
      window.updateResourceUI?.();
      return got;
    }

    function runGauntlet(dunDef, level, onAllFinish){
      var waves = U.buildWavesForLevel(dunDef.wavesTemplate, level);
      var total = waves.length;
      var idx = 0;

      var scaledView = U.scaledFinalRewardsForLevel(dunDef.finalRewards, level);
      var dispRewards = [];
      Object.keys(scaledView || {}).forEach(function(k){
        var r = scaledView[k]; if (!r) return;
        var unit = /碎片|石|券|票|符|令/.test(k) ? "個" : "";
        dispRewards.push({ type:"text", key: k + " " + U.formatRange(r, unit), qty: "" });
      });

      var rewarded = false;
      var hooks = {
        onRender: function(){
          var el = document.getElementById("dun-result");
          if (el) el.textContent = "波次："+(idx+1)+" / "+total;
        },
        onSwitchMonster: function(){
          var hd = document.querySelector("#dun-card .dun-hd > div:first-child");
          if (hd) hd.textContent = dunDef.name+" — "+waves[idx].label+"（Lv."+level+"）";
        },
        afterPlayerAct: function(args){
          var ctx=args.ctx;
          if (window.monsterHP <= 0 && idx < total - 1) {
            idx++;
            var next = waves[idx];
            ctx.api.setMonster(next.monster);
            ctx.api.log("➡️ 進入第 "+(idx+1)+"/"+total+" 波（"+next.label+"）");
          }
        },
        afterMonsterAct: function(args){
          var ctx=args.ctx;
          if (window.monsterHP <= 0 && idx < total - 1) {
            idx++;
            var next = waves[idx];
            ctx.api.setMonster(next.monster);
            ctx.api.log("➡️ 進入第 "+(idx+1)+"/"+total+" 波（"+next.label+"）");
          }
        },
        onResult: function(args){
          var state=args.state;
          if (state === "win" && !rewarded){
            rewarded = true;
            var got = U.grantFinalRewards(scaledView, dunDef.name+"（Lv."+level+"）");
            renderGotRewards(got);
            setMaxCleared(dunDef.id, level);
          }
        }
      };

      var finishUI = {
        isFinal: true,
        claimLabel: "領取獎勵",
        onClaim: function(){
          if (rewarded) return;
          rewarded = true;
          var got = U.grantFinalRewards(scaledView, dunDef.name+"（Lv."+level+"）");
          renderGotRewards(got);
          setMaxCleared(dunDef.id, level);
        }
      };

      var first = waves[0];
      window.DungeonBattle?.start({
        title: dunDef.name+" — "+first.label+"（Lv."+level+"）",
        monster: first.monster,
        timeLimitSec: dunDef.timeLimitSec || 0,
        rewards: dispRewards,
        hooks: hooks,
        finishUI: finishUI,
        onFinish: function(res){
          if (typeof onAllFinish === "function") onAllFinish(res.state);
        }
      });
    }

    function headerHTML(){
      window.ChallengeTicket.refill();
      var t = window.ChallengeTicket.get();
      var cfg = window.ChallengeTicket.getConfig();
      var left = window.ChallengeTicket.timeToNext();
      var leftTxt = (t.free.count >= t.free.cap) ? "已滿" : ("+"+fmtClock(left));
      var label = (cfg.ITEM_NAME || cfg.NAME);

      return [
        '<div style="border:1px solid #243247;background:#0b1220;border-radius:10px;padding:10px;display:flex;align-items:center;justify-content:space-between;gap:10px">',
          '<div style="font-size:12px;line-height:1.6">',
            '<div>',
              "<b>"+cfg.NAME+"</b>（免費）：<span style=\"font-weight:800\">"+t.free.count+"</span> / "+t.free.cap,
              '<span style="font-size:12px;opacity:.8;margin-left:6px;">（每 300 分復原 1）</span>',
              '<span style="margin-left:8px;opacity:.9;">下次回復：'+leftTxt+'</span>',
            '</div>',
            '<div>背包：<b>'+t.bag.count+'</b>　總計：<b>'+t.total+'</b></div>',
          '</div>',
          '<div style="display:flex;align-items:center;gap:10px">',
            '<button id="btnExpandTicket" style="padding:6px 10px;border:0;border-radius:8px;background:#6b21a8;color:#fff;cursor:pointer">',
              "擴充上限（-"+cfg.EXPAND_COST_GEM+"💎 / +"+cfg.EXPAND_DELTA+"）+ 贈"+cfg.GIFT_ON_EXPAND+"張"+label,
            '</button>',
          '</div>',
        '</div>'
      ].join("");
    }

    function ensureGateStopped(){
      if (GATE && typeof GATE.ensureStopped === "function") { return !!GATE.ensureStopped(); }
      if (window.autoEnabled){ alert("請先停止外部戰鬥再進入副本"); return false; }
      return true;
    }

    window.DungeonHub.registerTab({
      id: "challenge",
      title: "挑戰",
      render: function(container){
        window.ChallengeTicket.refill();

        container.innerHTML = [
          headerHTML(),
          '<div style="display:grid;gap:10px;margin-top:10px">',
            DUNS.map(function(d){
              var maxCleared = getMaxCleared(d.id);
              var nextLv = Math.min((maxCleared + 1), LV.MAX_LEVEL);
              var scaled = U.scaledFinalRewardsForLevel(d.finalRewards, nextLv);
              var rewardLines = [];
              Object.keys(scaled || {}).forEach(function(k){
                var r = scaled[k]; if (!r) return;
                var unit = /碎片|石|券|票|符|令/.test(k) ? "個" : "";
                rewardLines.push("・"+k+"："+U.formatRange(r, unit));
              });
              if (rewardLines.length === 0) rewardLines.push("・—");

              var waves = U.buildWavesForLevel(d.wavesTemplate, nextLv);
              var boss  = waves[waves.length-1].monster;
              var consumeLabel = (window.ChallengeTicket.getConfig().ITEM_NAME || window.ChallengeTicket.getConfig().NAME);

              var retryBtn = (maxCleared>0)
                ? '<button class="btn-ch-retry" data-id="'+d.id+'" data-level="'+maxCleared+'" style="padding:8px 12px;border:0;border-radius:8px;background:#4b5563;color:#fff;cursor:pointer">挑戰上次通關（Lv.'+maxCleared+'）</button>'
                : "";
              var sweepBtn = (maxCleared>0)
                ? '<button class="btn-ch-sweep" data-id="'+d.id+'" data-level="'+maxCleared+'" style="padding:8px 12px;border:0;border-radius:8px;background:#1f2937;color:#fff;cursor:pointer">掃蕩（以 Lv.'+maxCleared+' 計 / ×0.75）</button>'
                : "";

              return [
                '<div class="ch-card" data-id="'+d.id+'" style="border:1px solid #2b344a;background:#0b1220;border-radius:10px;padding:10px">',
                  '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">',
                    '<div style="font-weight:800">'+d.name+'</div>',
                    '<div class="ch-level" style="font-size:12px;">最高通關：<b>'+maxCleared+'</b> / '+LV.MAX_LEVEL+'　下一關：<b>Lv.'+nextLv+'</b></div>',
                  '</div>',
                  '<div style="opacity:.9;font-size:12px;margin:6px 0 8px">'+(d.desc || "")+'</div>',
                  '<div style="font-size:12px;opacity:.95;line-height:1.8">',
                    '<div>最終波敵人能力（以下一關預覽）：</div>',
                    '<div>・攻擊力：'+((boss.atk||1).toLocaleString())+'</div>',
                    '<div>・防禦力：'+((boss.def||0).toLocaleString())+'</div>',
                    '<div>・生命值：'+((boss.hp||1).toLocaleString())+'</div>',
                  '</div>',
                  '<div style="font-size:12px;opacity:.95;line-height:1.8;margin-top:6px">',
                    '<div>最終獎勵（以下一關預覽）</div>',
                    rewardLines.join("<br>"),
                  '</div>',
                  '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px">',
                    '<button class="btn-ch-start" data-id="'+d.id+'" data-level="'+nextLv+'" style="padding:8px 12px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer">',
                      "挑戰下一關（消耗："+consumeLabel+" ×1）",
                    '</button>',
                    retryBtn,
                    sweepBtn,
                  '</div>',
                '</div>'
              ].join("");
            }).join(""),
          '</div>'
        ].join("");

        var exBtn = container.querySelector("#btnExpandTicket");
        if (exBtn) exBtn.onclick = tryExpandCap;

        function rerender(){ window.DungeonHub.requestRerender(); }

        container.querySelectorAll(".btn-ch-start").forEach(function(btn){
          btn.onclick = function(){
            if (!ensureGateStopped()) return;

            var id = this.getAttribute("data-id");
            var level = Number(this.getAttribute("data-level"));
            var d  = DUNS.find(function(x){ return x.id===id; });
            if (!d) return;

            window.ChallengeTicket.refill();
            if (!window.ChallengeTicket.canSpend(1)) {
              var needLabel = (window.ChallengeTicket.getConfig().ITEM_NAME || window.ChallengeTicket.getConfig().NAME);
              alert("需要 "+needLabel+" ×1"); return;
            }

            window.DungeonHub.close();
            runGauntlet(d, level, function(state){
              if (state === "win") {
                window.ChallengeTicket.spend(1);
                setMaxCleared(d.id, level);
                window.saveGame?.();
                rerender();
              }
            });
          };
        });

        container.querySelectorAll(".btn-ch-retry").forEach(function(btn){
          btn.onclick = function(){
            if (!ensureGateStopped()) return;

            var id = this.getAttribute("data-id");
            var level = Number(this.getAttribute("data-level"));
            var d  = DUNS.find(function(x){ return x.id===id; });
            if (!d) return;

            if (!window.ChallengeTicket.canSpend(1)) {
              var needLabel = (window.ChallengeTicket.getConfig().ITEM_NAME || window.ChallengeTicket.getConfig().NAME);
              alert("需要 "+needLabel+" ×1"); return;
            }

            window.DungeonHub.close();
            runGauntlet(d, level, function(state){
              if (state === "win") {
                window.ChallengeTicket.spend(1);
                window.saveGame?.();
                rerender();
              }
            });
          };
        });

        container.querySelectorAll(".btn-ch-sweep").forEach(function(btn){
          btn.onclick = function(){
            var id = this.getAttribute("data-id");
            var level = Number(this.getAttribute("data-level"));
            var d  = DUNS.find(function(x){ return x.id===id; });
            if (!d) return;

            if (!window.ChallengeTicket.canSpend(1)) {
              var needLabel = (window.ChallengeTicket.getConfig().ITEM_NAME || window.ChallengeTicket.getConfig().NAME);
              alert("需要 "+needLabel+" ×1"); return;
            }

            var got = sweepGrant(d, level);
            window.ChallengeTicket.spend(1);
            window.saveGame?.();

            var parts = Object.keys(got||{}).map(function(k){ return k+"×"+got[k].toLocaleString(); });
            window.logPrepend?.("⏩ 掃蕩成功（挑戰 "+d.name+" Lv."+level+"）：獲得 "+(parts.join("、")||"—"));
            alert("掃蕩獲得：\n"+(parts.join("\n") || "—"));

            rerender();
          };
        });
      }
    });

  })();
})();