// =====================================================
// IWGUILD AUTO LOADER
// ES5 Sequential Script Loader
// =====================================================

(function () {

    // =====================================================
    // Global Namespace
    // =====================================================

    window.IWGUILD = window.IWGUILD || {};



    // =====================================================
    // Script Loader
    // =====================================================

    function loadScript(src, callback) {

        var script = document.createElement('script');

        script.src = src;

        script.async = false;

        script.onload = function () {

            console.log('[IWGUILD Loaded] ' + src);

            if (callback) {
                callback();
            }
        };

        script.onerror = function () {

            console.error('[IWGUILD Load Failed] ' + src);

        };

        document.head.appendChild(script);
    }



    // =====================================================
    // Load Order
    // ES5 順序非常重要
    // =====================================================

var LOAD_ORDER = [

    // 中央控制
    'iwguild/control/stock_market_central_control.js',

    // 市場核心
    'iwguild/market/data/stock_market_assets.js',
    'iwguild/market/data/stock_market_currency.js',
    'iwguild/market/core/stock_market_climate.js',
    'iwguild/market/event/stock_market_events.js',
    'iwguild/market/company/stock_market_company_dynamics.js',

    // ETF
    'iwguild/etfv2/core/etf_config_registry.js',
    'iwguild/etfv2/behavior/etf_behavior_registry.js',
    'iwguild/etfv2/core/universal_etf_core.js',
    'iwguild/etfv2/rebalance/etf_rebalance_engine.js',
    'iwguild/etfv2/engine/etf_nav_engine.js',
    'iwguild/etfv2/engine/etf_market_engine.js',
    'iwguild/etfv2/engine/etf_dividend_engine.js',
    'iwguild/etfv2/engine/etf_announcement_engine.js',
    'iwguild/etfv2/tab/etf_ui_adapter.js',
    'iwguild/etfv2/engine/etf_capital_flow_engine.js',
    'iwguild/etfv2/core/etfv2_bootstrap.js',
'iwguild/etfv2/core/passive_etf_engine.js',
'iwguild/etfv2/core/mad_dog_core.js',
'iwguild/etfv2/ui/mad_dog/mad_dog_state.js',
'iwguild/etfv2/ui/mad_dog/mad_dog_render.js',


    // 公司/商會
    'iwguild/market/data/stock_market_company_templates.js',
    'iwguild/market/core/stock_market_name_generator.js',
    'iwguild/market/data/stock_market_registry.js',

    // 股票市場核心
    'iwguild/market/core/stock_market_engine.js',
    'iwguild/market/core/stock_state_manager.js',
    'iwguild/ai/foreign_capital_ai.js',

    // 顯示/世界
    'iwguild/market/core/stock_market_display.js',
    'iwguild/market/core/market_index_system.js',
    'iwguild/world/climate/world_climate_system.js',

    // Tabs
    'iwguild/market/tab/stock_overview_tab.js',
    'iwguild/market/tab/stock_exchange_tab.js',
    'iwguild/market/tab/stock_portfolio_tab.js',
    'iwguild/market/tab/stock_market_info_tab.js',
    'iwguild/market/tab/stock_finance_tab.js',
    'iwguild/market/tab/stock_dynamics_tab.js',
    'iwguild/market/tab/stock_dividend_shop_tab.js',
    'iwguild/world/news/world_news_tab.js',

    // ETF UI 最後
    'iwguild/etfv2/tab/stock_etf_tab.js',
    'iwguild/etfv2/ui/mad_dog/mad_dog_tab.js'
];



    // =====================================================
    // Sequential Loader
    // =====================================================

    function loadSequentially(index) {

        if (index >= LOAD_ORDER.length) {

            console.log('====================================');
            console.log('IWGUILD ENGINE LOADED');
            console.log('====================================');

            return;
        }

        loadScript(LOAD_ORDER[index], function () {

            loadSequentially(index + 1);

        });
    }



    // =====================================================
    // Start Loading
    // =====================================================

    console.log('====================================');
    console.log('IWGUILD ENGINE START');
    console.log('====================================');

    loadSequentially(0);

})();

// ===============================================// =====================================================
// MAD DOG UI CSS
// =====================================================

(function(){

  function loadCSS(path){

    var link =
      document.createElement('link');

    link.rel = 'stylesheet';
    link.href = path;

    document.head.appendChild(link);
  }

  loadCSS(
    'iwguild/etfv2/ui/mad_dog/mad_dog_ui.css'
  );

  loadCSS(
    'iwguild/etfv2/ui/mad_dog/mad_dog_etf_ui.css'
  );

})();