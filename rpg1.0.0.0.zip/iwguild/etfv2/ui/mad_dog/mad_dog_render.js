// =====================================================
// mad_dog_render.js
// 王國戰略資本 V1.1.2
// 完整可覆蓋版：修正交易按鈕位置 / 防止右側溢出
// =====================================================

(function(w){
  "use strict";

  var currentSubTab = "holdings";
  var lastRoot = null;

  
  function formatMoney(value){

    if(value >= 1000000000000){
      return (value / 1000000000000).toFixed(2) + '兆';
    }

    if(value >= 100000000){
      return (value / 100000000).toFixed(2) + '億';
    }

    if(value >= 10000){
      return (value / 10000).toFixed(2) + '萬';
    }

    return Math.floor(value).toLocaleString();
  }


  function getMarketFlowText(d){

    var p = Number(d.marketPressure || 0);

    if(p >= 0.12){
      return '<span style="color:#facc15;">🔥 資金強力流入</span>';
    }

    if(p >= 0.03){
      return '<span style="color:#4ade80;">🟢 市場偏多</span>';
    }

    if(p <= -0.12){
      return '<span style="color:#ef4444;">⚠ 大量賣壓</span>';
    }

    if(p <= -0.03){
      return '<span style="color:#fb7185;">🔴 市場偏空</span>';
    }

    return '<span style="color:#cbd5e1;">⚖ 市場平穩</span>';
  }

function injectStyle(){

    if(document.getElementById("mad-dog-etf-style-v112")) return;

    var style = document.createElement("style");
    style.id = "mad-dog-etf-style-v112";

    style.textContent =
      ".mad-wrap,.mad-wrap *{box-sizing:border-box;}" +
      ".mad-wrap{width:100%;max-width:100%;overflow:hidden;padding:12px 14px 28px;color:#e5e7eb;font-family:sans-serif;}" +

      ".mad-card{width:100%;max-width:100%;background:#071225;border:1px solid rgba(148,163,184,.14);border-radius:16px;padding:13px;margin-bottom:10px;box-shadow:0 0 0 1px rgba(255,255,255,.02) inset;overflow:hidden;}" +
      ".mad-hero{width:100%;max-width:100%;background:linear-gradient(180deg,rgba(70,32,0,.86),rgba(5,12,28,.96));border:1px solid rgba(245,158,11,.35);border-radius:18px;padding:16px 15px 15px;text-align:left;margin-bottom:10px;overflow:hidden;}" +
      ".mad-title{font-size:17px;font-weight:1000;letter-spacing:.3px;margin-bottom:8px;color:#fef3c7;}" +
      ".mad-nav{font-size:52px;font-weight:1000;line-height:.98;margin-bottom:7px;color:#ffffff;}" +
      ".mad-change{font-size:16px;font-weight:1000;margin-bottom:7px;}" +
      ".mad-up{color:#4ade80;}.mad-down{color:#f87171;}" +
      ".mad-status{font-size:13px;font-weight:900;color:#facc15;margin-bottom:5px;}" +
      ".mad-tags{font-size:12px;line-height:1.5;color:#cbd5e1;opacity:.78;}" +

      ".mad-section-title{font-size:15px;font-weight:1000;margin-bottom:10px;color:#f8fafc;}" +

      ".mad-hold-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px;margin-bottom:8px;}" +
      ".mad-hold-box{background:#0b1830;border:1px solid rgba(148,163,184,.1);border-radius:13px;padding:10px;min-height:54px;min-width:0;}" +
      ".mad-hold-box.full{grid-column:1 / -1;}" +
      ".mad-label{font-size:11px;opacity:.64;font-weight:800;margin-bottom:5px;}" +
      ".mad-value{font-size:17px;font-weight:1000;color:#f8fafc;word-break:break-word;}" +

      ".mad-trade-wrap{width:100%;display:grid;grid-template-columns:minmax(0,1fr) 58px 58px;gap:7px;align-items:center;overflow:hidden;}" +
      ".mad-input{min-width:0;width:100%;height:40px;border-radius:11px;border:1px solid rgba(255,255,255,.08);background:#08162d;color:#fff;font-size:16px;font-weight:900;padding:0 11px;outline:none;}" +
      ".mad-btn{width:100%;min-width:0;height:40px;border-radius:11px;border:none;font-size:13px;font-weight:900;transition:.18s;padding:0;}" +
      ".mad-buy{background:rgba(40,120,70,.22);border:1px solid rgba(80,255,140,.18);color:#8fffaa;}" +
      ".mad-buy:hover{background:rgba(40,120,70,.35);}" +
      ".mad-sell{background:rgba(120,40,40,.22);border:1px solid rgba(255,90,90,.18);color:#ff9d9d;}" +
      ".mad-sell:hover{background:rgba(120,40,40,.35);}" +
      ".mad-note{font-size:11px;color:#94a3b8;opacity:.72;margin-top:8px;line-height:1.5;}" +

      ".mad-subtabs{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px;margin:10px 0;}" +
      ".mad-subtab{height:42px;border:none;border-radius:12px;background:#162033;color:#cbd5e1;font-size:14px;font-weight:1000;}" +
      ".mad-subtab.active{background:#7c3f0b;color:#fff3c4;box-shadow:0 0 0 1px rgba(251,191,36,.22) inset;}" +

      ".mad-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:9px;}" +
      ".mad-grid-card{background:#0b1830;border:1px solid rgba(148,163,184,.10);border-radius:13px;padding:11px;min-height:68px;min-width:0;}" +
      ".mad-grid-label{font-size:11px;opacity:.64;font-weight:800;margin-bottom:6px;}" +
      ".mad-grid-value{font-size:16px;font-weight:1000;color:#f8fafc;word-break:break-word;}" +

      ".mad-holding-row{padding:14px 2px;border-bottom:1px solid rgba(255,255,255,.06);}" +
      ".mad-holding-row:last-child{border-bottom:none;}" +
      ".mad-holding-top{display:flex;justify-content:space-between;align-items:center;gap:10px;}" +
      ".mad-holding-name{font-size:16px;font-weight:900;color:#fff;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}" +
      ".mad-holding-weight{font-size:17px;font-weight:1000;color:#67ff9a;white-space:nowrap;}" +
      ".mad-holding-bottom{margin-top:6px;display:flex;justify-content:space-between;align-items:center;gap:10px;}" +
      ".mad-holding-shares{font-size:13px;color:rgba(255,255,255,.58);}" +
      ".mad-holding-action{font-size:14px;font-weight:900;display:flex;align-items:center;gap:6px;white-space:nowrap;}" +
      ".mad-holding-action span{font-size:12px;opacity:.92;}" +
      ".mad-holding-action.build{color:#7dff8a;}" +
      ".mad-holding-action.add{color:#39ff88;}" +
      ".mad-holding-action.reduce{color:#ff7b7b;}" +
      ".mad-holding-action.neutral{color:#c7ccd6;}" +
      ".mad-empty{opacity:.68;text-align:center;padding:18px 0;font-size:13px;}";

    document.head.appendChild(style);
  }

  function num(v,d){
    v = Number(v);
    return isFinite(v) ? v : (d || 0);
  }

  function esc(v){
    return String(v == null ? "" : v)
      .replace(/&/g,"&amp;")
      .replace(/</g,"&lt;")
      .replace(/>/g,"&gt;");
  }

  function fmt(v){
    return Math.floor(num(v,0)).toLocaleString();
  }

  function scale(){
    return (w.MadDogETFState && w.MadDogETFState.getScale)
      ? w.MadDogETFState.getScale()
      : 1000;
  }

  function milli(v){
    return num(v,0) / scale();
  }

  function price(v){
    return num(v,0).toFixed(3);
  }

  function getData(){
    if(!w.MadDogETFState || !w.MadDogETFState.getUIData){
      return null;
    }
    return w.MadDogETFState.getUIData();
  }

  function miniBox(label, value, cls){
    return '<div class="mad-hold-box ' + (cls || '') + '">' +
      '<div class="mad-label">' + esc(label) + '</div>' +
      '<div class="mad-value">' + esc(value) + '</div>' +
    '</div>';
  }

  function signedMoney(v){
    var n = num(v,0);
    var sign = n > 0 ? '+' : (n < 0 ? '-' : '');
    return sign + formatMoney(Math.abs(milli(n)));
  }

  function signedPct(v){
    var n = num(v,0);
    var sign = n > 0 ? '+' : '';
    return sign + n.toFixed(2) + '%';
  }


  function tab(id, title){
    return '<button class="mad-subtab ' +
      (currentSubTab === id ? 'active' : '') +
      '" data-md-tab="' + id + '">' +
      esc(title) +
    '</button>';
  }

  function render(root){
    injectStyle();
    lastRoot = root;

    var d = getData();

    if(!d){
      root.innerHTML =
        '<div class="mad-wrap"><div class="mad-card">王國戰略資本資料尚未載入。</div></div>';
      return;
    }

    var nav = num(d.nav,10);
    var marketPrice = num(
      d.marketPrice,
      d.currentPriceMilli ? milli(d.currentPriceMilli) : nav
    );
    var diffMilli = num(d.diffMilli,0);
    var diff = milli(diffMilli);
    var pct = num(d.diffPercent,0);
    var isUp = diffMilli >= 0;

    var holdingQty = num(d.holdingQty,0);
    var avgCost = num(d.holdingAvgCostMilli,0);
    var investmentValue = num(d.investmentValueMilli, holdingQty * num(d.currentPriceMilli || d.marketPriceMilli || 0,0));
    var unrealized = num(d.unrealizedPnlMilli,0);
    var unrealizedPct = num(d.unrealizedPnlPercent,0);
    var realized = num(d.realizedPnlMilli,0);
    var feesPaid = num(d.feesPaidMilli,0);
    var totalShares = num(d.totalShares || d.totalUnits,0);
    var maxUnits = num(d.playerMaxUnits, Math.floor(totalShares * 0.001));
    var remain = num(d.playerRemainingUnits, Math.max(0, maxUnits - holdingQty));

    root.innerHTML =
      '<div class="mad-wrap">' +

        '<div class="mad-hero">' +
          '<div class="mad-title">⚔ 王國戰略資本</div>' +
          '<div class="mad-nav">' + price(marketPrice) + '</div>' +
          '<div class="mad-change ' + (isUp ? 'mad-up' : 'mad-down') + '">' +
            (isUp ? '▲ ' : '▼ ') +
            Math.abs(diff).toFixed(3) +
            ' (' + pct.toFixed(2) + '%)' +
          '</div>' +
          '<div class="mad-status">' + (d.listed ? '● BERSERK ACTIVE' : '● 建倉中') + '</div>' +
          '<div style="margin-top:6px;font-size:11px;font-weight:900;opacity:.92;">' + getMarketFlowText(d) + '</div>' +
          '<div class="mad-tags">高股利輪動 ｜ 高頻換倉 ｜ 極端資本策略 ｜ 不配息</div>' +
        '</div>' +

        '<div class="mad-card">' +
          '<div class="mad-section-title">📦 你的持有</div>' +
          '<div class="mad-hold-grid">' +
miniBox('持有份額', Number(holdingQty || 0).toFixed(0)) +

miniBox(
  '均價',
  avgCost > 0
    ? Number(milli(avgCost)).toFixed(3)
    : '0.000'
) +

miniBox(
  '投資市值',
  Number(milli(investmentValue || 0)).toFixed(3)
) +

miniBox(
  '未實現損益',
  Number(milli(unrealized || 0)).toFixed(3) +
  ' / ' +
  Number(unrealizedPct || 0).toFixed(3) +
  '%'
) +

miniBox(
  '累計已實現',
  Number(milli(realized || 0)).toFixed(3)
) +

miniBox(
  '累計手續費',
  Number(milli(feesPaid || 0)).toFixed(3)
) +

miniBox(
  '總發行份額',
  Number(totalShares || 0).toFixed(0),
  'full'
) +

miniBox(
  '購買上限 (0.3%)',
  Number(maxUnits || 0).toFixed(0)
) +

miniBox(
  '尚可買入',
  Number(remain || 0).toFixed(0)
) +
          '</div>' +
        '</div>' +

        '<div class="mad-card">' +
          '<div class="mad-section-title">🧾 ETF交易</div>' +
          '<div class="mad-trade-wrap">' +
            '<input id="madDogTradeQty" class="mad-input" type="number" min="1" value="1">' +
            '<button class="mad-btn mad-buy" data-md-action="buy">買入</button>' +
            '<button class="mad-btn mad-sell" data-md-action="sell">賣出</button>' +
          '</div>' +
          '<div class="mad-note">建倉期間無法買入；上市後可正常買入 / 賣出。</div>' +
        '</div>' +

        '<div class="mad-subtabs">' +
          tab('holdings','基金持倉') +
          tab('status','基金狀態') +
        '</div>' +

        renderBottom(d) +

      '</div>';

    bind(root);
  }

  function renderBottom(d){
    if(!currentSubTab) return '';
    if(currentSubTab === 'status') return renderStatus(d);
    return renderHoldings(d);
  }

  function renderHoldings(d){
    var list = d.holdings || [];

    if(!list.length){
      return '<div class="mad-card"><div class="mad-empty">目前尚未建倉</div></div>';
    }

    var html = '<div class="mad-card">';

    for(var i = 0; i < list.length; i++){
      var h = list[i] || {};
      var oldShares = num(h.oldSharesHeld, h.sharesHeld);
      var shares = num(h.sharesHeld,0);
      var delta = shares - oldShares;

      var weight = num(h.weight,0);
      if(weight <= 1) weight *= 100;

      var actionClass = 'neutral';
      var actionText = '觀察中';

      if(delta > 5000){
        actionClass = 'add';
        actionText = '強力加倉';
      }else if(delta > 1000){
        actionClass = 'build';
        actionText = '加倉中';
      }else if(delta > 0){
        actionClass = 'build';
        actionText = '建倉中';
      }else if(delta < -3000){
        actionClass = 'reduce';
        actionText = '大幅減倉';
      }else if(delta < 0){
        actionClass = 'reduce';
        actionText = '減倉中';
      }

      html +=
        '<div class="mad-holding-row">' +
          '<div class="mad-holding-top">' +
            '<div class="mad-holding-name">#' + (i + 1) + ' ' +
              esc(h.name || h.symbol || h.assetId) +
            '</div>' +
            '<div class="mad-holding-weight">' + weight.toFixed(2) + '%</div>' +
          '</div>' +
          '<div class="mad-holding-bottom">' +
            '<div class="mad-holding-shares">' + fmt(shares) + ' 股</div>' +
            '<div class="mad-holding-action ' + actionClass + '">' +
              (delta >= 0 ? '+' : '-') + fmt(Math.abs(delta)) +
              '<span>' + actionText + '</span>' +
            '</div>' +
          '</div>' +
        '</div>';
    }

    html += '</div>';
    return html;
  }

  function renderStatus(d){
    return '<div class="mad-card">' +
      '<div class="mad-grid">' +
        statusCard('基金總資產', formatMoney(milli(d.totalAssetValueMilli))) +
        statusCard('現金餘額', formatMoney(milli(d.cashReserveMilli))) +
        statusCard('股票持倉', formatMoney(milli(d.stockAssetValueMilli))) +
        statusCard('建倉數量', fmt((d.holdings || []).length)) +
        statusCard('基金份額', fmt(d.totalShares || d.totalUnits)) +
        statusCard('累計分割', (d.splitCount ? (fmt(d.splitCount) + ' 次 / 累計 ' + fmt(d.totalSplitRatio || 1) + 'x') : '尚未分割')) +
        statusCard('最近分割', d.lastSplitRatio && d.lastSplitRatio > 1 ? ('1 拆 ' + fmt(d.lastSplitRatio)) : '無') +
        statusCard('基金淨值 NAV', price(d.nav)) +
        statusCard('經理人個性', 'BERSERK') +
        statusCard('作風', '極速輪動') +
      '</div>' +
    '</div>';
  }

  function statusCard(label, value){
    return '<div class="mad-grid-card">' +
      '<div class="mad-grid-label">' + esc(label) + '</div>' +
      '<div class="mad-grid-value">' + esc(value) + '</div>' +
    '</div>';
  }

  function getQty(root){
    var input = root.querySelector('#madDogTradeQty');
    var qty = input ? parseInt(input.value,10) : 1;
    if(!isFinite(qty) || qty <= 0) qty = 1;
    return qty;
  }

  function getPlayerCoins(){
    var state = (w.StockStateManager && w.StockStateManager.getState)
      ? w.StockStateManager.getState()
      : null;

    if(state && state.player){
      return num(
        state.player.coin ||
        state.player.coins ||
        state.player.money ||
        state.player.gold ||
        0,
        0
      );
    }

    if(w.Player){
      return num(
        w.Player.coin ||
        w.Player.coins ||
        w.Player.money ||
        w.Player.gold ||
        0,
        0
      );
    }

    return null;
  }

  function handleBuy(qty){
    var d = getData();

    if(!d){
      return { ok:false, reason:'no_state' };
    }

    if(!d.listed){
      return { ok:false, reason:'fund_building_locked' };
    }

    var coins = getPlayerCoins();

    if(coins !== null){
      var cost = num(d.marketPrice || d.nav, 0) * qty;

      if(coins < cost){
        return { ok:false, reason:'money_not_enough' };
      }
    }

    return w.MadDogETFState.buy(qty);
  }

  function alertResult(res){
    if(!res || res.ok) return;

    var map = {
      no_state: '市場資料尚未載入。',
      no_fund: '基金尚未建立。',
      fund_building: '建倉中無法購買。',
      fund_building_locked: '建倉中無法購買。',
      holding_not_enough: '持有份額不足。',
      etf_holding_limit: '超過持有上限。',
      money_not_enough: '金額不足。',
      coin_not_enough: '金額不足。',
      universal_etf_missing: 'ETF核心尚未載入。'
    };

    alert(map[res.reason] || ('交易失敗：' + res.reason));
  }

  function bind(root){
    var tabs = root.querySelectorAll('[data-md-tab]');

    for(var i = 0; i < tabs.length; i++){
      tabs[i].onclick = function(){
        var next = this.getAttribute('data-md-tab');

        if(currentSubTab === next){
          currentSubTab = null;
        }else{
          currentSubTab = next;
        }

        render(root);
      };
    }

    var actions = root.querySelectorAll('[data-md-action]');

    for(var j = 0; j < actions.length; j++){
      actions[j].onclick = function(){
        var qty = getQty(root);
        var act = this.getAttribute('data-md-action');
        var res;

        if(act === 'buy'){
          res = handleBuy(qty);
        }else{
          res = w.MadDogETFState.sell(qty);
        }

        alertResult(res);
        render(root);
      };
    }
  }

  function update(root){

    var active = document.activeElement;

    // 使用者正在輸入交易數量時，避免整個 UI 重繪
    // 否則 input 會被銷毀重建，造成 focus 與輸入內容遺失
    if(
      active &&
      active.id === 'madDogTradeQty'
    ){
      return;
    }

    render(root);
  }

  function tick(){
    // UI tick 只允許初始化 / 讀資料，禁止推進市場。
    if(w.MadDogETFState && w.MadDogETFState.ensureFund){
      w.MadDogETFState.ensureFund();
    }
  }

  w.MadDogRender = {
    render: render,
    update: update,
    tick: tick
  };

})(window);
